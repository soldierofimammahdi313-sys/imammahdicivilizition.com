# Phase 1 — Backup & Stability

No routes, pages, content, database data, or features change. Only rendering-timing fixes plus two backup steps you perform in the Lovable UI.

## 1. GitHub sync (your action, one time)

I cannot create the repo from here. In the editor: the **+** menu (bottom-left of chat) → **GitHub** → **Connect project** → authorize → choose the account/org → **Create Repository**. After that the sync is two-way and automatic; every change I make is pushed for you.

## 2. Database export (your action, one time)

**Cloud → Advanced settings → Export data**. That produces a downloadable copy of all tables (profiles, articles, user_xp, daily_task_progress, saved_items, team_applications, ai_conversations, ai_messages, article_categories). There is no self-serve import, so keep the file safe. If you also want a per-table CSV of anything specific, tell me the table and I can export it.

## 3. Hydration mismatch fixes (code)

Currently the server renders one date/time and the browser renders another, so React throws a hydration error on every page load and re-renders the whole ticker tree. Root cause: date and clock values are computed during the very first render, where the server's timezone differs from the visitor's.

Fixes, all display-only:

- **DateTicker** — Hijri and Gregorian dates render as a stable placeholder on the server and fill in after hydration (the visible strip keeps identical height, so no layout jump). The prayer-times query key stops using a live `new Date()` so it doesn't change between server and client.
- **PrayerTimes (homepage)** — the ticking clock and countdown start after mount instead of during the first render; the "loading" state renders on the server exactly as it does on the client's first paint.
- **SiteFooter** — the copyright year is fixed at build/render time rather than recomputed per environment.
- **LiveTicker** — its `new Date()` day key moves out of render into the same post-hydration pattern.

## 4. Re-render / performance cleanups (code)

- The two ticker marquees use a single animation loop each and stop cleanly on unmount, so the scroll doesn't stack up or stutter after language switches.
- Memoize the ticker item lists so the once-a-minute clock tick doesn't rebuild every hadith/date node.
- Query stale times set so Quran/hadith/prayer fetches aren't repeated on each navigation.

## Verification

After the edits I load the site in a headless browser and confirm the console has zero hydration errors, then confirm every existing route still renders (spot-check home, quran, hadith, daily, academy-ai, dashboard).

## Technical notes

Files touched: `src/components/site/DateTicker.tsx`, `src/components/site/LiveTicker.tsx`, `src/components/site/PrayerTimes.tsx`, `src/components/site/SiteFooter.tsx`. Pattern used: `useHydrated()` from `@tanstack/react-router` / `useEffect`-deferred reads, plus `useMemo` on derived lists. No route files, no schema, no content edits.
