# Digital Observatory Homepage

## Goal
Transform the homepage entrance and module discovery into a cinematic, interactive “living civilization” while preserving every existing destination, section, language behavior, and mobile workflow.

## What will change
- Replace the current first screen with a full-bleed digital observatory in obsidian, moss green, emerald, and antique gold.
- Build a central 3D crystal node carrying “یا صاحب الزمان”; its light and facets will respond subtly to pointer movement, with touch-safe and reduced-motion fallbacks.
- Add slow rotating Girih star geometry, orbital rings, depth fog, and restrained cinematic entrance motion behind the content.
- Add edge telemetry showing live platform figures such as module count, Quran index, active systems, and research activity. Real database-backed values will be used where available; otherwise labels will clearly represent platform indexes rather than invented live users.
- Rework the command center/module discovery into floating glass panels sourced from the existing module registry, retaining every working link and status.
- Add a one-pixel animated gold “laser trace” around focused or hovered panels, with keyboard focus parity.
- Keep the remaining homepage sections intact, visually bridging the observatory into the current content rather than replacing site functionality.

## Mobile and accessibility
- Use a lighter scene and stable framing on phones so text and controls remain readable and fast.
- Preserve one semantic H1, keyboard navigation, visible focus states, screen-reader labels, and sufficient contrast.
- Respect reduced-motion preferences and provide a non-WebGL visual fallback.

## Technical approach
- Add React Three Fiber/Three.js for a client-only, decorative 3D layer; no external runtime assets or third-party scene downloads.
- Create focused components for the observatory scene, telemetry overlay, and spatial module deck rather than expanding the homepage file further.
- Generate Girih/crystal forms procedurally and keep the 3D canvas unframed, full-bleed, and pointer-efficient.
- Use the existing semantic color tokens and add only reusable observatory/glass tokens and animation utilities to the global design system.
- Drive module totals and panels from the existing module data so counts cannot drift.

## Verification
- Confirm the scene renders and moves in a real browser with no blank canvas, hydration warning, missing links, or console errors.
- Check desktop and mobile layouts, pointer interaction, keyboard focus, reduced-motion behavior, and readable telemetry.
- Run targeted type/build checks and confirm the current preview build is healthy.
