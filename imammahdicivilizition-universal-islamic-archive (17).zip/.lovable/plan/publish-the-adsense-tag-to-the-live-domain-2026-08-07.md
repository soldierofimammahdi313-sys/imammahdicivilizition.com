# Publish the AdSense tag to the live domain

## What I verified

- The AdSense tag is already correct in the app code and appears **exactly once** in the global `<head>`, server-rendered on every page. Confirmed in the current preview HTML: one `pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9467507763265762` script with `async` and `crossorigin="anonymous"`.
- The **live site does not have it yet**: the published HTML at `https://imammahdicivilizition.com/` contains zero AdSense references. The tag exists only in the unpublished preview build.
- Domain note: `imammahdicivilization.com` (the spelling in your message) does not resolve at all. The domain actually connected and serving the site is **imammahdicivilizition.com** (spelled "izition"), plus its `www` version.

## What to do

1. Publish the current build so the already-correct head tag reaches production. No code changes needed — design, features, and the publisher ID stay untouched.
2. After the deploy finishes, re-fetch the live domain and confirm the script appears exactly once in `<head>`, and that `/ads.txt` still serves the publisher line.
3. Report the verified result with the exact tag found live.

## Domain decision needed

If you intended the correctly spelled `imammahdicivilization.com` to be your site, that domain is not connected here and cannot serve anything today. Connecting it is a separate step (own the domain, then add it in Project settings > Domains with the DNS records shown there). Tell me if you want that included; otherwise I verify against the live `imammahdicivilizition.com`.

## Technical detail

- Tag source: `src/routes/__root.tsx` root `head().scripts`, values from `src/lib/adsense.ts` (`ADSENSE_PUBLISHER_ID = "ca-pub-9467507763265762"`, `ADS_ENABLED = true`).
- Because it renders through the route head, it is emitted server-side into `<head>` on every public page, with no duplicate client-side injection.