# Move the ticker date forward one day

## What is happening

The ticker reads the date from each visitor's own device clock and timezone. On a device sitting behind Pakistan time (for example a US timezone), it is still the previous calendar day there, so the ticker shows yesterday's Gregorian and Hijri date. Right now the ticker reads 06 Aug 2026 / 23 Safar 1448 while in Pakistan it is already 07 Aug 2026.

## The fix

1. Anchor both dates to a single reference timezone (Asia/Karachi, PKT) instead of the visitor's device. Every visitor then sees the same, correct Pakistan-local day, no matter where they are or how their device clock is set.
2. Set the Hijri adjustment to +1 day so the Islamic date matches the local South Asian moon-sighting calendar rather than the Umm al-Qura default (Umm al-Qura currently gives 23 Safar; local reckoning is 24 Safar).
3. Keep both values as named settings at the top of the file so the reference timezone and the Hijri +1/-1 nudge can be changed in one line later.
4. The date keeps refreshing on its existing timer, so it rolls over at Pakistan midnight.

Prayer times are unaffected — they stay based on the visitor's actual location.

## Technical notes

- `src/components/site/DateTicker.tsx`: add `DISPLAY_TIME_ZONE = "Asia/Karachi"`; derive the reference day via `Intl.DateTimeFormat` with that `timeZone` for both the Gregorian string and the Umm al-Qura Hijri parts; set `HIJRI_DATE_OFFSET_DAYS = 1`.
