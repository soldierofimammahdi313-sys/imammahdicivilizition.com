# Fix: Floating AI is not answering

## What I checked
- The floating widget and the `/ai` page both call the same chat endpoint, so one fix covers both.
- AI Gateway logs for this project show **no requests at all since 7 Aug** — recent attempts are failing before they ever reach the model.
- Workspace credits: the monthly and bonus grants are fully used (0 left); only the small daily allowance is available right now.
- The chat endpoint is pinned to a **preview build of a Gemini model** (`google/gemini-3-flash-preview`). Preview ids get retired, and a retired id is rejected outright — which matches the missing gateway requests.

Two things can each block an answer: the retired preview model, and an empty credit balance. Both need handling.

## The fix
1. **Move the chat to the current default model** (`openai/gpt-5.6-sol`) via the gateway's Responses API, with streaming, so the widget gets a real reply instead of a silent failure.
2. **Keep the Ja'fari system prompt and safety caps exactly as they are** — no change to the AI's voice or doctrine.
3. **Make every failure visible in the floating widget** — a retired/invalid model, rate limit, or network error each show a short readable message with a Retry button, instead of the panel sitting blank.
4. **Verify with a real message** from the floating widget and confirm a streamed answer appears.

## Technical notes
- `src/lib/ai-gateway.server.ts`: add a Responses-API provider (`createOpenAI` from `@ai-sdk/openai`, baseURL `https://ai.gateway.lovable.dev/v1`, `Lovable-API-Key` header) alongside the existing chat provider, plus the run-id fetch wrapper.
- `src/routes/api/chat.ts`: switch to `lovable.responses("openai/gpt-5.6-sol")` with `streamText` and `providerOptions.openai = { store: false }`. Keep `MAX_MESSAGES` / `MAX_TOTAL_CHARS` and the `onError` mapping to `AI_CREDITS_CODE` / `AI_RATE_LIMIT_CODE`; add a generic branch so unknown errors surface their message.
- `src/components/site/FloatingAi.tsx`: no structural change — `AiCreditsNotice` already renders `kind: "other"`; ensure the error clears on a new send and Retry re-sends the last user text.
- Verification: send a live message through the running app and read the streamed response plus the new gateway log entry.

## Note on credits
The monthly credit grant for this workspace is used up. Even after the code fix, replies are limited by the daily allowance until credits are topped up in Settings → Plans & credits.