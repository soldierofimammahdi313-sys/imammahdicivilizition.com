Homepage Connect Section — Social Icon Buttons

Goal
Replace the "YT, TT, X, IG, FB" text abbreviation buttons in the homepage footer "Connect" section with proper branded social-media icon buttons for YouTube, TikTok, X, Instagram, and Facebook.

What will change
1. `src/routes/index.tsx`
   - In the footer "Connect" column, swap the inline `SOCIALS` text links for icon buttons.
   - Each button will use the existing `SocialIcons` icon set from `src/components/site/SocialIcons.tsx` (YouTube, TikTok, X, Instagram, Facebook) so the visual is instantly recognizable.
   - Keep the current square button styling (border, hover:bg-gold, hover:text-primary-foreground) so it matches the existing premium design language.
   - Preserve `target="_blank"`, `rel="noreferrer"`, and `aria-label` for accessibility and SEO.

Out of scope
- No changes to social URLs or the `SocialIcons` component itself.
- No backend changes.
- No other pages or sections.
