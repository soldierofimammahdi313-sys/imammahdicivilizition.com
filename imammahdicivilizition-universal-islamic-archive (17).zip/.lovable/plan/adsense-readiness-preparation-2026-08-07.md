# AdSense-Readiness Preparation

No ads will be added, no publisher values invented, and no existing feature or Islamic content will be changed in meaning.

## What the audit found

- Every public route already has a title/description, but canonical and og:url across the site still point at the old `mahdi-civilization.lovable.app` address instead of the real domain. Same for robots.txt, the sitemap and the Organization schema.
- There is no **Contact**, **Disclaimer** or **Cookie Policy** page, and the footer has no legal column at all — these are the pages reviewers look for first.
- Breadcrumbs exist as a component but are used on only 2 pages.
- The sitemap is missing several live pages (Duas, 99 Names, Library, Flashcards, Journal, Citation, Maps, Family Tree) and does not include individual articles or Surah pages.
- An AdSense loader script and an `ads.txt` with your existing publisher ID are already in place from earlier work; these stay as-is, but the values move into one clearly documented config file instead of being hardcoded in the page shell.

## 1. Domain + SEO consistency

- Introduce a single `SITE_URL` constant (`https://imammahdicivilizition.com`) and use it for every canonical, `og:url`, breadcrumb schema and sitemap entry — replacing the ~20 hardcoded lovable.app strings.
- Verify each public page's title is unique and under 60 chars, description under 160.
- Add `og:type` and `twitter:card` where missing.
- Add **WebSite** schema with SearchAction (pointing at `/search`) and keep the existing Organization schema, updated to the real domain.
- Add **FAQPage** schema to the homepage FAQ section (existing questions only) and **BreadcrumbList** wherever breadcrumbs render. Article schema already exists on article pages.

## 2. Sitemap + robots

- Add the missing static routes to `sitemap.xml`, drop `/auth`, and generate entries for published articles and the Surah pages from the same source the routes use.
- Update the `robots.txt` sitemap line to the real domain, keep public pages crawlable, and disallow only account/admin paths (`/dashboard`, `/admin`, `/settings`, `/bookmarks`, `/history`).

## 3. Trust pages

New pages, written in the site's existing voice, factual only:

- `/contact` — email, WhatsApp/phone from the existing contact config, social links, and a simple message form saved to the backend.
- `/disclaimer` — religious-content disclaimer (AI output is not a fatwa, calculators are estimates, refer to your marjaʿ), third-party data sources, no financial or legal advice.
- `/cookies` — essential vs. analytics/advertising cookies and how to control them.
- Expand `/about` with mission, what the platform offers, who runs it, and an editorial/sourcing policy.
- Extend the Privacy Policy with an advertising/third-party-cookie section (generic; no ad network claimed as active yet).

The footer gains a **Legal** column linking About, Contact, Privacy, Terms, Disclaimer and Cookies.

## 4. Navigation

- Add breadcrumbs to the major content pages (Quran, Surah, Hadith, Duas, Articles, article detail, tools, academy, legal pages).
- Add a footer "More" column covering sections currently reachable only through the command centre, so every public page is two clicks from the homepage for a crawler.
- Keep the existing ⌘K search and `/search` page; link search from the footer.

## 5. Content quality pass

- Sweep every public route for placeholder copy, dead links, and loading states with no error/empty fallback; add proper empty and error states where a fetch can hang.
- Report thin pages rather than padding them — no invented religious content.

## 6. Performance and mobile

- `loading="lazy"` plus explicit width/height on non-hero images; preload the homepage hero with `fetchpriority="high"`.
- Trim the Google Fonts request to the weights actually used, keeping `display=swap`.
- Defer the ad loader script so it never blocks first paint.
- Responsive check of the main public pages at phone, tablet and desktop widths, fixing overflow and tap-target issues found.

## 7. AdSense configuration mechanism

Create `src/lib/adsense.ts` holding the publisher ID and an `ADS_ENABLED` flag in one place, with comments marking exactly where the verification meta tag goes and where ad slots would later be placed. No ad units rendered, no fake IDs. `ads.txt` keeps its current real line and gains a comment noting it must match the AdSense account exactly.

## 8. Security review

Read-only check plus fixes for anything found: RLS policies and grants on all public tables, admin route gating, input validation on the join/contact/discussion forms, and confirmation that no secret or service key is reachable from client code.

## 9. Final report

A written report in chat: what was fixed, what improved, which pages are ready, which need more original content, remaining issues, and the manual steps you must do inside AdSense and Search Console (site verification, ads.txt confirmation, domain review). No approval guarantees.

## Technical notes

Central `SITE_URL` in `src/lib/site.ts`; canonicals stay on leaf routes only (root keeps sitewide defaults). The contact form uses a new backend table with an insert-only public policy plus admin read, following the existing `team_applications` pattern.