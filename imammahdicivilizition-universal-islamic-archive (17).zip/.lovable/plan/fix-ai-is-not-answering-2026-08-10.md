# Fix: AI is not answering

## What's wrong
The AI chat endpoint rejects every request from a signed-out visitor. The server replies `401 Sign in required`, so the chat window (both the `/ai` page and the floating assistant) just sits there with no answer.

## The fix
Open the AI to everyone — no sign-in needed.

- Remove the sign-in requirement from the chat endpoint so any visitor gets a real streamed answer.
- Keep the existing safety caps (message count and total length) so a single request can't be abused.
- Signed-in users keep saved conversation history exactly as today; guests simply chat without history.
- Surface any real failure (rate limit, credits, network) as a visible error message in the chat instead of silence.

## Technical notes
- `src/routes/api/chat.ts`: drop the `requireUser` gate and its 401 branch; keep `MAX_MESSAGES` / `MAX_TOTAL_CHARS` validation and the Lovable AI Gateway streaming call.
- `src/lib/chat-transport.ts`: keep attaching the bearer token when a session exists (harmless, useful later), no change needed.
- `src/routes/ai.tsx` / `src/components/site/FloatingAi.tsx`: add an `onError` toast/inline error so failures are visible; history saving stays gated on a signed-in user.
- Verify by sending a real message as a signed-out visitor and confirming a streamed reply.
