# Fix Date Ticker + Expand Live Hadith Ticker

## 1. Date ticker showing a day behind

Both dates in the date ticker currently read one day earlier than the real date.

- Remove the hardcoded `-1` day shift applied to the Hijri date. That offset was subtracting a full day from every Hijri reading.
- Compute both the Hijri and Gregorian dates from the visitor's own local time instead of a UTC-based value, so users ahead of UTC no longer see yesterday.
- Add a configurable Hijri adjustment set to 0 by default (kept so the date can be nudged +1/-1 later for regional moon sighting, without touching the Gregorian date).
- Keep the ticker refreshing so it rolls over correctly at midnight.

## 2. Live ticker — sayings of the 14 Infallibles

Rebuild the fallback narration list so it covers all fourteen Infallibles, each with several complete narrations:

Prophet Muhammad (ﷺ), Sayyida Fatima al-Zahra (s.a), Imam Ali (a.s), Imam Hasan (a.s), Imam Husayn (a.s), Imam Zayn al-Abidin (a.s), Imam Muhammad al-Baqir (a.s), Imam Ja'far al-Sadiq (a.s), Imam Musa al-Kadhim (a.s), Imam Ali al-Rida (a.s), Imam Muhammad al-Jawad (a.s), Imam Ali al-Hadi (a.s), Imam Hasan al-Askari (a.s), Imam Mahdi (a.j).

Every entry will be written in full — complete Arabic text, complete English translation, the Infallible's name, and a real book reference with volume/page or hadith number. No truncated or partial narrations.

The ticker will also label each item with the Infallible's name so readers know who the saying belongs to.

## 3. AI daily hadith source

The daily AI-generated hadith set stays as the primary source. Its instructions will be tightened so it also returns complete Arabic + full English translation and rotates across all fourteen Infallibles rather than a few.

## Technical notes

- `src/components/site/DateTicker.tsx`: drop `HIJRI_DATE_OFFSET_DAYS = -1`, derive Hijri via `Intl` on the local date, format the Gregorian date with local components.
- `src/components/site/LiveTicker.tsx`: replace the `NARRATIONS` array with a grouped, fully-written set covering all 14 Infallibles.
- `src/lib/daily-hadiths.functions.ts`: prompt update for completeness and coverage across the 14.
