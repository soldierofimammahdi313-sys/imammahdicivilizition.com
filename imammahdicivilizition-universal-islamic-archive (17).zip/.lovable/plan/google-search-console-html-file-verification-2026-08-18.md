# Google Search Console HTML file verification

Add the uploaded verification file so Google can confirm ownership of imammahdicivilizition.com.

## What happens

- Place `google3cf0beab491d7aed.html` in the site's public folder so it is served at
  `https://imammahdicivilizition.com/google3cf0beab491d7aed.html` with the exact content
  `google-site-verification: google3cf0beab491d7aed.html`.
- Confirm it loads locally before handing off.
- Existing `<meta name="google-site-verification">` tags stay untouched — both methods can coexist.

## After the change

1. You publish the site so the file is live on the custom domain.
2. Then click Verify in Search Console (HTML file method).

## Technical detail

Single new static file: `public/google3cf0beab491d7aed.html` (copied verbatim from the upload).
No route, config, or build changes needed — files in `public/` are served at the site root.
