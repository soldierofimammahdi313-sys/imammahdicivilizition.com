Full rebrand to "Imam Mahdi Civilization" across the platform

## What we're changing
Replace the remaining legacy "Soldier of Imam Mahdi 313" / "313" branding with the full "Imam Mahdi Civilization" name across the site, page titles, metadata, i18n translations, and social links.

## Scope
- All route files under `src/routes/` that still use "313" in titles, descriptions, headings, or body text.
- Translation dictionary in `src/lib/i18n.tsx` (all 7 languages: en, ur, fa, ar, tr, fr, de).
- Static metadata and copy in `src/lib/site-index.ts`, `src/lib/modules.ts`, `src/lib/catalog.ts`, `src/lib/social-links.ts`.
- Any remaining components or footer/header copy that still shows the old brand.

## Plan
1. Audit all occurrences of "313" / "Soldier of Imam Mahdi 313" / "soldierofimammahdi313" / "313 Studio" / "313 Academy" / "Join 313" / "Vanguard of the 313" / "the 313" across the codebase and classify each as brand text vs. numeric concept to keep.
2. Update page titles and meta descriptions to use "Imam Mahdi Civilization" consistently (e.g., "Digital Library — Imam Mahdi Civilization" instead of "Digital Library — 313").
3. Replace old brand body text in route components, tool descriptions, hub cards, and CTAs with the new full name.
4. Update all 7 language translations in `src/lib/i18n.tsx` so phrases like "Join 313", "Vanguard of the 313", and "Every Gate of the 313" become "Join Imam Mahdi Civilization", "Vanguard of Imam Mahdi Civilization", and "Every Gate of Imam Mahdi Civilization".
5. Update `src/lib/social-links.ts` to the new social-media handles for YouTube, TikTok, X, Instagram, and Facebook once the new URLs are provided. If not provided in this turn, placeholder the change and flag it for the user.
6. Update `src/lib/catalog.ts`, `src/lib/site-index.ts`, and `src/lib/modules.ts` labels/descriptions to use the new brand name.
7. Run a final search to verify no stray "313" brand references remain, then run the TypeScript build check.

## Outcome
The site will read as one cohesive "Imam Mahdi Civilization" brand everywhere users see text, titles, translations, and shared links. I will list any remaining social URLs that need your new handles before I can update them.
