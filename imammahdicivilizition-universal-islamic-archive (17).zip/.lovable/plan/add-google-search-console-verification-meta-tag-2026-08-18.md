# Add Google Search Console verification meta tag

## Goal
Add the new Google Search Console verification tag

```html
<meta name="google-site-verification" content="XGZ08tgLwZVaAdWgxtbvPyU8Egys3g97j_kLrzxbj4U" />
```

so it renders on the home page (and every page) of `imammahdicivilizition.com`, alongside the existing `swS7BQ…` verification tag.

## Why a static tag, not another `meta` entry
TanStack's `HeadContent` deduplicates `<meta>` tags by `name` (`if (metaByAttribute[attribute]) continue` in `headContentUtils.cjs`). The root already declares `{ name: "google-site-verification", content: "swS7BQ…" }` in its `meta` array. Adding a second entry with the same `name` would be dropped — only one would ever render, breaking verification for whichever property loses.

Static `<meta>` elements placed directly in the document shell `<head>` are **not** processed by `HeadContent`, so they are immune to deduplication and always render.

## Change (single file: `src/routes/__root.tsx`)
In `RootShell`, add the new verification tag as a static element inside `<head>`, right after `<HeadContent />`:

```tsx
<head>
  <HeadContent />
  <meta name="google-site-verification" content="XGZ08tgLwZVaAdWgxtbvPyU8Egys3g97j_kLrzxbj4U" />
</head>
```

- The existing `swS7BQ…` entry stays in the `meta` array untouched (it still renders via `HeadContent`).
- Both tags now coexist on every route, including `/`.
- No other files change.

## Verification
1. Typecheck passes.
2. After the dev server picks up the edit, fetch `http://localhost:8080/` and grep the served HTML for `XGZ08tgLwZVaAdWgxtbvPyU8Egys3g97j_kLrzxbj4U` — it must be present, and `swS7BQaG` must still be present.
3. The user should publish so the live custom domain `https://imammahdicivilizition.com/` carries the new tag, then run verification in Google Search Console (or I can verify via the gateway once published).

## Note
The Search Console `index:inspect` / verify API cannot run a live test or force a re-crawl from here; final verification of the property must be triggered by the user in Search Console once the tag is live on the domain.
