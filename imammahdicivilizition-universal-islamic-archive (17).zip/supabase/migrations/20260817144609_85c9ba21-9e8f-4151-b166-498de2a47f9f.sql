
insert into public.articles (slug, title, excerpt, content, category_id, status, published_at, reading_minutes, tags, language) values
(
'what-is-islam-complete-introduction',
'What Is Islam? — Complete Introduction to Islam',
'A clear, sourced introduction to Islam: its meaning, core beliefs, practices and the major schools of interpretation.',
$md$Islam is the way of life built on submission to one God — *Allah* — and on the guidance He sent through prophets, completed in the message of Prophet Muhammad (ﷺ). The Arabic root *s-l-m* carries both "submission" and "peace": peace with the Creator produces peace within the self and with creation.

## The central claim

The whole of Islam condenses into one sentence: *La ilaha illa Allah, Muhammadun rasul Allah* — there is no deity except Allah, and Muhammad is His Messenger. Everything else — law, ethics, worship, spirituality — unfolds from that. The Qur'an states it plainly: "Say: He is Allah, One" (112:1).

## What a Muslim believes

- **Tawhid** — God is one, without partner, image or offspring.
- **Prophethood** — from Adam to Muhammad (ﷺ), God guided humanity through chosen messengers.
- **Revelation** — the Qur'an is God's final revealed speech, preserved in its Arabic text.
- **Accountability** — this life is a trust; the Hereafter is where the account is settled.

## What a Muslim does

Practice is anchored in the Five Pillars: testimony of faith, prayer, fasting Ramadan, zakat, and Hajj for those able. Around these sit the wider ethics of Islam — honesty, justice, mercy to parents, neighbours and the poor.

## One faith, several schools

Muslims agree on the Qur'an, the Prophet (ﷺ) and the pillars. They differ on questions of leadership after the Prophet and on methods of deriving law:

- **Sunni Islam** follows four legal schools (Hanafi, Maliki, Shafi'i, Hanbali) and accepts the caliphate of Abu Bakr, Umar, Uthman and Ali.
- **Shia Islam** (majority Ithna Ashari) holds that leadership passed by divine designation to Imam Ali and eleven Imams from his lineage, ending with Imam Mahdi.
- **Salafi/Wahhabi** currents are a Sunni reform movement rooted in Hanbali thought, stressing direct reliance on Qur'an and hadith and rejecting later accretions in practice.

These differences are real and should be studied honestly rather than papered over — but they sit inside a shared creed of one God, one Qur'an and one Prophet.

## Where to begin

Read the Qur'an with a reliable translation, learn the prayer, and read the Prophet's biography. Understanding grows with practice, not before it.

## References across the schools

- **Qur'an**: 2:177, 3:19, 49:13, 112:1–4.
- **Sunni**: Sahih al-Bukhari 8 and Sahih Muslim 16 (hadith of the five pillars); Sahih Muslim 8 (hadith of Jibril on islam, iman, ihsan).
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Iman wa'l-Kufr (Islam built on five); al-Saduq, *al-I'tiqadat*.
- **Salafi/Wahhabi**: Muhammad ibn Abd al-Wahhab, *Kitab al-Tawhid*; Ibn Taymiyyah, *al-Aqidah al-Wasitiyyah*.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 7,
array['islam','introduction','tawhid','basics'],'en'
),
(
'five-pillars-of-islam-explained',
'The Five Pillars of Islam Explained',
'Shahadah, Salah, Sawm, Zakat and Hajj — what each pillar requires, what it means, and how Sunni, Shia and Salafi sources describe them.',
$md$The Prophet (ﷺ) said Islam is built on five foundations. They are not five separate rituals but one structure: belief declared, God remembered daily, appetite disciplined yearly, wealth purified, and the body sent on a journey of return.

## 1. Shahadah — testimony

To say with conviction that there is no god but Allah and Muhammad is His Messenger. Shia Muslims commonly add the testimony that Ali is the *wali* of Allah as a recommended (not obligatory) statement of loyalty, not as a condition of Islam.

## 2. Salah — prayer

Five daily prayers at fixed times. Sunni practice generally prays them at five separate times; Shia practice permits combining Dhuhr with Asr and Maghrib with Isha, on the basis of narrations reporting the Prophet doing so without fear or travel.

## 3. Sawm — fasting Ramadan

Abstaining from food, drink and intimacy from true dawn to sunset for the lunar month. Shia fiqh ends the fast at *maghrib* defined as the disappearance of the eastern redness, slightly later than the common Sunni timing at sunset.

## 4. Zakat — purifying wealth

An obligatory charge on qualifying wealth held for a lunar year — classically 2.5% on gold, silver and trade goods. Shia fiqh applies zakat to nine specified categories and adds *khums*, one fifth of annual surplus, on the basis of Qur'an 8:41.

## 5. Hajj — pilgrimage

Once in a lifetime for the physically and financially able. The rites are essentially identical across schools: ihram, tawaf, sa'i, Arafah, Muzdalifah, Mina, and the farewell tawaf.

## Why they hold together

Each pillar trains a different faculty: the tongue, the body's schedule, the appetite, the wallet and the whole life. Remove one and the structure leans. Perform them without character — honesty, mercy, justice — and the structure is hollow; the Qur'an calls that out directly in Surah al-Ma'un.

## References across the schools

- **Qur'an**: 2:183–185 (fasting), 2:43 (zakat and prayer), 3:97 (Hajj), 8:41 (khums).
- **Sunni**: Sahih al-Bukhari 8; Sahih Muslim 16; al-Nawawi, *al-Arba'un al-Nawawiyyah*, hadith 3.
- **Shia**: al-Kulayni, *al-Kafi* 2/18 (Islam built on five); al-Tusi, *al-Nihayah*; Sayyid al-Khu'i, *Minhaj al-Salihin*.
- **Salafi/Wahhabi**: Ibn Baz, *Majmu' Fatawa* on the pillars; Ibn Uthaymin, *Sharh al-Usul al-Thalathah*.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 6,
array['pillars','fiqh','worship','basics'],'en'
),
(
'six-articles-of-faith-iman',
'The Six Articles of Faith (Iman)',
'God, angels, books, messengers, the Last Day and divine decree — the creedal spine of Islam, with the Shia framing of the five usul al-din.',
$md$Where the pillars describe what a Muslim *does*, the articles of faith describe what a Muslim *holds true*. The Qur'an lists them nearly complete in one verse: "The Messenger believes in what was revealed to him from his Lord, and so do the believers. All believe in Allah, His angels, His books and His messengers" (2:285).

## The six articles

1. **Allah** — one, eternal, without partner or likeness (Qur'an 42:11).
2. **Angels** — created servants of light who never disobey (66:6).
3. **Revealed books** — the Torah, Psalms, Gospel and the Qur'an as the final, preserved revelation.
4. **Messengers** — thousands sent to every nation, sealed by Muhammad (ﷺ).
5. **The Last Day** — resurrection, reckoning, Paradise and Hellfire.
6. **Divine decree (qadar)** — nothing occurs outside God's knowledge and permission.

## The Shia formulation

Shia theology teaches five *usul al-din*: Tawhid (oneness), Adl (divine justice), Nubuwwah (prophethood), Imamah (divinely appointed leadership) and Ma'ad (resurrection). The content overlaps heavily with the six articles; the distinctive emphases are *Adl* — that God never acts unjustly, so human responsibility is real — and *Imamah*.

## The debate over qadar

All schools affirm that God knows and wills all things. They differ on how human freedom fits. Ash'ari Sunni theology teaches *kasb*, human "acquisition" of acts God creates. Shia and Mu'tazili theology teach *amr bayn al-amrayn* — "a matter between the two extremes": neither compulsion nor human independence from God. Salafi creed affirms four levels of qadar (knowledge, writing, will, creation) while insisting the servant genuinely chooses.

## Why the creed matters practically

A creed is not trivia. Belief in accountability restrains behaviour when nobody is watching. Belief in divine justice makes oppression intolerable rather than fated. Belief in the books makes the Muslim a reader.

## References across the schools

- **Qur'an**: 2:177, 2:285, 4:136, 42:11, 54:49.
- **Sunni**: Sahih Muslim 8 (hadith of Jibril); al-Tahawi, *al-Aqidah al-Tahawiyyah*.
- **Shia**: al-Saduq, *al-I'tiqadat*; al-Hilli, *al-Bab al-Hadi Ashar*; al-Kulayni, *al-Kafi*, Kitab al-Tawhid.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *al-Aqidah al-Wasitiyyah*; Ibn Uthaymin, *Sharh al-Aqidah al-Wasitiyyah*.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 6,
array['iman','aqeedah','creed','qadar'],'en'
),
(
'life-and-mission-of-prophet-muhammad',
'The Life and Mission of Prophet Muhammad ﷺ',
'From orphan of Makkah to leader of a transformed community — the arc of the Prophet''s life and the mission he carried.',
$md$Muhammad ibn Abdullah (ﷺ) was born in Makkah around 570 CE into the clan of Banu Hashim. Orphaned young, raised by his grandfather Abd al-Muttalib and then his uncle Abu Talib, he earned the title *al-Amin* — the trustworthy — long before he claimed prophethood.

## Before revelation

He worked in trade, married Khadijah bint Khuwaylid, and withdrew regularly to the cave of Hira to reflect. Makkah at the time was a shrine city of idols, tribal vendetta, buried daughters and debt slavery. His discomfort with it was recorded by his own community before it was recorded by scripture.

## The call

At forty, in Hira, came the first revelation: "Read, in the name of your Lord who created" (96:1). The first believers were Khadijah, Ali ibn Abi Talib, Zayd ibn Harithah and Abu Bakr. For three years the call was quiet; then it became public and the persecution began — the boycott of Banu Hashim, the migration of companions to Abyssinia, the deaths of Khadijah and Abu Talib in the "Year of Sorrow".

## Madinah

In 622 CE he migrated to Yathrib, which became *Madinat al-Nabi*. There the mission changed shape: a constitution binding Muslims, Jews and pagan clans into one polity; a mosque that doubled as court, school and shelter; a system of brotherhood pairing migrants with hosts. Then came Badr, Uhud, the Trench, Hudaybiyyah and finally the near-bloodless conquest of Makkah in 630 CE.

## The mission itself

The Qur'an sums it up twice: "We sent you only as a mercy to the worlds" (21:107) and "so that people may uphold justice" (57:25). The Prophet described his own purpose as perfecting noble character. In practice the mission dismantled idolatry, restrained tribal vengeance, gave women inheritance and contract rights, capped and regulated warfare, and made knowledge an obligation.

## The farewell

At the Farewell Pilgrimage he declared the sanctity of life, property and honour, ended the vendettas of the age of ignorance, and reminded the crowd that no Arab is superior to a non-Arab. He died in Madinah in 632 CE in the room of A'ishah.

## References across the schools

- **Qur'an**: 3:164, 21:107, 33:21, 33:40, 68:4.
- **Sunni**: Ibn Hisham, *al-Sirah al-Nabawiyyah*; Ibn Kathir, *al-Bidayah wa'l-Nihayah*; Sahih al-Bukhari, Kitab al-Maghazi.
- **Shia**: al-Ya'qubi, *Tarikh*; al-Majlisi, *Bihar al-Anwar* vols. 15–22; Ja'far Subhani, *The Message*.
- **Salafi/Wahhabi**: Safi al-Rahman al-Mubarakpuri, *al-Rahiq al-Makhtum*; Ibn Uthaymin's sirah lectures.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 8,
array['seerah','prophet','history','makkah','madinah'],'en'
),
(
'holy-quran-revelation-preservation-guidance',
'The Holy Quran — Revelation, Preservation and Guidance',
'How the Qur''an was revealed, how its text was preserved, and how Sunni, Shia and Salafi scholarship agree on its integrity.',
$md$The Qur'an is, for Muslims, the literal speech of God revealed in Arabic to Prophet Muhammad (ﷺ) over roughly twenty-three years. It is not a book that was written; it is a recitation that was received, memorised, and only then written down.

## How it came

Revelation began in Hira in 610 CE and continued in fragments responding to events: a battle lost, an accusation made, a law needed, a heart consoled. This gradual descent is defended in the Qur'an itself: "so that We may strengthen your heart by it" (25:32). Makkan passages tend to be short, rhythmic and focused on God, resurrection and moral urgency; Madinan passages are longer and legislative.

## How it was preserved

Three mechanisms worked together:

1. **Memorisation** — the Prophet's companions memorised passages as they came; *huffaz* have transmitted the text in unbroken chains ever since.
2. **Immediate writing** — scribes recorded revelation on parchment, bone and leather during the Prophet's lifetime, with him specifying placement of each verse.
3. **Compilation** — collected under Abu Bakr and standardised in a single Qurayshi orthography under Uthman, with copies dispatched to the main cities.

The result is that the Qur'an recited in Jakarta, Karbala, Cairo and Riyadh today is the same text. On this point Sunni, Shia and Salafi scholarship agree: al-Saduq, al-Murtada, al-Tusi and al-Khu'i all explicitly affirm that the Qur'an is free of distortion, matching the mainstream Sunni and Salafi position.

## Recitations and readings

The canonical *qira'at* — ten established readings, of which Hafs an Asim and Warsh an Nafi are most widespread — differ in vowelling and minor pronunciation, not in content. They are transmitted variants of one revelation, not competing editions.

## Reading it as guidance

The Qur'an calls itself *hudan li'l-muttaqin* — guidance for the conscious. That framing matters: it is a book of formation, not merely information. Read it with a reliable tafsir, in small consistent portions, and with the intention to act on what you understand.

## References across the schools

- **Qur'an**: 2:2, 15:9, 17:88, 25:32, 75:16–19.
- **Sunni**: Sahih al-Bukhari, Kitab Fada'il al-Qur'an; al-Suyuti, *al-Itqan fi Ulum al-Qur'an*; al-Zarkashi, *al-Burhan*.
- **Shia**: al-Tusi, *al-Tibyan*; al-Tabatabai, *al-Mizan*; al-Khu'i, *al-Bayan fi Tafsir al-Qur'an* (on the absence of tahrif).
- **Salafi/Wahhabi**: Ibn Kathir, *Tafsir al-Qur'an al-Azim*; Ibn Uthaymin, *Usul fi al-Tafsir*.$md$,
'b1723cd5-df2c-4b48-9aa9-7d17fb9652a3','published', now(), 7,
array['quran','revelation','tafsir','preservation'],'en'
),
(
'salah-importance-and-spiritual-meaning-of-prayer',
'Salah — The Importance and Spiritual Meaning of Prayer',
'Why prayer is the pillar that holds the rest, how it is performed, and where Sunni and Shia practice differ.',
$md$Salah is the only act of worship whose obligation the Qur'an reports being given directly, and the only one repeated five times a day for a lifetime. The Prophet (ﷺ) called it the pillar of religion and the first deed to be examined on the Day of Judgement.

## What it does to a person

"Indeed, prayer restrains from immorality and wrongdoing" (29:45). The mechanism is repetition: five interruptions in every day that reset perspective, place the forehead — the seat of pride — on the ground, and rehearse dependence on God. A person who genuinely stands before God at dawn behaves differently at noon.

## The structure

Each prayer consists of units (*rak'ahs*) of standing, recitation of al-Fatihah, bowing, prostration and sitting, sealed with *tashahhud* and *salam*. Prerequisites are ritual purity (wudu or ghusl), clean clothing and place, covering the body, facing the Qiblah, and correct time.

## Where the schools differ

- **Timing**: Shia fiqh permits combining Dhuhr–Asr and Maghrib–Isha routinely, citing narrations of the Prophet combining without excuse; most Sunni schools restrict combining to travel, rain or need (Hanafi being strictest).
- **Hands**: Shia and Maliki practice pray with arms at the sides (*sadl*); Hanafi, Shafi'i, Hanbali and Salafi practice fold them (*qabd*).
- **Prostration**: Shia practice prostrates on earth or a *turbah* of pure clay, following narrations that the earth was made a place of prostration and purity.
- **Adhan**: wording differs slightly, including the Shia phrase *hayya ala khayr al-amal*.

These are differences of transmitted practice, not of the prayer's validity in each school's own framework.

## Building the habit

Start with the times, not the perfection. Fix Fajr first — it is the hardest and it sets the rest. Learn the meaning of what you recite; prayer in a language you do not understand becomes exercise. Add the *nawafil* only once the obligatory five are stable.

## References across the schools

- **Qur'an**: 2:238, 4:103, 17:78, 20:14, 29:45.
- **Sunni**: Sahih al-Bukhari 631 ("pray as you have seen me pray"); Sahih Muslim, Kitab al-Salah; al-Nawawi, *al-Majmu'*.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Salah; al-Tusi, *Tahdhib al-Ahkam*; Sayyid al-Sistani, *Islamic Laws*, prayer chapter.
- **Salafi/Wahhabi**: al-Albani, *Sifat Salat al-Nabi*; Ibn Baz, *Fatawa* on prayer times.$md$,
'cd30feed-a283-46c2-8300-6a7ac290f9d7','published', now(), 6,
array['salah','prayer','worship','fiqh'],'en'
),
(
'ramadan-fasting-worship-spiritual-transformation',
'Ramadan — Fasting, Worship and Spiritual Transformation',
'The rules, purpose and inner work of the month of fasting, including the differing timings and night-prayer practices.',
$md$Ramadan is the ninth lunar month, the month in which the Qur'an began to descend (2:185). Its fast is obligatory on every sane, adult, resident Muslim in health, with exemptions and make-up rules for the ill, travelling, pregnant, nursing, menstruating and elderly.

## The rule and the reason

From true dawn to sunset a fasting person abstains from food, drink, intimacy and deliberate vomiting. The Qur'an gives the purpose in one word: *taqwa* — God-consciousness (2:183). The Prophet (ﷺ) warned that whoever does not abandon false speech and acting on it, God has no need of them abandoning food and drink.

## Timing across schools

The start of the fast is agreed: true dawn. The end differs slightly — most Sunni fiqh breaks at sunset (the disc disappearing), while Shia fiqh waits for *maghrib* proper, when the redness in the eastern sky has passed, typically a dozen or so minutes later.

## Nights of Ramadan

Sunni practice centres on *Tarawih* in congregation, generally eight or twenty rak'ahs. Shia practice recommends the same recommended night prayers individually, along with the *Du'a al-Iftitah* and the nightly supplications of the month. Both traditions intensify Qur'an recitation, aiming to complete the text.

## Laylat al-Qadr

"Better than a thousand months" (97:3). Sunni tradition seeks it in the odd nights of the last ten, especially the 27th; Shia tradition emphasises the 19th, 21st and 23rd, with the 23rd most stressed — the nights that also commemorate the striking and martyrdom of Imam Ali.

## Making the month count

Three practical anchors: a fixed daily portion of Qur'an, a fixed act of charity, and a fixed sin you are actively leaving. Feed someone. Repair one relationship. The month ends with *zakat al-fitr* paid before the Eid prayer, so that nobody in the community celebrates hungry.

## References across the schools

- **Qur'an**: 2:183–187, 97:1–5.
- **Sunni**: Sahih al-Bukhari 1899, 1901; Sahih Muslim, Kitab al-Siyam; Ibn Rajab, *Lata'if al-Ma'arif*.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Siyam; al-Saduq, *Fada'il al-Ashhur al-Thalathah*; the Prophet's Sha'ban sermon in *Uyun Akhbar al-Rida*.
- **Salafi/Wahhabi**: Ibn Uthaymin, *Majalis Shahr Ramadan*; Ibn Baz, *Fatawa al-Siyam*.$md$,
'cd30feed-a283-46c2-8300-6a7ac290f9d7','published', now(), 6,
array['ramadan','fasting','siyam','laylat al-qadr'],'en'
),
(
'zakat-charity-wealth-social-responsibility',
'Zakat — Charity, Wealth and Social Responsibility',
'How zakat is calculated, who receives it, and how khums and sadaqah complete the Islamic economy of giving.',
$md$Zakat is not charity in the voluntary sense. It is a due — a right the poor hold over the wealth of the rich, named in the Qur'an alongside prayer more than thirty times. To withhold it is to keep property that is not yours.

## What is owed

Classical Sunni fiqh charges 2.5% annually on wealth held above the *nisab* (roughly the value of 85g of gold or 595g of silver) for one lunar year: cash, gold, silver, trade goods and receivable debts. Different rates apply to livestock (varying by herd), crops (5% irrigated, 10% rain-fed) and mined treasure (20%).

Shia fiqh confines obligatory zakat to nine categories — gold, silver, camels, cattle, sheep, wheat, barley, dates and raisins — and adds **khums**: one fifth of the annual surplus after living expenses, based on Qur'an 8:41, divided between the share of the Imam and the descendants of the Prophet in need.

## Who receives it

Qur'an 9:60 names eight categories: the poor, the destitute, those employed to collect it, those whose hearts are to be reconciled, freeing captives, the debt-burdened, in the path of God, and the stranded traveller. Zakat cannot be paid to one's own dependants, nor — in most schools — to the Prophet's family, for whom khums exists instead.

## Beyond the obligation

*Sadaqah* is voluntary and unlimited, and includes non-financial acts: a good word, removing harm from the road, a smile. *Sadaqah jariyah* — a well, a school, a published book — continues to earn after death. *Waqf*, the endowment, built much of Muslim civilisation's hospital and university infrastructure.

## The social logic

Zakat is a circulation mechanism: it penalises hoarding, funds the base of society directly, and is calculated on assets rather than income so that idle wealth cannot hide. "So that it does not circulate solely among the rich among you" (59:7) is the operating principle.

## References across the schools

- **Qur'an**: 2:43, 2:267, 9:60, 9:103, 8:41, 59:7.
- **Sunni**: Sahih al-Bukhari, Kitab al-Zakat; al-Qaradawi, *Fiqh al-Zakat*.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Zakat; al-Sistani, *Islamic Laws* (zakat and khums chapters).
- **Salafi/Wahhabi**: Ibn Baz and the Permanent Committee, *Fatawa al-Lajnah al-Da'imah* on zakat calculation.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 6,
array['zakat','khums','charity','economy'],'en'
);
