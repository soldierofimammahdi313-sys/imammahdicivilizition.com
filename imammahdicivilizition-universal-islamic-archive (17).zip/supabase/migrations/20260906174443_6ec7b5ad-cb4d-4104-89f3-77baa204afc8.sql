CREATE TABLE public.library_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  arabic_title text,
  author text,
  category text NOT NULL DEFAULT 'General',
  era text,
  language text NOT NULL DEFAULT 'en',
  summary text,
  body text,
  cover_url text,
  sort_order integer NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.library_items TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.library_items TO authenticated;
GRANT ALL ON public.library_items TO service_role;

ALTER TABLE public.library_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Published library items are public"
  ON public.library_items FOR SELECT
  USING (is_published = true);

CREATE POLICY "Admins can read all library items"
  ON public.library_items FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert library items"
  ON public.library_items FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update library items"
  ON public.library_items FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete library items"
  ON public.library_items FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_library_items_updated_at
  BEFORE UPDATE ON public.library_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.library_items (slug, title, arabic_title, author, category, era, language, summary, sort_order) VALUES
('tafsir-nur-al-thaqalayn', 'Nur al-Thaqalayn: A Reader''s Introduction', 'نور الثقلين', 'Compiled by our editorial team', 'Tafsir', '11th century AH', 'en', 'A guided introduction to narration-based Qur''anic exegesis, explaining how tradition and verse illuminate one another.', 10),
('tafsir-al-mizan-companion', 'Companion to Tafsir al-Mizan', 'الميزان في تفسير القرآن', 'Our editorial team', 'Tafsir', '20th century', 'en', 'How Allamah Tabatabai reads the Qur''an through the Qur''an itself, with worked examples from Surah al-Baqarah.', 20),
('history-karbala-chronicle', 'The Chronicle of Karbala', 'واقعة كربلاء', 'Our editorial team', 'History', '61 AH', 'en', 'A day-by-day account of the events of Muharram 61 AH, drawn from classical historical reports.', 30),
('history-ghaybah-era', 'The Age of Occultation: A Historical Survey', 'عصر الغيبة', 'Our editorial team', 'History', '260-329 AH', 'en', 'The minor occultation, the four deputies, and the transition to the age of scholarly guidance.', 40),
('philosophy-transcendent-wisdom', 'Transcendent Wisdom: An Approach to Islamic Philosophy', 'الحكمة المتعالية', 'Our editorial team', 'Philosophy', '17th century', 'en', 'Existence, essence and substantial motion explained in plain language for the modern reader.', 50),
('philosophy-reason-and-revelation', 'Reason and Revelation in Islamic Thought', 'العقل والنقل', 'Our editorial team', 'Philosophy', 'Classical to modern', 'en', 'How Muslim thinkers balanced intellect and scripture, from the early theologians to contemporary scholarship.', 60),
('hadith-four-books-guide', 'A Guide to the Four Books', 'الكتب الأربعة', 'Our editorial team', 'Hadith', '4th-5th century AH', 'en', 'Al-Kafi, Man la Yahduruhu al-Faqih, Tahdhib and Istibsar — what each contains and how to use them.', 70),
('supplication-kumayl-study', 'Dua Kumayl: A Line-by-Line Study', 'دعاء كميل', 'Our editorial team', 'Supplication', 'Classical', 'en', 'The themes, structure and spiritual arc of the supplication taught by Imam Ali to Kumayl ibn Ziyad.', 80),
('fiqh-jafari-foundations', 'Foundations of Ja''fari Jurisprudence', 'أصول الفقه الجعفري', 'Our editorial team', 'Jurisprudence', 'Classical to modern', 'en', 'Sources, principles and the practice of ijtihad explained for students beginning legal study.', 90),
('urdu-mahdi-intro', 'امام مہدی عج: ایک تعارف', 'الإمام المهدي', 'ہماری ادارتی ٹیم', 'History', 'معاصر', 'ur', 'امام مہدی علیہ السلام کی ولادت، غیبت اور ظہور سے متعلق بنیادی معلومات کا جامع تعارف۔', 100);