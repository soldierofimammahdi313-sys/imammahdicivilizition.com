
insert into public.articles (slug, title, excerpt, content, category_id, status, published_at, reading_minutes, tags, language) values
(
'qiyamah-resurrection-judgment-hereafter',
'Qiyamah — Resurrection, Judgment and the Hereafter',
'From the blowing of the trumpet to the crossing of the Sirat: the stages of the Day of Judgement in Qur''an and hadith.',
$md$Belief in the Last Day is the second most repeated theme of the Qur'an after the oneness of God. It is what makes justice coherent: a world in which the oppressor dies comfortable and the oppressed dies unheard is only bearable if the account is settled elsewhere.

## Barzakh

Between death and resurrection lies *barzakh*, an intermediate state (23:100). The soul is questioned in the grave and experiences ease or constriction according to its deeds. All schools affirm barzakh; details of its nature are debated.

## The stages

1. **The trumpet** — Israfil's first blast ends the world; the second raises the dead (39:68).
2. **The gathering** — humanity assembled barefoot and uncircumcised, the sun brought near, some shaded by God's shade (Bukhari 660).
3. **The book** — each person handed their record in the right hand or the left (69:19–25); limbs testify (24:24, 36:65).
4. **The scale** — deeds weighed, "an atom's weight" counted either way (99:7–8, 21:47).
5. **Intercession** — the Prophet's *shafa'ah* by God's permission (2:255, 20:109). Sunni and Shia affirm it broadly; Shia extend it explicitly to the Ahl al-Bayt, while Salafi thought restricts it to what is textually established and rejects requesting it from the dead.
6. **The Sirat** — the crossing over Hellfire.
7. **The Hawd** — the Prophet's Pool, from which the faithful drink.

## The questions asked

Reports across the schools list the first matters examined: the prayer, then the blood one shed, then how a life was spent, how knowledge was used, how wealth was earned and spent, and how the body was used. Shia sources add the question of *wilayah* — loyalty to the household.

## Living with it

Qiyamah is not meant to paralyse but to calibrate. It reframes every private choice as public, every unseen injustice as recorded, and every small good — a coin given, a harm removed — as permanent.

## References across the schools

- **Qur'an**: 21:47, 23:100, 39:68, 69:13–37, 75:1–15, 81:1–14, 99:1–8, 101:1–11.
- **Sunni**: Sahih al-Bukhari, Kitab al-Riqaq; Sahih Muslim, Kitab al-Jannah; al-Qurtubi, *al-Tadhkirah*.
- **Shia**: al-Saduq, *al-I'tiqadat*; al-Kulayni, *al-Kafi*, Kitab al-Jana'iz; *Bihar al-Anwar* vol. 7.
- **Salafi/Wahhabi**: Ibn al-Qayyim, *al-Ruh*; Ibn Kathir, *al-Nihayah*; Ibn Uthaymin, *Sharh al-Wasitiyyah*.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 7,
array['qiyamah','judgment','hereafter','barzakh'],'en'
),
(
'jannah-and-jahannam-islamic-teachings-afterlife',
'Jannah and Jahannam — Islamic Teachings About the Afterlife',
'What the Qur''an and hadith describe about Paradise and Hellfire, and how the schools read those descriptions.',
$md$The Qur'an describes the two final destinations in vivid, sensory language — gardens beneath which rivers flow, and a fire whose fuel is people and stones. Muslim scholars have always debated how much of this is literal and how much conveys realities beyond language; the majority position across schools is that the descriptions are real, and that their reality exceeds anything imagined.

## Jannah

Paradise is described in eight named gates and multiple levels, the highest being *al-Firdaws*, beneath the Throne. Its features: permanent security, no fatigue, no idle or sinful speech, purified companions, rivers of water, milk, honey and wine that does not intoxicate, and clothing of silk. The Prophet transmitted God's words: "I have prepared for My righteous servants what no eye has seen, no ear has heard, and no heart has conceived" (Bukhari 3244).

The greatest reward, in Sunni, Shia and Salafi commentary alike, is not the gardens: it is *ridwan* — God's pleasure (9:72) — and the vision of God, affirmed by Sunni and Salafi creed as a beatific vision without form, and interpreted by Shia and Mu'tazili theology as vision of the heart, since God has no physical location.

## Jahannam

Hellfire is described with seven gates matched to the gravity of deeds. Its punishments target the specific corruptions of a life: the hoarder branded with his gold (9:35), the slanderer, the one who devoured orphans' property (4:10). Its dwellers include those who rejected truth knowingly, the arrogant, and the unjust.

## Eternity and mercy

Most scholars hold that believers who enter the Fire for sins are eventually removed by God's mercy and intercession, and that permanence is for those who rejected faith deliberately. The Qur'an insists mercy is the wider attribute: "My mercy encompasses all things" (7:156), and the divine statement, "My mercy outstrips My wrath" (Bukhari 3194).

## The practical point

Fear and hope are meant to work in pair — the classical image is two wings of one bird. Worship purely from fear becomes anxiety; purely from hope becomes complacency. The tradition's highest station, expressed by Imam Ali, is worship of God because He is worthy of worship.

## References across the schools

- **Qur'an**: 2:25, 4:10, 7:156, 9:35, 9:72, 18:29–31, 55:46–78, 56:10–56, 76:5–22.
- **Sunni**: Sahih al-Bukhari 3244, 3194; Sahih Muslim, Kitab al-Jannah wa Sifat Na'imiha.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Iman; al-Tabatabai, *al-Mizan* on 55 and 56; *Bihar al-Anwar* vol. 8.
- **Salafi/Wahhabi**: Ibn al-Qayyim, *Hadi al-Arwah ila Bilad al-Afrah*; Ibn Kathir on the descriptions of Paradise.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 7,
array['jannah','jahannam','afterlife','mercy'],'en'
),
(
'duas-and-dhikr-remembrance-of-allah-daily-life',
'Duas and Dhikr — Remembrance of Allah in Daily Life',
'The etiquette of supplication, the great books of du''a, and a practical daily routine of remembrance.',
$md$"Call upon Me; I will respond to you" (40:60). Du'a is described by the Prophet (ﷺ) as the essence of worship — the one act in which a human being admits total dependence.

## Etiquette of du'a

Begin with praise of God and blessings on the Prophet and his family; face the Qiblah; raise the hands; be in a state of purity where possible; ask with certainty of response; be persistent; and choose the moments of greatest acceptance — the last third of the night, between adhan and iqamah, in prostration, on Friday, while fasting, while travelling, and while oppressed.

## Why answers seem delayed

Classical scholars across schools give three modes of response: the request granted, an equivalent harm averted, or the reward stored for the Hereafter. The Prophet warned that the one obstacle is impatience — saying "I asked and was not answered".

## Dhikr in daily life

- **Tasbih al-Zahra** after every prayer — 34 *Allahu Akbar*, 33 *Alhamdulillah*, 33 *Subhanallah*, taught by the Prophet to Fatimah and reported in both Sunni and Shia collections.
- **Ayat al-Kursi** (2:255) after prayers and before sleep.
- **Astaghfirullah** — the Prophet sought forgiveness over seventy times daily.
- **Salawat** on the Prophet and his family — the one du'a all schools agree is always accepted.
- **Surah al-Kahf** on Fridays; **al-Mulk** before sleep; **al-Ikhlas, al-Falaq, al-Nas** morning and night.

## The great collections

- **Sunni**: al-Nawawi, *al-Adhkar*; Ibn al-Sunni, *Amal al-Yawm wa'l-Laylah*; al-Jazari, *al-Hisn al-Hasin*.
- **Shia**: *al-Sahifah al-Sajjadiyyah* of Imam Zayn al-Abidin; *Mafatih al-Jinan* of Shaykh Abbas al-Qummi; Du'a Kumayl, Du'a Abu Hamzah al-Thumali, Ziyarat Ashura, and Du'a al-Sabah of Imam Ali.
- **Salafi/Wahhabi**: *Hisn al-Muslim* by Sa'id al-Qahtani — the most widely distributed du'a booklet in the world.

## Build a routine you can keep

Ten minutes of morning and evening adhkar, salawat in idle moments, and one long supplication weekly does more over a year than an intense week that collapses. The Prophet said the most beloved deeds to God are the consistent ones, however small.

## References across the schools

- **Qur'an**: 2:152, 2:186, 13:28, 33:41–42, 40:60.
- **Sunni**: Sahih al-Bukhari 6407; Sahih Muslim 2675, 2137; al-Tirmidhi 3371.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Du'a; *Mafatih al-Jinan*.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *al-Kalim al-Tayyib*; Ibn al-Qayyim, *al-Wabil al-Sayyib*.$md$,
'cd30feed-a283-46c2-8300-6a7ac290f9d7','published', now(), 6,
array['dua','dhikr','supplication','worship'],'en'
),
(
'islamic-ethics-justice-mercy-honesty-character',
'Islamic Ethics — Justice, Mercy, Honesty and Good Character',
'Akhlaq as the purpose of revelation: the core virtues, the vices that undo worship, and the sources that teach them.',
$md$"I was sent only to perfect noble character." The Prophet's summary of his own mission places ethics not beside worship but as its purpose. The Qur'an makes the same link: prayer that does not restrain wrongdoing has failed (29:45), and the one who denies the Judgement is identified not as a theologian but as someone who repels the orphan (107:1–3).

## Justice ('adl)

The Qur'an commands justice even against oneself, one's parents and one's kin (4:135), and warns that hatred of a people must not push you to injustice (5:8). In Shia theology divine justice is a pillar of creed, which makes human justice a religious obligation rather than a civic preference. Imam Ali's letter to Malik al-Ashtar sets the standard for public office.

## Mercy (rahmah)

Every chapter but one opens with the two names of mercy. "The merciful are shown mercy by the Most Merciful: be merciful to those on earth and the One above the heavens will be merciful to you" (Abu Dawud 4941). Mercy in Islamic ethics extends to animals, prisoners, opponents and the environment.

## Honesty (sidq) and trust (amanah)

Truthfulness leads to righteousness and righteousness to Paradise; lying leads the other way (Bukhari 6094). Trustworthiness is the trait that earned the Prophet his title before prophethood, and the sign of hypocrisy in the hadith is the betrayal of trust, the broken promise and the lie.

## The vices that hollow worship

Backbiting — likened to eating a dead brother's flesh (49:12); arrogance, the first sin ever committed; envy, which "consumes good deeds as fire consumes wood"; and cheating in trade — "whoever deceives us is not of us" (Muslim 102). The famous hadith of *al-muflis*, the bankrupt, describes a person arriving with mountains of prayer and fasting who leaves with nothing because he insulted, struck and cheated others.

## Training character

Classical *akhlaq* literature — al-Ghazali's *Ihya Ulum al-Din*, al-Naraqi's *Jami al-Sa'adat*, Ibn Miskawayh's *Tahdhib al-Akhlaq* — treats virtue as a habit built by repetition and self-accounting (*muhasabah*), not as a temperament you either have or lack. The practice is simple and hard: review the day nightly, name one fault, and work on it until the next fault is the worst one left.

## References across the schools

- **Qur'an**: 4:58, 4:135, 5:8, 16:90, 17:23–37, 49:11–13, 68:4, 107:1–7.
- **Sunni**: Sahih al-Bukhari 6094; Sahih Muslim 2581 (al-muflis); al-Ghazali, *Ihya Ulum al-Din*.
- **Shia**: *Nahj al-Balagha*, Letter 53 and Letter 31; Imam Zayn al-Abidin, *Risalat al-Huquq*; al-Naraqi, *Jami al-Sa'adat*.
- **Salafi/Wahhabi**: Ibn al-Qayyim, *Madarij al-Salikin*; Ibn Uthaymin, *Makarim al-Akhlaq*.$md$,
'cd30feed-a283-46c2-8300-6a7ac290f9d7','published', now(), 7,
array['akhlaq','ethics','justice','character'],'en'
),
(
'women-in-islam-rights-dignity-family-society',
'Women in Islam — Rights, Dignity, Family and Society',
'What the sources establish about women''s rights in property, marriage, education and public life — and how to read the contested verses.',
$md$Any honest treatment of this subject separates three layers: what the Qur'an and Sunnah establish, what classical jurists inferred in their own social contexts, and what specific cultures practise today in the name of religion. Conflating them produces most of the confusion.

## What the sources established

- **Personhood before God** — identical spiritual standing and identical reward (33:35, 16:97, 3:195).
- **Property** — a woman owns her wealth independently; marriage does not transfer it, and her *mahr* is hers alone (4:4).
- **Inheritance** — a guaranteed share at a time when women were themselves inherited (4:7, 4:11–12), calibrated to a system in which maintenance is entirely the man's obligation.
- **Consent in marriage** — a marriage contracted without the woman's consent is invalid; the Prophet annulled such a marriage on a woman's complaint (Bukhari 5138).
- **Education** — "seeking knowledge is an obligation on every Muslim", male and female.
- **Ending the burial of infant girls** — 81:8–9 confronts the practice directly.

## Women who shaped Islam

Khadijah, a merchant who employed and then proposed to the Prophet. Fatimah al-Zahra, whose public address on her rights is preserved in both traditions. A'ishah, a jurist and transmitter of over two thousand hadith. Umm Salamah, whose political counsel at Hudaybiyyah resolved a crisis. Nusaybah bint Ka'b, who fought at Uhud. Zaynab bint Ali, whose oratory preserved the meaning of Karbala. Fatimah al-Fihri, who founded al-Qarawiyyin, the oldest continually operating university.

## The contested passages

Verses on witnesses (2:282), inheritance shares (4:11) and 4:34 have been read very differently. Contemporary scholarship across schools — including many traditional jurists — emphasises the specific context of 2:282 (commercial debt in a society where women rarely handled such transactions), the maintenance logic behind inheritance ratios, and readings of 4:34 that exclude harm entirely, citing the Prophet's own conduct: he never struck a woman, and his final sermon commanded good treatment of wives as a trust from God.

## Culture is not revelation

Denying girls education, forced marriage, honour violence and denial of inheritance are practised in some Muslim societies and are prohibited by the sources those societies claim to follow. Naming that gap is a religious duty, not a concession to outsiders.

## References across the schools

- **Qur'an**: 2:228, 4:1, 4:4, 4:7, 4:19, 9:71, 16:97, 33:35, 81:8–9.
- **Sunni**: Sahih al-Bukhari 5138; Sahih Muslim 1218 (Farewell Sermon); Ibn Sa'd, *al-Tabaqat*, women's volume.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Nikah; Fatimah's *Khutbah al-Fadakiyyah*; Murtada Mutahhari, *The Rights of Women in Islam*.
- **Salafi/Wahhabi**: Ibn Baz and the Permanent Committee fatawa on women's education, consent and inheritance rights.$md$,
'4d7399d7-1a68-468c-8137-8b70fe3db03d','published', now(), 8,
array['women','rights','family','society'],'en'
),
(
'islam-in-the-modern-world-faith-knowledge-peace',
'Islam in the Modern World — Faith, Knowledge, Peace and Humanity',
'How Muslims engage science, technology, pluralism, extremism and the environment from within the tradition.',
$md$Roughly two billion Muslims live across every continent, political system and economic condition on earth. The question of Islam in the modern world is therefore not whether Muslims will engage modernity — they already constitute a quarter of it — but on what terms.

## Knowledge and science

The first revealed word was *iqra*, read. Between the 8th and 14th centuries Muslim scholars produced al-Khwarizmi's algebra, Ibn al-Haytham's experimental optics, Ibn Sina's medicine and al-Biruni's geodesy — not despite religious commitment but as an expression of it. Contemporary bioethics, AI ethics and environmental law are being worked through in *fiqh* councils in Jeddah, Qom, Cairo and Kuala Lumpur today, using the classical tools of *maqasid* (higher objectives) and *maslahah* (public interest).

## Peace and the rejection of extremism

The Qur'an makes killing one innocent person equivalent to killing all humanity (5:32), forbids compulsion in religion (2:256), and restricts fighting to defence against aggression (2:190). Classical law of war forbids killing non-combatants, women, children, the elderly, clergy, and even cutting trees or poisoning wells — rules Abu Bakr issued to his armies. Extremist movements violate these rules and have been condemned across the schools, from the Amman Message signed by hundreds of Sunni and Shia scholars to specific fatawa by senior jurists in both traditions.

## Living as a minority and as a majority

Muslims in the West navigate questions of finance, food, schooling and identity; Muslims in majority countries navigate governance, corruption and sectarianism. Both need the same two capacities: fluency in the tradition, and honesty about present reality. The Qur'an's framing of diversity is not tolerance-as-concession but design: "We made you peoples and tribes that you may know one another" (49:13).

## Technology and the digital ummah

The Qur'an is now searchable in a hundred languages; scholars answer questions across continents in seconds; and misinformation spreads just as fast. Digital *adab* — verifying before forwarding (49:6), guarding privacy, not backbiting in a group chat — is classical ethics applied to new pipes.

## Environment and stewardship

Humanity is *khalifah*, steward, and the Prophet planted the principles: do not waste water even at a flowing river; whoever plants a tree and a bird or human eats from it earns charity; the earth is a mosque. Islamic environmental scholarship (*mizan*, balance, 55:7–9) is one of the fastest-growing fields in contemporary fiqh.

## The task

Faith that cannot engage the century it lives in becomes nostalgia; engagement without roots becomes drift. The tradition's own instruction is to hold both: knowledge with justice, mercy with courage, and service to humanity as service to God.

## References across the schools

- **Qur'an**: 2:190, 2:256, 5:32, 30:41, 49:6, 49:13, 55:7–9, 96:1–5.
- **Sunni**: al-Shatibi, *al-Muwafaqat* (maqasid); the Amman Message (2005); International Islamic Fiqh Academy resolutions.
- **Shia**: Murtada Mutahhari, *Islam and the Requirements of Our Time*; Muhammad Baqir al-Sadr, *Iqtisaduna*; contemporary marja' fatawa on bioethics and finance.
- **Salafi/Wahhabi**: Ibn Baz and Ibn Uthaymin's fatawa condemning terrorism and the killing of non-combatants.$md$,
'4d7399d7-1a68-468c-8137-8b70fe3db03d','published', now(), 8,
array['modern','science','peace','environment'],'en'
);
