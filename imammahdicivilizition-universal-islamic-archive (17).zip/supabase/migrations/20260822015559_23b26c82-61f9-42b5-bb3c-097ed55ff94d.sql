CREATE TABLE public.autopilot_state (
  id text PRIMARY KEY,
  paused boolean NOT NULL DEFAULT false,
  pause_reason text,
  lease_until timestamptz,
  last_run_date date,
  last_error text,
  last_success_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.autopilot_state TO service_role;
ALTER TABLE public.autopilot_state ENABLE ROW LEVEL SECURITY;

INSERT INTO public.autopilot_state (id) VALUES ('daily');

CREATE TABLE public.daily_ticker (
  run_date date PRIMARY KEY,
  hijri text,
  theme text,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.daily_ticker TO anon;
GRANT SELECT ON public.daily_ticker TO authenticated;
GRANT ALL ON public.daily_ticker TO service_role;
ALTER TABLE public.daily_ticker ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Daily ticker is public" ON public.daily_ticker FOR SELECT TO anon, authenticated USING (true);