
CREATE TABLE public.team_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  country TEXT NOT NULL,
  languages TEXT,
  role TEXT NOT NULL,
  skills TEXT,
  experience TEXT,
  portfolio_url TEXT,
  motivation TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT INSERT ON public.team_applications TO anon;
GRANT SELECT, INSERT ON public.team_applications TO authenticated;
GRANT ALL ON public.team_applications TO service_role;

ALTER TABLE public.team_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit an application"
  ON public.team_applications FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view their own applications"
  ON public.team_applications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);
