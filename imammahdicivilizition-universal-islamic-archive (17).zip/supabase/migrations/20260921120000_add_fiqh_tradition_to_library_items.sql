-- Universal Fiqh categorisation for the Islamic library.
--
-- Additive and reversible in spirit: one nullable column, one check constraint
-- and one index. No existing column is altered and no existing row is rewritten
-- except the single entry whose own title already names its school.
--
-- NULL means "not recorded" and is rendered as "General / Unclassified".
-- An entry's school is never inferred from its subject matter.

ALTER TABLE public.library_items
  ADD COLUMN IF NOT EXISTS fiqh_tradition text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'library_items_fiqh_tradition_check'
  ) THEN
    ALTER TABLE public.library_items
      ADD CONSTRAINT library_items_fiqh_tradition_check
      CHECK (
        fiqh_tradition IS NULL
        OR fiqh_tradition IN ('general', 'hanafi', 'shafii', 'maliki', 'hanbali', 'jafari')
      );
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS library_items_fiqh_tradition_idx
  ON public.library_items (fiqh_tradition);

COMMENT ON COLUMN public.library_items.fiqh_tradition IS
  'School of jurisprudence this entry belongs to: general, hanafi, shafii, maliki, hanbali or jafari. NULL means not recorded and is displayed as General / Unclassified.';

-- The only backfill performed: this entry states its own school in its title.
UPDATE public.library_items
   SET fiqh_tradition = 'jafari'
 WHERE slug = 'fiqh-jafari-foundations'
   AND fiqh_tradition IS NULL;
