CREATE TABLE public.security_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_type TEXT NOT NULL DEFAULT 'suspicious_search_input',
  severity TEXT NOT NULL DEFAULT 'warn',
  source TEXT NOT NULL,
  raw_input TEXT NOT NULL,
  sanitized_input TEXT,
  reasons TEXT[] NOT NULL DEFAULT '{}',
  user_id UUID REFERENCES auth.users ON DELETE SET NULL,
  reviewed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, UPDATE ON public.security_events TO authenticated;
GRANT ALL ON public.security_events TO service_role;

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and reviewers can view security events"
ON public.security_events FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));

CREATE POLICY "Admins and reviewers can mark security events reviewed"
ON public.security_events FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'))
WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));

CREATE INDEX security_events_created_at_idx ON public.security_events (created_at DESC);
CREATE INDEX security_events_unreviewed_idx ON public.security_events (reviewed) WHERE reviewed = false;