
DROP POLICY "Anyone can submit an application" ON public.team_applications;

CREATE POLICY "Anonymous submissions only without user_id"
  ON public.team_applications FOR INSERT
  TO anon
  WITH CHECK (user_id IS NULL);

CREATE POLICY "Authenticated users submit as themselves"
  ON public.team_applications FOR INSERT
  TO authenticated
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());
