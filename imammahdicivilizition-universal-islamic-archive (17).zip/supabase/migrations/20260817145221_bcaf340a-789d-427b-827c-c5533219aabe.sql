
insert into public.articles (slug, title, excerpt, content, category_id, status, published_at, reading_minutes, tags, language) values
(
'companions-of-prophet-muhammad',
'The Companions of Prophet Muhammad ﷺ',
'Who the Sahabah were, the greatest among them, and how Sunni, Shia and Salafi scholarship evaluate them.',
$md$A *sahabi* is one who met the Prophet (ﷺ) as a believer and died in faith. They number in the thousands, and through them the Qur'an, the prayer and the Prophet's practice reached the next generation.

## The earliest and the eminent

- **Khadijah** — the first believer of all.
- **Ali ibn Abi Talib** — the first male youth to believe, raised in the Prophet's home.
- **Abu Bakr al-Siddiq** — the first among the free adult men; companion of the cave.
- **Bilal ibn Rabah** — tortured under the Makkan sun, later the caller to prayer.
- **Salman al-Farsi** — the Persian seeker of whom the Prophet said, "Salman is of us, the People of the House."
- **Abu Dharr al-Ghifari** — the outspoken critic of hoarded wealth.
- **Ammar ibn Yasir** — whose parents were the first martyrs of Islam.
- **Umm Ammarah (Nusaybah)** — who shielded the Prophet with her body at Uhud.

## Categories

Historians classify them as *Muhajirun* (the Makkan migrants), *Ansar* (the Madinan hosts), *Ahl Badr* (the 313), *Ahl Bay'at al-Ridwan* (Hudaybiyyah), and the *Tulaqa* — those freed and admitted at the conquest of Makkah, who entered late.

## How the traditions evaluate them

This is where the schools genuinely diverge.

- **Sunni** doctrine holds the Sahabah collectively upright (*adalat al-sahabah*): honest transmitters, though not sinless, and disputes among them are not to be relitigated.
- **Shia** scholarship distinguishes among them individually: many are venerated at the highest level — Salman, Abu Dharr, Ammar, Miqdad, Bilal, Jabir — while others, especially those who fought Imam Ali or entered Islam late for advantage, are criticised on historical evidence.
- **Salafi** thought takes the strongest form of the Sunni position, treating criticism of any companion as a grave matter.

## Reading responsibly

A Muslim can honour the sacrifices of the companions and still study history critically, using chains of transmission and primary sources rather than polemic. Insulting believers is forbidden in every school (49:11), and so is suspending the intellect. The Qur'an itself praises companions (9:100, 48:29) and warns of hypocrites among the Madinan population (9:101) — both statements are in the same book.

## References across the schools

- **Qur'an**: 8:74, 9:100, 9:101, 48:18, 48:29, 49:11.
- **Sunni**: Sahih al-Bukhari, Kitab Fada'il Ashab al-Nabi; Ibn Hajar, *al-Isabah fi Tamyiz al-Sahabah*.
- **Shia**: al-Tusi, *Rijal*; al-Barqi, *Rijal*; al-Mufid, *al-Jamal*.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah al-Nabawiyyah*; Ibn Baz on the status of the Sahabah.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 7,
array['sahabah','companions','history','rijal'],'en'
),
(
'four-rightly-guided-caliphs',
'The Four Rightly Guided Caliphs',
'Abu Bakr, Umar, Uthman and Ali: the thirty years after the Prophet, their achievements, and the Sunni–Shia difference over succession.',
$md$The three decades following the Prophet's death in 11 AH are called by Sunni tradition the *Khilafah Rashidah*, the rightly guided caliphate, on the basis of the hadith "the caliphate after me is thirty years."

## Abu Bakr (11–13 AH)

Chosen at the gathering of Saqifah. He faced the *Riddah* wars, held the peninsula together, and authorised the first compilation of the Qur'an into a single copy after the deaths of many memorisers at Yamamah. He lived austerely and reigned barely two years.

## Umar ibn al-Khattab (13–23 AH)

Under him Islam expanded into Persia, Syria, Egypt and Iraq. He established the *diwan* register of stipends, the Hijri calendar, judicial appointments and public granaries, and he was known for personally auditing his governors. He was assassinated in the mosque by Abu Lu'lu'ah.

## Uthman ibn Affan (23–35 AH)

He standardised the Qur'anic text into the *mushaf* copies sent to the main cities — the single most consequential act of preservation in Islamic history. His later years drew accusations of favouring his Umayyad relatives in appointments; rebels from Egypt and Iraq besieged his house and killed him while he was reciting the Qur'an.

## Ali ibn Abi Talib (35–40 AH)

He inherited a fractured community and refused to buy loyalty with public money. His caliphate was consumed by the Battle of the Camel, Siffin against Mu'awiyah, and the revolt of the Khawarij at Nahrawan. His letters and sermons, gathered in *Nahj al-Balagha*, remain among the highest literature in Arabic on justice and governance. He was assassinated in the mosque of Kufa in 40 AH.

## The two readings of succession

**Sunni** view: the Prophet left no binding designation; the community chose by consultation, and the order of the four caliphs reflects their order of merit.

**Shia** view: the Prophet designated Ali at Ghadir Khumm — "whoever's master I am, Ali is his master" — and leadership is a divine appointment, not an election. Shia Muslims therefore regard Ali as the first legitimate successor while still recording the historical caliphate as it occurred.

Understanding the argument on both sides, from their own primary sources, is the mark of an educated Muslim; reducing it to slogans is not.

## References across the schools

- **Sunni**: Sahih al-Bukhari, Kitab Fada'il al-Sahabah; Sunan Abi Dawud 4646; al-Tabari, *Tarikh*.
- **Shia**: al-Mufid, *al-Irshad*; al-Ya'qubi, *Tarikh*; *Nahj al-Balagha*, Sermon 3.
- **Shared**: the Ghadir report is recorded in Sunan Ibn Majah 116, Musnad Ahmad 4/281 and Shia sources alike; the schools differ on its interpretation, not its occurrence.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah*; Ibn Kathir, *al-Bidayah wa'l-Nihayah*.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 7,
array['caliphate','khilafah','history','succession'],'en'
),
(
'ahl-al-bayt-importance-in-islamic-history',
'Ahl al-Bayt — Their Importance in Islamic History',
'The Qur''anic verses, the hadith of the two weighty things, and the historical role of the Prophet''s household.',
$md$*Ahl al-Bayt* — the People of the House — denotes the Prophet's household. Every school of Islam honours them; the schools differ over the boundary of the term and the authority it carries.

## The Qur'anic basis

- **33:33** — "God only wishes to remove impurity from you, People of the House, and purify you completely."
- **42:23** — "Say: I ask of you no reward for it except love of the near kin."
- **3:61** — the verse of *Mubahalah*, where the Prophet brought Ali, Fatimah, Hasan and Husayn to the confrontation with the Christians of Najran, an event agreed by Sunni and Shia commentators.

## Hadith al-Thaqalayn

"I leave among you two weighty things: the Book of God and my family, my household. They will not separate until they return to me at the Pool." Recorded in Sahih Muslim 2408, Sunan al-Tirmidhi 3786, Musnad Ahmad, and throughout Shia collections. Shia scholarship reads it as establishing the Imams as authoritative guides alongside the Qur'an; Sunni scholarship generally reads it as a binding command to love, respect and consult the household.

## Historical role

The household did not withdraw from history. Ali governed as caliph and wrote the most searching Islamic literature on justice. Fatimah al-Zahra defended her inheritance and rights in public address. Hasan negotiated a treaty that prevented civil war. Husayn refused allegiance to Yazid and died at Karbala. Zaynab bint Ali carried the account of Karbala into the courts of Kufa and Damascus. Ali ibn al-Husayn (Zayn al-Abidin) left *al-Sahifah al-Sajjadiyyah*, the great book of supplication. Muhammad al-Baqir and Ja'far al-Sadiq taught thousands of students — Abu Hanifah and Malik among those who studied in that circle — making the household a fountain of Sunni as well as Shia jurisprudence.

## Why it matters today

The household models what the Qur'an calls for: knowledge joined to justice, and refusal to legitimise tyranny. Whatever a Muslim's school, sending blessings upon the Prophet *and his family* is recited in every prayer, five times a day, by all of them.

## References across the schools

- **Qur'an**: 3:61, 8:41, 33:33, 42:23.
- **Sunni**: Sahih Muslim 2404, 2408; al-Tirmidhi 3786, 3871; al-Hakim, *al-Mustadrak*.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Hujjah; al-Saduq, *Uyun Akhbar al-Rida*; *Bihar al-Anwar* vol. 23.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah* (affirming their rights while contesting Imamah); Ibn Kathir on 33:33.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 7,
array['ahl al-bayt','thaqalayn','mubahalah','aqeedah'],'en'
),
(
'twelve-imams-lives-knowledge-legacy',
'The 12 Imams — Their Lives, Knowledge and Legacy',
'A concise profile of each of the twelve Imams of Ahl al-Bayt, their contributions, and how Sunni scholarship regards them.',
$md$Twelver Shia Islam holds that after the Prophet (ﷺ) guidance continued through twelve divinely appointed Imams from his household. Sunni tradition does not accept Imamah as a creedal office, but the great majority of Sunni scholars revere these figures as scholars and saints, and Sunni chains of transmission and Sufi lineages pass through several of them.

## The twelve

1. **Ali ibn Abi Talib** (d. 40 AH) — caliph, judge, author of the sermons and letters of *Nahj al-Balagha*.
2. **Hasan ibn Ali** (d. 50 AH) — negotiated the treaty with Mu'awiyah to stop Muslim bloodshed.
3. **Husayn ibn Ali** (d. 61 AH) — martyred at Karbala refusing allegiance to Yazid.
4. **Ali ibn al-Husayn, Zayn al-Abidin** (d. 95 AH) — author of *al-Sahifah al-Sajjadiyyah* and the *Risalat al-Huquq* on rights.
5. **Muhammad al-Baqir** (d. 114 AH) — "the splitter open of knowledge"; teacher of a generation of jurists.
6. **Ja'far al-Sadiq** (d. 148 AH) — founder of the Ja'fari school of law; taught thousands, including Abu Hanifah and Malik ibn Anas.
7. **Musa al-Kazim** (d. 183 AH) — "the forbearing"; died in Abbasid imprisonment in Baghdad.
8. **Ali al-Rida** (d. 203 AH) — nominated heir apparent by al-Ma'mun; buried in Mashhad.
9. **Muhammad al-Jawad** (d. 220 AH) — reached the Imamate as a child; famed for debates with jurists.
10. **Ali al-Hadi** (d. 254 AH) — held under surveillance at Samarra; author of *Ziyarat al-Jami'ah*.
11. **Hasan al-Askari** (d. 260 AH) — taught under house arrest in Samarra.
12. **Muhammad al-Mahdi** — believed to be in occultation, to appear to fill the earth with justice.

## The shared intellectual legacy

Ja'far al-Sadiq's circle is a documented meeting point of Sunni and Shia scholarship. Zayn al-Abidin's supplications are read across the Muslim world. Al-Rida's shrine city became a centre of learning for all schools.

## Where the schools differ

Shia doctrine holds the Imams infallible (*ma'sum*) and divinely designated. Sunni doctrine holds them righteous scholars and descendants of the Prophet deserving love, without infallibility or binding authority. Salafi scholarship affirms their piety while rejecting infallibility, intercession through them, and shrine veneration.

## References across the schools

- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Hujjah; al-Mufid, *al-Irshad*; al-Saduq, *Kamal al-Din*; al-Majlisi, *Bihar al-Anwar*.
- **Sunni**: Sahih al-Bukhari 7222 and Sahih Muslim 1821 ("twelve leaders, all from Quraysh"); Ibn Hajar al-Haytami, *al-Sawa'iq al-Muhriqah*; al-Dhahabi, *Siyar A'lam al-Nubala* (entries on al-Baqir, al-Sadiq, al-Rida).
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah*, on the twelve report and its interpretation.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 8,
array['imams','ahl al-bayt','shia','history'],'en'
),
(
'imam-ali-ibn-abi-talib-life-character-legacy',
'Imam Ali ibn Abi Talib — Life, Character and Legacy',
'The Prophet''s cousin, ward and son-in-law: warrior, judge, caliph, and the author of Islam''s finest writing on justice.',
$md$Ali ibn Abi Talib was born in Makkah around 600 CE, reportedly within the precinct of the Ka'bah, and raised in the Prophet's own household. He was the first youth to accept Islam and the man the Prophet called "my brother in this world and the next."

## The years of struggle

He slept in the Prophet's bed on the night of the Hijrah while assassins surrounded the house. He carried the standard at Badr, held the line at Uhud, and at Khaybar was given the banner after the Prophet said he would hand it to "one who loves God and His Messenger and whom they love." At Tabuk the Prophet left him over Madinah with the words: "Are you not content to be to me as Harun was to Musa, except that there is no prophet after me?"

## The scholar and judge

The Prophet said, "I am the city of knowledge and Ali is its gate." Umar ibn al-Khattab's repeated remark — "were it not for Ali, Umar would have perished" — is recorded in Sunni sources over the difficulty of legal cases. Ali structured Arabic grammar's foundations with Abu al-Aswad al-Du'ali, judged with famous precision, and formulated principles of evidence.

## The caliph

He accepted the caliphate in 35 AH over a community already fractured by the killing of Uthman. He refused to distribute public wealth as political payment, dismissed corrupt governors, and consequently faced the Battle of the Camel, Siffin, and the Khawarij at Nahrawan. His letter appointing Malik al-Ashtar over Egypt — instructing him that the people are "either your brother in faith or your equal in creation" — is studied today as a charter of just administration and has been cited by the United Nations Development Programme as a model of governance.

## The character

He owned little, patched his own sandals, fed orphans, and was assassinated by Ibn Muljam while praying in the mosque of Kufa in Ramadan 40 AH. His dying instruction to his sons was to fear God, protect orphans, and never abandon justice — and to give his killer only the punishment due, no more.

## Legacy

For Shia Muslims he is the first Imam and designated successor. For Sunni Muslims he is the fourth rightly guided caliph and the greatest of judges. Sufi orders trace almost all their chains to him. *Nahj al-Balagha* remains a landmark of Arabic prose.

## References across the schools

- **Qur'an**: 2:207, 5:55, 3:61, 33:33 (as read by the commentators).
- **Sunni**: Sahih al-Bukhari 3706, 4210; Sahih Muslim 2404, 2408; al-Hakim, *al-Mustadrak*.
- **Shia**: *Nahj al-Balagha* (esp. Letter 53); al-Mufid, *al-Irshad*; al-Kulayni, *al-Kafi*.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah*; Ibn Kathir, *al-Bidayah wa'l-Nihayah*, biography of Ali.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 8,
array['imam ali','justice','nahj al-balagha','history'],'en'
),
(
'imam-husayn-and-tragedy-of-karbala',
'Imam Husayn ibn Ali and the Tragedy of Karbala',
'Why the Prophet''s grandson refused allegiance to Yazid, what happened on Ashura, and what the stand means.',
$md$Husayn ibn Ali, grandson of the Prophet (ﷺ), was killed with his family and companions on the plain of Karbala on 10 Muharram 61 AH (680 CE). The event is the most commemorated day in Shia Islam and is mourned by Muslims far beyond it.

## The refusal

When Mu'awiyah died in 60 AH, his son Yazid took power and demanded allegiance from Husayn. The demand was not a formality — it was a request to legitimise hereditary rule by a man whose public conduct Husayn considered a repudiation of the Prophet's example. Husayn's answer was recorded: "A man like me does not pledge allegiance to a man like him." He left Madinah for Makkah, and then, on the invitation of thousands of letters from Kufa, set out for Iraq.

## The siege

The Kufan support collapsed under the governor Ubaydullah ibn Ziyad. Husayn's caravan of roughly seventy-two fighting men, with women and children, was intercepted by al-Hurr's cavalry and forced to halt at Karbala on 2 Muharram. From the 7th the water of the Euphrates was cut off. Husayn offered to withdraw; the army under Umar ibn Sa'd was ordered to accept nothing but submission or battle.

## Ashura

On the morning of the tenth, the companions of Husayn fell one by one — Habib ibn Mazahir, Muslim ibn Awsajah, Zuhayr, al-Hurr who defected back to Husayn, the sons of Aqil, Ali al-Akbar, and Abbas ibn Ali who died trying to bring water to the children. Husayn was killed last. The infant Abdullah was killed in his arms. The tents were burned and the survivors — Zaynab bint Ali and the ill Ali ibn al-Husayn among them — were marched as captives to Kufa and Damascus.

## Zaynab's role

The stand would have been buried as a border skirmish without Zaynab. Her addresses in the court of Ibn Ziyad and before Yazid turned a military massacre into a permanent moral indictment. "I saw nothing but beauty" is her recorded answer when mocked about God's decree.

## What it means

Karbala is not only grief; it is a political and ethical argument: legitimacy comes from justice, not from power, and there are conditions under which silence is complicity. Sunni scholars from al-Tabari to Ibn Kathir record the tragedy and condemn the killing; Ghandi, Tagore and countless reformers cited Husayn as a model of principled resistance.

## References across the schools

- **Sunni**: al-Tabari, *Tarikh al-Rusul wa'l-Muluk*, year 61; Ibn Kathir, *al-Bidayah wa'l-Nihayah*; al-Tirmidhi 3768 (Hasan and Husayn as masters of the youth of Paradise).
- **Shia**: Abu Mikhnaf, *Maqtal al-Husayn*; al-Mufid, *al-Irshad*; Ibn Tawus, *al-Luhuf*; *Bihar al-Anwar* vol. 45.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Ra's al-Husayn*, condemning the killing while criticising ritual mourning practices.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 8,
array['karbala','husayn','ashura','justice'],'en'
),
(
'imam-mahdi-islamic-beliefs-awaited-savior',
'Imam Mahdi — Islamic Beliefs About the Awaited Savior',
'What Sunni, Shia and Salafi sources actually say about the Mahdi, the occultation, and awaiting with action.',
$md$Belief that God will send a guided leader to fill the earth with justice after it has been filled with oppression is not a sectarian peculiarity. It is reported in Sunni, Shia and Salafi hadith literature alike; the schools differ over identity and mechanism, not over the promise.

## The Sunni position

Sunan Abi Dawud, Sunan al-Tirmidhi and Sunan Ibn Majah contain a "Book of the Mahdi". The reports state that he will be of the Prophet's family, from the descendants of Fatimah, that his name will match the Prophet's, that he will rule seven or nine years, and that Isa (Jesus) will descend and pray behind him. Ibn Khaldun questioned some chains, but the doctrine is affirmed by the great majority of Sunni scholars, and the Salafi tradition affirms it explicitly — Ibn Baz and Ibn Uthaymin both stated the reports reach the level of *mutawatir* in meaning.

## The Shia position

Twelver Shia belief identifies the Mahdi as **Muhammad ibn al-Hasan al-Askari**, born in Samarra in 255 AH, the twelfth Imam. He entered a **minor occultation** (874–941 CE) during which four successive deputies relayed communication, and then the **major occultation**, which continues. In his absence, general authority passes to qualified jurists (*niyabah ammah*), the basis of the modern institution of *marja'iyyah*.

## Signs and cautions

Sources mention the appearance of Sufyani, a cry from the sky, the emergence of Dajjal, and the descent of Isa. Every school also warns against date-setting and against claimants: history is full of failed Mahdis, and the Prophet warned of many liars.

## Awaiting correctly

The strongest teaching in both traditions is that *intizar* — awaiting — is active, not passive. The Imams taught that the best deed is "awaiting relief" while preparing oneself: acquiring knowledge, establishing justice locally, and living so that one would be fit to serve him if he appeared tomorrow. A person waiting for a just leader while ignoring injustice within reach has misunderstood the belief.

## References across the schools

- **Sunni**: Sunan Abi Dawud 4282–4290; Sunan al-Tirmidhi 2230–2232; Sunan Ibn Majah 4082–4088; al-Suyuti, *al-Urf al-Wardi*.
- **Shia**: al-Saduq, *Kamal al-Din wa Tamam al-Ni'mah*; al-Nu'mani, *al-Ghaybah*; al-Tusi, *al-Ghaybah*; al-Kulayni, *al-Kafi*, Kitab al-Hujjah.
- **Salafi/Wahhabi**: Ibn Baz, *Fatawa* on the Mahdi; Ibn Uthaymin, *Sharh al-Aqidah al-Wasitiyyah*; al-Albani's grading of the Mahdi reports.$md$,
'dd222d56-ee58-40a1-bd31-cbb25d990e07','published', now(), 8,
array['mahdi','occultation','eschatology','justice'],'en'
),
(
'dajjal-signs-of-the-hour-end-times',
'Dajjal, Signs of the Hour and the End Times',
'The minor and major signs, who Dajjal is, and how to read eschatological hadith responsibly.',
$md$Islamic eschatology divides the signs of the Hour into *minor* signs, which unfold gradually across history, and *major* signs, which occur in sequence near the end.

## Minor signs

Reported in Bukhari, Muslim and the Shia collections: the sending of the Prophet himself as the first sign, the spread of ignorance despite widespread literacy, the loss of trustworthiness, competition in tall buildings among former shepherds, widespread killing without cause, the disappearance of scholars, treating interest as normal, and time seeming to pass faster.

## Dajjal

*al-Masih al-Dajjal* — the false messiah. The reports describe a one-eyed figure with *kafir* written between his eyes, readable by any believer; a claimant to divinity who travels the earth rapidly, carrying what appears to be paradise and fire, water and drought. He will deceive by spectacle and dominate through resources. The Prophet said no trial greater has existed since Adam, taught the *isti'adhah* from the trial of Dajjal in every prayer's final sitting, and prescribed memorising the first (or last) ten verses of Surah al-Kahf as protection. He will not enter Makkah or Madinah.

## Isa ibn Maryam

Jesus descends near the white minaret east of Damascus, breaks the cross, abolishes the jizyah, kills Dajjal at the gate of Ludd, and rules by the Qur'an. Sunni, Shia and Salafi sources agree, and Shia sources add that he prays behind Imam Mahdi — a report also found in Sunni collections.

## Other major signs

Ya'juj and Ma'juj; the emergence of the Beast; the rising of the sun from the west, after which repentance is no longer accepted; three landslides; the smoke; and finally the fire that drives people to their place of gathering.

## Reading these reports responsibly

Three cautions apply across all schools:

1. **No date-setting.** "None knows its timing but He" (7:187).
2. **No political mapping.** Every generation has identified its enemies as Dajjal or Ya'juj, and every generation so far has been wrong.
3. **Preparation, not prediction.** The point of the reports is moral readiness: the Prophet's advice to one who lives to see Dajjal is to flee from him, not to hunt him.

## References across the schools

- **Qur'an**: 7:187, 18:83–99, 27:82, 43:61, 44:10, 54:1.
- **Sunni**: Sahih Muslim 2937 (the long hadith of Tamim al-Dari and al-Jassasah), 2901 (the ten major signs); Sahih al-Bukhari 7131.
- **Shia**: al-Saduq, *Kamal al-Din*; al-Nu'mani, *al-Ghaybah*; *Bihar al-Anwar* vol. 52.
- **Salafi/Wahhabi**: Ibn Kathir, *al-Nihayah fi al-Fitan wa'l-Malahim*; Ibn Uthaymin on the signs of the Hour.$md$,
'0138a262-841f-4b01-8ef5-9f2ec055307e','published', now(), 7,
array['dajjal','signs','end times','eschatology'],'en'
);
