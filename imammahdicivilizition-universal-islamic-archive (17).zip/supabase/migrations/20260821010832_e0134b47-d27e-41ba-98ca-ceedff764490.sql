INSERT INTO public.articles (slug, title, excerpt, content, status, language, reading_minutes, tags, published_at)
VALUES ('muslim-scientists-700-ce', 'Muslim Scientists of 700 CE — The First Century of Islamic Science', 'How the first Islamic century (around 700 CE) produced Imam Ja''far al-Sadiq''s scientific circle, Jabir ibn Hayyan''s chemistry, the first translation movement, quarantine medicine and qibla astronomy — with Shia, Sunni and Western references.', '
## The Century That Lit the Lamp

Around the year 700 CE (roughly 80 AH) the Muslim world was barely three generations old, yet it already stretched from the Indus to the Atlantic. In that single century the community moved from conquest to curiosity: translation halls opened, hospitals were endowed, observatories were funded, and the study of nature was framed as an act of worship — "the ink of the scholar is more sacred than the blood of the martyr" was not a slogan but a policy.

This article surveys the scientists of the first Islamic century and the ones who directly built on them, with references drawn from Shia, Sunni, and Salafi scholarly traditions as well as modern Western historians of science.

## 1. Imam Ja''far al-Sadiq (a.s.) — The Teacher of the Sciences (83–148 AH / 702–765 CE)

The sixth Imam of the Ahl al-Bayt taught in Madinah to a circle that historians place at four thousand students. Among them were Abu Hanifa and Malik ibn Anas, founders of two Sunni schools — a fact recorded with respect in Sunni sources.

His scientific legacy includes:

- **Cosmology**: statements attributed to him describe the earth as a body suspended and rotating, and light as travelling in rays that reach the eye.
- **Embryology and medicine**: the dictations gathered in *Tawhid al-Mufaddal* discuss digestion, the senses, bone structure, and the purposeful design of the body.
- **Method**: he insisted that observation and reason (aql) confirm revelation rather than compete with it.

## 2. Jabir ibn Hayyan (c. 721–815 CE) — The Father of Chemistry

Jabir, known in Latin Europe as *Geber*, repeatedly names Imam Ja''far al-Sadiq as his teacher. He is credited with:

- Isolating and describing **acids** (including nitric and hydrochloric preparations) and processes such as **distillation, crystallisation, sublimation, calcination and evaporation**.
- Insisting on the **experiment** as the arbiter of truth: "The first essential is that you should perform practical work and conduct experiments, for he who does not is never successful."
- Introducing systematic laboratory apparatus — the alembic, the retort, controlled heating baths.

Modern historians of science (Holmyard, Sarton) regard him as the point where alchemy begins to become chemistry.

## 3. Khalid ibn Yazid (d. c. 704 CE) — The First Patron

An Umayyad prince who abandoned the pursuit of power for the pursuit of knowledge. He commissioned the first translations of Greek and Coptic works on medicine, astronomy and alchemy into Arabic — the earliest recorded act of state-funded science in Islam. Ibn al-Nadim''s *al-Fihrist* preserves the record.

## 4. Al-Harith ibn Kalada and Early Islamic Medicine

Medicine in the first century rested on Prophetic guidance about hygiene, quarantine, diet and moderation — including the celebrated instruction not to enter or leave a land struck by plague, cited in Bukhari and Muslim, which is nothing less than an early quarantine protocol. Physicians such as al-Harith ibn Kalada and, in the Umayyad court, Ibn Athal, laid the ground for the great hospitals (*bimaristans*) of the following century.

## 5. Astronomy Born from Worship

Three religious needs made astronomy a necessity, not a luxury:

1. **Prayer times** — determined by the sun''s altitude and shadow lengths.
2. **The qibla** — a spherical-trigonometry problem solved centuries before Europe attempted it.
3. **The Hijri calendar** — requiring lunar visibility prediction.

From this need came the refinement of the **astrolabe**, the building of observatories at Baghdad and Damascus under al-Ma''mun, and, within a generation, the work of **al-Khwarizmi** (c. 780–850 CE), whose *Kitab al-Jabr* gives us the word *algebra* and whose name gives us *algorithm*.

## 6. What Made It Possible

- **A Qur''anic mandate**: dozens of verses command reflection on the heavens, the earth, the alternation of night and day, and the human body itself.
- **Freedom of transmission**: Greek, Persian, Indian and Syriac knowledge was translated without prejudice to its origin.
- **Institutions**: endowments (*waqf*) funded libraries, hospitals and schools with permanent, non-political income.
- **A shared language**: Arabic became the scientific lingua franca from Samarqand to Cordoba.

## 7. Why It Matters Today

The first Islamic century proves that faith and science were never rivals in the Muslim intellectual tradition — they shared a single premise: that the universe is ordered, knowable and meaningful. Reviving that premise is the work of every Muslim student, engineer and researcher today.

## References

1. Ibn al-Nadim, *al-Fihrist* — on Khalid ibn Yazid and Jabir ibn Hayyan.
2. *Tawhid al-Mufaddal*, dictated by Imam Ja''far al-Sadiq (a.s.).
3. Sahih al-Bukhari & Sahih Muslim — hadith of plague and quarantine.
4. E. J. Holmyard, *Alchemy* (1957) — on Jabir''s experimental method.
5. George Sarton, *Introduction to the History of Science*, Vol. I.
6. Seyyed Hossein Nasr, *Science and Civilization in Islam*.
7. Ibn Abi Usaybi''a, *Uyun al-Anba'' fi Tabaqat al-Atibba''* — early physicians.
', 'published', 'en', 11,
 ARRAY['science','history','astronomy','medicine','jabir','khwarizmi','knowledge'], now())
ON CONFLICT (slug) DO UPDATE SET title=EXCLUDED.title, excerpt=EXCLUDED.excerpt, content=EXCLUDED.content, tags=EXCLUDED.tags, status='published', published_at=now();