-- ============ ARTICLES: additive pipeline columns ============
ALTER TABLE public.articles
  ADD COLUMN IF NOT EXISTS pipeline_status text NOT NULL DEFAULT 'published',
  ADD COLUMN IF NOT EXISTS quality_score integer,
  ADD COLUMN IF NOT EXISTS quality_report jsonb,
  ADD COLUMN IF NOT EXISTS seo_title text,
  ADD COLUMN IF NOT EXISTS meta_description text,
  ADD COLUMN IF NOT EXISTS og_title text,
  ADD COLUMN IF NOT EXISTS og_description text,
  ADD COLUMN IF NOT EXISTS keywords text[],
  ADD COLUMN IF NOT EXISTS image_prompt text,
  ADD COLUMN IF NOT EXISTS image_alt_text text,
  ADD COLUMN IF NOT EXISTS image_generation_status text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS refs jsonb NOT NULL DEFAULT '{"quran":[],"hadith":[],"historical":[],"additional":[]}'::jsonb,
  ADD COLUMN IF NOT EXISTS verification_status text NOT NULL DEFAULT 'unverified',
  ADD COLUMN IF NOT EXISTS verification_notes jsonb,
  ADD COLUMN IF NOT EXISTS scheduled_for timestamptz,
  ADD COLUMN IF NOT EXISTS duplicate_of uuid,
  ADD COLUMN IF NOT EXISTS similarity_score numeric,
  ADD COLUMN IF NOT EXISTS topic_id uuid,
  ADD COLUMN IF NOT EXISTS generation_meta jsonb,
  ADD COLUMN IF NOT EXISTS view_count integer NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_articles_pipeline_status ON public.articles (pipeline_status);
CREATE INDEX IF NOT EXISTS idx_articles_scheduled_for ON public.articles (scheduled_for) WHERE scheduled_for IS NOT NULL;

-- Existing rows keep behaving exactly as before.
UPDATE public.articles SET pipeline_status = status WHERE pipeline_status IS DISTINCT FROM status;

-- ============ CONTENT TOPICS ============
CREATE TABLE IF NOT EXISTS public.content_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  normalized_title text GENERATED ALWAYS AS (lower(regexp_replace(title, '[^a-zA-Z0-9]+', ' ', 'g'))) STORED,
  category text NOT NULL DEFAULT 'general',
  language text NOT NULL DEFAULT 'en',
  priority integer NOT NULL DEFAULT 50,
  keywords text[] NOT NULL DEFAULT '{}',
  angle text,
  status text NOT NULL DEFAULT 'idea',
  last_error text,
  attempts integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_content_topics_unique ON public.content_topics (normalized_title);
CREATE INDEX IF NOT EXISTS idx_content_topics_status ON public.content_topics (status, priority DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.content_topics TO authenticated;
GRANT ALL ON public.content_topics TO service_role;
ALTER TABLE public.content_topics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage content topics" ON public.content_topics
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_content_topics_updated_at BEFORE UPDATE ON public.content_topics
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ ENGINE SETTINGS (singleton) ============
CREATE TABLE IF NOT EXISTS public.content_engine_settings (
  id text PRIMARY KEY DEFAULT 'default',
  auto_publish boolean NOT NULL DEFAULT false,
  auto_image boolean NOT NULL DEFAULT true,
  auto_translation boolean NOT NULL DEFAULT false,
  auto_seo boolean NOT NULL DEFAULT true,
  auto_verification boolean NOT NULL DEFAULT true,
  articles_per_day integer NOT NULL DEFAULT 1,
  max_articles_per_day integer NOT NULL DEFAULT 3,
  publish_time text NOT NULL DEFAULT '06:00',
  default_language text NOT NULL DEFAULT 'en',
  categories text[] NOT NULL DEFAULT '{}',
  daily_generation_limit integer NOT NULL DEFAULT 40,
  monthly_generation_limit integer NOT NULL DEFAULT 600,
  min_quality_score integer NOT NULL DEFAULT 75,
  max_similarity numeric NOT NULL DEFAULT 0.72,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.content_engine_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

GRANT SELECT, INSERT, UPDATE ON public.content_engine_settings TO authenticated;
GRANT ALL ON public.content_engine_settings TO service_role;
ALTER TABLE public.content_engine_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage engine settings" ON public.content_engine_settings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_content_engine_settings_updated_at BEFORE UPDATE ON public.content_engine_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ API USAGE / COST MONITOR ============
CREATE TABLE IF NOT EXISTS public.content_api_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL,
  provider text,
  model text,
  success boolean NOT NULL DEFAULT true,
  error_message text,
  duration_ms integer,
  estimated_cost numeric NOT NULL DEFAULT 0,
  usage_date date NOT NULL DEFAULT (now() AT TIME ZONE 'utc')::date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_content_api_usage_date ON public.content_api_usage (usage_date DESC);

GRANT SELECT ON public.content_api_usage TO authenticated;
GRANT ALL ON public.content_api_usage TO service_role;
ALTER TABLE public.content_api_usage ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read api usage" ON public.content_api_usage
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- ============ ARTICLE REVISIONS ============
CREATE TABLE IF NOT EXISTS public.article_revisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id uuid NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
  version integer NOT NULL DEFAULT 1,
  previous_content text,
  new_content text,
  previous_title text,
  new_title text,
  change_reason text,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_article_revisions_article ON public.article_revisions (article_id, version DESC);

GRANT SELECT, INSERT ON public.article_revisions TO authenticated;
GRANT ALL ON public.article_revisions TO service_role;
ALTER TABLE public.article_revisions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read article revisions" ON public.article_revisions
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins write article revisions" ON public.article_revisions
  FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));