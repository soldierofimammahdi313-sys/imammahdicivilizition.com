
insert into public.articles (slug, title, excerpt, content, category_id, status, published_at, reading_minutes, tags, language) values
(
'hajj-history-rituals-spiritual-meaning',
'Hajj — History, Rituals and Spiritual Meaning',
'The pilgrimage from Ibrahim to today: its rites day by day, its conditions, and the meaning behind each station.',
$md$Hajj is obligatory once in a lifetime on every Muslim who is adult, sane, and able in body and means, with a safe route and provision left for dependants (Qur'an 3:97). It is performed in Dhu al-Hijjah, and no other worship gathers Muslims of every school, language and class into one uniform garment at one place.

## The Ibrahimic root

The Ka'bah is described as the first house appointed for humanity (3:96), raised by Ibrahim and Isma'il (2:127). The *sa'i* between Safa and Marwah re-enacts Hajar's search for water for her infant; the stoning at Mina recalls Ibrahim's rejection of temptation; the sacrifice recalls the ransomed son. Hajj is therefore a physical re-performance of a family's trust in God.

## The rites in sequence

1. **Ihram** — two unstitched cloths for men, ordinary modest dress for women, entered at the *miqat* with the *talbiyah*: *Labbayk Allahumma labbayk*.
2. **Tawaf** — seven circuits of the Ka'bah, anticlockwise, beginning at the Black Stone.
3. **Sa'i** — seven passages between Safa and Marwah.
4. **8th Dhu al-Hijjah** — to Mina.
5. **9th — Arafah** — standing from noon to sunset; the Prophet said "Hajj is Arafah."
6. **Muzdalifah** — night under the open sky, collecting pebbles.
7. **10th** — stoning of Jamarat al-Aqabah, sacrifice, shaving or trimming, then Tawaf al-Ifadah.
8. **11th–13th** — Mina, stoning the three pillars daily.
9. **Tawaf al-Wada** — the farewell circuit.

Shia fiqh most commonly performs *Hajj al-Tamattu'* for those outside the sacred precinct, treats *tawaf al-nisa* as an additional required circuit, and follows its own detail on the sacrifice and stoning timings; the outward sequence is otherwise shared.

## The meaning

Ihram strips rank: no thread of status, no perfume, no argument, no hunting, no harm. Arafah is a rehearsal of standing before God at the resurrection. The farewell tawaf teaches that you leave the House but the House does not leave you.

## References across the schools

- **Qur'an**: 2:125–128, 2:196–203, 3:96–97, 22:26–29.
- **Sunni**: Sahih Muslim 1218 (Jabir's full description of the Prophet's Hajj); Sahih al-Bukhari, Kitab al-Hajj.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Hajj; al-Sistani, *Manasik al-Hajj*.
- **Salafi/Wahhabi**: Ibn Uthaymin, *Sifat al-Hajj wa'l-Umrah*; Ibn Baz, *Fatawa al-Hajj*.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 8,
array['hajj','pilgrimage','makkah','worship'],'en'
),
(
'umrah-complete-guide-spiritual-significance',
'Umrah — Complete Islamic Guide and Spiritual Significance',
'A step-by-step guide to the lesser pilgrimage: ihram, tawaf, sa''i, and release — plus its rulings and rewards.',
$md$Umrah is the "lesser pilgrimage": the visit to the Ka'bah performable at any time of year, far shorter than Hajj and without Arafah, Muzdalifah or Mina. The Prophet (ﷺ) said that one Umrah to the next is an expiation for what falls between them.

## Is it obligatory?

Shafi'i, Hanbali and mainstream Shia fiqh hold Umrah obligatory once in a lifetime for the able. Hanafi and Maliki fiqh classify it as a strongly emphasised sunnah. All agree it is among the most rewarded voluntary acts, and its reward multiplies in Ramadan.

## The four steps

1. **Ihram at the miqat** — bathe, put on the two white cloths (men) or modest dress (women), pray two rak'ahs, form the intention and begin the talbiyah. From this moment the ihram prohibitions apply: no perfume, no cutting hair or nails, no intimacy, no arguing, no hunting.
2. **Tawaf** — seven circuits of the Ka'bah starting at the Black Stone, followed by two rak'ahs behind Maqam Ibrahim and drinking Zamzam.
3. **Sa'i** — seven passages between Safa and Marwah, beginning at Safa.
4. **Halq or taqsir** — shaving or trimming the hair, which releases you from ihram. Shia pilgrims performing *Umrah mufradah* additionally perform *tawaf al-nisa* and its two rak'ahs before intimacy becomes lawful again.

## Common mistakes

Crossing the miqat without ihram (requiring a return or expiation), inventing a specific du'a for each circuit — none is fixed, so supplicate freely — touching or kissing the Black Stone by force and harming others, and treating the trip as tourism with a ritual attached.

## The inner work

Umrah is deliberately small: arrival, circuit, search, release. It teaches the shape of every return to God — you come stripped, you orbit the centre, you strive between two points, and you leave lighter.

## References across the schools

- **Qur'an**: 2:158, 2:196, 22:27.
- **Sunni**: Sahih al-Bukhari 1773; Sahih Muslim 1349 (Umrah in Ramadan equals a Hajj in reward).
- **Shia**: al-Tusi, *Tahdhib al-Ahkam*, Kitab al-Hajj; al-Khu'i, *Manasik*.
- **Salafi/Wahhabi**: Ibn Uthaymin, *Sifat al-Hajj wa'l-Umrah*; Permanent Committee fatawa on the miqat.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 6,
array['umrah','pilgrimage','ihram','tawaf'],'en'
),
(
'seerah-of-prophet-muhammad',
'The Seerah of Prophet Muhammad ﷺ',
'The discipline of studying the Prophet''s biography: its sources, its major phases, and how Sunni and Shia historians differ.',
$md$*Seerah* means the recorded path of a life. As a science it is older than most Muslim disciplines — the first monographs on the Prophet's campaigns were written within a century of his death — and it is the frame through which the Qur'an becomes intelligible.

## The primary sources

- **Ibn Ishaq** (d. 150 AH), whose *Sirah* survives in the recension of **Ibn Hisham**.
- **al-Waqidi**, *Kitab al-Maghazi*, and his secretary **Ibn Sa'd**, *al-Tabaqat al-Kubra*.
- **al-Tabari**, *Tarikh al-Rusul wa'l-Muluk*, preserving chains other works dropped.
- The **hadith collections**, especially Bukhari's *Kitab al-Maghazi* and Muslim's campaign reports.
- Shia historiography: **al-Ya'qubi**, *Tarikh*; **al-Mas'udi**, *Muruj al-Dhahab*; **al-Mufid**, *al-Irshad*; and *Bihar al-Anwar* vols. 15–22.

Salafi scholarship favours seerah filtered through hadith authentication — al-Albani's critiques and al-Mubarakpuri's *al-Rahiq al-Makhtum* are typical.

## The phases

1. **Makkah, 570–610** — lineage, orphanhood, trade, marriage to Khadijah, the rebuilding of the Ka'bah.
2. **Secret call, 610–613** — the first believers, revelation in fragments.
3. **Public call and persecution, 613–622** — boycott, Abyssinia, the Year of Sorrow, Ta'if, Isra and Mi'raj, the pledges of Aqabah.
4. **Madinah, 622–630** — constitution, brotherhood, Badr, Uhud, the Trench, Hudaybiyyah.
5. **Consolidation, 630–632** — conquest of Makkah, Hunayn, Tabuk, delegations, Farewell Pilgrimage.

## Where accounts diverge

Sunni and Shia historians agree on the overwhelming majority of events and dates. Divergence concentrates on the succession — the meaning of Ghadir Khumm, the events at Saqifah — and on the evaluation of individual companions. Reading both traditions side by side, with attention to chains of transmission, is better scholarship than reading either alone.

## How to study it

Pair the biography with the Qur'an's occasions of revelation, and read for pattern rather than anecdote: how he negotiated, how he treated opponents after victory, how he delegated, how he handled failure at Uhud.

## References across the schools

- **Qur'an**: 33:21, 8:5–19 (Badr), 3:121–155 (Uhud), 48:1–29 (Hudaybiyyah).
- **Sunni**: Ibn Hisham; Ibn Kathir, *al-Bidayah wa'l-Nihayah*; Sahih al-Bukhari, Kitab al-Maghazi.
- **Shia**: al-Mufid, *al-Irshad*; al-Ya'qubi, *Tarikh*; Ja'far Subhani, *The Message*.
- **Salafi/Wahhabi**: al-Mubarakpuri, *al-Rahiq al-Makhtum*; al-Albani, *Difa an al-Hadith al-Nabawi*.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 7,
array['seerah','history','biography','sources'],'en'
),
(
'the-hijrah-migration-makkah-to-madinah',
'The Hijrah — Migration from Makkah to Madinah',
'The migration that started the Islamic calendar: why it happened, how it unfolded, and what it built.',
$md$In 622 CE the Prophet (ﷺ) left Makkah for Yathrib. Muslims date their calendar not from his birth, nor from the first revelation, but from this journey — because it marks the moment a persecuted message became a functioning society.

## Why it happened

After thirteen years of boycott, torture and the deaths of Khadijah and Abu Talib, the Quraysh leadership resolved to kill the Prophet, with one man from each clan striking together so that Banu Hashim could not demand vengeance from a single tribe (Qur'an 8:30). Meanwhile delegations from Yathrib had pledged at Aqabah to protect him.

## The journey

Ali ibn Abi Talib slept in the Prophet's bed to cover the departure — an act Shia and Sunni sources both record, and which Shia tradition connects to Qur'an 2:207 on the one who sells his soul seeking God's pleasure. The Prophet travelled with Abu Bakr, sheltering three days in the cave of Thawr, the episode referenced in "the second of two, when they were in the cave" (9:40). Guided by Abdullah ibn Urayqit, they took a southern route and arrived at Quba, where the first mosque was built, then entered Yathrib.

## What was built there

- **Masjid al-Nabawi** — mosque, court, school, treasury and shelter for the destitute *ahl al-suffah*.
- **Mu'akhah** — the pairing of each Muhajir with an Ansari host in formal brotherhood.
- **The Constitution of Madinah** — a written compact making Muslims, the Jewish tribes and allied clans one community for defence, with religious autonomy and defined obligations.

Yathrib became *Madinat al-Nabi*, the City of the Prophet.

## The lesson

Hijrah is not only geography. The Prophet defined the *muhajir* as "one who abandons what God has forbidden." Migration in Islamic ethics means moving from a state where you cannot practise or grow into one where you can — physically when necessary, morally always.

## References across the schools

- **Qur'an**: 2:207, 8:30, 9:40, 9:100, 16:41.
- **Sunni**: Sahih al-Bukhari 3905 (A'ishah's account of the migration); Ibn Hisham, *al-Sirah*.
- **Shia**: al-Mufid, *al-Irshad*; al-Tabrisi, *I'lam al-Wara*; *Bihar al-Anwar* vol. 19.
- **Salafi/Wahhabi**: al-Mubarakpuri, *al-Rahiq al-Makhtum*, chapter on the Hijrah.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 6,
array['hijrah','madinah','calendar','history'],'en'
),
(
'battle-of-badr-history-and-lessons',
'The Battle of Badr — History and Lessons',
'The first major engagement of Islam: what happened at Badr in 2 AH and the principles it established.',
$md$Badr, fought on 17 Ramadan 2 AH (624 CE), was the first open battle between the Muslims of Madinah and the Quraysh of Makkah. Roughly 313 believers, with two horses and seventy camels between them, faced some 1,000 well-equipped Makkans. The Qur'an calls the day *yawm al-furqan* — the day of distinction between truth and falsehood (8:41).

## How it began

The Muslims set out to intercept a Qurayshi caravan returning under Abu Sufyan — compensation, in principle, for the property confiscated from the migrants in Makkah. The caravan escaped; the Makkan army marched anyway. The Prophet consulted his companions, and the Ansar pledged to fight beside him even into the sea. Hubab ibn al-Mundhir advised seizing the wells, and the Prophet adopted the suggestion — a precedent for consultation over rank.

## The battle

It opened with single combats in which Ali ibn Abi Talib, Hamzah and Ubaydah ibn al-Harith faced the Qurayshi champions. In the general engagement the Makkans lost around seventy dead — including Abu Jahl — and seventy captured. Fourteen Muslims were martyred. The Qur'an describes angelic reinforcement (8:9, 3:123–125).

## The prisoners

The Prophet consulted on the captives: Abu Bakr urged ransom, Umar execution. Ransom was accepted, and literate prisoners were freed in exchange for teaching ten Muslim children to read — one of the earliest links in Islam between mercy and literacy. Qur'an 8:67–68 comments on the decision.

## Lessons

- **Numbers are not the decisive factor** — preparation, cohesion and sincerity are (8:65–66).
- **Consultation is method, not courtesy** — the Prophet took tactical advice from a non-elite companion.
- **Victory is a test** — the immediate sequel, Uhud, proved how quickly discipline can slip.
- **Captives have rights** — the treatment of Badr's prisoners shaped Islamic law of war.

## References across the schools

- **Qur'an**: Surah al-Anfal, especially 8:5–19, 8:41, 8:67–68; 3:123.
- **Sunni**: Sahih al-Bukhari, Kitab al-Maghazi (Bab Ghazwat Badr); Ibn Hisham, *al-Sirah*.
- **Shia**: al-Mufid, *al-Irshad*; al-Waqidi's reports as cited in *Bihar al-Anwar* vol. 19.
- **Salafi/Wahhabi**: al-Mubarakpuri, *al-Rahiq al-Makhtum*, chapter on Badr.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 6,
array['badr','battle','history','ramadan'],'en'
),
(
'battle-of-uhud-lessons',
'The Battle of Uhud — What Muslims Can Learn',
'A near-victory turned to disaster by one broken order — and the Qur''an''s remarkably honest account of it.',
$md$In Shawwal 3 AH the Quraysh returned with 3,000 men to avenge Badr. The Prophet (ﷺ) initially preferred to defend inside Madinah; the majority, especially the young who had missed Badr, urged meeting the enemy outside. He accepted the majority view — and did not reverse it even when they reconsidered, teaching that consultation once concluded is binding.

## The archers

The Muslim force of about 700 (after Abdullah ibn Ubayy withdrew 300) took position at the foot of Mount Uhud. Fifty archers were placed on a hill with an unconditional order: do not leave, whether you see us winning or being killed. The Muslims broke the Makkan lines. Seeing the rout, most archers descended to collect spoils. Khalid ibn al-Walid, then still fighting for Quraysh, swept his cavalry around the exposed hill and struck from behind.

## The reversal

The Muslim formation collapsed. Around seventy were martyred, among them Hamzah ibn Abd al-Muttalib, the Prophet's uncle, whose body was mutilated. The Prophet was wounded — his tooth broken, his face cut — and a rumour of his death spread. Ali, Abu Dujanah, Talhah, Nusaybah bint Ka'b (Umm Ammarah) and a small band held the line around him.

## The Qur'an's response

Surah Al Imran 121–180 discusses Uhud at length, and it does not soften the account. It names the failure — "until you lost courage, fell to disputing and disobeyed after He had shown you what you loved" (3:152) — and then, remarkably, commands gentleness toward those responsible: "had you been harsh and hard-hearted, they would have dispersed from around you" (3:159).

## Lessons

- **Discipline outlives momentum.** A won battle was lost by fifty men leaving a post.
- **Greed for gain corrupts intention** mid-action, not just before it.
- **Defeat is diagnostic**, not final. The Muslims marched out again the next day to Hamra al-Asad.
- **Leaders absorb blame and forgive** — the verse of consultation was revealed immediately after the worst military failure of the Prophet's life.

## References across the schools

- **Qur'an**: 3:121–180, especially 3:152, 3:159.
- **Sunni**: Sahih al-Bukhari 4043, 4067; Ibn Hisham, *al-Sirah*.
- **Shia**: al-Mufid, *al-Irshad* (on Ali's defence of the Prophet); *Bihar al-Anwar* vol. 20.
- **Salafi/Wahhabi**: al-Mubarakpuri, *al-Rahiq al-Makhtum*, chapter on Uhud.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 6,
array['uhud','battle','discipline','history'],'en'
),
(
'conquest-of-makkah-history-significance',
'The Conquest of Makkah — History and Significance',
'How the city that expelled the Prophet was taken in 8 AH almost without bloodshed — and why the amnesty mattered more than the victory.',
$md$In 8 AH (630 CE) the Prophet (ﷺ) entered Makkah at the head of 10,000 men. Twenty-one years earlier the same city had boycotted his clan into starvation and plotted his assassination. The conquest is remembered less for the military operation than for what did not happen afterwards.

## The breach

The Treaty of Hudaybiyyah (6 AH) had fixed a ten-year truce and allowed tribes to ally with either side. When Banu Bakr, allied to Quraysh, attacked the Prophet's allies Banu Khuza'ah with Qurayshi support, the truce was void. Abu Sufyan travelled to Madinah to repair it and failed.

## The march

The Prophet mobilised in secrecy and ordered 10,000 separate campfires lit outside Makkah — a display of strength intended to make resistance appear futile and thereby avoid a fight. Abu Sufyan, brought to the camp by al-Abbas, accepted Islam that night. The Prophet declared safety for anyone who entered the Sacred Mosque, entered Abu Sufyan's house, or stayed indoors.

## The entry

The army entered from four directions; only Khalid ibn al-Walid's column met brief resistance. The Prophet entered with his head lowered to his mount in humility, not triumph. He circled the Ka'bah, destroyed the 360 idols reciting "Truth has come and falsehood has vanished" (17:81), and had the interior images erased.

## The amnesty

Standing at the door of the Ka'bah, he asked the Quraysh what they expected. They answered: "A noble brother, son of a noble brother." He replied with Yusuf's words: *"No blame upon you this day"* — go, you are free. Even Hind bint Utbah, who had mutilated Hamzah, and Wahshi, who killed him, were pardoned. Bilal, once tortured in that city's sun, climbed the Ka'bah to call the adhan.

## Significance

- The Sacred House was returned to monotheism.
- A model was set for victory without vengeance, later cited in Islamic law of war.
- Tribes across Arabia entered Islam in the following two years — the "entering in crowds" of Surah al-Nasr.

## References across the schools

- **Qur'an**: 17:81, 48:1, 48:27, 110:1–3.
- **Sunni**: Sahih al-Bukhari, Kitab al-Maghazi (Fath Makkah); Sahih Muslim 1780.
- **Shia**: al-Ya'qubi, *Tarikh*; al-Mufid, *al-Irshad*; *Bihar al-Anwar* vol. 21.
- **Salafi/Wahhabi**: al-Mubarakpuri, *al-Rahiq al-Makhtum*, chapter on the Conquest.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 6,
array['fath makkah','conquest','mercy','history'],'en'
),
(
'family-of-prophet-muhammad',
'The Family of Prophet Muhammad ﷺ',
'His wives, children, grandchildren and household — who they were and how the traditions honour them.',
$md$The Prophet's household is a subject of deep affection across the Muslim world, and also one of its most discussed. Setting out the plain historical record first makes the later theology easier to follow.

## Khadijah and the children

Khadijah bint Khuwaylid was his only wife for twenty-five years, the first to believe in him, and the mother of all his children but one: Qasim, Abdullah, Zaynab, Ruqayyah, Umm Kulthum and Fatimah. Only Fatimah's line continued. His son Ibrahim, born to Mariyah al-Qibtiyyah in Madinah, died in infancy.

## The wives

After Khadijah's death he married Sawdah, A'ishah bint Abi Bakr, Hafsah bint Umar, Zaynab bint Khuzaymah, Umm Salamah, Zaynab bint Jahsh, Juwayriyyah, Umm Habibah, Safiyyah and Maymunah. Most of these marriages were made in his fifties and sixties and carried political or protective purposes: sheltering widows of fallen companions, and binding hostile tribes into kinship. The Qur'an titles them *Ummahat al-Mu'minin* — Mothers of the Believers (33:6).

## Fatimah, Ali and the grandsons

Fatimah al-Zahra married Ali ibn Abi Talib, the Prophet's cousin and ward. Their children were Hasan, Husayn, Zaynab and Umm Kulthum. The Prophet said of Hasan and Husayn that they are "the two masters of the youth of Paradise", and of Fatimah that she is "a part of me; whoever angers her angers me."

## Who are the Ahl al-Bayt?

The verse of purification (33:33) is central. The **Hadith of the Cloak** (*Kisa*), reported in Muslim, Tirmidhi, Ahmad and the Shia collections, records the Prophet gathering Ali, Fatimah, Hasan and Husayn under his cloak and praying that God purify them — which is why Shia scholarship and many Sunni commentators identify the Ahl al-Bayt primarily as these five plus the Imams of their line. Other Sunni readings include the wives, given the verse's context, or combine both.

## The shared ground

Every school affirms the obligation to send blessings on the Prophet's family in every prayer, and to love and honour them. Differences concern scope and authority, not merit.

## References across the schools

- **Qur'an**: 33:6, 33:33, 33:56, 42:23 (love of the near kin).
- **Sunni**: Sahih Muslim 2404, 2424; Sunan al-Tirmidhi 3768, 3871; Ibn Sa'd, *al-Tabaqat*.
- **Shia**: al-Kulayni, *al-Kafi*, Kitab al-Hujjah; al-Saduq, *Uyun Akhbar al-Rida*; *Bihar al-Anwar* vols. 37, 43.
- **Salafi/Wahhabi**: Ibn Taymiyyah, *Minhaj al-Sunnah* (on the rights of the household); Ibn Kathir on 33:33.$md$,
'07f1e43e-8f5e-4473-b715-16594873fde2','published', now(), 7,
array['ahl al-bayt','family','fatimah','household'],'en'
);
