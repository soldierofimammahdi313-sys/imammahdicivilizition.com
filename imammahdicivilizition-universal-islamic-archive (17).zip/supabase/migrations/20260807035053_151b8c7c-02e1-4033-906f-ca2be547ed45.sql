-- 1) Aggregate public like counts view (no user_id exposure)
CREATE OR REPLACE VIEW public.community_post_like_counts
WITH (security_invoker = false) AS
SELECT post_id, count(*)::int AS like_count
FROM public.community_likes
GROUP BY post_id;

GRANT SELECT ON public.community_post_like_counts TO anon, authenticated;
GRANT ALL ON public.community_post_like_counts TO service_role;

-- 2) Restrict raw likes reads
DROP POLICY IF EXISTS "likes readable" ON public.community_likes;

CREATE POLICY "likes readable own or post author"
ON public.community_likes
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id
  OR EXISTS (
    SELECT 1 FROM public.community_posts p
    WHERE p.id = community_likes.post_id AND p.author_id = auth.uid()
  )
);

REVOKE SELECT ON public.community_likes FROM anon;

-- 3) has_role: drop SECURITY DEFINER, rely on own-row RLS
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

GRANT SELECT ON public.user_roles TO anon;
