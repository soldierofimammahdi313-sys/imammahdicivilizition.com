DROP POLICY IF EXISTS "Public profile fields readable" ON public.profiles;

ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS author_name text;
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS author_avatar text;
ALTER TABLE public.community_comments ADD COLUMN IF NOT EXISTS author_name text;
ALTER TABLE public.community_comments ADD COLUMN IF NOT EXISTS author_avatar text;