DROP VIEW IF EXISTS public.community_post_like_counts;

CREATE TABLE public.community_post_like_counts (
  post_id uuid PRIMARY KEY REFERENCES public.community_posts(id) ON DELETE CASCADE,
  like_count integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.community_post_like_counts TO anon, authenticated;
GRANT ALL ON public.community_post_like_counts TO service_role;

ALTER TABLE public.community_post_like_counts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "like counts readable"
ON public.community_post_like_counts
FOR SELECT
TO anon, authenticated
USING (true);

CREATE OR REPLACE FUNCTION public.sync_post_like_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target uuid := COALESCE(NEW.post_id, OLD.post_id);
BEGIN
  INSERT INTO public.community_post_like_counts (post_id, like_count, updated_at)
  VALUES (target, (SELECT count(*) FROM public.community_likes WHERE post_id = target), now())
  ON CONFLICT (post_id) DO UPDATE
    SET like_count = EXCLUDED.like_count, updated_at = now();
  RETURN NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_post_like_count() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER trg_sync_post_like_count
AFTER INSERT OR DELETE ON public.community_likes
FOR EACH ROW EXECUTE FUNCTION public.sync_post_like_count();

INSERT INTO public.community_post_like_counts (post_id, like_count)
SELECT p.id, (SELECT count(*) FROM public.community_likes l WHERE l.post_id = p.id)
FROM public.community_posts p
ON CONFLICT (post_id) DO UPDATE SET like_count = EXCLUDED.like_count;
