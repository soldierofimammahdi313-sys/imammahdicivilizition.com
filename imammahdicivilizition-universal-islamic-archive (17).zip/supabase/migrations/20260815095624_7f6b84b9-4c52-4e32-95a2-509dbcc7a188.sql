DROP POLICY IF EXISTS "posts readable" ON public.community_posts;
CREATE POLICY "posts readable anon" ON public.community_posts FOR SELECT TO anon
  USING (is_hidden = false);
CREATE POLICY "posts readable auth" ON public.community_posts FOR SELECT TO authenticated
  USING (is_hidden = false OR auth.uid() = author_id OR public.has_role(auth.uid(), 'reviewer') OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "comments readable" ON public.community_comments;
CREATE POLICY "comments readable anon" ON public.community_comments FOR SELECT TO anon
  USING (is_hidden = false);
CREATE POLICY "comments readable auth" ON public.community_comments FOR SELECT TO authenticated
  USING (is_hidden = false OR auth.uid() = author_id OR public.has_role(auth.uid(), 'reviewer') OR public.has_role(auth.uid(), 'admin'));