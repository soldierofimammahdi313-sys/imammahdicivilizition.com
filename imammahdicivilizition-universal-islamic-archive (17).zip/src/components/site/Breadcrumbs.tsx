import { Link } from "@tanstack/react-router";
import { SITE_URL as BASE } from "@/lib/site";

export type Crumb = { label: string; to?: string };


/**
 * Accessible breadcrumb trail + BreadcrumbList structured data.
 */
export function Breadcrumbs({ items, jsonLd: emitJsonLd = true }: { items: Crumb[]; jsonLd?: boolean }) {
  const trail: Crumb[] = [{ label: "Home", to: "/" }, ...items];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: trail.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: c.label,
      ...(c.to ? { item: `${BASE}${c.to === "/" ? "" : c.to}` } : {}),
    })),
  };

  return (
    <nav aria-label="Breadcrumb" className="mx-auto w-full max-w-7xl px-6 pt-40 pb-3">
      <ol className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        {trail.map((c, i) => {
          const last = i === trail.length - 1;
          return (
            <li key={`${c.label}-${i}`} className="flex items-center gap-2">
              {c.to && !last ? (
                <Link to={c.to} className="transition-colors hover:text-gold">
                  {c.label}
                </Link>
              ) : (
                <span aria-current={last ? "page" : undefined} className="text-foreground/80">
                  {c.label}
                </span>
              )}
              {!last && <span aria-hidden className="text-muted-foreground/40">/</span>}
            </li>
          );
        })}
      </ol>
      {emitJsonLd && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      )}
    </nav>
  );
}
