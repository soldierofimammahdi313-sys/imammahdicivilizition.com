import { Canvas, useFrame, useLoader } from "@react-three/fiber";
import { Float, Lightformer, Environment, Sparkles, Stars } from "@react-three/drei";
import { Suspense, useMemo, useRef } from "react";
import * as THREE from "three";
import earthMapUrl from "@/assets/earth-gold-map.jpg";

const GOLD = "#e3c274";
const GOLD_DEEP = "#a8843a";
const EMERALD = "#2f9a74";

/** Eight-pointed girih star (khatam) as an extruded flat shape. */
function useStarGeometry(points = 8, outer = 1, inner = 0.46) {
  return useMemo(() => {
    const shape = new THREE.Shape();
    const total = points * 2;
    for (let i = 0; i < total; i++) {
      const radius = i % 2 === 0 ? outer : inner;
      const angle = (i / total) * Math.PI * 2 - Math.PI / 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 0.08,
      bevelEnabled: true,
      bevelSize: 0.035,
      bevelThickness: 0.035,
      bevelSegments: 3,
      curveSegments: 2,
    });
    geo.center();
    return geo;
  }, [points, outer, inner]);
}

/** Rotating world globe inside a luminous glass atmosphere. */
function SanctuaryCore() {
  const shellRef = useRef<THREE.Mesh>(null);
  const cageRef = useRef<THREE.Group>(null);
  const ringsRef = useRef<THREE.Group>(null);
  const starGeo = useStarGeometry(8, 1, 0.44);
  const earthMap = useLoader(THREE.TextureLoader, earthMapUrl);
  useMemo(() => {
    earthMap.colorSpace = THREE.SRGBColorSpace;
    earthMap.anisotropy = 4;
  }, [earthMap]);

  useFrame(({ pointer, clock }, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05);
    const t = clock.elapsedTime;
    const shell = shellRef.current;
    const cage = cageRef.current;
    const rings = ringsRef.current;
    if (!shell || !cage || !rings) return;

    cage.rotation.y += dt * 0.22;
    cage.rotation.x = THREE.MathUtils.damp(cage.rotation.x, pointer.y * 0.24, 3, dt);
    shell.rotation.y -= dt * 0.06;
    shell.rotation.z = THREE.MathUtils.damp(shell.rotation.z, -pointer.x * 0.14, 3, dt);
    shell.scale.setScalar(1.9 + Math.sin(t * 0.8) * 0.02);
    rings.rotation.z += dt * 0.05;
    rings.rotation.x = THREE.MathUtils.damp(rings.rotation.x, 0.38 + pointer.y * 0.1, 2.4, dt);
    rings.rotation.y = THREE.MathUtils.damp(rings.rotation.y, pointer.x * 0.14, 2.4, dt);
  });

  return (
    <group>
      <Float speed={1.1} rotationIntensity={0.06} floatIntensity={0.3}>
        {/* Atmosphere / glass shell around the globe */}
        <mesh ref={shellRef} scale={1.9}>
          <sphereGeometry args={[1, 48, 32]} />
          <meshPhysicalMaterial
            color="#0d2a22"
            metalness={0.1}
            roughness={0.06}
            transmission={0.92}
            thickness={1.4}
            ior={1.3}
            iridescence={0.5}
            iridescenceIOR={1.5}
            clearcoat={1}
            clearcoatRoughness={0.06}
            transparent
            opacity={0.5}
          />
        </mesh>

        {/* Rotating world globe */}
        <group ref={cageRef}>
          <mesh scale={1.62}>
            <sphereGeometry args={[1, 96, 64]} />
            <meshStandardMaterial
              map={earthMap}
              emissiveMap={earthMap}
              emissive="#ffffff"
              emissiveIntensity={0.5}
              metalness={0.35}
              roughness={0.62}
            />
          </mesh>
          {/* Latitude / longitude grid */}
          <mesh scale={1.635}>
            <sphereGeometry args={[1, 24, 16]} />
            <meshBasicMaterial color={EMERALD} wireframe transparent opacity={0.16} />
          </mesh>
          {/* Gold orbit markers */}
          {Array.from({ length: 8 }, (_, i) => {
            const angle = (i / 8) * Math.PI * 2;
            return (
              <mesh
                key={i}
                geometry={starGeo}
                position={[Math.cos(angle) * 1.82, Math.sin(angle * 2) * 0.5, Math.sin(angle) * 1.82]}
                scale={0.16}
                onUpdate={(self) => self.lookAt(0, 0, 0)}
              >
                <meshStandardMaterial
                  color={GOLD}
                  emissive={GOLD_DEEP}
                  emissiveIntensity={0.8}
                  metalness={1}
                  roughness={0.2}
                />
              </mesh>
            );
          })}
        </group>

        <Sparkles count={60} scale={4.6} size={2.4} speed={0.28} color={GOLD} opacity={0.7} />
      </Float>


      {/* Orbital gold rings */}
      <group ref={ringsRef}>
        <mesh rotation-x={Math.PI / 2}>
          <torusGeometry args={[2.95, 0.018, 12, 220]} />
          <meshStandardMaterial color={GOLD} emissive={GOLD} emissiveIntensity={1.3} metalness={1} roughness={0.2} toneMapped={false} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]} position-y={0.001}>
          <torusGeometry args={[3.35, 0.006, 8, 200]} />
          <meshBasicMaterial color={GOLD} transparent opacity={0.4} />
        </mesh>
        <mesh rotation={[Math.PI / 2.6, Math.PI / 6, 0]}>
          <torusGeometry args={[3.8, 0.01, 8, 200]} />
          <meshBasicMaterial color={EMERALD} transparent opacity={0.35} />
        </mesh>
      </group>

      <pointLight position={[0, 0.4, 2.2]} color={GOLD} intensity={22} distance={14} decay={2} />
      <pointLight position={[-3, -1.5, -2]} color={EMERALD} intensity={14} distance={16} decay={2} />
    </group>
  );
}

/** Distant filigree lattice drifting behind the core. */
function GirihField() {
  const groupRef = useRef<THREE.Group>(null);
  const starGeo = useStarGeometry(8, 1, 0.45);
  const nodes = useMemo(
    () =>
      Array.from({ length: 12 }, (_, index) => {
        const ring = 5.2 + (index % 4) * 1.35;
        const angle = index * 2.39996;
        return {
          position: [Math.cos(angle) * ring, Math.sin(angle) * ring * 0.55, -4.5 - (index % 3) * 1.2] as [number, number, number],
          scale: 0.34 + (index % 5) * 0.08,
          rotation: angle,
          gold: index % 3 !== 0,
        };
      }),
    [],
  );

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05);
    if (groupRef.current) groupRef.current.rotation.z += dt * 0.014;
  });

  return (
    <group ref={groupRef}>
      {nodes.map((node, index) => (
        <mesh key={index} geometry={starGeo} position={node.position} scale={node.scale} rotation-z={node.rotation}>
          <meshBasicMaterial color={node.gold ? GOLD : EMERALD} transparent opacity={0.22} wireframe />
        </mesh>
      ))}
    </group>
  );
}

export default function ObservatoryScene() {
  const isSmall = typeof window !== "undefined" && window.innerWidth < 640;
  return (
    <Canvas
      aria-hidden
      dpr={[1, 1.6]}
      camera={{ position: [0, 0.4, isSmall ? 13 : 9], fov: 46 }}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
    >
      <fog attach="fog" args={["#050907", 11, 26]} />
      <ambientLight intensity={0.45} color="#4f795f" />
      <directionalLight position={[5, 6, 7]} intensity={2.1} color="#f6e2ac" />
      <directionalLight position={[-6, -3, 2]} intensity={0.7} color={EMERALD} />
      <Stars radius={40} depth={26} count={isSmall ? 500 : 1100} factor={3} saturation={0} fade speed={0.6} />
      <Suspense fallback={null}>
        <SanctuaryCore />
      </Suspense>
      <GirihField />
      <Environment resolution={64}>
        <Lightformer intensity={3} color={GOLD} position={[0, 4, 4]} scale={[6, 2, 1]} />
        <Lightformer intensity={1.6} color={EMERALD} position={[-5, 0, 1]} rotation-y={Math.PI / 2} scale={[9, 2, 1]} />
        <Lightformer intensity={1.2} color="#ffffff" position={[3, -2, 3]} scale={[4, 2, 1]} />
      </Environment>
    </Canvas>
  );
}
