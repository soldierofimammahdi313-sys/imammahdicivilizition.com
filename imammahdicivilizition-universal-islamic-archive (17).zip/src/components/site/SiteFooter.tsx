import { Link } from "@tanstack/react-router";
import { SocialIcons } from "./SocialIcons";
import { CONTACT } from "@/lib/social-links";
import { useI18n } from "@/lib/i18n";
import { FIQH_SCHOOLS, fiqhName } from "@/lib/fiqh";
import { openPreferences } from "./PreferencesModal";
import mahdiLogo from "@/assets/mahdi-logo.png";

const COPYRIGHT_YEAR = new Date().getFullYear();

export function SiteFooter() {
  const { t, lang } = useI18n();
  return (
    <footer className="border-t border-border bg-card/30 mt-32">
      <div className="max-w-7xl mx-auto px-6 py-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8">
        <div className="sm:col-span-2">
          <div className="flex items-center gap-3">
            <img loading="lazy" decoding="async"
              src={mahdiLogo}
              alt="Imam Mahdi Civilization logo"
              width={1024}
              height={1024}
              className="size-11 object-contain"
            />
            <span className="font-display italic text-xl">Imam Mahdi Civilization</span>
          </div>
          <p className="mt-2 text-[10px] uppercase tracking-[0.3em] text-gold">
            {t("footer.positioning")}
          </p>
          <p className="mt-4 text-sm text-muted-foreground max-w-md leading-relaxed">
            A universal Islamic knowledge and digital archive — Qur'an, hadith, tafsir, library,
            research and the schools of jurisprudence, open to every tradition.
          </p>
          <SocialIcons className="mt-6" iconClass="size-5" />
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Realms</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/quran" className="hover:text-gold">Quran Reader</Link></li>
            <li><Link to="/hadith" className="hover:text-gold">Hadith Library</Link></li>
            <li><Link to="/duas" className="hover:text-gold">Duas & Adhkar</Link></li>
            <li><Link to="/names" className="hover:text-gold">99 Names</Link></li>
            <li><Link to="/articles" className="hover:text-gold">Articles</Link></li>
            <li><Link to="/ai" className="hover:text-gold">AI Assistant</Link></li>
            <li><Link to="/daily" className="hover:text-gold">Daily Devotion</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Tools</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/qibla" className="hover:text-gold">Qibla Compass</Link></li>
            <li><Link to="/zakat" className="hover:text-gold">Zakat Calculator</Link></li>
            <li><Link to="/inheritance" className="hover:text-gold">Inheritance</Link></li>
            <li><Link to="/tasbih" className="hover:text-gold">Digital Tasbih</Link></li>
            <li><Link to="/khatam" className="hover:text-gold">Khatam Tracker</Link></li>
            <li><Link to="/events" className="hover:text-gold">Islamic Calendar</Link></li>
            <li><Link to="/mosques" className="hover:text-gold">Mosque Finder</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Explore</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/modules" className="hover:text-gold">All Modules</Link></li>
            <li><Link to="/library" className="hover:text-gold">Islamic Library</Link></li>
            <li><Link to="/fiqh" className="hover:text-gold">Fiqh Schools</Link></li>
            <li><Link to="/videos" className="hover:text-gold">Video Center</Link></li>
            <li><Link to="/timeline" className="hover:text-gold">History Timeline</Link></li>
            <li><Link to="/academy" className="hover:text-gold">Academy</Link></li>
            <li><Link to="/community" className="hover:text-gold">Community</Link></li>
            <li><Link to="/search" className="hover:text-gold">Search</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">{t("footer.fiqh")}</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/fiqh" className="hover:text-gold">{t("fiqh.schools")}</Link>
            </li>
            {FIQH_SCHOOLS.map((s) => (
              <li key={s.id}>
                <Link to="/fiqh/$school" params={{ school: s.slug }} className="hover:text-gold">
                  {fiqhName(s, lang)}
                </Link>
              </li>
            ))}
            <li>
              <button type="button" onClick={openPreferences} className="hover:text-gold text-start">
                {t("nav.preferences")}
              </button>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Organisation</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-gold">About Us</Link></li>
            <li><Link to="/founder" className="hover:text-gold">The Founder</Link></li>
            <li><Link to="/contact" className="hover:text-gold">Contact Us</Link></li>
            <li><Link to="/join" className="hover:text-gold">Join the Team</Link></li>
            <li><Link to="/donate" className="hover:text-gold">Donate (Sadaqah)</Link></li>
            <li><a href="mailto:imammahdicivilization@gmail.com" className="hover:text-gold break-all">imammahdicivilization@gmail.com</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Legal</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/privacy" className="hover:text-gold">Privacy Policy</Link></li>
            <li><Link to="/terms" className="hover:text-gold">Terms of Service</Link></li>
            <li><Link to="/disclaimer" className="hover:text-gold">Disclaimer</Link></li>
            <li><Link to="/cookies" className="hover:text-gold">Cookie Policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-muted-foreground">
          <span>© {COPYRIGHT_YEAR} Imam Mahdi Civilization</span>
          <nav aria-label="Legal" className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2">
            <Link to="/privacy" className="hover:text-gold transition-colors">Privacy Policy</Link>
            <span className="text-border">•</span>
            <Link to="/terms" className="hover:text-gold transition-colors">Terms of Service</Link>
            <span className="text-border">•</span>
            <Link to="/disclaimer" className="hover:text-gold transition-colors">Disclaimer</Link>
            <span className="text-border">•</span>
            <Link to="/cookies" className="hover:text-gold transition-colors">Cookies</Link>
            <span className="text-border">•</span>
            <Link to="/contact" className="hover:text-gold transition-colors">Contact</Link>
          </nav>
          <span>Developed &amp; Managed by <span className="text-foreground">{CONTACT.admin}</span></span>
        </div>
        {/* Hidden SEO metadata */}
        <div className="sr-only" aria-hidden="true">
          SEO, Development &amp; Management by {CONTACT.admin} — Imam Mahdi Civilization, the world's first Islamic digital civilization.
        </div>
      </div>
    </footer>
  );
}