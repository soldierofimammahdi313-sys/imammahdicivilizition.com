// Reusable "Buy on Amazon" button + ProductCard for the Shop page.
// One button component, one card component — used for every product.

export function BuyOnAmazon({ url }: { url: string }) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer nofollow sponsored"
      className="inline-flex w-full items-center justify-center rounded-md px-4 py-2.5 text-sm font-bold text-white shadow-md transition-all hover:brightness-110 hover:shadow-lg"
      style={{ backgroundImage: "linear-gradient(135deg, #D4AF37, #B8860B)" }}
    >
      Buy on Amazon
    </a>
  );
}

export type Product = { name: string; url: string };

export function ProductCard({ product }: { product: Product }) {
  return (
    <div className="glass-panel ring-1 ring-border p-4 flex flex-col gap-3 min-h-[120px] justify-between transition-colors hover:ring-gold/50">
      <h3 className="text-sm font-semibold leading-snug text-foreground line-clamp-3">
        {product.name}
      </h3>
      <BuyOnAmazon url={product.url} />
    </div>
  );
}
