import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getDailyHadiths } from "@/lib/daily-hadiths.functions";

export const NARRATIONS: { text: string; source: string; by: string }[] = [
  // 1 — Rasul Allah Muhammad (ﷺ)
  { text: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى — Actions are judged only by intentions, and every person shall have only that which he intended.", source: "Sahih al-Bukhari, Hadith 1", by: "Rasul Allah Muhammad (ﷺ)" },
  { text: "إِنِّي تَارِكٌ فِيكُمُ الثَّقَلَيْنِ: كِتَابَ اللّٰهِ وَعِتْرَتِي أَهْلَ بَيْتِي، مَا إِنْ تَمَسَّكْتُمْ بِهِمَا لَنْ تَضِلُّوا بَعْدِي أَبَدًا — Verily I leave among you two weighty things: the Book of Allah and my progeny, the People of my House. So long as you hold fast to them both you will never go astray after me.", source: "Sahih Muslim 2408; Musnad Ahmad 3/17", by: "Rasul Allah Muhammad (ﷺ)" },
  { text: "مَنْ كُنْتُ مَوْلَاهُ فَهٰذَا عَلِيٌّ مَوْلَاهُ، اَللّٰهُمَّ وَالِ مَنْ وَالَاهُ وَعَادِ مَنْ عَادَاهُ — Whoever holds me as his master, this Ali is his master. O Allah, befriend whoever befriends him and oppose whoever opposes him.", source: "Hadith al-Ghadir — Musnad Ahmad 4/281; Sunan Ibn Majah 116", by: "Rasul Allah Muhammad (ﷺ)" },
  { text: "طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ — Seeking knowledge is an obligation upon every Muslim.", source: "Sunan Ibn Majah 224; al-Kafi 1/30", by: "Rasul Allah Muhammad (ﷺ)" },
  { text: "خَيْرُ النَّاسِ أَنْفَعُهُمْ لِلنَّاسِ — The best of people are those who are most beneficial to people.", source: "al-Mu'jam al-Awsat 6026", by: "Rasul Allah Muhammad (ﷺ)" },

  // 2 — Sayyida Fatima al-Zahra (s.a)
  { text: "جَعَلَ اللّٰهُ الْإِيمَانَ تَطْهِيرًا لَكُمْ مِنَ الشِّرْكِ، وَالصَّلَاةَ تَنْزِيهًا لَكُمْ عَنِ الْكِبْرِ، وَالزَّكَاةَ تَزْكِيَةً لِلنَّفْسِ وَنَمَاءً فِي الرِّزْقِ — Allah made faith a purification for you from polytheism, prayer a cleansing for you from arrogance, and zakat a purification of the soul and an increase in sustenance.", source: "Khutbah Fadakiyyah — Bihar al-Anwar 29/223", by: "Sayyida Fatima al-Zahra (s.a)" },
  { text: "مَنْ أَصْعَدَ إِلَى اللّٰهِ خَالِصَ عِبَادَتِهِ، أَهْبَطَ اللّٰهُ عَزَّ وَجَلَّ إِلَيْهِ أَفْضَلَ مَصْلَحَتِهِ — Whoever raises up to Allah his sincere worship, Allah the Mighty and Majestic will send down to him what is best for his welfare.", source: "Bihar al-Anwar 67/249; Uddat al-Da'i", by: "Sayyida Fatima al-Zahra (s.a)" },
  { text: "اَلْجَارُ ثُمَّ الدَّارُ — [Pray first for] the neighbour, then for your own household.", source: "Bihar al-Anwar 43/81; Ilal al-Sharai'", by: "Sayyida Fatima al-Zahra (s.a)" },

  // 3 — Imam Ali ibn Abi Talib (a.s)
  { text: "قِيمَةُ كُلِّ امْرِئٍ مَا يُحْسِنُهُ — The worth of every person is measured by what he does well.", source: "Nahj al-Balagha, Hikmah 81", by: "Imam Ali ibn Abi Talib (a.s)" },
  { text: "اَلنَّاسُ صِنْفَانِ: إِمَّا أَخٌ لَكَ فِي الدِّينِ، أَوْ نَظِيرٌ لَكَ فِي الْخَلْقِ — People are of two kinds: either your brother in faith, or your equal in humanity.", source: "Nahj al-Balagha, Letter 53 (to Malik al-Ashtar)", by: "Imam Ali ibn Abi Talib (a.s)" },
  { text: "لَا تَكُنْ عَبْدَ غَيْرِكَ وَقَدْ جَعَلَكَ اللّٰهُ حُرًّا — Do not be the slave of another when Allah has created you free.", source: "Nahj al-Balagha, Letter 31", by: "Imam Ali ibn Abi Talib (a.s)" },
  { text: "اَلصَّبْرُ مِنَ الْإِيمَانِ بِمَنْزِلَةِ الرَّأْسِ مِنَ الْجَسَدِ، وَلَا خَيْرَ فِي جَسَدٍ لَا رَأْسَ مَعَهُ — Patience is to faith what the head is to the body; there is no good in a body without a head.", source: "Nahj al-Balagha, Hikmah 82", by: "Imam Ali ibn Abi Talib (a.s)" },
  { text: "اَلْعَالِمُ حَيٌّ وَإِنْ كَانَ مَيِّتًا، وَالْجَاهِلُ مَيِّتٌ وَإِنْ كَانَ حَيًّا — The scholar lives even though he is dead, and the ignorant is dead even though he is alive.", source: "Nahj al-Balagha, Hikmah 147", by: "Imam Ali ibn Abi Talib (a.s)" },

  // 4 — Imam Hasan al-Mujtaba (a.s)
  { text: "اِعْمَلْ لِدُنْيَاكَ كَأَنَّكَ تَعِيشُ أَبَدًا، وَاعْمَلْ لِآخِرَتِكَ كَأَنَّكَ تَمُوتُ غَدًا — Work for your world as though you will live forever, and work for your Hereafter as though you will die tomorrow.", source: "Bihar al-Anwar 44/139; Kashf al-Ghumma 1/571", by: "Imam Hasan al-Mujtaba (a.s)" },
  { text: "مَنْ عَرَفَ اللّٰهَ أَحَبَّهُ، وَمَنْ عَرَفَ الدُّنْيَا زَهِدَ فِيهَا — Whoever knows Allah loves Him, and whoever knows this world abstains from it.", source: "Bihar al-Anwar 75/109", by: "Imam Hasan al-Mujtaba (a.s)" },
  { text: "اَلْخَيْرُ الَّذِي لَا شَرَّ فِيهِ: اَلشُّكْرُ مَعَ النِّعْمَةِ، وَالصَّبْرُ عَلَى النَّازِلَةِ — The good in which there is no evil is gratitude with blessing and patience in calamity.", source: "Tuhaf al-Uqul, p. 233", by: "Imam Hasan al-Mujtaba (a.s)" },

  // 5 — Imam Husayn ibn Ali (a.s)
  { text: "إِنِّي لَمْ أَخْرُجْ أَشِرًا وَلَا بَطِرًا وَلَا مُفْسِدًا وَلَا ظَالِمًا، وَإِنَّمَا خَرَجْتُ لِطَلَبِ الْإِصْلَاحِ فِي أُمَّةِ جَدِّي — I did not rise out of arrogance, nor vanity, nor to spread corruption, nor to oppress. I rose only seeking reform in the nation of my grandfather.", source: "Bihar al-Anwar 44/329; Maqtal al-Husayn", by: "Imam Husayn ibn Ali (a.s)" },
  { text: "هَيْهَاتَ مِنَّا الذِّلَّةُ، يَأْبَى اللّٰهُ ذٰلِكَ لَنَا وَرَسُولُهُ وَالْمُؤْمِنُونَ — Far be it from us to accept humiliation! Allah refuses that for us, as do His Messenger and the believers.", source: "Bihar al-Anwar 45/83; al-Luhuf", by: "Imam Husayn ibn Ali (a.s)" },
  { text: "إِنْ لَمْ يَكُنْ لَكُمْ دِينٌ وَكُنْتُمْ لَا تَخَافُونَ الْمَعَادَ، فَكُونُوا أَحْرَارًا فِي دُنْيَاكُمْ — If you have no religion and do not fear the Day of Return, then at least be free men in your world.", source: "Bihar al-Anwar 45/51; al-Luhuf", by: "Imam Husayn ibn Ali (a.s)" },
  { text: "مَنْ حَاوَلَ أَمْرًا بِمَعْصِيَةِ اللّٰهِ كَانَ أَفْوَتَ لِمَا يَرْجُو وَأَسْرَعَ لِمَجِيءِ مَا يَحْذَرُ — Whoever pursues a goal through disobedience to Allah is farther from what he hopes for and nearer to what he fears.", source: "Tuhaf al-Uqul, p. 245", by: "Imam Husayn ibn Ali (a.s)" },

  // 6 — Imam Ali Zayn al-Abidin (a.s)
  { text: "اَللّٰهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِهِ، وَبَلِّغْ بِإِيمَانِي أَكْمَلَ الْإِيمَانِ، وَاجْعَلْ يَقِينِي أَفْضَلَ الْيَقِينِ، وَانْتَهِ بِنِيَّتِي إِلَى أَحْسَنِ النِّيَّاتِ — O Allah, bless Muhammad and his family, bring my faith to the most perfect faith, make my certainty the most excellent certainty, and take my intention to the best of intentions.", source: "al-Sahifa al-Sajjadiyya, Supplication 20 (Makarim al-Akhlaq)", by: "Imam Ali Zayn al-Abidin (a.s)" },
  { text: "مَنْ كَرُمَتْ عَلَيْهِ نَفْسُهُ هَانَتْ عَلَيْهِ الدُّنْيَا — Whoever holds his own soul in honour finds this world insignificant.", source: "Tuhaf al-Uqul, p. 278; Bihar al-Anwar 75/136", by: "Imam Ali Zayn al-Abidin (a.s)" },
  { text: "إِيَّاكَ وَالْكَسَلَ وَالضَّجَرَ، فَإِنَّهُمَا مِفْتَاحُ كُلِّ شَرٍّ، مَنْ كَسِلَ لَمْ يُؤَدِّ حَقًّا، وَمَنْ ضَجِرَ لَمْ يَصْبِرْ عَلَى حَقٍّ — Beware of laziness and impatience, for they are the key to every evil: the lazy fulfils no right, and the impatient endures no truth.", source: "Bihar al-Anwar 75/141; Tuhaf al-Uqul", by: "Imam Ali Zayn al-Abidin (a.s)" },

  // 7 — Imam Muhammad al-Baqir (a.s)
  { text: "بُنِيَ الْإِسْلَامُ عَلَى خَمْسٍ: عَلَى الصَّلَاةِ وَالزَّكَاةِ وَالصَّوْمِ وَالْحَجِّ وَالْوَلَايَةِ، وَلَمْ يُنَادَ بِشَيْءٍ كَمَا نُودِيَ بِالْوَلَايَةِ — Islam is built upon five: prayer, zakat, fasting, hajj and wilayah — and nothing was proclaimed as emphatically as wilayah was proclaimed.", source: "al-Kafi 2/18, Hadith 5", by: "Imam Muhammad al-Baqir (a.s)" },
  { text: "مَا شِيعَتُنَا إِلَّا مَنِ اتَّقَى اللّٰهَ وَأَطَاعَهُ — None are our Shia except those who fear Allah and obey Him.", source: "al-Kafi 2/74; Bihar al-Anwar 65/163", by: "Imam Muhammad al-Baqir (a.s)" },
  { text: "أَسْرَعُ الْخَيْرِ ثَوَابًا اَلْبِرُّ، وَأَسْرَعُ الشَّرِّ عِقَابًا اَلْبَغْيُ — The good deed swiftest in reward is righteousness, and the evil swiftest in punishment is transgression.", source: "Tuhaf al-Uqul, p. 295", by: "Imam Muhammad al-Baqir (a.s)" },

  // 8 — Imam Ja'far al-Sadiq (a.s)
  { text: "اَلْعِلْمُ نُورٌ يَقْذِفُهُ اللّٰهُ فِي قَلْبِ مَنْ يَشَاءُ — Knowledge is a light which Allah casts into the heart of whomever He wills.", source: "Misbah al-Shari'ah, ch. 1; Bihar al-Anwar 1/225", by: "Imam Ja'far al-Sadiq (a.s)" },
  { text: "كُونُوا دُعَاةً لِلنَّاسِ بِغَيْرِ أَلْسِنَتِكُمْ، لِيَرَوْا مِنْكُمُ الْوَرَعَ وَالِاجْتِهَادَ وَالصَّلَاةَ وَالْخَيْرَ، فَإِنَّ ذٰلِكَ دَاعِيَةٌ — Invite people [to faith] without your tongues: let them see from you piety, striving, prayer and goodness, for that is the true invitation.", source: "al-Kafi 2/78, Hadith 14", by: "Imam Ja'far al-Sadiq (a.s)" },
  { text: "اَلصِّدْقُ يُنْجِي وَالْكَذِبُ يُهْلِكُ — Truthfulness delivers and lying destroys.", source: "al-Kafi 2/338", by: "Imam Ja'far al-Sadiq (a.s)" },
  { text: "اَلْغَضَبُ مِفْتَاحُ كُلِّ شَرٍّ — Anger is the key to every evil.", source: "al-Kafi 2/303, Hadith 3", by: "Imam Ja'far al-Sadiq (a.s)" },

  // 9 — Imam Musa al-Kadhim (a.s)
  { text: "يَا هِشَامُ، إِنَّ اللّٰهَ تَبَارَكَ وَتَعَالَى بَشَّرَ أَهْلَ الْعَقْلِ وَالْفَهْمِ فِي كِتَابِهِ — O Hisham, indeed Allah the Blessed and Exalted gave glad tidings in His Book to the people of intellect and understanding.", source: "al-Kafi 1/13 (Hadith al-'Aql wa al-Jahl)", by: "Imam Musa al-Kadhim (a.s)" },
  { text: "لَيْسَ مِنَّا مَنْ لَمْ يُحَاسِبْ نَفْسَهُ فِي كُلِّ يَوْمٍ، فَإِنْ عَمِلَ حَسَنًا اسْتَزَادَ اللّٰهَ، وَإِنْ عَمِلَ سَيِّئًا اسْتَغْفَرَ اللّٰهَ مِنْهُ وَتَابَ إِلَيْهِ — He is not of us who does not take account of himself every day: if he did good, he asks Allah for more; if he did evil, he seeks Allah's forgiveness and repents to Him.", source: "al-Kafi 2/453; Bihar al-Anwar 67/72", by: "Imam Musa al-Kadhim (a.s)" },
  { text: "اَلْمُؤْمِنُ مِثْلُ كِفَّتَيِ الْمِيزَانِ: كُلَّمَا زِيدَ فِي إِيمَانِهِ زِيدَ فِي بَلَائِهِ — The believer is like the two pans of a balance: whenever his faith increases, his trials increase.", source: "al-Kafi 2/254", by: "Imam Musa al-Kadhim (a.s)" },

  // 10 — Imam Ali al-Rida (a.s)
  { text: "كَلِمَةُ لَا إِلٰهَ إِلَّا اللّٰهُ حِصْنِي، فَمَنْ دَخَلَ حِصْنِي أَمِنَ مِنْ عَذَابِي… بِشُرُوطِهَا وَأَنَا مِنْ شُرُوطِهَا — [Allah says:] 'La ilaha illa Allah' is My fortress; whoever enters My fortress is safe from My punishment — with its conditions, and I am among its conditions.", source: "Hadith Silsilat al-Dhahab — Uyun Akhbar al-Rida 2/134", by: "Imam Ali al-Rida (a.s)" },
  { text: "لَيْسَ الْعِبَادَةُ كَثْرَةَ الصَّلَاةِ وَالصَّوْمِ، إِنَّمَا الْعِبَادَةُ التَّفَكُّرُ فِي أَمْرِ اللّٰهِ عَزَّ وَجَلَّ — Worship is not an abundance of prayer and fasting; worship is rather reflection upon the affair of Allah, the Mighty and Majestic.", source: "al-Kafi 2/55; Bihar al-Anwar 68/321", by: "Imam Ali al-Rida (a.s)" },
  { text: "صَدِيقُ كُلِّ امْرِئٍ عَقْلُهُ، وَعَدُوُّهُ جَهْلُهُ — Every person's friend is his intellect, and his enemy is his ignorance.", source: "Tuhaf al-Uqul, p. 443", by: "Imam Ali al-Rida (a.s)" },

  // 11 — Imam Muhammad al-Jawad (a.s)
  { text: "مَنِ اسْتَغْنَى بِاللّٰهِ افْتَقَرَ النَّاسُ إِلَيْهِ، وَمَنِ اتَّقَى اللّٰهَ أَحَبَّهُ النَّاسُ وَإِنْ كَرِهُوا — Whoever is enriched by Allah, people become needy of him; and whoever fears Allah, people love him even if they dislike it.", source: "Bihar al-Anwar 75/365", by: "Imam Muhammad al-Jawad (a.s)" },
  { text: "اَلْمُؤْمِنُ يَحْتَاجُ إِلَى ثَلَاثِ خِصَالٍ: تَوْفِيقٍ مِنَ اللّٰهِ، وَوَاعِظٍ مِنْ نَفْسِهِ، وَقَبُولٍ مِمَّنْ يَنْصَحُهُ — The believer needs three qualities: success granted by Allah, an admonisher from within himself, and acceptance of the one who advises him.", source: "Tuhaf al-Uqul, p. 457", by: "Imam Muhammad al-Jawad (a.s)" },
  { text: "مَنْ أَطَاعَ هَوَاهُ أَعْطَى عَدُوَّهُ مُنَاهُ — Whoever obeys his desire has handed his enemy what he wished for.", source: "Bihar al-Anwar 75/364", by: "Imam Muhammad al-Jawad (a.s)" },

  // 12 — Imam Ali al-Hadi (a.s)
  { text: "اَلدُّنْيَا سُوقٌ رَبِحَ فِيهَا قَوْمٌ وَخَسِرَ آخَرُونَ — This world is a marketplace: in it some profit and others lose.", source: "Tuhaf al-Uqul, p. 483; Bihar al-Anwar 75/366", by: "Imam Ali al-Hadi (a.s)" },
  { text: "مَنْ رَضِيَ عَنْ نَفْسِهِ كَثُرَ السَّاخِطُونَ عَلَيْهِ — Whoever is pleased with himself, many will be displeased with him.", source: "Tuhaf al-Uqul, p. 483", by: "Imam Ali al-Hadi (a.s)" },
  { text: "اَلْحِكْمَةُ لَا تَنْجَعُ فِي الطِّبَاعِ الْفَاسِدَةِ — Wisdom bears no fruit in corrupted natures.", source: "Bihar al-Anwar 75/370", by: "Imam Ali al-Hadi (a.s)" },

  // 13 — Imam Hasan al-Askari (a.s)
  { text: "اَلْعَالِمُ بِزَمَانِهِ لَا تَهْجُمُ عَلَيْهِ اللَّوَابِسُ — One who is aware of his times will not be assailed by confusions.", source: "Tuhaf al-Uqul, p. 489; Bihar al-Anwar 75/269", by: "Imam Hasan al-Askari (a.s)" },
  { text: "خَيْرٌ مِنَ الْحَيَاةِ مَا إِذَا فَقَدْتَهُ أَبْغَضْتَ الْحَيَاةَ، وَشَرٌّ مِنَ الْمَوْتِ مَا إِذَا نَزَلَ بِكَ أَحْبَبْتَ الْمَوْتَ — Better than life is that whose loss makes you hate life; worse than death is that whose arrival makes you love death.", source: "Tuhaf al-Uqul, p. 489", by: "Imam Hasan al-Askari (a.s)" },
  { text: "مَنْ وَعَظَ أَخَاهُ سِرًّا فَقَدْ زَانَهُ، وَمَنْ وَعَظَهُ عَلَانِيَةً فَقَدْ شَانَهُ — Whoever admonishes his brother privately has adorned him, and whoever admonishes him publicly has disgraced him.", source: "Tuhaf al-Uqul, p. 489; Bihar al-Anwar 75/374", by: "Imam Hasan al-Askari (a.s)" },

  // 14 — Imam al-Mahdi (a.j)
  { text: "أَنَا خَاتَمُ الْأَوْصِيَاءِ، وَبِي يَدْفَعُ اللّٰهُ الْبَلَاءَ عَنْ أَهْلِي وَشِيعَتِي — I am the seal of the successors, and through me Allah repels affliction from my family and my Shia.", source: "Kamal al-Din wa Tamam al-Ni'mah 2/441", by: "Imam al-Mahdi (a.j)" },
  { text: "وَأَمَّا الْحَوَادِثُ الْوَاقِعَةُ فَارْجِعُوا فِيهَا إِلَى رُوَاةِ حَدِيثِنَا، فَإِنَّهُمْ حُجَّتِي عَلَيْكُمْ وَأَنَا حُجَّةُ اللّٰهِ عَلَيْهِمْ — As for newly arising events, refer in them to the narrators of our hadith, for they are my proof over you and I am the proof of Allah over them.", source: "Tawqi' — Kamal al-Din 2/483; Wasa'il al-Shia 27/140", by: "Imam al-Mahdi (a.j)" },
  { text: "فَأَكْثِرُوا الدُّعَاءَ بِتَعْجِيلِ الْفَرَجِ، فَإِنَّ ذٰلِكَ فَرَجُكُمْ — So supplicate abundantly for the hastening of the Relief, for indeed that is your own relief.", source: "Kamal al-Din 2/485; Bihar al-Anwar 53/181", by: "Imam al-Mahdi (a.j)" },
  { text: "إِنِّي أَمَانٌ لِأَهْلِ الْأَرْضِ كَمَا أَنَّ النُّجُومَ أَمَانٌ لِأَهْلِ السَّمَاءِ — I am a security for the people of the earth just as the stars are a security for the people of the heaven.", source: "Kamal al-Din 2/485; Bihar al-Anwar 53/181", by: "Imam al-Mahdi (a.j)" },
];

const ITEMS = NARRATIONS;

export function LiveTicker() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [today, setToday] = useState<string | null>(null);
  useEffect(() => {
    setToday(new Date().toISOString().slice(0, 10));
  }, []);
  const { data } = useQuery({
    queryKey: ["daily-hadiths", today ?? "pending"],
    enabled: today !== null,
    queryFn: () => getDailyHadiths(),
    staleTime: 1000 * 60 * 60 * 12,
    gcTime: 1000 * 60 * 60 * 24,
    refetchOnWindowFocus: false,
    retry: 1,
  });
  const liveItems = useMemo(
    () =>
      data?.items && data.items.length > 0
        ? data.items.map((i) => ({ text: i.text, by: i.by, source: i.source }))
        : ITEMS,
    [data],
  );
  const themeLabel = data?.hijri ? `Today · ${data.hijri}` : "Hadith";
  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    let raf = 0;
    let x = 0;
    const speed = 0.5;
    const tick = () => {
      x -= speed;
      const half = el.scrollWidth / 2;
      if (-x >= half) x = 0;
      el.style.transform = `translateX(${x}px)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [liveItems]);

  const row = (
    <>
      {liveItems.map((it, i) => (
        <span key={i} className="inline-flex items-center gap-3 px-8 whitespace-nowrap">
          <span className="text-gold text-[10px] uppercase tracking-[0.3em]">✦ {themeLabel}</span>
          <span className="text-foreground/90">{it.text}</span>
          <span className="text-muted-foreground italic">— {it.by}</span>
          <span className="text-[10px] uppercase tracking-widest text-gold/70">[{it.source}]</span>
          <span className="text-gold/40">•</span>
        </span>
      ))}
    </>
  );

  return (
    <div className="fixed top-20 left-0 right-0 z-40 border-b border-gold/20 bg-background/90 backdrop-blur-md overflow-hidden">
      <div className="relative flex items-center h-9">
        <div className="shrink-0 z-10 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] px-4 py-1.5 mr-2">
          ● Live
        </div>
        <div className="overflow-hidden flex-1">
          <div ref={trackRef} className="flex whitespace-nowrap text-sm will-change-transform">
            <div className="flex">{row}</div>
            <div className="flex" aria-hidden="true">{row}</div>
          </div>
        </div>
      </div>
    </div>
  );
}