import { AlertTriangle, ExternalLink, RefreshCw, CreditCard } from "lucide-react";
import { CREDITS_DOCS_URL, CREDITS_SETTINGS_URL } from "@/lib/ai-errors";

type Props = {
  kind: "credits" | "rate-limit" | "other";
  message?: string;
  compact?: boolean;
  onRetry?: () => void;
  onDismiss?: () => void;
};

const STEPS = [
  "Open Lovable → Settings → Plans & credits.",
  "Choose “Buy credits” (or upgrade your plan).",
  "Come back here and press Retry — N-EYES resumes instantly.",
];

export function AiCreditsNotice({ kind, message, compact, onRetry, onDismiss }: Props) {
  const isCredits = kind === "credits";
  return (
    <div
      role="alert"
      className={`border border-gold/50 bg-gold-soft/15 rounded-lg ${compact ? "p-3" : "p-5"} space-y-3`}
    >
      <div className="flex items-start gap-2">
        <AlertTriangle className="size-4 text-gold shrink-0 mt-0.5" />
        <div className="min-w-0">
          <h2 className={`font-semibold ${compact ? "text-xs" : "text-sm"}`}>
            {isCredits
              ? "AI credits khatam — N-EYES ruk gaya hai"
              : kind === "rate-limit"
                ? "Too many requests — please wait a moment"
                : "AI could not respond"}
          </h2>
          <p className={`mt-1 text-muted-foreground ${compact ? "text-[11px]" : "text-xs"}`}>
            {isCredits
              ? "Workspace ke AI credits khatam ho chuke hain. Credits add karte hi jawab dobara chalu ho jayenge."
              : message || "Please try again."}
          </p>
        </div>
      </div>

      {isCredits && !compact && (
        <ol className="space-y-1.5 ps-1 text-xs text-muted-foreground">
          {STEPS.map((s, i) => (
            <li key={s} className="flex gap-2">
              <span className="size-4 rounded-full bg-gold/20 text-gold text-[10px] flex items-center justify-center shrink-0">
                {i + 1}
              </span>
              <span>{s}</span>
            </li>
          ))}
        </ol>
      )}

      <div className="flex flex-wrap items-center gap-2">
        {isCredits && (
          <a
            href={CREDITS_SETTINGS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 bg-gold text-primary-foreground px-3 py-2 rounded text-[10px] uppercase tracking-[0.2em] font-semibold hover:opacity-90"
          >
            <CreditCard className="size-3.5" /> Add credits
            <ExternalLink className="size-3" />
          </a>
        )}
        {onRetry && (
          <button
            onClick={onRetry}
            className="inline-flex items-center gap-1.5 border border-gold/60 text-gold px-3 py-2 rounded text-[10px] uppercase tracking-[0.2em] hover:bg-gold-soft/30"
          >
            <RefreshCw className="size-3.5" /> Retry
          </button>
        )}
        {isCredits && !compact && (
          <a
            href={CREDITS_DOCS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-gold"
          >
            How credits work
          </a>
        )}
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="ms-auto text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground"
          >
            Dismiss
          </button>
        )}
      </div>
    </div>
  );
}