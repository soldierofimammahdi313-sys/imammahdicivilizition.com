import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { ModulesAlbum } from "@/components/site/ModulesAlbum";

type Btn = {
  to: string;
  icon: string;
  arabic: string;
  k: string;
  desc: string;
  tone: "gold" | "emerald" | "ink";
};

type Section = { title: string; arabic: string; items: Btn[] };

const SECTIONS: Section[] = [
  {
    title: "Sacred Knowledge",
    arabic: "العلوم المقدسة",
    items: [
      { to: "/shop",            icon: "🛍", arabic: "المتجر",    k: "Shop Islamic Products", desc: "Books, prayer essentials, perfumes, decor and more", tone: "gold" },
      { to: "/quran",           icon: "۞", arabic: "القرآن",     k: "nav.quran",      desc: "hub.d.quran",     tone: "gold" },
      { to: "/tafsir-al-mizan", icon: "✦", arabic: "المیزان",    k: "nav.tafsir",     desc: "hub.d.tafsir",    tone: "emerald" },
      { to: "/hadith",          icon: "☪", arabic: "الحدیث",     k: "nav.hadith",     desc: "hub.d.hadith",    tone: "ink" },
      { to: "/duas",            icon: "☼", arabic: "الادعیة",    k: "nav.duas",       desc: "hub.d.duas",      tone: "gold" },
      { to: "/names",           icon: "✧", arabic: "الأسماء",    k: "hub.names",      desc: "hub.d.names",     tone: "ink" },
      { to: "/articles",        icon: "✎", arabic: "المقالات",   k: "hub.articles",   desc: "hub.d.articles",  tone: "emerald" },
    ],
  },
  {
    title: "AI & Academy",
    arabic: "الذکاء والأکادیمیة",
    items: [
      { to: "/ai",          icon: "◉",  arabic: "ن-آيز",       k: "nav.ai",         desc: "hub.d.ai",         tone: "emerald" },
      { to: "/academy-ai",  icon: "🧠", arabic: "أستاذ مہدی",  k: "hub.academyAi",  desc: "hub.d.academyAi",  tone: "gold" },
      { to: "/academy",     icon: "⌬",  arabic: "الأکادیمیة",  k: "hub.academy",    desc: "hub.d.academy",    tone: "ink" },
      { to: "/library",     icon: "❡",  arabic: "المکتبة",     k: "hub.library",    desc: "hub.d.library",    tone: "emerald" },
      { to: "/videos",      icon: "▶",  arabic: "الفیدیو",     k: "hub.videos",     desc: "hub.d.videos",     tone: "ink" },
    ],
  },
  {
    title: "Daily Devotion",
    arabic: "العبادة الیومیة",
    items: [
      { to: "/daily",   icon: "✺", arabic: "یومي",     k: "nav.daily",   desc: "hub.d.daily",   tone: "gold" },
      { to: "/qibla",   icon: "✦", arabic: "القبلة",    k: "hub.qibla",   desc: "hub.d.qibla",   tone: "emerald" },
      { to: "/tasbih",  icon: "◐", arabic: "التسبیح",   k: "hub.tasbih",  desc: "hub.d.tasbih",  tone: "ink" },
      { to: "/khatam",  icon: "✺", arabic: "الختم",     k: "hub.khatam",  desc: "hub.d.khatam",  tone: "gold" },
      { to: "/events",  icon: "✦", arabic: "الفعالیات", k: "hub.events",  desc: "hub.d.events",  tone: "emerald" },
    ],
  },
  {
    title: "Tools & Utilities",
    arabic: "الأدوات",
    items: [
      { to: "/zakat",       icon: "❂", arabic: "الزکاة",   k: "hub.zakat",       desc: "hub.d.zakat",       tone: "emerald" },
      { to: "/inheritance", icon: "⚖", arabic: "المیراث",  k: "hub.inheritance", desc: "hub.d.inheritance", tone: "ink" },
      { to: "/mosques",     icon: "☾", arabic: "المساجد",  k: "hub.mosques",     desc: "hub.d.mosques",     tone: "gold" },
      { to: "/simulator",   icon: "⛭", arabic: "المحاكاة", k: "Civilization Simulator", desc: "Govern a city by the standard of the Imams", tone: "gold" },
      { to: "/media",       icon: "◈", arabic: "الإعلام",  k: "Media Center",    desc: "Podcasts, audiobooks, documentaries, noha", tone: "emerald" },
      { to: "/maps",        icon: "⌖", arabic: "الخرائط",  k: "Sacred Maps",     desc: "Karbala, Makkah, Madinah, Najaf, Samarra", tone: "ink" },
      { to: "/timeline",    icon: "⏳", arabic: "التاریخ",  k: "History Timeline", desc: "Revelation to the Major Occultation", tone: "emerald" },
      { to: "/battles",     icon: "⚔", arabic: "الغزوات",  k: "Battle Explorer", desc: "Badr, Uhud, Khandaq, Siffin, Karbala", tone: "gold" },
      { to: "/family-tree", icon: "🜲", arabic: "شجرة النسب", k: "Family Tree",  desc: "Lineage of the Fourteen Infallibles", tone: "ink" },
      { to: "/isnad",       icon: "⛓", arabic: "الإسناد",  k: "Isnad Viewer",    desc: "Chains of transmission, narrator by narrator", tone: "emerald" },
      { to: "/flashcards",  icon: "▢", arabic: "البطاقات", k: "Flashcards",      desc: "Spaced repetition for Arabic, hadith, fiqh", tone: "gold" },
      { to: "/journal",     icon: "✍", arabic: "المذكرات", k: "Dua Journal",     desc: "Private duas, reflections and answers", tone: "ink" },
      { to: "/citation",    icon: "❝", arabic: "المراجع",  k: "Citation Tool",   desc: "APA, MLA, Chicago and Hawza styles", tone: "emerald" },
      { to: "/search",      icon: "⌕", arabic: "البحث",    k: "Global Search",   desc: "One ranked index across every source", tone: "gold" },
      { to: "/bookmarks",   icon: "❑", arabic: "المحفوظات", k: "My Bookmarks",   desc: "Everything you saved, in one shelf", tone: "ink" },
      { to: "/history",     icon: "↺", arabic: "السجل",    k: "Reading History", desc: "Continue exactly where you stopped", tone: "emerald" },
      { to: "/realms",      icon: "❖", arabic: "العوالم",  k: "nav.realms",      desc: "hub.d.realms",      tone: "gold" },
      { to: "/modules",     icon: "▤", arabic: "الوحدات",  k: "Module Grid",     desc: "All 60+ modules of the civilization", tone: "emerald" },
    ],
  },
  {
    title: "Community & Account",
    arabic: "المجتمع",
    items: [
      { to: "/community", icon: "♁", arabic: "المجتمع", k: "hub.community", desc: "hub.d.community", tone: "ink" },
      { to: "/about",     icon: "ℹ", arabic: "حول",     k: "hub.about",     desc: "hub.d.about",     tone: "emerald" },
      { to: "/join",      icon: "⚔", arabic: "انضم",    k: "nav.join",      desc: "hub.d.join",      tone: "gold" },
      { to: "/donate",    icon: "❤", arabic: "تبرع",    k: "nav.donate",    desc: "hub.d.donate",    tone: "emerald" },
      { to: "/auth",      icon: "→", arabic: "دخول",    k: "nav.signin",    desc: "hub.d.signin",    tone: "ink" },
    ],
  },
];

const TONES: Record<Btn["tone"], string> = {
  gold:    "ring-gold/30 hover:ring-gold hover:bg-gold/5 hover:shadow-[0_0_40px_-10px_hsl(var(--gold)/0.4)]",
  emerald: "ring-emerald/30 hover:ring-emerald hover:bg-emerald-soft hover:shadow-[0_0_40px_-10px_hsl(var(--emerald)/0.4)]",
  ink:     "ring-border hover:ring-foreground hover:bg-card",
};
const ICON_TONES: Record<Btn["tone"], string> = {
  gold: "text-gold", emerald: "text-emerald", ink: "text-foreground/80",
};

export function NavHub() {
  const { t } = useI18n();
  return (
    <section id="command-center" className="relative py-24 px-6 border-y border-border bg-gradient-to-b from-background via-card/40 to-background overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-[0.07]"
        style={{ backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)", backgroundSize: "32px 32px" }} />
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 size-[600px] bg-gold/10 blur-[140px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="font-arabic text-3xl text-gold/60 block mb-3">مركز القيادة</span>
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em] block mb-4">{t("hub.kicker")}</span>
          <h2 className="font-display italic text-4xl md:text-6xl leading-tight">{t("hub.title")}</h2>
          <p className="mt-5 max-w-2xl mx-auto text-muted-foreground">{t("hub.subtitle")}</p>
        </div>

        <div className="space-y-14">
          {SECTIONS.map((section) => (
            <div key={section.title}>
              <div className="flex items-baseline justify-between mb-5 pb-3 border-b border-border">
                <h3 className="text-[11px] font-bold uppercase tracking-[0.3em] text-gold">
                  {section.title}
                </h3>
                <span className="font-arabic text-lg text-muted-foreground/60">{section.arabic}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
                {section.items.map((b, i) => (
                  <Link
                    key={b.to + i}
                    to={b.to}
                    className={`group relative glass-panel laser-trace ring-1 ${TONES[b.tone]} p-4 md:p-5 flex flex-col gap-2 min-h-[140px] transition-all duration-300 hover:-translate-y-1`}
                  >
                    <div className="flex items-start justify-between">
                      <span className={`text-2xl md:text-3xl leading-none ${ICON_TONES[b.tone]} transition-transform group-hover:scale-110`}>{b.icon}</span>
                      <span className="font-arabic text-sm text-muted-foreground/60 leading-none">{b.arabic}</span>
                    </div>
                    <div className="mt-auto">
                      <h4 className="text-[11px] md:text-xs font-bold uppercase tracking-[0.18em] text-foreground group-hover:text-gold transition-colors leading-tight">
                        {t(b.k)}
                      </h4>
                      <p className="text-[10px] mt-1.5 text-muted-foreground leading-snug line-clamp-2">{t(b.desc)}</p>
                    </div>
                    <span className="absolute top-2 right-2 text-[9px] font-mono-display text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity">↗</span>
                  </Link>
                ))}
              </div>
              {section.title === "Tools & Utilities" && <ModulesAlbum />}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}