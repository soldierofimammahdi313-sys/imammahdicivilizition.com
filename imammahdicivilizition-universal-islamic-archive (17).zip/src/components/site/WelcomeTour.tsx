import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { X, Sparkles, BookOpen, Compass, GraduationCap, LayoutGrid } from "lucide-react";

const KEY = "imc.welcome.tour.v1";

const STEPS = [
  {
    icon: Sparkles,
    title: "Welcome to Imam Mahdi Civilization",
    body: "A complete Islamic digital civilization — Quran, Hadith, articles, tools and AI, all in one place. This 30-second guide shows you where everything lives.",
    to: null as string | null,
    cta: null as string | null,
  },
  {
    icon: LayoutGrid,
    title: "Command Center",
    body: "Every module — 60+ sections from Tafsir al-Mizan to Qibla and Zakat — is one tap away in the Command Center grid on the home page.",
    to: "/modules",
    cta: "Open modules",
  },
  {
    icon: BookOpen,
    title: "Read & study",
    body: "Read the full Quran with translation and tafsir, browse the Hadith library, and read in-depth articles with AI Summary, Ask and Translate buttons.",
    to: "/quran",
    cta: "Open Quran",
  },
  {
    icon: Compass,
    title: "Daily companion",
    body: "The top ticker gives you Hijri date, prayer times and a daily narration. Qibla, Tasbih, Duas and calculators are in Tools & Utilities.",
    to: "/daily",
    cta: "Daily trio",
  },
  {
    icon: GraduationCap,
    title: "Ask the AI anytime",
    body: "The floating AI button (bottom corner) answers per Fiqh Ja'fariya on every page. Kids can learn tech and ethics in Mahdi AI Academy.",
    to: "/ai",
    cta: "Try the AI",
  },
];

export function WelcomeTour() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    try {
      if (!localStorage.getItem(KEY)) {
        const t = setTimeout(() => setOpen(true), 1200);
        return () => clearTimeout(t);
      }
    } catch {
      /* storage blocked */
    }
    return;
  }, []);

  function close() {
    setOpen(false);
    try {
      localStorage.setItem(KEY, "done");
    } catch {
      /* ignore */
    }
  }

  if (!open) return null;
  const s = STEPS[step]!;
  const Icon = s.icon;
  const last = step === STEPS.length - 1;

  return (
    <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center bg-background/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-lg border border-gold/30 bg-card shadow-2xl">
        <button
          onClick={close}
          aria-label="Close guide"
          className="absolute top-3 end-3 text-muted-foreground hover:text-gold"
        >
          <X className="size-4" />
        </button>

        <div className="p-7">
          <div className="flex items-center gap-3 text-gold">
            <Icon className="size-5" />
            <span className="text-[10px] uppercase tracking-[0.3em]">
              Guide {step + 1} / {STEPS.length}
            </span>
          </div>
          <h2 className="mt-4 font-display italic text-2xl md:text-3xl leading-tight">{s.title}</h2>
          <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{s.body}</p>

          {s.to && s.cta && (
            <Link
              to={s.to}
              onClick={close}
              className="mt-5 inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] border border-gold/50 text-gold px-4 py-2.5 rounded-full hover:bg-gold/10 transition-colors"
            >
              {s.cta}
            </Link>
          )}

          <div className="mt-7 flex items-center justify-between">
            <div className="flex gap-1.5">
              {STEPS.map((_, i) => (
                <span
                  key={i}
                  className={`h-1 w-6 rounded-full ${i <= step ? "bg-gold" : "bg-border"}`}
                />
              ))}
            </div>
            <div className="flex items-center gap-3">
              <button onClick={close} className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">
                Skip
              </button>
              <button
                onClick={() => (last ? close() : setStep((v) => v + 1))}
                className="text-[10px] uppercase tracking-[0.2em] bg-gold text-primary-foreground px-5 py-2.5 rounded-full hover:opacity-90"
              >
                {last ? "Start exploring" : "Next"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
