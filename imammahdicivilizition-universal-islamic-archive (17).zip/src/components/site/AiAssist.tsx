import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { Sparkles, Loader2, MessageCircleQuestion, Languages, BookOpen } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { aiAssist } from "@/lib/ai-assist.functions";

type Mode = "summary" | "ask" | "explain" | "translate";

const LANGS = ["Urdu", "English", "Arabic", "Farsi", "Turkish", "French", "German"];

export function AiAssist({
  title,
  text,
  modes = ["summary", "ask", "translate"],
  compact = false,
}: {
  title?: string;
  text: string;
  modes?: Mode[];
  compact?: boolean;
}) {
  const run = useServerFn(aiAssist);
  const [active, setActive] = useState<Mode | null>(null);
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [question, setQuestion] = useState("");
  const [lang, setLang] = useState("Urdu");

  async function go(mode: Mode) {
    setActive(mode);
    if (mode === "ask" && !question.trim()) return;
    setLoading(true);
    setError("");
    setOutput("");
    try {
      const res = await run({
        data: {
          mode,
          title,
          text: text.slice(0, 12000),
          ...(mode === "ask" ? { question: question.trim() } : {}),
          ...(mode === "translate" ? { lang } : {}),
        },
      });
      if (res.error) setError(res.error);
      else setOutput(res.text);
    } catch {
      setError("AI could not answer this time. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  const btn =
    "inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] border border-border px-3 py-2 rounded-full text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors disabled:opacity-50";

  return (
    <div className={compact ? "mt-3" : "mt-10 border border-border bg-card/60 backdrop-blur p-5"}>
      {!compact && (
        <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-gold mb-4">
          <Sparkles className="size-3.5" /> AI Study Tools
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        {modes.includes("summary") && (
          <button className={btn} onClick={() => void go("summary")} disabled={loading}>
            <Sparkles className="size-3.5" /> Summary
          </button>
        )}
        {modes.includes("explain") && (
          <button className={btn} onClick={() => void go("explain")} disabled={loading}>
            <BookOpen className="size-3.5" /> Explain
          </button>
        )}
        {modes.includes("ask") && (
          <button className={btn} onClick={() => setActive("ask")} disabled={loading}>
            <MessageCircleQuestion className="size-3.5" /> Ask about this
          </button>
        )}
        {modes.includes("translate") && (
          <>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              aria-label="Translation language"
              className="bg-transparent border border-border rounded-full px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground"
            >
              {LANGS.map((l) => (
                <option key={l} value={l} className="bg-background">
                  {l}
                </option>
              ))}
            </select>
            <button className={btn} onClick={() => void go("translate")} disabled={loading}>
              <Languages className="size-3.5" /> Translate
            </button>
          </>
        )}
      </div>

      {active === "ask" && (
        <form
          className="mt-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void go("ask");
          }}
        >
          <input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question about this text…"
            className="flex-1 bg-transparent border border-border px-4 py-2.5 text-sm outline-none focus:border-gold/60"
          />
          <button type="submit" className={btn} disabled={loading || !question.trim()}>
            Ask
          </button>
        </form>
      )}

      {loading && (
        <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="size-4 animate-spin text-gold" /> Thinking…
        </p>
      )}
      {error && <p className="mt-4 text-xs text-destructive">{error}</p>}
      {output && (
        <div className="mt-4 prose prose-invert prose-sm max-w-none prose-a:text-gold prose-strong:text-gold">
          <ReactMarkdown>{output}</ReactMarkdown>
        </div>
      )}
    </div>
  );
}
