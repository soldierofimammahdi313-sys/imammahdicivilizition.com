type Props = {
  src: string;
  alt: string;
  eyebrow?: string;
  title?: string;
  subtitle?: string;
};

export function PageBanner({ src, alt, eyebrow, title, subtitle }: Props) {
  return (
    <div className="px-4 md:px-6 max-w-7xl mx-auto">
      <div className="relative overflow-hidden rounded-2xl ring-1 ring-border">
        <img
          src={src}
          alt={alt}
          width={1536}
          height={768}
          loading="lazy"
          decoding="async"
          className="w-full h-[180px] sm:h-[240px] md:h-[320px] object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-transparent" />
        {(eyebrow || title || subtitle) && (
          <div className="absolute inset-x-0 bottom-0 p-5 md:p-8">
            {eyebrow && (
              <span className="text-[10px] font-bold text-gold uppercase tracking-[0.35em]">{eyebrow}</span>
            )}
            {title && (
              <h2 className="mt-2 font-display italic text-2xl md:text-4xl text-foreground">{title}</h2>
            )}
            {subtitle && (
              <p className="mt-2 text-xs md:text-sm text-muted-foreground max-w-[60ch]">{subtitle}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
