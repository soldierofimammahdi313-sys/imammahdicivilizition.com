import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { SocialIcons } from "./SocialIcons";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { useI18n } from "@/lib/i18n";
import { SearchPalette, useSearchPalette } from "./SearchPalette";
import { ThemeToggle } from "./ThemeToggle";
import { NotificationBell } from "./NotificationBell";
import { SadaqahTrigger } from "./SadaqahModal";
import { PreferencesButton } from "./PreferencesModal";
import { FIQH_SCHOOLS, fiqhName, useFiqh } from "@/lib/fiqh";
import mahdiLogo from "@/assets/mahdi-logo.png";

/** Knowledge destinations, in the order a reader is likely to want them. */
const KNOWLEDGE_LINKS = [
  { to: "/quran", key: "nav.quran" },
  { to: "/hadith", key: "nav.hadith" },
  { to: "/tafsir-al-mizan", key: "nav.tafsir" },
  { to: "/library", key: "nav.library" },
  { to: "/articles", key: "nav.research" },
  { to: "/academy", key: "nav.academy" },
  { to: "/who-is-imam-mahdi", key: "nav.imamMahdi" },
  { to: "/duas", key: "nav.duas" },
] as const;

const SECONDARY_LINKS = [
  { to: "/ai", key: "nav.ai" },
  { to: "/daily", key: "nav.daily" },
  { to: "/modules", key: "hub.kicker" },
  { to: "/discussions", key: "hub.community" },
  { to: "/videos", key: "hub.videos" },
  { to: "/shop", key: "nav.shop" },
] as const;

const LEGAL_LINKS = [
  { to: "/about", key: "nav.about" },
  { to: "/contact", key: "nav.contact" },
  { to: "/privacy", key: "nav.privacy" },
  { to: "/terms", key: "nav.terms" },
  { to: "/disclaimer", key: "nav.disclaimer" },
] as const;

/** Small accessible dropdown: closes on outside click and on Escape. */
function NavMenu({
  label,
  children,
  className = "",
}: {
  label: string;
  children: (close: () => void) => ReactNode;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="true"
        className="flex items-center gap-1.5 hover:text-gold transition-colors"
      >
        {label}
        <svg width="9" height="9" viewBox="0 0 10 10" aria-hidden className="opacity-60">
          <path d="M2 3.5l3 3 3-3" stroke="currentColor" fill="none" strokeWidth="1.5" />
        </svg>
      </button>
      {open && (
        <div className="absolute start-0 mt-3 w-60 bg-card border border-border ring-1 ring-gold/20 shadow-2xl z-[60] py-1.5">
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

const dropdownItem =
  "block px-4 py-2.5 text-[11px] uppercase tracking-[0.16em] text-muted-foreground hover:bg-emerald-soft hover:text-gold transition-colors";

export function SiteHeader() {
  const [user, setUser] = useState<User | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const { t, lang } = useI18n();
  const { fiqh } = useFiqh();
  const { open: searchOpen, setOpen: setSearchOpen } = useSearchPalette();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const closeMobile = () => setMenuOpen(false);

  return (
    <nav
      aria-label="Primary"
      className="fixed top-0 w-full z-50 border-b border-border bg-background/75 backdrop-blur-md"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between gap-3">
        <Link to="/" className="flex items-center gap-3 group shrink-0">
          <img
            loading="eager"
            fetchPriority="high"
            decoding="async"
            src={mahdiLogo}
            alt="Imam Mahdi Civilization logo"
            width={1024}
            height={1024}
            className="size-11 object-contain drop-shadow-[0_0_12px_color-mix(in_oklab,var(--gold)_35%,transparent)] transition-transform group-hover:scale-105"
          />
          <span className="font-bold text-[13px] tracking-[0.18em] uppercase hidden sm:inline lg:hidden xl:inline">
            Imam Mahdi Civilization
          </span>
        </Link>

        {/* Universal desktop navigation */}
        <div className="hidden lg:flex items-center gap-5 text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
          <NavMenu label={t("nav.knowledge")}>
            {(close) => (
              <>
                {KNOWLEDGE_LINKS.map((l) => (
                  <Link key={l.to} to={l.to} onClick={close} className={dropdownItem}>
                    {t(l.key)}
                  </Link>
                ))}
                <span className="block border-t border-border my-1.5" />
                {SECONDARY_LINKS.map((l) => (
                  <Link key={l.to} to={l.to} onClick={close} className={dropdownItem}>
                    {t(l.key)}
                  </Link>
                ))}
              </>
            )}
          </NavMenu>

          <NavMenu label={t("nav.fiqh")}>
            {(close) => (
              <>
                <Link to="/fiqh" onClick={close} className={`${dropdownItem} text-gold`}>
                  {t("fiqh.schools")}
                </Link>
                <span className="block border-t border-border my-1.5" />
                {FIQH_SCHOOLS.map((s) => (
                  <Link
                    key={s.id}
                    to="/fiqh/$school"
                    params={{ school: s.slug }}
                    onClick={close}
                    className={`${dropdownItem} ${s.id === fiqh ? "text-gold" : ""}`}
                  >
                    {fiqhName(s, lang)}
                  </Link>
                ))}
              </>
            )}
          </NavMenu>

          <Link to="/library" className="hover:text-gold transition-colors hidden xl:inline">
            {t("nav.library")}
          </Link>
          <Link to="/articles" className="hover:text-gold transition-colors hidden xl:inline">
            {t("nav.research")}
          </Link>
          {user && (
            <Link to="/dashboard" className="hover:text-gold transition-colors">
              {t("nav.dashboard")}
            </Link>
          )}
          <Link to="/donate" className="hover:text-gold transition-colors">
            {t("nav.donate")}
          </Link>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            aria-label={t("nav.search")}
            className="group flex items-center gap-2 rounded-md border border-border px-3 h-9 text-[11px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-gold/60 hover:text-gold"
          >
            <span aria-hidden className="text-sm leading-none">⌕</span>
            <span className="hidden lg:inline">{t("nav.search")}</span>
            <kbd className="hidden lg:inline font-mono-display text-[9px] text-muted-foreground/60 border border-border rounded px-1 py-0.5">
              ⌘K
            </kbd>
          </button>
          <SocialIcons className="hidden 2xl:flex" iconClass="size-3.5" />
          <PreferencesButton className="hidden sm:flex" />
          <LanguageSwitcher className="hidden md:block" />
          <ThemeToggle />
          <NotificationBell user={user} />
          {user ? (
            <button
              onClick={() => supabase.auth.signOut()}
              className="hidden sm:inline text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-gold transition-colors"
            >
              {t("nav.signout")}
            </button>
          ) : (
            <Link
              to="/auth"
              className="hidden sm:inline text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-gold transition-colors"
            >
              {t("nav.signin")}
            </Link>
          )}
          <SadaqahTrigger
            className="hidden xl:inline-flex items-center gap-2 px-4 py-2.5 bg-[#F0B90B] text-[#1E2329] font-bold uppercase text-[11px] tracking-[0.16em] rounded-md hover:brightness-110 transition-all"
            label={t("nav.donate")}
          />
          <Link
            to="/join"
            className="hidden 2xl:inline-flex px-5 py-2.5 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors"
          >
            {t("nav.join")}
          </Link>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? t("nav.close") : t("nav.menu")}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            className="lg:hidden grid place-items-center size-11 border border-border text-foreground hover:border-gold hover:text-gold transition-colors"
          >
            <span aria-hidden className="text-lg leading-none">{menuOpen ? "✕" : "☰"}</span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div
          id="mobile-menu"
          className="lg:hidden border-t border-border bg-background/98 backdrop-blur-md max-h-[75dvh] overflow-y-auto overscroll-contain"
        >
          <div className="px-4 sm:px-6 py-4 space-y-5">
            <MobileGroup title={t("nav.knowledge")}>
              {KNOWLEDGE_LINKS.map((l) => (
                <MobileLink key={l.to} to={l.to} label={t(l.key)} onClick={closeMobile} />
              ))}
            </MobileGroup>

            <MobileGroup title={t("nav.fiqh")}>
              <MobileLink to="/fiqh" label={t("fiqh.schools")} onClick={closeMobile} />
              {FIQH_SCHOOLS.map((s) => (
                <MobileLink
                  key={s.id}
                  to="/fiqh/$school"
                  params={{ school: s.slug }}
                  label={fiqhName(s, lang)}
                  onClick={closeMobile}
                  active={s.id === fiqh}
                />
              ))}
            </MobileGroup>

            <MobileGroup title={t("nav.more")}>
              {SECONDARY_LINKS.map((l) => (
                <MobileLink key={l.to} to={l.to} label={t(l.key)} onClick={closeMobile} />
              ))}
              {user && <MobileLink to="/dashboard" label={t("nav.dashboard")} onClick={closeMobile} />}
            </MobileGroup>

            <MobileGroup title={t("nav.about")}>
              {LEGAL_LINKS.map((l) => (
                <MobileLink key={l.to} to={l.to} label={t(l.key)} onClick={closeMobile} />
              ))}
            </MobileGroup>

            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <PreferencesButton className="flex-1 justify-center min-h-11" showLabel />
                <LanguageSwitcher className="md:hidden" />
              </div>
              <SadaqahTrigger
                className="flex min-h-11 items-center justify-center bg-[#F0B90B] text-[#1E2329] font-bold uppercase text-[12px] tracking-[0.2em] rounded-md"
                label={t("nav.donate")}
              />
              <Link
                to="/join"
                onClick={closeMobile}
                className="flex min-h-11 items-center justify-center bg-gold text-primary-foreground font-bold uppercase text-[12px] tracking-[0.2em]"
              >
                {t("nav.join")}
              </Link>
              {!user && (
                <Link
                  to="/auth"
                  onClick={closeMobile}
                  className="flex min-h-11 items-center justify-center border border-border text-[12px] uppercase tracking-[0.2em] text-muted-foreground"
                >
                  {t("nav.signin")}
                </Link>
              )}
            </div>
          </div>
        </div>
      )}

      <SearchPalette open={searchOpen} onOpenChange={setSearchOpen} />
    </nav>
  );
}

function MobileGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold">{title}</h2>
      <ul className="mt-2 grid grid-cols-2 gap-2">{children}</ul>
    </section>
  );
}

function MobileLink({
  to,
  params,
  label,
  onClick,
  active,
}: {
  to: string;
  params?: Record<string, string>;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <li>
      <Link
        to={to as never}
        params={params as never}
        onClick={onClick}
        className={`flex min-h-11 items-center px-3 text-[12px] font-medium uppercase tracking-[0.12em] border border-border transition-colors hover:text-gold hover:border-gold/50 ${
          active ? "text-gold border-gold/50" : "text-muted-foreground"
        }`}
      >
        {label}
      </Link>
    </li>
  );
}
