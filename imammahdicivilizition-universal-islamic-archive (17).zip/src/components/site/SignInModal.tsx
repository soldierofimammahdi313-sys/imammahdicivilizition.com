import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";

export function SignInModal() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (cancelled) return;
      if (data.user) return;
      try {
        if (localStorage.getItem("signin-dismissed")) return;
      } catch {}
      setTimeout(() => !cancelled && setOpen(true), 1200);
    });
    return () => { cancelled = true; };
  }, []);

  const close = () => {
    setOpen(false);
    try { localStorage.setItem("signin-dismissed", "1"); } catch {}
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Welcome back.");
    close();
  };

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/85 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-card border border-gold/30 ring-1 ring-gold/10 p-8 shadow-[0_0_80px_-20px_rgba(212,175,55,0.4)]">
        <button onClick={close} className="absolute top-3 right-3 size-8 flex items-center justify-center text-muted-foreground hover:text-gold text-xl">×</button>
        <div className="text-center mb-6">
          <div className="mx-auto size-14 rounded-full ring-1 ring-gold/50 flex items-center justify-center font-bold text-gold text-lg">IM</div>
          <h2 className="mt-4 font-display italic text-3xl">{t("auth.welcome")}</h2>
          <p className="mt-2 text-xs text-muted-foreground">{t("auth.subtitle")}</p>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <input type="email" required placeholder={t("auth.email")} value={email} onChange={e => setEmail(e.target.value)}
            className="w-full bg-background border border-border px-4 py-3 text-sm focus:border-gold outline-none" />
          <input type="password" required placeholder={t("auth.password")} value={password} onChange={e => setPassword(e.target.value)}
            className="w-full bg-background border border-border px-4 py-3 text-sm focus:border-gold outline-none" />
          <button type="submit" disabled={loading}
            className="w-full bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.25em] py-3.5 hover:bg-foreground transition-colors disabled:opacity-60">
            {loading ? "…" : t("auth.signin")}
          </button>
        </form>
        <div className="mt-5 flex items-center justify-between text-[11px] uppercase tracking-[0.2em]">
          <Link to="/auth" onClick={close} className="text-gold hover:underline">{t("auth.create")}</Link>
          <button onClick={close} className="text-muted-foreground hover:text-foreground">{t("auth.later")}</button>
        </div>
      </div>
    </div>
  );
}