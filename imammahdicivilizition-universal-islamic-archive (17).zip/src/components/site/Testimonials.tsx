import { useEffect, useMemo, useRef, useState } from "react";
import { Star, Quote, PenLine, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";
import { supabase } from "@/integrations/supabase/client";

type Review = {
  id: string;
  name: string;
  place: string;
  rating: number;
  text: string;
};

const COPY = {
  en: {
    eyebrow: "Voices of the Ummah",
    title: "Reader reviews",
    sub: "Every review below was submitted by a real visitor and published only after review by our team.",
    empty: "No reviews have been published yet. Be the first to share your experience of the platform.",
    cta: "Share your review",
    formTitle: "Share your review",
    name: "Your name",
    place: "City or title (optional)",
    rating: "Your rating",
    message: "Your review",
    submit: "Submit review",
    thanks: "JazakAllah khair — your review was sent for moderation and appears once approved.",
    error: "Could not save your review. Please try again.",
    close: "Close",
  },
  ur: {
    eyebrow: "امت کی آوازیں",
    title: "قارئین کی آراء",
    sub: "یہاں درج ہر رائے حقیقی زائرین نے بھیجی ہے اور جانچ کے بعد شائع کی گئی ہے۔",
    empty: "ابھی کوئی رائے شائع نہیں ہوئی۔ سب سے پہلے آپ اپنی رائے بھیجیں۔",
    cta: "اپنی رائے کا اظہار کریں",
    formTitle: "اپنی رائے کا اظہار کریں",
    name: "آپ کا نام",
    place: "شہر یا عہدہ (اختیاری)",
    rating: "آپ کی درجہ بندی",
    message: "آپ کی رائے",
    submit: "رائے بھیجیں",
    thanks: "جزاک اللہ خیر — آپ کی رائے جانچ کے لیے بھیج دی گئی ہے، منظوری کے بعد شائع ہوگی۔",
    error: "رائے محفوظ نہ ہو سکی۔ براہِ کرم دوبارہ کوشش کریں۔",
    close: "بند کریں",
  },
};

function Stars({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`flex items-center gap-0.5 ${className}`} aria-label={`${value} / 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          aria-hidden
          className={`size-3.5 ${i < value ? "fill-gold text-gold" : "text-muted-foreground/40"}`}
        />
      ))}
      <span className="ms-2 text-[10px] font-mono-display tracking-widest text-muted-foreground">{value}/5</span>
    </div>
  );
}

function ReviewCard({ r, urdu }: { r: Review; urdu: boolean }) {
  return (
    <article className="surface-card p-6 rounded-lg text-start" dir={urdu ? "rtl" : "ltr"}>
      <div className="flex items-start justify-between gap-3">
        <Stars value={r.rating} />
        <Quote aria-hidden className="size-5 text-gold/50 shrink-0" />
      </div>
      <p className={`mt-4 text-sm leading-relaxed text-foreground/90 ${urdu ? "font-urdu" : ""}`}>{r.text}</p>
      <div className="mt-5 pt-4 border-t border-border">
        <p className={`text-sm font-semibold text-gold ${urdu ? "font-urdu" : ""}`}>{r.name}</p>
        {r.place && (
          <p className={`text-xs text-muted-foreground mt-0.5 ${urdu ? "font-urdu" : ""}`}>{r.place}</p>
        )}
      </div>
    </article>
  );
}

export function Testimonials() {
  const { lang } = useI18n();
  const urdu = lang === "ur";
  const c = urdu ? COPY.ur : COPY.en;

  const [live, setLive] = useState<Review[]>([]);
  const [open, setOpen] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    supabase
      .from("site_reviews")
      .select("id,name,place,rating,message")
      .eq("approved", true)
      .order("created_at", { ascending: false })
      .limit(12)
      .then(({ data }) => {
        if (cancelled || !data) return;
        setLive(
          data.map((d) => ({
            id: d.id,
            name: d.name,
            place: d.place ?? "",
            rating: d.rating,
            text: d.message,
          })),
        );
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const reviews = useMemo(() => live, [live]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <section id="reviews" aria-labelledby="reviews-heading" className="py-24 border-t border-border">
      <div className="max-w-7xl mx-auto px-6 text-center" dir={urdu ? "rtl" : "ltr"}>
        <span className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold">{c.eyebrow}</span>
        <h2 id="reviews-heading" className={`mt-4 font-display italic text-3xl md:text-5xl ${urdu ? "font-urdu not-italic" : ""}`}>
          {c.title}
        </h2>
        <p className={`mt-4 text-sm text-muted-foreground max-w-2xl mx-auto ${urdu ? "font-urdu" : ""}`}>{c.sub}</p>

        {reviews.length > 0 ? (
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {reviews.map((r) => (
              <ReviewCard key={r.id} r={r} urdu={urdu} />
            ))}
          </div>
        ) : (
          <p className={`mt-10 text-sm text-muted-foreground max-w-xl mx-auto ${urdu ? "font-urdu" : ""}`}>{c.empty}</p>
        )}

        <div className="mt-12">
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-primary-foreground text-[11px] font-bold uppercase tracking-[0.25em] hover-lift"
          >
            <PenLine aria-hidden className="size-4" />
            <span className={urdu ? "font-urdu tracking-normal" : ""}>{c.cta}</span>
          </button>
        </div>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
          aria-label={c.formTitle}
          onClick={(e) => e.target === e.currentTarget && setOpen(false)}
        >
          <div ref={dialogRef} className="w-full max-w-lg surface-card rounded-lg p-7 shadow-luxe" dir={urdu ? "rtl" : "ltr"}>
            <ReviewForm c={c} urdu={urdu} onClose={() => setOpen(false)} />
          </div>
        </div>
      )}
    </section>
  );
}

function ReviewForm({ c, urdu, onClose }: { c: typeof COPY.en; urdu: boolean; onClose: () => void }) {
  const [name, setName] = useState("");
  const [place, setPlace] = useState("");
  const [rating, setRating] = useState(5);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const n = name.trim().slice(0, 80);
    const m = message.trim().slice(0, 600);
    if (n.length < 2 || m.length < 5) return;
    setBusy(true);
    const { error } = await supabase.from("site_reviews").insert({
      name: n,
      place: place.trim().slice(0, 80) || null,
      rating,
      message: m,
    });
    setBusy(false);
    if (error) {
      toast.error(c.error);
      return;
    }
    toast.success(c.thanks);
    onClose();
  };

  const field = "w-full bg-background/60 border border-border px-4 py-3 text-sm outline-none focus:border-gold/60";

  return (
    <form onSubmit={submit} className="space-y-4 text-start">
      <h3 className={`font-display italic text-2xl ${urdu ? "font-urdu not-italic" : ""}`}>{c.formTitle}</h3>

      <input
        className={`${field} ${urdu ? "font-urdu" : ""}`}
        placeholder={c.name}
        aria-label={c.name}
        value={name}
        maxLength={80}
        required
        onChange={(e) => setName(e.target.value)}
      />
      <input
        className={`${field} ${urdu ? "font-urdu" : ""}`}
        placeholder={c.place}
        aria-label={c.place}
        value={place}
        maxLength={80}
        onChange={(e) => setPlace(e.target.value)}
      />

      <div>
        <span className={`block text-[10px] uppercase tracking-[0.3em] text-gold mb-2 ${urdu ? "font-urdu tracking-normal" : ""}`}>
          {c.rating}
        </span>
        <div className="flex items-center gap-1" dir="ltr">
          {[1, 2, 3, 4, 5].map((v) => (
            <button key={v} type="button" onClick={() => setRating(v)} aria-label={`${v} / 5`} aria-pressed={rating === v} className="p-1">
              <Star className={`size-6 ${v <= rating ? "fill-gold text-gold" : "text-muted-foreground/40"}`} />
            </button>
          ))}
        </div>
      </div>

      <textarea
        className={`${field} min-h-32 resize-y ${urdu ? "font-urdu" : ""}`}
        placeholder={c.message}
        aria-label={c.message}
        value={message}
        maxLength={600}
        required
        onChange={(e) => setMessage(e.target.value)}
      />

      <div className="flex items-center justify-end gap-3 pt-1">
        <button type="button" onClick={onClose} className={`px-5 py-3 text-xs text-muted-foreground hover:text-foreground ${urdu ? "font-urdu" : ""}`}>
          {c.close}
        </button>
        <button
          type="submit"
          disabled={busy}
          className={`inline-flex items-center gap-2 px-6 py-3 bg-gold text-primary-foreground text-[11px] font-bold uppercase tracking-[0.25em] disabled:opacity-60 ${urdu ? "font-urdu tracking-normal" : ""}`}
        >
          {busy && <Loader2 aria-hidden className="size-4 animate-spin" />}
          {c.submit}
        </button>
      </div>
    </form>
  );
}
