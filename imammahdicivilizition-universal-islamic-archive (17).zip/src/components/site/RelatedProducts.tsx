import { Link } from "@tanstack/react-router";
import { ProductCard } from "@/components/site/ShopProduct";
import { relatedProducts } from "@/lib/shop-products";

/** Shows 3-4 Amazon products relevant to the page topic. */
export function RelatedProducts({ topic, limit = 4 }: { topic: string; limit?: number }) {
  const products = relatedProducts(topic, limit);
  if (products.length === 0) return null;

  return (
    <section className="mt-14">
      <div className="flex items-baseline justify-between mb-5 pb-3 border-b border-border">
        <h2 className="text-[11px] font-bold uppercase tracking-[0.3em] text-gold">
          Related Islamic Products
        </h2>
        <Link to="/shop" className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-gold">
          View shop
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {products.map((p) => (
          <ProductCard key={p.url} product={p} />
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground italic">
        As an Amazon Associate I earn from qualifying purchases.
      </p>
    </section>
  );
}
