import { getCoordsSilently } from "@/lib/geo";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useHydrated } from "@tanstack/react-router";

const HIJRI_AR = [
  "محرم","صفر","ربیع الأول","ربیع الثانی","جمادی الأولی","جمادی الثانیة",
  "رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة",
];

// Every visitor sees the same reference day, independent of their device clock.
const DISPLAY_TIME_ZONE = "Asia/Karachi";
// +1 / -1 nudge for regional moon-sighting. Never affects the Gregorian date.
const HIJRI_DATE_OFFSET_DAYS = 0;

/** The calendar day in DISPLAY_TIME_ZONE, as a UTC-midday Date (drift-proof). */
function referenceDay(date: Date, addDays = 0) {
  const p = new Intl.DateTimeFormat("en-CA", {
    timeZone: DISPLAY_TIME_ZONE,
    year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date);
  const get = (t: string) => Number(p.find(x => x.type === t)?.value);
  return new Date(Date.UTC(get("year"), get("month") - 1, get("day") + addDays, 12));
}

function getHijri(date: Date) {
  try {
    const fmt = new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", {
      timeZone: "UTC",
      day: "numeric", month: "numeric", year: "numeric",
    });
    const parts = fmt.formatToParts(referenceDay(date, HIJRI_DATE_OFFSET_DAYS));
    const d = Number(parts.find(p => p.type === "day")?.value);
    const m = Number(parts.find(p => p.type === "month")?.value);
    const y = Number(parts.find(p => p.type === "year")?.value);
    return { d, m, y };
  } catch {
    return { d: 1, m: 1, y: 1446 };
  }
}

const PRAYERS: { key: string; label: string }[] = [
  { key: "Fajr", label: "فجر" },
  { key: "Sunrise", label: "طلوع" },
  { key: "Dhuhr", label: "ظهر" },
  { key: "Asr", label: "عصر" },
  { key: "Maghrib", label: "مغرب" },
  { key: "Isha", label: "عشاء" },
];

export function DateTicker() {
  const [now, setNow] = useState(() => new Date());
  const trackRef = useRef<HTMLDivElement>(null);
  const hydrated = useHydrated();
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const { data: timings } = useQuery({
    queryKey: ["ticker-prayer-times"],
    enabled: hydrated,
    queryFn: async () => {
      const coords = await getCoordsSilently();
      const r = await fetch(`https://api.aladhan.com/v1/timings?latitude=${coords.lat}&longitude=${coords.lng}&method=2`);
      const j = await r.json();
      return j.data.timings as Record<string, string>;
    },
    staleTime: 1000 * 60 * 60 * 6,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    let raf = 0; let x = 0; const speed = 0.4;
    const tick = () => {
      x -= speed;
      const half = el.scrollWidth / 2;
      if (-x >= half) x = 0;
      el.style.transform = `translateX(${x}px)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [timings]);

  const items = useMemo(() => {
    if (!hydrated) return [] as { k: string; v: string }[];
    const hijri = getHijri(now);
    const greg = referenceDay(now).toLocaleDateString("en-GB", {
      timeZone: "UTC", day: "2-digit", month: "short", year: "numeric",
    });
    const list: { k: string; v: string }[] = [
      { k: "☾ ہجری تاریخ", v: `${hijri.d} ${HIJRI_AR[hijri.m - 1]} ${hijri.y} هـ` },
      { k: "تاریخ", v: greg },
    ];
    if (timings) {
      for (const p of PRAYERS) {
        if (timings[p.key]) list.push({ k: p.label, v: timings[p.key] });
      }
    }
    return list;
  }, [hydrated, now, timings]);

  const row = (
    <>
      {items.map((it, i) => (
        <span key={i} className="inline-flex items-center gap-2 px-6 whitespace-nowrap text-[11px] tracking-wider">
          <span className="text-emerald font-bold uppercase tracking-[0.25em] text-[10px]">{it.k}</span>
          <span className="text-foreground/90">{it.v}</span>
          <span className="text-emerald/40">•</span>
        </span>
      ))}
    </>
  );

  return (
    <div className="fixed top-[7.25rem] left-0 right-0 z-40 bg-card/95 backdrop-blur-md border-b border-emerald/20 overflow-hidden">
      <div className="relative flex items-center h-8">
        <div className="shrink-0 z-10 bg-emerald text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] px-4 py-1 mr-2">
          ☾ Date
        </div>
        <div className="overflow-hidden flex-1">
          <div ref={trackRef} className="flex whitespace-nowrap will-change-transform">
            <div className="flex">{row}</div>
            <div className="flex" aria-hidden="true">{row}</div>
          </div>
        </div>
      </div>
    </div>
  );
}