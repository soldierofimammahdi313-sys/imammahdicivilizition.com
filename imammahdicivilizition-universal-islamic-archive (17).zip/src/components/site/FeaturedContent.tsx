import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, Flame, Clock, Heart, MessageSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CardGridSkeleton, InlineEmpty, InlineError } from "./States";
import { coverFor } from "@/lib/article-covers";

type ArticleRow = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  published_at: string | null;
  reading_minutes: number | null;
  cover_url: string | null;
  tags: string[] | null;
};

type TrendingPost = {
  id: string;
  title: string;
  category: string;
  created_at: string;
  likes: number;
};

/**
 * Live editorial rail: recently published articles and the most-appreciated
 * community discussions. Everything is real data — empty states show when
 * the archive has nothing yet.
 */
export function FeaturedContent() {
  const articles = useQuery({
    queryKey: ["home-recent-articles"],
    queryFn: async (): Promise<ArticleRow[]> => {
      const { data, error } = await supabase
        .from("articles")
        .select("id,slug,title,excerpt,published_at,reading_minutes,cover_url,tags")
        .eq("status", "published")
        .order("published_at", { ascending: false })
        .limit(3);
      if (error) throw error;
      return data ?? [];
    },
  });

  const trending = useQuery({
    queryKey: ["home-trending-discussions"],
    queryFn: async (): Promise<TrendingPost[]> => {
      const { data, error } = await supabase
        .from("community_posts")
        .select("id,title,category,created_at,community_post_like_counts(like_count)")
        .order("created_at", { ascending: false })
        .limit(24);
      if (error) throw error;
      return (data ?? [])
        .map((p) => ({
          id: p.id,
          title: p.title,
          category: p.category,
          created_at: p.created_at,
          likes:
            (p.community_post_like_counts as unknown as { like_count: number }[] | null)?.[0]?.like_count ?? 0,
        }))
        .sort((a, b) => b.likes - a.likes || (a.created_at < b.created_at ? 1 : -1))
        .slice(0, 5);
    },
  });

  return (
    <section aria-labelledby="featured-title" className="py-24 px-6 max-w-7xl mx-auto">
      <header className="text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-gold">Living Archive</p>
        <h2 id="featured-title" className="mt-4 font-display italic text-4xl md:text-5xl">
          Featured &amp; Fresh
        </h2>
        <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
          Newly published research from the archive, and the discussions the Ummah is engaging with right now.
        </p>
      </header>

      <div className="mt-14 grid lg:grid-cols-[2fr_1fr] gap-10">
        <div>
          <h3 className="flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            <Clock className="size-3.5" aria-hidden /> Recently added
          </h3>

          {articles.isLoading && <CardGridSkeleton count={2} className="mt-5 lg:grid-cols-2" />}
          {articles.isError && (
            <div className="mt-5">
              <InlineError onRetry={() => articles.refetch()} />
            </div>
          )}
          {articles.data && articles.data.length === 0 && (
            <div className="mt-5">
              <InlineEmpty
                title="The archive is being written"
                hint="Published research will appear here the moment the first article goes live."
                action={
                  <Link to="/articles" className="text-[10px] uppercase tracking-[0.3em] text-gold">
                    Visit the archive ▸
                  </Link>
                }
              />
            </div>
          )}
          {articles.data && articles.data.length > 0 && (
            <ul className="mt-5 grid md:grid-cols-2 gap-6">
              {articles.data.map((a) => (
                <li key={a.id}>
                  <Link
                    to="/articles/$slug"
                    params={{ slug: a.slug }}
                    className="group block h-full overflow-hidden border border-border bg-card/40 transition-colors hover:border-gold/50"
                  >
                    <div className="aspect-[16/9] overflow-hidden bg-muted">
                      <img
                        src={coverFor({ cover_url: a.cover_url, slug: a.slug, title: a.title, tags: a.tags })}
                        alt={a.title}
                        width={1280}
                        height={720}
                        loading="lazy"
                        className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                    <p className="text-[10px] uppercase tracking-[0.28em] text-gold">
                      {a.published_at ? new Date(a.published_at).toLocaleDateString() : "New"}
                      {a.reading_minutes ? ` · ${a.reading_minutes} min read` : ""}
                    </p>
                    <h4 className="mt-3 font-display italic text-2xl leading-snug group-hover:text-gold transition-colors">
                      {a.title}
                    </h4>
                    {a.excerpt && <p className="mt-3 text-sm text-muted-foreground line-clamp-3">{a.excerpt}</p>}
                    <span className="mt-5 inline-flex items-center gap-1 text-[10px] uppercase tracking-[0.28em] text-muted-foreground group-hover:text-gold">
                      Read <ArrowUpRight className="size-3" aria-hidden />
                    </span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <h3 className="flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            <Flame className="size-3.5" aria-hidden /> Trending discussions
          </h3>

          {trending.isLoading && (
            <div className="mt-5 space-y-3" role="status" aria-busy="true">
              <span className="sr-only">Loading discussions…</span>
              {[0, 1, 2].map((i) => (
                <div key={i} className="border border-border p-4">
                  <div className="h-3 w-20 animate-pulse rounded-sm bg-muted/60" />
                  <div className="mt-3 h-4 w-4/5 animate-pulse rounded-sm bg-muted/60" />
                </div>
              ))}
            </div>
          )}
          {trending.isError && (
            <div className="mt-5">
              <InlineError onRetry={() => trending.refetch()} />
            </div>
          )}
          {trending.data && trending.data.length === 0 && (
            <div className="mt-5">
              <InlineEmpty
                title="The majlis is quiet"
                hint="Be the first to open a discussion for the global Ummah."
                action={
                  <Link to="/discussions" className="text-[10px] uppercase tracking-[0.3em] text-gold">
                    Start a discussion ▸
                  </Link>
                }
              />
            </div>
          )}
          {trending.data && trending.data.length > 0 && (
            <ul className="mt-5 divide-y divide-border ring-1 ring-border bg-card/30">
              {trending.data.map((p, i) => (
                <li key={p.id}>
                  <Link
                    to="/discussions/$id"
                    params={{ id: p.id }}
                    className="flex gap-3 p-4 transition-colors hover:bg-gold-soft/15"
                  >
                    <span className="font-display italic text-gold text-lg leading-none w-6 shrink-0">{i + 1}</span>
                    <span className="min-w-0">
                      <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{p.category}</span>
                      <span className="block mt-1 text-sm truncate">{p.title}</span>
                      <span className="mt-1 flex items-center gap-3 text-[10px] text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <Heart className="size-3" aria-hidden /> {p.likes}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <MessageSquare className="size-3" aria-hidden /> Open
                        </span>
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}

          <Link
            to="/discussions"
            className="mt-5 inline-block text-[10px] uppercase tracking-[0.3em] text-gold hover:text-foreground transition-colors"
          >
            All discussions ▸
          </Link>
        </div>
      </div>
    </section>
  );
}