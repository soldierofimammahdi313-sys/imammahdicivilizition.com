import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { SadaqahModal } from "./SadaqahModal";

const LEFT_TABS = [
  { to: "/", label: "Home", icon: "⌂", exact: true },
  { to: "/quran", label: "Quran", icon: "۩", exact: false },
] as const;

const RIGHT_TABS = [
  { to: "/ai", label: "AI", icon: "✦", exact: false },
  { to: "/modules", label: "Hub", icon: "⬢", exact: false },
] as const;

const tabClass =
  "flex min-h-14 flex-col items-center justify-center gap-0.5 px-1 text-[10px] uppercase tracking-[0.12em] text-muted-foreground transition-colors [&.active]:text-gold hover:text-gold";

/** Thumb-reachable navigation for phones; hidden from md upwards. */
export function MobileTabBar() {
  const [sadaqahOpen, setSadaqahOpen] = useState(false);
  return (
    <>
      <nav
        aria-label="Primary mobile navigation"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t border-border bg-background/95 backdrop-blur-md pb-[env(safe-area-inset-bottom)]"
      >
        <ul className="grid grid-cols-5 items-end">
          {LEFT_TABS.map((t) => (
            <li key={t.to}>
              <Link to={t.to} className={tabClass} activeOptions={{ exact: t.exact }}>
                <span aria-hidden className="text-base leading-none">{t.icon}</span>
                {t.label}
              </Link>
            </li>
          ))}
          <li className="relative">
            <button
              type="button"
              onClick={() => setSadaqahOpen(true)}
              aria-label="Give Sadaqah — support our work"
              className="flex w-full min-h-14 flex-col items-center justify-end gap-1 pb-1.5"
            >
              <span
                aria-hidden
                className="-mt-6 grid size-12 place-items-center rounded-full bg-[#F0B90B] text-[#1E2329] text-xl font-bold shadow-[0_10px_24px_-8px_rgba(240,185,11,0.7)] ring-4 ring-background active:scale-95 transition-transform"
              >
                ☪
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#F0B90B]">
                Sadaqah
              </span>
            </button>
          </li>
          {RIGHT_TABS.map((t) => (
            <li key={t.to}>
              <Link to={t.to} className={tabClass} activeOptions={{ exact: t.exact }}>
                <span aria-hidden className="text-base leading-none">{t.icon}</span>
                {t.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <SadaqahModal open={sadaqahOpen} onOpenChange={setSadaqahOpen} />
    </>
  );
}
