import { useChat } from "@ai-sdk/react";
import { toast } from "sonner";
import { chatTransport } from "@/lib/chat-transport";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { Send, Square, X, Sparkles, Maximize2 } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { AiCreditsNotice } from "@/components/site/AiCreditsNotice";
import { classifyAiError } from "@/lib/ai-errors";

export function FloatingAi() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [aiError, setAiError] = useState<{ kind: "credits" | "rate-limit" | "other"; message: string } | null>(null);
  const { messages, sendMessage, status, stop } = useChat({
    transport: chatTransport,
    onError: (err) => {
      const kind = classifyAiError(err);
      setAiError({ kind, message: err.message || "AI could not respond. Please try again." });
      if (kind !== "credits") toast.error(err.message || "AI could not respond. Please try again.");
    },
  });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 100);
  }, [open]);

  const busy = status === "submitted" || status === "streaming";

  function submit() {
    const v = input.trim();
    if (!v || busy) return;
    setAiError(null);
    sendMessage({ text: v });
    setInput("");
  }

  function retryLast() {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    setAiError(null);
    if (lastUser) {
      const text = lastUser.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
      if (text) sendMessage({ text });
    }
  }

  return (
    <>
      {/* Launcher */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open N-EYES AI"
          className="fixed bottom-20 md:bottom-6 right-6 z-[70] group"
        >
          <span className="absolute inset-0 rounded-full bg-gold/40 blur-xl animate-pulse" />
          <span className="relative flex items-center gap-2 bg-gradient-to-br from-gold via-gold to-amber-600 text-primary-foreground pl-3 pr-5 py-3 rounded-full shadow-2xl ring-2 ring-gold/50 hover:scale-105 transition-transform">
            <span className="size-9 rounded-full bg-background/20 flex items-center justify-center font-bold text-sm">
              <Sparkles className="size-4" />
            </span>
            <span className="flex flex-col text-left leading-tight">
              <span className="text-[10px] uppercase tracking-[0.25em] opacity-80">N-EYES</span>
              <span className="text-xs font-bold">AI</span>
            </span>
          </span>
        </button>
      )}

      {/* Panel */}
      {open && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-6 sm:right-6 sm:w-[400px] sm:h-[600px] z-[70] flex flex-col bg-background border border-gold/30 sm:rounded-2xl shadow-2xl ring-1 ring-gold/20 overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-border bg-card/60">
            <div className="flex items-center gap-2">
              <div className="size-8 rounded-full ring-1 ring-gold/50 flex items-center justify-center text-[10px] font-bold text-gold">IM</div>
              <div className="leading-tight">
                <div className="text-[10px] uppercase tracking-[0.3em] text-emerald">N-EYES</div>
                <div className="text-xs font-bold">AI</div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Link to="/ai" onClick={() => setOpen(false)} className="size-8 flex items-center justify-center text-muted-foreground hover:text-gold" title="Full page">
                <Maximize2 className="size-4" />
              </Link>
              <button onClick={() => setOpen(false)} className="size-8 flex items-center justify-center text-muted-foreground hover:text-gold" aria-label="Close">
                <X className="size-4" />
              </button>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            {messages.length === 0 && (
              <div className="text-center pt-6">
                <span className="font-arabic text-3xl text-gold/40 block">بسم الله</span>
                <p className="mt-3 text-xs text-muted-foreground px-4">
                  کوئی بھی سوال پوچھیں — قرآن، فقہِ جعفریہ، احادیثِ اہلِ بیتؑ، یا تاریخ۔
                </p>
              </div>
            )}
            {messages.map((m) => {
              const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
              return (
                <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}>
                  {m.role === "user" ? (
                    <div className="max-w-[85%] bg-emerald text-primary-foreground px-3 py-2 rounded-2xl rounded-br-sm text-sm whitespace-pre-wrap">
                      {text}
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <div className="size-7 rounded-full ring-1 ring-gold/50 flex items-center justify-center text-[9px] font-bold text-gold shrink-0">IM</div>
                      <div className="flex-1 prose prose-invert prose-sm max-w-none prose-p:my-1.5 prose-a:text-gold prose-strong:text-gold text-sm">
                        <ReactMarkdown>{text || "…"}</ReactMarkdown>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            {status === "submitted" && (
              <div className="flex gap-2 items-center">
                <div className="size-7 rounded-full ring-1 ring-gold/50 flex items-center justify-center text-[9px] font-bold text-gold">IM</div>
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse" />
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse [animation-delay:.2s]" />
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse [animation-delay:.4s]" />
              </div>
            )}

            {aiError && (
              <AiCreditsNotice kind={aiError.kind} message={aiError.message} compact onRetry={retryLast} onDismiss={() => setAiError(null)} />
            )}
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); submit(); }}
            className="border-t border-border p-2 bg-card/40"
          >
            <div className="flex items-end gap-2 border border-border focus-within:border-gold/60 bg-background p-1.5 rounded-lg">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }}
                rows={1}
                placeholder="یہاں سوال لکھیں…"
                className="flex-1 bg-transparent resize-none px-2 py-1.5 text-sm focus:outline-none max-h-32"
              />
              {busy ? (
                <button type="button" onClick={() => stop()} className="size-9 bg-destructive text-destructive-foreground flex items-center justify-center rounded">
                  <Square className="size-4" />
                </button>
              ) : (
                <button type="submit" disabled={!input.trim()} className="size-9 bg-gold text-primary-foreground flex items-center justify-center disabled:opacity-40 rounded">
                  <Send className="size-4" />
                </button>
              )}
            </div>
          </form>
        </div>
      )}
    </>
  );
}