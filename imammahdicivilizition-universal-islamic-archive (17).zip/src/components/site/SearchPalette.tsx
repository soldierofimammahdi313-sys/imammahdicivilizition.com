import { useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { SITE_GROUPS, SITE_INDEX } from "@/lib/site-index";
import { LOCAL_DOCS } from "@/lib/search-sources";
import { TYPE_LABELS, rank } from "@/lib/search-engine";

/**
 * Global search / command palette. Opens with ⌘K, Ctrl+K or "/".
 */
export function SearchPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const go = useCallback(
    (to: string) => {
      onOpenChange(false);
      navigate({ to });
    },
    [navigate, onOpenChange],
  );

  const deep = useMemo(
    () =>
      q.trim().length > 1
        ? rank(
            LOCAL_DOCS.filter((d) => d.type !== "page"),
            q,
            6,
          )
        : [],
    [q],
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="overflow-hidden p-0 sm:max-w-2xl border-gold/25 bg-background/95 backdrop-blur-xl shadow-luxe">
        <DialogTitle className="sr-only">Search the civilization</DialogTitle>
        <Command
          loop
          className="bg-transparent [&_[cmdk-group-heading]]:px-3 [&_[cmdk-group-heading]]:py-2 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-bold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-[0.28em] [&_[cmdk-group-heading]]:text-gold"
        >
          <CommandInput
            value={q}
            onValueChange={setQ}
            placeholder="Search Quran, Hadith, articles, books, tools…"
          />
          <CommandList className="max-h-[60dvh]">
            <CommandEmpty className="py-10 text-center text-sm text-muted-foreground">
              Nothing found. Try “tafsir”, “qibla” or “zakat”.
            </CommandEmpty>
            {q.trim().length > 1 && (
              <CommandGroup heading="Advanced">
                <CommandItem
                  value={`search everything ${q}`}
                  onSelect={() => {
                    onOpenChange(false);
                    navigate({ to: "/search", search: { q, type: "all", sort: "relevance" } });
                  }}
                  className="cursor-pointer gap-3 rounded-md data-[selected=true]:bg-emerald-soft"
                >
                  <span className="flex-1 text-sm font-medium">
                    Search everything for “{q}”
                  </span>
                  <span className="font-mono-display text-[10px] text-gold">Enter</span>
                </CommandItem>
              </CommandGroup>
            )}
            {deep.length > 0 && (
              <CommandGroup heading="Content">
                {deep.map((d) => (
                  <CommandItem
                    key={d.id}
                    value={`${d.id} ${d.title} ${d.subtitle ?? ""} ${d.body ?? ""}`}
                    onSelect={() => {
                      onOpenChange(false);
                      if (d.href) window.open(d.href, "_blank", "noopener,noreferrer");
                      else navigate({ to: d.to ?? "/" });
                    }}
                    className="cursor-pointer gap-3 rounded-md data-[selected=true]:bg-emerald-soft"
                  >
                    <span className="flex-1 truncate text-sm">
                      {d.body ? d.body.slice(0, 70) : d.title}
                    </span>
                    <span className="font-mono-display text-[10px] text-muted-foreground/70">
                      {TYPE_LABELS[d.type]}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {SITE_GROUPS.map((group) => (
              <CommandGroup key={group} heading={group}>
                {SITE_INDEX.filter((e) => e.group === group).map((e) => (
                  <CommandItem
                    key={e.to}
                    value={`${e.label} ${e.arabic ?? ""} ${e.keywords} ${e.to}`}
                    onSelect={() => go(e.to)}
                    className="group cursor-pointer gap-3 rounded-md data-[selected=true]:bg-emerald-soft data-[selected=true]:text-foreground"
                  >
                    <span className="flex-1 text-sm font-medium">{e.label}</span>
                    {e.arabic && (
                      <span className="font-arabic text-base text-gold/70">{e.arabic}</span>
                    )}
                    <span className="font-mono-display text-[10px] text-muted-foreground/60">
                      {e.to}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
}

/** Hook that wires the global keyboard shortcut and returns palette state. */
export function useSearchPalette() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        !!target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "/" && !typing) {
        e.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return { open, setOpen };
}
