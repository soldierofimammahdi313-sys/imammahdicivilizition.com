import { getCoordsSilently } from "@/lib/geo";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useHydrated } from "@tanstack/react-router";
import { getDailyHadiths } from "@/lib/daily-hadiths.functions";
import { NARRATIONS } from "./LiveTicker";
import { NARRATIONS_UR } from "@/lib/ticker-urdu";
import { useI18n } from "@/lib/i18n";
import { getIslamicEvent } from "@/lib/islamic-events";

const HIJRI_AR = [
  "محرم","صفر","ربیع الأول","ربیع الثانی","جمادی الأولی","جمادی الثانیة",
  "رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة",
];

const DISPLAY_TIME_ZONE = "Asia/Karachi";
const HIJRI_DATE_OFFSET_DAYS = 0;

function referenceDay(date: Date, addDays = 0) {
  const p = new Intl.DateTimeFormat("en-CA", {
    timeZone: DISPLAY_TIME_ZONE,
    year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date);
  const get = (t: string) => Number(p.find((x) => x.type === t)?.value);
  return new Date(Date.UTC(get("year"), get("month") - 1, get("day") + addDays, 12));
}

function getHijri(date: Date) {
  try {
    const parts = new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", {
      timeZone: "UTC", day: "numeric", month: "numeric", year: "numeric",
    }).formatToParts(referenceDay(date, HIJRI_DATE_OFFSET_DAYS));
    const n = (t: string) => Number(parts.find((p) => p.type === t)?.value);
    return { d: n("day"), m: n("month"), y: n("year") };
  } catch {
    return { d: 1, m: 1, y: 1446 };
  }
}

const PRAYERS = [
  { key: "Fajr", label: "فجر", ur: "فجر" },
  { key: "Sunrise", label: "طلوع", ur: "طلوعِ آفتاب" },
  { key: "Dhuhr", label: "ظهر", ur: "ظہر" },
  { key: "Asr", label: "عصر", ur: "عصر" },
  { key: "Maghrib", label: "مغرب", ur: "مغرب" },
  { key: "Isha", label: "عشاء", ur: "عشاء" },
];

const HIJRI_UR = [
  "محرم","صفر","ربیع الاول","ربیع الثانی","جمادی الاول","جمادی الثانی",
  "رجب","شعبان","رمضان","شوال","ذی القعدہ","ذی الحجہ",
];

/**
 * One compact bar that merges the date/prayer strip and the hadith ticker.
 * Scrolling runs on a CSS transform animation (compositor-only) instead of a
 * per-frame JS loop, and pauses on hover/focus and for reduced-motion users.
 */
export function UnifiedTicker() {
  const hydrated = useHydrated();
  const { lang } = useI18n();
  const isUrdu = lang === "ur";
  const [today, setToday] = useState<string | null>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setToday(new Date().toISOString().slice(0, 10));
  }, []);

  const { data: hadiths } = useQuery({
    queryKey: ["daily-hadiths", today ?? "pending"],
    enabled: today !== null,
    queryFn: () => getDailyHadiths(),
    staleTime: 1000 * 60 * 60 * 12,
    gcTime: 1000 * 60 * 60 * 24,
    refetchOnWindowFocus: false,
    retry: 1,
  });

  const { data: timings } = useQuery({
    queryKey: ["ticker-prayer-times"],
    enabled: hydrated,
    queryFn: async () => {
      const coords = await getCoordsSilently();
      const r = await fetch(
        `https://api.aladhan.com/v1/timings?latitude=${coords.lat}&longitude=${coords.lng}&method=2`,
      );
      const j = await r.json();
      return j.data.timings as Record<string, string>;
    },
    staleTime: 1000 * 60 * 60 * 6,
    refetchOnWindowFocus: false,
  });

  const dateLabel = useMemo(() => {
    if (!hydrated) return "";
    const now = new Date();
    const h = getHijri(now);
    const months = isUrdu ? HIJRI_UR : HIJRI_AR;
    return `${h.d} ${months[h.m - 1]} ${h.y} ${isUrdu ? "ھ" : "هـ"}`;
  }, [hydrated, isUrdu]);

  const gregLabel = useMemo(() => {
    if (!hydrated) return "";
    return referenceDay(new Date()).toLocaleDateString("en-GB", {
      timeZone: "UTC", day: "2-digit", month: "short", year: "numeric",
    });
  }, [hydrated]);

  const occasion = useMemo(() => {
    if (!hydrated) return null;
    const h = getHijri(new Date());
    return getIslamicEvent(h.d, h.m);
  }, [hydrated]);

  const narrations = useMemo(
    () => (isUrdu ? NARRATIONS_UR : hadiths?.items?.length ? hadiths.items : NARRATIONS),
    [hadiths, isUrdu],
  );

  const row = useMemo(
    () => (
      <div className="flex items-center">
        {hydrated && (
          <span className="inline-flex items-center gap-2 px-5 whitespace-nowrap text-[11px]">
            <span className="text-emerald text-[10px] font-bold uppercase tracking-[0.25em]">☾ تاریخ</span>
            <span className="text-foreground/90">{dateLabel}</span>
            <span className="text-muted-foreground">· {gregLabel}</span>
            <span className="text-gold/40">•</span>
          </span>
        )}
        {occasion && (
          <span dir={isUrdu ? "rtl" : "ltr"} className="inline-flex items-center gap-2 px-5 whitespace-nowrap text-[11px]">
            <span className="text-gold text-[10px] font-bold uppercase tracking-[0.25em]">
              {isUrdu ? "★ آج کی مناسبت" : "★ Today"}
            </span>
            <span className="text-foreground font-semibold">{isUrdu ? occasion.ur : occasion.en}</span>
            <span className="text-gold/40">•</span>
          </span>
        )}

        {timings &&
          PRAYERS.filter((p) => timings[p.key]).map((p) => (
            <span key={p.key} className="inline-flex items-center gap-2 px-4 whitespace-nowrap text-[11px]">
              <span className="text-emerald text-[10px] font-bold uppercase tracking-[0.25em]">{isUrdu ? p.ur : p.label}</span>
              <span className="text-foreground/90">{timings[p.key]}</span>
              <span className="text-gold/40">•</span>
            </span>
          ))}
        {narrations.map((it, i) => (
          <span
            key={i}
            dir={isUrdu ? "rtl" : "ltr"}
            className="inline-flex items-center gap-3 px-6 whitespace-nowrap text-[13px]"
          >
            <span className="text-gold text-[10px] uppercase tracking-[0.3em]">✦</span>
            <span className="text-foreground/90">{it.text}</span>
            <span className="text-muted-foreground italic">— {it.by}</span>
            <span className="text-[10px] uppercase tracking-widest text-gold/70">[{it.source}]</span>
            <span className="text-gold/40">•</span>
          </span>
        ))}
      </div>
    ),
    [hydrated, dateLabel, gregLabel, timings, narrations, isUrdu, occasion],
  );

  // Duration scales with content width so the speed stays constant.
  // Measured once per content build — deferred to idle so the animation
  // never restarts mid-scroll (which caused the visible "jump").
  const [duration, setDuration] = useState(240);
  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    const measure = () => {
      const half = el.scrollWidth / 2;
      if (half > 0) setDuration((d) => {
        const next = Math.max(60, half / 55);
        return Math.abs(next - d) > 20 ? next : d;
      });
    };
    const w = window as unknown as {
      requestIdleCallback?: (cb: () => void) => number;
      cancelIdleCallback?: (id: number) => void;
    };
    if (w.requestIdleCallback) {
      const id = w.requestIdleCallback(measure);
      return () => w.cancelIdleCallback?.(id);
    }
    const id = window.setTimeout(measure, 300);
    return () => window.clearTimeout(id);
  }, [row]);

  return (
    <div dir="ltr" translate="no" className="notranslate fixed top-20 left-0 right-0 z-40 border-b border-gold/20 bg-background/90 backdrop-blur-md overflow-hidden">
      <div className="relative flex items-center h-9">
        <div className="shrink-0 z-10 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] px-3 sm:px-4 py-1.5 mr-2">
          ● Live
        </div>
        <div className="ticker-viewport">
          <div
            ref={trackRef}
            className={`ticker-track${isUrdu ? " ticker-track--reverse" : ""}`}
            style={{ ["--ticker-duration" as string]: `${duration}s` }}
          >
            {row}
            <div aria-hidden="true" className="flex items-center">{row}</div>
          </div>
        </div>
      </div>
    </div>
  );
}