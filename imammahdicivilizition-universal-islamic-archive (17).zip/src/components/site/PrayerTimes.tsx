import { getCoordsSilently } from "@/lib/geo";
import { useEffect, useMemo, useState } from "react";
import { MapPin, Loader2, Compass } from "lucide-react";

type Timings = Record<string, string> & {
  Fajr: string; Sunrise: string; Dhuhr: string; Asr: string; Maghrib: string; Isha: string;
};

const ORDER: (keyof Timings)[] = ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];
const ARABIC: Record<string, string> = {
  Fajr: "الفجر", Sunrise: "الشروق", Dhuhr: "الظهر", Asr: "العصر", Maghrib: "المغرب", Isha: "العشاء",
};

function toDateToday(hhmm: string) {
  const [h, m] = hhmm.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
}
function fmtCountdown(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

export function PrayerTimes() {
  const [timings, setTimings] = useState<Timings | null>(null);
  const [city, setCity] = useState<string>("");
  const [status, setStatus] = useState<"idle" | "loading" | "error">("loading");
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const load = async (lat: number, lon: number, label?: string) => {
      try {
        const today = new Date();
        const date = `${String(today.getDate()).padStart(2, "0")}-${String(today.getMonth() + 1).padStart(2, "0")}-${today.getFullYear()}`;
        // method=0 → Shia Ithna-Ashari, Leva Institute, Qum
        const r = await fetch(`https://api.aladhan.com/v1/timings/${date}?latitude=${lat}&longitude=${lon}&method=0&school=0`);
        const d = await r.json();
        if (d?.data?.timings) {
          setTimings(d.data.timings);
          setCity(label || `${d.data.meta?.timezone ?? "Local"}`);
          setStatus("idle");
        } else setStatus("error");
      } catch { setStatus("error"); }
    };

    // Never prompts on load: uses the device position only when the visitor
    // already granted permission, otherwise falls back to Tehran.
    const fallback = { lat: 35.6892, lng: 51.389 };
    void getCoordsSilently(fallback).then((c) => {
      const isFallback = c.lat === fallback.lat && c.lng === fallback.lng;
      load(c.lat, c.lng, isFallback ? "Tehran (default)" : "");
    });
  }, []);

  const next = useMemo(() => {
    if (!timings) return null;
    for (const k of ORDER) {
      const t = toDateToday(String(timings[k]).slice(0, 5));
      if (t.getTime() > now.getTime()) return { key: k, at: t };
    }
    const first = toDateToday(String(timings.Fajr).slice(0, 5));
    first.setDate(first.getDate() + 1);
    return { key: "Fajr" as const, at: first };
  }, [timings, now]);

  return (
    <section className="py-16 px-6">
      <div className="max-w-6xl mx-auto border border-gold/30 bg-gradient-to-br from-emerald-soft/40 via-card/40 to-gold-soft/30 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 size-64 bg-gold/10 blur-[100px] rounded-full pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 size-64 bg-emerald/15 blur-[100px] rounded-full pointer-events-none" />

        <div className="relative p-6 md:p-10">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Awqāt al-Ṣalāh</span>
              <h2 className="mt-1 font-display italic text-2xl md:text-3xl">Prayer Times · <span className="text-gold">Ja'fari</span></h2>
              <div className="mt-1 text-[11px] text-muted-foreground flex items-center gap-1.5">
                <MapPin className="size-3" /> {city || "Detecting location…"}
              </div>
            </div>

            {next && timings ? (
              <div className="text-right">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Next · {next.key}</div>
                <div className="font-mono-display text-3xl md:text-4xl text-gold tabular-nums drop-shadow-[0_0_20px_hsl(var(--gold)/0.4)]">
                  {fmtCountdown(next.at.getTime() - now.getTime())}
                </div>
                <div className="text-[11px] text-muted-foreground">at {String(timings[next.key]).slice(0, 5)}</div>
              </div>
            ) : status === "loading" ? (
              <Loader2 className="size-6 animate-spin text-gold" />
            ) : null}
          </div>

          {timings && (
            <div className="grid grid-cols-3 md:grid-cols-6 gap-px bg-border ring-1 ring-border">
              {ORDER.map((k) => {
                const isNext = next?.key === k;
                return (
                  <div key={k} className={`p-4 flex flex-col items-center text-center transition-colors ${isNext ? "bg-gold text-primary-foreground" : "bg-background/70 hover:bg-emerald-soft"}`}>
                    <span className={`font-arabic text-lg ${isNext ? "" : "text-gold/70"}`}>{ARABIC[k]}</span>
                    <span className="text-[10px] uppercase tracking-widest mt-1 opacity-80">{k}</span>
                    <span className="font-mono-display text-base mt-1 tabular-nums">{String(timings[k]).slice(0, 5)}</span>
                  </div>
                );
              })}
            </div>
          )}

          {status === "error" && (
            <p className="text-sm text-muted-foreground">Unable to fetch prayer times. Please try again later.</p>
          )}

          <div className="mt-4 flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
            <span>Method 0 · Leva Institute, Qum (Shīʿa Ithnāʿasharī)</span>
            <a href="/qibla" className="flex items-center gap-1 hover:text-gold"><Compass className="size-3" /> Qibla</a>
          </div>
        </div>
      </div>
    </section>
  );
}
