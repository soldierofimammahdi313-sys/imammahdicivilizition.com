import { useState, useRef, useEffect } from "react";
import { LANGUAGES, useI18n } from "@/lib/i18n";

export function LanguageSwitcher({ className = "" }: { className?: string }) {
  const { lang, setLang, t } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const current = LANGUAGES.find(l => l.code === lang)!;
  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        onClick={() => setOpen(o => !o)}
        title={t("lang.choose")}
        className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold transition-colors px-2.5 py-1.5 border border-border hover:border-gold/50 min-w-[6.5rem] justify-between"
      >
        <span className="flex items-center gap-2">
          <span className="text-base leading-none">{current.flag}</span>
          <span className="font-bold truncate max-w-[6rem]">{current.label}</span>
        </span>
        <svg width="10" height="10" viewBox="0 0 10 10" className="opacity-60 flex-shrink-0"><path d="M2 3.5l3 3 3-3" stroke="currentColor" fill="none" strokeWidth="1.5" /></svg>
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-56 bg-card border border-border ring-1 ring-gold/20 shadow-2xl z-[60]">
          <div className="px-3 py-2 text-[10px] uppercase tracking-[0.3em] text-gold border-b border-border">{t("lang.choose")}</div>
          <ul className="py-1 max-h-80 overflow-auto">
            {LANGUAGES.map(l => (
              <li key={l.code}>
                <button
                  onClick={() => { setLang(l.code); setOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2 hover:bg-emerald-soft transition-colors ${l.code === lang ? "text-gold" : "text-foreground"}`}
                >
                  <span className="text-lg">{l.flag}</span>
                  <span className="flex-1 text-left">
                    <span className="block text-sm font-medium">{l.label}</span>
                    <span className="block text-[10px] text-muted-foreground">{l.native}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}