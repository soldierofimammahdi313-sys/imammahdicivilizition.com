import { lazy, Suspense, useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowDown, Orbit, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MODULE_STATS } from "@/lib/modules";

const ObservatoryScene = lazy(() => import("@/components/site/ObservatoryScene"));

const TELEMETRY = [
  { label: "QURAN INDEX", value: "6,236 AYAT" },
  { label: "SYSTEMS ONLINE", value: `${MODULE_STATS.live} / ${MODULE_STATS.total}` },
  { label: "KNOWLEDGE NODES", value: "11 CLUSTERS" },
  { label: "LANGUAGE MATRIX", value: "07 ACTIVE" },
];

export function ObservatoryHero() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  return (
    <section className="observatory-hero relative isolate flex min-h-[760px] h-[min(900px,calc(100svh-12px))] items-center justify-center overflow-hidden px-5 pb-16 pt-24 sm:px-8">
      <div aria-hidden className="observatory-velvet absolute inset-0" />
      <div aria-hidden className="observatory-girih-fallback absolute inset-0 opacity-35" />
      <div className="absolute inset-0 z-[1] pointer-events-none opacity-45 sm:opacity-100" aria-hidden>
        {mounted && (
          <Suspense fallback={null}>
            <ObservatoryScene />
          </Suspense>
        )}
      </div>
      <div aria-hidden className="observatory-vignette absolute inset-0 z-[2] opacity-70" />

      <div className="absolute inset-x-4 top-32 z-10 hidden items-start justify-between lg:flex">
        <div className="space-y-3 border-l border-emerald/30 pl-4 font-mono-display text-[9px] text-muted-foreground">
          {TELEMETRY.slice(0, 2).map((item) => (
            <p key={item.label}><span className="text-emerald">{item.label}</span><br />{item.value}</p>
          ))}
        </div>
        <div className="space-y-3 border-r border-gold/30 pr-4 text-right font-mono-display text-[9px] text-muted-foreground">
          {TELEMETRY.slice(2).map((item) => (
            <p key={item.label}><span className="text-gold">{item.label}</span><br />{item.value}</p>
          ))}
        </div>
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-5xl flex-col items-center gap-8 text-center">
        <div className="flex items-center gap-2 font-mono-display text-[9px] uppercase tracking-[0.28em] text-emerald">
          <Radio className="size-3 animate-pulse" /> Civilization signal active
        </div>

        <div className="pointer-events-none">
          <p lang="ar" dir="rtl" className="crystal-inscription font-arabic text-center text-4xl leading-[1.6] sm:text-6xl md:text-7xl">
            يا صاحب الزمان
          </p>
          <p className="mt-3 font-mono-display text-[9px] uppercase tracking-[0.34em] text-muted-foreground">
            The luminous heart of a digital civilization
          </p>
        </div>

        <div>
          <p className="mb-3 flex items-center justify-center gap-2 font-mono-display text-[9px] uppercase tracking-[0.32em] text-gold">
            <Orbit className="size-3" /> Imam Mahdi Civilization
          </p>
          <h1 className="font-display text-3xl leading-tight text-balance sm:text-5xl md:text-6xl">
            A Living Observatory of <em className="not-italic text-gold">Islamic Knowledge</em>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Quran, Hadith, research, learning and intelligent tools—connected as one global knowledge system.
          </p>
          <div className="mt-7 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:flex-wrap sm:items-center">
            <Button asChild size="lg" className="h-12 rounded-none px-7 text-[10px] font-bold uppercase tracking-[0.22em]">
              <Link to="/join">Enlist Now</Link>
            </Button>
            <Button asChild size="lg" variant="secondary" className="h-12 rounded-none px-7 text-[10px] font-bold uppercase tracking-[0.22em]">
              <Link to="/academy-ai">Mahdi AI Academy</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="h-12 rounded-none border-border bg-background/35 px-7 text-[10px] font-bold uppercase tracking-[0.22em] backdrop-blur-md">
              <Link to="/realms">Explore the Eight Realms</Link>
            </Button>
            <Button asChild variant="ghost" size="lg" className="h-12 rounded-none px-7 text-[10px] font-bold uppercase tracking-[0.22em]">
              <a href="#command-center">{`Explore ${MODULE_STATS.total} Modules`}</a>
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-3 left-1/2 z-10 -translate-x-1/2 text-muted-foreground" aria-hidden>
        <ArrowDown className="size-4 animate-bounce" />
      </div>
    </section>
  );
}