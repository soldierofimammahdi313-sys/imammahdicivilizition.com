import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type Note = { id: string; title: string; body: string; at: string; postId?: string };
const SEEN_KEY = "mahdi.notifications.seenAt";

/**
 * Notification centre built entirely from real member activity:
 * replies + likes on the member's discussions, and their team application status.
 */
export function NotificationBell({ user }: { user: User | null }) {
  const [open, setOpen] = useState(false);
  const [seenAt, setSeenAt] = useState<string>("1970-01-01T00:00:00.000Z");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const v = window.localStorage.getItem(SEEN_KEY);
      if (v) setSeenAt(v);
    } catch {
      /* storage unavailable */
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    function onDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const query = useQuery({
    queryKey: ["notifications", user?.id],
    enabled: Boolean(user),
    refetchInterval: 120_000,
    queryFn: async (): Promise<Note[]> => {
      const uid = user!.id;
      const { data: myPosts } = await supabase.from("community_posts").select("id,title").eq("author_id", uid);
      const postIds = (myPosts ?? []).map((p) => p.id);
      const titleOf = (id: string) => (myPosts ?? []).find((p) => p.id === id)?.title ?? "your discussion";

      const notes: Note[] = [];

      if (postIds.length > 0) {
        const [{ data: replies }, { data: likes }] = await Promise.all([
          supabase
            .from("community_comments")
            .select("id,post_id,author_name,created_at,author_id")
            .in("post_id", postIds)
            .order("created_at", { ascending: false })
            .limit(15),
          supabase
            .from("community_likes")
            .select("id,post_id,created_at,user_id")
            .in("post_id", postIds)
            .order("created_at", { ascending: false })
            .limit(15),
        ]);
        for (const r of replies ?? []) {
          if (r.author_id === uid) continue;
          notes.push({
            id: `c-${r.id}`,
            title: "New reply",
            body: `${r.author_name ?? "A member"} replied to “${titleOf(r.post_id)}”`,
            at: r.created_at,
            postId: r.post_id,
          });
        }
        for (const l of likes ?? []) {
          if (l.user_id === uid) continue;
          notes.push({
            id: `l-${l.id}`,
            title: "New like",
            body: `Someone appreciated “${titleOf(l.post_id)}”`,
            at: l.created_at,
            postId: l.post_id,
          });
        }
      }

      const { data: apps } = await supabase
        .from("team_applications")
        .select("id,status,created_at,role")
        .eq("user_id", uid)
        .order("created_at", { ascending: false })
        .limit(5);
      for (const a of apps ?? []) {
        notes.push({
          id: `a-${a.id}`,
          title: "Application update",
          body: `Your ${a.role} application is ${a.status}.`,
          at: a.created_at,
        });
      }

      return notes.sort((x, y) => (x.at < y.at ? 1 : -1)).slice(0, 20);
    },
  });

  const notes = useMemo(() => query.data ?? [], [query.data]);
  const unread = notes.filter((n) => n.at > seenAt).length;

  function openPanel() {
    setOpen((v) => {
      const next = !v;
      if (next) {
        const now = new Date().toISOString();
        setSeenAt(now);
        try {
          window.localStorage.setItem(SEEN_KEY, now);
        } catch {
          /* storage unavailable */
        }
      }
      return next;
    });
  }

  if (!user) return null;

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={openPanel}
        aria-label={unread > 0 ? `Notifications, ${unread} new` : "Notifications"}
        aria-expanded={open}
        className="relative grid place-items-center size-9 rounded-md border border-border text-muted-foreground transition-colors hover:border-gold/60 hover:text-gold"
      >
        <Bell className="size-4" aria-hidden />
        {unread > 0 && (
          <span className="absolute -top-1 -end-1 min-w-4 h-4 px-1 rounded-full bg-gold text-primary-foreground text-[9px] font-bold grid place-items-center">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute end-0 mt-2 w-80 max-h-96 overflow-y-auto border border-border bg-popover shadow-luxe z-50">
          <p className="px-4 py-3 border-b border-border text-[10px] uppercase tracking-[0.3em] text-gold">Notifications</p>
          {query.isLoading && <p className="p-4 text-xs text-muted-foreground">Loading…</p>}
          {!query.isLoading && notes.length === 0 && (
            <p className="p-4 text-xs text-muted-foreground">
              No activity yet. Start a discussion and replies will appear here.
            </p>
          )}
          <ul className="divide-y divide-border">
            {notes.map((n) => {
              const inner = (
                <>
                  <p className="text-[10px] uppercase tracking-[0.22em] text-gold">{n.title}</p>
                  <p className="mt-1 text-xs text-foreground line-clamp-2">{n.body}</p>
                  <p className="mt-1 text-[10px] text-muted-foreground">{new Date(n.at).toLocaleString()}</p>
                </>
              );
              const cls = "block px-4 py-3 hover:bg-gold-soft/20 transition-colors";
              return (
                <li key={n.id}>
                  {n.postId ? (
                    <Link to="/discussions/$id" params={{ id: n.postId }} onClick={() => setOpen(false)} className={cls}>
                      {inner}
                    </Link>
                  ) : (
                    <Link to="/dashboard" onClick={() => setOpen(false)} className={cls}>
                      {inner}
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}