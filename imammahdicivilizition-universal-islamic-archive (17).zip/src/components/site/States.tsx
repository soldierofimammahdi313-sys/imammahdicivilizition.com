import type { ReactNode } from "react";

/** Shimmering placeholder block used by every skeleton below. */
export function Shimmer({ className = "" }: { className?: string }) {
  return <div aria-hidden className={`animate-pulse rounded-sm bg-muted/60 ${className}`} />;
}

/** Skeleton card matching the platform's content-card proportions. */
export function CardSkeleton() {
  return (
    <div className="border border-border bg-card/30 p-6">
      <Shimmer className="h-3 w-24" />
      <Shimmer className="mt-4 h-5 w-3/4" />
      <Shimmer className="mt-2 h-5 w-1/2" />
      <Shimmer className="mt-5 h-3 w-full" />
      <Shimmer className="mt-2 h-3 w-5/6" />
    </div>
  );
}

export function CardGridSkeleton({ count = 3, className = "" }: { count?: number; className?: string }) {
  return (
    <div role="status" aria-live="polite" aria-busy="true" className={`grid gap-6 md:grid-cols-2 lg:grid-cols-3 ${className}`}>
      <span className="sr-only">Loading content…</span>
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}

export function ListSkeleton({ rows = 4 }: { rows?: number }) {
  return (
    <div role="status" aria-live="polite" aria-busy="true" className="divide-y divide-border ring-1 ring-border">
      <span className="sr-only">Loading…</span>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="p-5">
          <Shimmer className="h-4 w-2/3" />
          <Shimmer className="mt-3 h-3 w-1/3" />
        </div>
      ))}
    </div>
  );
}

export function InlineEmpty({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="border border-dashed border-border bg-card/20 p-10 text-center">
      <p className="font-display italic text-xl text-foreground">{title}</p>
      {hint && <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">{hint}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function InlineError({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="border border-destructive/40 bg-destructive/5 p-6 text-center">
      <p className="text-sm text-foreground">{message ?? "We couldn't load this section right now."}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 px-5 py-2 border border-border text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-gold hover:border-gold/60 transition-colors"
        >
          Try again
        </button>
      )}
    </div>
  );
}