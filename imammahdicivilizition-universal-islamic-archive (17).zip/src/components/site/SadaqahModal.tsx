import { useEffect, useState, useCallback } from "react";
import binanceQrAsset from "@/assets/binance-pay-qr.jpg.asset.json";

const BINANCE_PAY_URL = "https://pay.binance.com";

const ACCOUNT = {
  nickname: "imammahdicivilizition",
  uid: "1274561942",
  email: "s.ahmad.raza.shamsi.official@gmail.com",
};

export function SadaqahModal({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onOpenChange]);

  const copy = useCallback(async (value: string, key: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 1800);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = value;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(key);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 1800);
    }
  }, []);

  const downloadQr = useCallback(async () => {
    try {
      const res = await fetch(binanceQrAsset.url);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "binance-pay-qr.jpg";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      window.open(binanceQrAsset.url, "_blank", "noopener,noreferrer");
    }
  }, []);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Support Our Work — Sadaqah Jariyah"
      className="fixed inset-0 z-[120] flex items-center justify-center p-4"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={() => onOpenChange(false)}
        aria-hidden
      />

      {/* Card */}
      <div className="relative w-full max-w-md max-h-[92dvh] overflow-y-auto rounded-2xl border border-[#F0B90B]/30 bg-[#1E2329] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)]">
        {/* Header band */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <span className="grid place-items-center size-9 rounded-lg bg-[#F0B90B] text-[#1E2329] font-bold">
              ☪
            </span>
            <div>
              <h2 className="text-base font-bold tracking-wide text-[#F0B90B]">
                Support Our Work
              </h2>
              <p className="text-[11px] uppercase tracking-[0.18em] text-white/50">
                Sadaqah Jariyah
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            aria-label="Close"
            className="grid place-items-center size-9 rounded-lg border border-white/10 text-white/70 hover:text-white hover:border-[#F0B90B]/50 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-6">
          {/* Message */}
          <div className="rounded-xl bg-white/[0.03] border border-white/5 p-4 mb-5">
            <p className="font-arabic text-right text-lg text-[#F0B90B]/90 leading-relaxed mb-2" dir="rtl">
              صَدَقَةٌ جَارِيَةٌ — جو کوئی علم پھیلائے گا، اس کے لیے ثواب جاری رہے گا۔
            </p>
            <p className="text-sm text-white/70 leading-relaxed">
              Your contribution is <span className="text-[#F0B90B] font-semibold">Sadaqah Jariyah</span> — a
              continuous charity. It directly funds the Quran, Hadith, articles, AI assistant, and free
              educational content that reaches seekers worldwide through this platform.
            </p>
          </div>

          {/* QR code */}
          <div className="flex flex-col items-center">
            <div className="rounded-2xl bg-white p-3 shadow-lg ring-1 ring-[#F0B90B]/30">
              <img
                src={binanceQrAsset.url}
                alt="Binance Pay QR code for imammahdicivilizition"
                width={220}
                height={220}
                loading="lazy"
                decoding="async"
                className="size-[220px] object-contain"
              />
            </div>
            <button
              type="button"
              onClick={downloadQr}
              className="mt-3 inline-flex items-center gap-2 rounded-lg border border-white/15 px-4 py-2 text-xs font-medium text-white/80 hover:text-white hover:border-[#F0B90B]/50 transition-colors"
            >
              ⬇ Download QR Code
            </button>
          </div>

          {/* Account details */}
          <div className="mt-6 space-y-2.5">
            <DetailRow
              label="Account Nickname"
              value={ACCOUNT.nickname}
              onCopy={() => copy(ACCOUNT.nickname, "nick")}
              copied={copied === "nick"}
            />
            <DetailRow
              label="Binance UID"
              value={ACCOUNT.uid}
              mono
              onCopy={() => copy(ACCOUNT.uid, "uid")}
              copied={copied === "uid"}
            />
            <DetailRow
              label="Binance Email"
              value={ACCOUNT.email}
              mono
              onCopy={() => copy(ACCOUNT.email, "email")}
              copied={copied === "email"}
            />
          </div>

          {/* CTA */}
          <a
            href={BINANCE_PAY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[#F0B90B] px-5 py-3.5 font-bold text-[#1E2329] text-sm uppercase tracking-[0.12em] shadow-[0_10px_25px_-8px_rgba(240,185,11,0.5)] hover:brightness-110 active:scale-[0.99] transition-all"
          >
            Donate via Binance Pay
          </a>
          <p className="mt-3 text-center text-[11px] text-white/40">
            Open Binance Pay, scan the QR, or enter the UID above.
          </p>
        </div>
      </div>
    </div>
  );
}

function DetailRow({
  label,
  value,
  mono,
  onCopy,
  copied,
}: {
  label: string;
  value: string;
  mono?: boolean;
  onCopy: () => void;
  copied: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-white/8 bg-white/[0.02] px-3.5 py-2.5">
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-[0.16em] text-white/40">{label}</div>
        <div
          className={`truncate text-sm text-white/90 ${mono ? "font-mono-display" : ""}`}
          title={value}
        >
          {value}
        </div>
      </div>
      <button
        type="button"
        onClick={onCopy}
        className="shrink-0 rounded-md border border-[#F0B90B]/30 px-2.5 py-1.5 text-[11px] font-medium text-[#F0B90B] hover:bg-[#F0B90B]/10 transition-colors"
      >
        {copied ? "✓ Copied" : "Copy"}
      </button>
    </div>
  );
}

/** Convenience hook + trigger button for embedding anywhere (e.g. donate page). */
export function SadaqahTrigger({
  className,
  label = "Support Our Work",
}: {
  className?: string;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={
          className ??
          "inline-flex items-center gap-2 rounded-lg bg-[#F0B90B] px-5 py-3 font-bold text-[#1E2329] text-sm uppercase tracking-[0.12em] shadow-lg hover:brightness-110 transition-all"
        }
      >
        ☪ {label}
      </button>
      <SadaqahModal open={open} onOpenChange={setOpen} />
    </>
  );
}
