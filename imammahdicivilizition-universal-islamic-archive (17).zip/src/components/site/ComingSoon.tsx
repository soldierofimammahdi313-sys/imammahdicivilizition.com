import { Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";

export function ComingSoon({
  realm,
  arabic,
  title,
  description,
  number,
}: {
  realm: string;
  arabic: string;
  title: string;
  description: string;
  number: string;
}) {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <section className="pt-40 pb-32 px-6 max-w-5xl mx-auto relative">
        <div className="absolute top-32 left-1/2 -translate-x-1/2 size-[600px] bg-emerald/5 blur-[120px] rounded-full pointer-events-none" />
        <div className="relative text-center">
          <span className="font-mono-display text-[10px] text-emerald tracking-[0.4em]">{number} / REALM</span>
          <span className="font-arabic text-4xl text-gold/30 block mt-6">{arabic}</span>
          <h1 className="mt-3 font-display italic text-5xl md:text-7xl">{title}</h1>
          <p className="mt-3 text-[10px] uppercase tracking-[0.4em] text-gold">{realm}</p>
          <p className="mt-10 text-muted-foreground text-lg max-w-2xl mx-auto">{description}</p>

          <div className="mt-16 inline-flex items-center gap-3 border border-gold/30 px-8 py-4">
            <span className="size-2 bg-gold rounded-full animate-twinkle" />
            <span className="text-[10px] uppercase tracking-[0.4em] text-gold">Under Construction · Phase II</span>
          </div>

          <div className="mt-14 flex gap-3 justify-center flex-col sm:flex-row">
            <Link to="/join" className="px-10 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors">
              Help Build This Realm
            </Link>
            <Link to="/" className="px-10 py-4 border border-border font-bold uppercase text-xs tracking-[0.3em] hover:bg-emerald-soft transition-colors">
              ← Return Home
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}