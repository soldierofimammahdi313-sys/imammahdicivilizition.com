import { Youtube, Facebook } from "lucide-react";
import { SOCIAL_LINKS } from "@/lib/social-links";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  youtube: Youtube,
  facebook: Facebook,
};

export function SocialIcons({ className = "", iconClass = "size-4" }: { className?: string; iconClass?: string }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {SOCIAL_LINKS.map((s) => {
        const Icon = ICONS[s.icon];
        return (
          <a
            key={s.name}
            href={s.href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={s.name}
            className="text-muted-foreground hover:text-gold transition-colors"
          >
            <Icon className={iconClass} />
          </a>
        );
      })}
    </div>
  );
}
