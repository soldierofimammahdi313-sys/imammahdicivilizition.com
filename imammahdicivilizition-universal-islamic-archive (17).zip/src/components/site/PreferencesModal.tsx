/**
 * Language & Fiqh preferences.
 *
 * Shown automatically on a first visit (when either preference is missing) and
 * re-openable at any time from the header. Choices are written to localStorage
 * under `imc_language` and `imc_fiqh`; corrupted values are ignored rather than
 * allowed to break the page.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { LANGUAGES, useI18n, type Lang } from "@/lib/i18n";
import { FIQH_SCHOOLS, fiqhName, fiqhTagline, useFiqh, type FiqhId } from "@/lib/fiqh";

/** Custom event that any component can fire to open the dialog. */
export const OPEN_PREFERENCES_EVENT = "imc:open-preferences";

export function openPreferences() {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(OPEN_PREFERENCES_EVENT));
}

/** The three languages offered first; the rest stay one click away. */
const PRIMARY_LANGS: Lang[] = ["en", "ur", "ar"];

export function PreferencesModal() {
  const { lang, setLang, t, dir, ready: langReady, unset: langUnset } = useI18n();
  const { fiqh, setFiqh, ready: fiqhReady, unset: fiqhUnset } = useFiqh();

  const [open, setOpen] = useState(false);
  /** First visit asks for both; reopening is a plain settings dialog. */
  const [welcome, setWelcome] = useState(false);
  const [draftLang, setDraftLang] = useState<Lang>(lang);
  const [draftFiqh, setDraftFiqh] = useState<FiqhId>(fiqh);
  const [showAllLangs, setShowAllLangs] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  // First visit: open once both providers have read localStorage.
  useEffect(() => {
    if (!langReady || !fiqhReady) return;
    if (!langUnset && !fiqhUnset) return;
    const timer = setTimeout(() => {
      setWelcome(true);
      setOpen(true);
    }, 500);
    return () => clearTimeout(timer);
  }, [langReady, fiqhReady, langUnset, fiqhUnset]);

  // Header button (or anything else) asking for the dialog.
  useEffect(() => {
    const handler = () => {
      setWelcome(false);
      setOpen(true);
    };
    window.addEventListener(OPEN_PREFERENCES_EVENT, handler);
    return () => window.removeEventListener(OPEN_PREFERENCES_EVENT, handler);
  }, []);

  // Start from whatever is currently active each time the dialog opens.
  useEffect(() => {
    if (!open) return;
    setDraftLang(lang);
    setDraftFiqh(fiqh);
    setShowAllLangs(!PRIMARY_LANGS.includes(lang));
  }, [open, lang, fiqh]);

  const close = useCallback(() => setOpen(false), []);

  // Escape closes, and the current draft is kept so nobody is trapped.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setLang(draftLang);
        setFiqh(draftFiqh);
        close();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, draftLang, draftFiqh, setLang, setFiqh, close]);

  // Stop the page behind the dialog from scrolling.
  useEffect(() => {
    if (!open || typeof document === "undefined") return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  useEffect(() => {
    if (open) panelRef.current?.focus();
  }, [open]);

  if (!open) return null;

  const confirm = () => {
    setLang(draftLang);
    setFiqh(draftFiqh);
    close();
  };

  const visibleLangs = showAllLangs
    ? LANGUAGES
    : LANGUAGES.filter((l) => PRIMARY_LANGS.includes(l.code));

  return (
    <div
      className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center bg-obsidian/85 backdrop-blur-sm p-0 sm:p-4"
      role="presentation"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && !welcome) confirm();
      }}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="imc-prefs-title"
        aria-describedby="imc-prefs-desc"
        tabIndex={-1}
        dir={dir}
        className="relative w-full sm:max-w-2xl max-h-[92dvh] overflow-y-auto surface-card shadow-luxe outline-none rounded-t-xl sm:rounded-xl"
      >
        <div className="border-b border-border px-5 sm:px-8 py-5 sm:py-6">
          <span className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold">
            {t("footer.positioning")}
          </span>
          <h2 id="imc-prefs-title" className="mt-3 font-display italic text-2xl sm:text-3xl leading-tight">
            {welcome ? t("prefs.title") : t("prefs.editTitle")}
          </h2>
          <p id="imc-prefs-desc" className="mt-2 text-sm text-muted-foreground leading-relaxed">
            {welcome ? t("prefs.subtitle") : t("prefs.changeLater")}
          </p>
        </div>

        <div className="px-5 sm:px-8 py-6 space-y-8">
          {/* ---------------- Language ---------------- */}
          <fieldset>
            <legend className="text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground">
              {t("prefs.language")}
            </legend>
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-2">
              {visibleLangs.map((l) => {
                const active = draftLang === l.code;
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => setDraftLang(l.code)}
                    aria-pressed={active}
                    lang={l.code}
                    className={`flex min-h-12 items-center gap-3 border px-3 py-2.5 text-start transition-colors ${
                      active
                        ? "border-gold bg-gold-soft text-foreground"
                        : "border-border text-muted-foreground hover:border-gold/50 hover:text-foreground"
                    }`}
                  >
                    <span aria-hidden className="text-lg leading-none">{l.flag}</span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold truncate">{l.native}</span>
                      <span className="block text-[10px] uppercase tracking-[0.18em] opacity-70">{l.label}</span>
                    </span>
                  </button>
                );
              })}
            </div>
            {LANGUAGES.length > PRIMARY_LANGS.length && (
              <button
                type="button"
                onClick={() => setShowAllLangs((v) => !v)}
                className="mt-3 text-[11px] uppercase tracking-[0.2em] text-gold hover:underline"
              >
                {showAllLangs ? t("prefs.fewerLanguages") : t("prefs.moreLanguages")}
              </button>
            )}
          </fieldset>

          {/* ---------------- Fiqh ---------------- */}
          <fieldset>
            <legend className="text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground">
              {t("prefs.fiqh")}
            </legend>
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {FIQH_SCHOOLS.map((s) => {
                const active = draftFiqh === s.id;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setDraftFiqh(s.id)}
                    aria-pressed={active}
                    className={`flex min-h-12 flex-col justify-center border px-3 py-2.5 text-start transition-colors ${
                      active
                        ? "border-gold bg-gold-soft text-foreground"
                        : "border-border text-muted-foreground hover:border-gold/50 hover:text-foreground"
                    }`}
                  >
                    <span className="text-sm font-semibold">{fiqhName(s, draftLang)}</span>
                    <span className="mt-0.5 text-[11px] leading-snug opacity-75 line-clamp-2">
                      {fiqhTagline(s, draftLang)}
                    </span>
                  </button>
                );
              })}
            </div>
          </fieldset>
        </div>

        <div className="sticky bottom-0 border-t border-border bg-card/95 backdrop-blur px-5 sm:px-8 py-4 flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-3">
          <p className="text-[11px] text-muted-foreground">{t("prefs.changeLater")}</p>
          <div className="flex items-center gap-2 justify-end">
            {!welcome && (
              <button
                type="button"
                onClick={close}
                className="min-h-11 px-4 text-[11px] uppercase tracking-[0.2em] text-muted-foreground border border-border hover:text-foreground hover:border-gold/50 transition-colors"
              >
                {t("common.cancel")}
              </button>
            )}
            <button
              type="button"
              onClick={confirm}
              className="min-h-11 px-6 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors"
            >
              {welcome ? t("prefs.continue") : t("prefs.save")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Header/footer control that reopens the dialog. */
export function PreferencesButton({
  className = "",
  showLabel = false,
}: {
  className?: string;
  /** Force the school name to be visible regardless of breakpoint. */
  showLabel?: boolean;
}) {
  const { t, lang } = useI18n();
  const { school } = useFiqh();
  return (
    <button
      type="button"
      onClick={openPreferences}
      title={t("nav.preferences")}
      aria-label={`${t("nav.preferences")} — ${fiqhName(school, lang)}`}
      className={`flex items-center gap-2 min-h-9 px-2.5 border border-border text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors ${className}`}
    >
      <span aria-hidden className="text-sm leading-none">⚙</span>
      <span className={`${showLabel ? "" : "hidden xl:inline"} truncate max-w-[12rem]`}>
        {showLabel ? `${t("nav.preferences")} · ${fiqhName(school, lang)}` : fiqhName(school, lang)}
      </span>
    </button>
  );
}
