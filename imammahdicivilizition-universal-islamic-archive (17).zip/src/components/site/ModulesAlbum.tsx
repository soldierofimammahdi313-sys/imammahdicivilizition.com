import { Link } from "@tanstack/react-router";
import { MODULE_GROUPS, MODULE_STATS } from "@/lib/modules";

/** Album of every module system — sits directly under Tools & Utilities in the Command Center. */
export function ModulesAlbum() {
  return (
    <div className="mt-14">
      <div className="flex items-baseline justify-between mb-5 pb-3 border-b border-border">
        <h3 className="text-[11px] font-bold uppercase tracking-[0.3em] text-gold">
          Module Album · {MODULE_STATS.total} Modules
        </h3>
        <span className="font-arabic text-lg text-muted-foreground/60">ألبوم الوحدات</span>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory [scrollbar-width:thin]">
        {MODULE_GROUPS.map((g) => {
          const live = g.modules.filter((m) => m.status === "live").length;
          const beta = g.modules.filter((m) => m.status === "beta").length;
          return (
            <Link
              key={g.code}
              to="/modules"
              hash={`system-${g.code}`}
              className="group snap-start shrink-0 w-[240px] sm:w-[268px] bg-background ring-1 ring-border hover:ring-gold hover:-translate-y-1 hover:bg-gold/5 transition-all duration-300 p-5 flex flex-col"
            >
              <div className="flex items-start justify-between">
                <span className="font-mono-display text-[10px] tracking-[0.3em] text-emerald">{g.code}</span>
                <span className="font-arabic text-lg text-gold/50 leading-none">{g.arabic}</span>
              </div>

              <h4 className="mt-4 font-display italic text-2xl leading-tight group-hover:text-gold transition-colors">
                {g.title}
              </h4>
              <p className="mt-2 text-[11px] text-muted-foreground leading-snug line-clamp-3">{g.blurb}</p>

              <ul className="mt-4 space-y-1">
                {g.modules.slice(0, 3).map((m) => (
                  <li key={m.name} className="text-[10px] text-muted-foreground/80 truncate">
                    <span className="text-gold/60 me-1.5">▸</span>
                    {m.name}
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-4 flex items-center justify-between text-[9px] uppercase tracking-[0.22em]">
                <span className="text-muted-foreground">{g.modules.length} modules</span>
                <span className="flex gap-2">
                  {live > 0 && <span className="text-emerald">{live} live</span>}
                  {beta > 0 && <span className="text-gold">{beta} beta</span>}
                </span>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="mt-4 text-center">
        <Link
          to="/modules"
          className="inline-block px-8 py-3 border border-gold text-gold text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-gold-soft/30 transition-colors"
        >
          Open the full module grid
        </Link>
      </div>
    </div>
  );
}