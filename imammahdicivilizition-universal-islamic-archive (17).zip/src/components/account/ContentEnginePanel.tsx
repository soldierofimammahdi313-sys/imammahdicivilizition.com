import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { LoaderCircle, Play, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  discoverTopicsNow,
  getEngineOverview,
  runContentPipeline,
  setArticleState,
  updateEngineSettings,
} from "@/lib/content-engine.functions";

/** Admin control room for the AI Islamic Content Engine. */
export function ContentEnginePanel() {
  const qc = useQueryClient();
  const overviewFn = useServerFn(getEngineOverview);
  const discoverFn = useServerFn(discoverTopicsNow);
  const pipelineFn = useServerFn(runContentPipeline);
  const stateFn = useServerFn(setArticleState);
  const settingsFn = useServerFn(updateEngineSettings);

  const overview = useQuery({ queryKey: ["content-engine"], queryFn: () => overviewFn({ data: undefined }) });
  const refresh = () => qc.invalidateQueries({ queryKey: ["content-engine"] });

  const discover = useMutation({
    mutationFn: () => discoverFn({ data: { count: 6 } }),
    onSuccess: (r) => {
      toast[r.ok ? "success" : "error"](r.ok ? `${r.inserted} new topics (${r.skipped} duplicates skipped)` : r.error!);
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const runPipeline = useMutation({
    mutationFn: (topicId?: string) => pipelineFn({ data: { topicId } }),
    onSuccess: (r) => {
      toast[r.ok ? "success" : "error"](r.message);
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const act = useMutation({
    mutationFn: (v: { articleId: string; action: "approve" | "publish" | "unpublish" | "reject" }) =>
      stateFn({ data: v }),
    onSuccess: (r) => {
      toast[r.ok ? "success" : "error"](r.message);
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const saveSetting = useMutation({
    mutationFn: (patch: Record<string, boolean | number>) => settingsFn({ data: patch }),
    onSuccess: (r) => {
      toast[r.ok ? "success" : "error"](r.message);
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (overview.isLoading) {
    return (
      <div className="flex items-center gap-3 p-8 text-muted-foreground text-sm">
        <LoaderCircle className="animate-spin size-4" /> Loading content engine…
      </div>
    );
  }
  if (overview.isError || !overview.data) {
    return <p className="p-6 text-sm text-destructive">Content engine unavailable: {(overview.error as Error)?.message}</p>;
  }

  const { settings, usage, topics, articles } = overview.data;
  const pending = articles.filter((a) => a.status !== "published");

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-3">
        <Button onClick={() => discover.mutate()} disabled={discover.isPending} variant="outline">
          {discover.isPending ? <LoaderCircle className="animate-spin" /> : <Sparkles />} Discover topics
        </Button>
        <Button onClick={() => runPipeline.mutate(undefined)} disabled={runPipeline.isPending}>
          {runPipeline.isPending ? <LoaderCircle className="animate-spin" /> : <Play />} Run pipeline
        </Button>
      </div>

      <div className="grid sm:grid-cols-4 gap-px bg-border ring-1 ring-border">
        <Cell label="AI calls today" value={String(usage.today)} />
        <Cell label="AI calls this month" value={String(usage.month)} />
        <Cell label="Auto-publish" value={settings.auto_publish ? "ON" : "OFF (draft)"} />
        <Cell label="Min quality" value={String(settings.min_quality_score)} />
      </div>
      {usage.blocked && <p className="text-xs text-destructive">{usage.reason}</p>}

      <div className="flex flex-wrap gap-2">
        {(
          [
            ["auto_publish", "Auto-publish"],
            ["auto_image", "Auto image"],
            ["auto_seo", "Auto SEO"],
            ["auto_verification", "Auto verification"],
            ["auto_translation", "Auto translation"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            onClick={() => saveSetting.mutate({ [key]: !settings[key] })}
            className={`px-3 py-2 text-[10px] uppercase tracking-[0.2em] border transition-colors ${
              settings[key] ? "border-emerald text-emerald" : "border-border text-muted-foreground hover:text-gold"
            }`}
          >
            {label}: {settings[key] ? "on" : "off"}
          </button>
        ))}
      </div>

      <Section title={`Topic queue (${topics.length})`}>
        {topics.length === 0 ? (
          <Empty>No topics yet — run discovery.</Empty>
        ) : (
          <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
            {topics.map((t) => (
              <li key={t.id} className="flex flex-wrap items-center justify-between gap-4 p-4">
                <div className="min-w-0">
                  <div className="font-display italic text-base truncate">{t.title}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {t.category ?? "general"} · {t.status}
                    {t.last_error ? ` · ${t.last_error.slice(0, 80)}` : ""}
                  </div>
                </div>
                <button
                  className="text-gold hover:text-foreground text-[10px] uppercase tracking-[0.2em]"
                  onClick={() => runPipeline.mutate(t.id)}
                  disabled={runPipeline.isPending}
                >
                  Generate
                </button>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title={`Review queue (${pending.length})`}>
        {pending.length === 0 ? (
          <Empty>Nothing waiting for review.</Empty>
        ) : (
          <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
            {pending.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-4 p-4">
                <div className="min-w-0">
                  <div className="font-display italic text-base truncate">{a.title}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {a.pipeline_status ?? a.status} · quality {a.quality_score ?? "—"} · {a.verification_status ?? "—"}
                    {a.similarity_score ? ` · ${Math.round(a.similarity_score * 100)}% similar` : ""}
                  </div>
                </div>
                <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                  <a className="text-muted-foreground hover:text-gold" href={`/articles/${a.slug}`} target="_blank" rel="noreferrer">
                    Preview
                  </a>
                  <button className="text-gold hover:text-foreground" onClick={() => act.mutate({ articleId: a.id, action: "approve" })}>
                    Approve
                  </button>
                  <button className="text-emerald hover:text-foreground" onClick={() => act.mutate({ articleId: a.id, action: "publish" })}>
                    Publish
                  </button>
                  <button className="text-destructive hover:text-foreground" onClick={() => act.mutate({ articleId: a.id, action: "reject" })}>
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Section>
    </div>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-card p-5">
      <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
      <div className="mt-2 font-display italic text-2xl text-gold">{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{title}</h3>
      {children}
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="text-sm text-muted-foreground ring-1 ring-border bg-card/40 p-5">{children}</p>;
}
