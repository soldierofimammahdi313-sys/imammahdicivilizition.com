import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";

const TABS = [
  { to: "/dashboard", label: "Dashboard", ar: "لوحة" },
  { to: "/bookmarks", label: "Bookmarks", ar: "المحفوظات" },
  { to: "/history", label: "History", ar: "السجل" },
  { to: "/settings", label: "Settings", ar: "الإعدادات" },
  { to: "/admin", label: "Admin", ar: "الإدارة" },
];

export function AccountShell({
  kicker,
  title,
  subtitle,
  children,
}: {
  kicker: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <div className="relative pt-32 pb-16 px-4 md:px-6 max-w-7xl mx-auto">
        <nav aria-label="Account sections" className="flex flex-wrap gap-2 mb-10">
          {TABS.map((tab) => (
            <Link
              key={tab.to}
              to={tab.to}
              activeProps={{ className: "border-gold text-gold bg-gold-soft/30" }}
              className="border border-border px-4 py-2 text-[11px] uppercase tracking-[0.22em] text-muted-foreground hover:border-gold/60 hover:text-gold transition-colors"
            >
              {tab.label}
              <span className="font-arabic text-sm ms-2 opacity-60">{tab.ar}</span>
            </Link>
          ))}
        </nav>
        <header className="mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">{kicker}</span>
          <h1 className="mt-3 font-display italic text-4xl md:text-5xl">{title}</h1>
          {subtitle && <p className="mt-3 text-sm text-muted-foreground max-w-2xl">{subtitle}</p>}
        </header>
        {children}
      </div>
      <SiteFooter />
    </div>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="border border-dashed border-border bg-card/30 p-12 text-center">
      <span className="font-arabic text-3xl text-gold/40 block">لا شيء بعد</span>
      <h3 className="mt-4 font-display italic text-2xl">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{body}</p>
    </div>
  );
}