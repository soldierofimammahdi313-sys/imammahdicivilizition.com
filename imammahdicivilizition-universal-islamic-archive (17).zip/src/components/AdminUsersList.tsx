import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { LoaderCircle, Search } from "lucide-react";
import { listAllUsers, type AdminUserRow } from "@/lib/admin-users.functions";

/**
 * Admin-only members table: every registered user, their join date and total
 * activity. Access is enforced on the server (admin role required); this
 * component only renders what the server agrees to return.
 */
export function AdminUsersList() {
  const [q, setQ] = useState("");
  const usersQuery = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => listAllUsers({}),
    staleTime: 30_000,
  });

  const rows = useMemo(() => {
    const all = usersQuery.data?.users ?? [];
    const needle = q.trim().toLowerCase();
    if (!needle) return all;
    return all.filter(
      (u) =>
        (u.full_name ?? "").toLowerCase().includes(needle) ||
        (u.email ?? "").toLowerCase().includes(needle) ||
        (u.country ?? "").toLowerCase().includes(needle),
    );
  }, [usersQuery.data, q]);

  if (usersQuery.isLoading) {
    return (
      <div className="flex items-center gap-3 text-sm text-muted-foreground p-8 justify-center">
        <LoaderCircle className="animate-spin size-4" /> Loading members…
      </div>
    );
  }

  if (usersQuery.isError) {
    return (
      <div className="border border-destructive/40 bg-destructive/5 p-6 text-sm">
        This list is restricted to administrators.
      </div>
    );
  }

  const data = usersQuery.data!;

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-3 gap-px bg-border ring-1 ring-border">
        <Stat label="Registered members" value={data.total} />
        <Stat label="New this week" value={data.newLast7Days} highlight={data.newLast7Days > 0} />
        <Stat label="Active members" value={data.users.filter((u) => u.activity > 0).length} />
      </div>

      <label className="flex items-center gap-3 border border-border bg-card px-4 py-3">
        <Search className="size-4 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search by name, email or country"
          className="w-full bg-transparent text-sm outline-none"
        />
      </label>

      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground p-6 border border-border">No members match that search.</p>
      ) : (
        <div className="overflow-x-auto ring-1 ring-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-card text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                <Th>Member</Th>
                <Th>Email</Th>
                <Th>Joined</Th>
                <Th className="text-end">Posts</Th>
                <Th className="text-end">Replies</Th>
                <Th className="text-end">Saves</Th>
                <Th className="text-end">XP</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((u) => (
                <Row key={u.id} u={u} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Row({ u }: { u: AdminUserRow }) {
  const isNew = Date.now() - new Date(u.created_at).getTime() < 7 * 24 * 60 * 60 * 1000;
  return (
    <tr className="border-t border-border bg-background/40">
      <Td>
        <span className="font-medium">{u.full_name ?? "Unnamed member"}</span>
        {isNew && (
          <span className="ms-2 text-[9px] uppercase tracking-[0.2em] text-gold border border-gold/40 px-1.5 py-0.5">
            new
          </span>
        )}
        {u.country && <span className="block text-xs text-muted-foreground">{u.country}</span>}
      </Td>
      <Td className="text-muted-foreground">{u.email ?? "—"}</Td>
      <Td className="text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</Td>
      <Td className="text-end">{u.posts}</Td>
      <Td className="text-end">{u.comments}</Td>
      <Td className="text-end">{u.saves}</Td>
      <Td className="text-end text-gold">{u.xp}</Td>
    </tr>
  );
}

function Th({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <th className={`px-4 py-3 text-start font-semibold ${className}`}>{children}</th>;
}

function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-3 align-top ${className}`}>{children}</td>;
}

function Stat({ label, value, highlight = false }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div className="bg-card p-6">
      <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
      <div className={`mt-2 font-display italic text-4xl ${highlight ? "text-gold" : ""}`}>{value}</div>
    </div>
  );
}
