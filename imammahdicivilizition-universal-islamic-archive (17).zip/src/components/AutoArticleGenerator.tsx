import React, { useState, useEffect } from "react";
import { generateNewArticle, getSavedArticles, type Article } from "@/lib/autoArticleService";

export const AutoArticleGenerator: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [selectedLang, setSelectedLang] = useState<"urdu" | "english" | "arabic">("urdu");
  const [message, setMessage] = useState<string>("");

  useEffect(() => {
    setArticles(getSavedArticles());
  }, []);

  const handleGenerate = async () => {
    setLoading(true);
    setMessage("AI انجن آرٹیکل لکھ رہا ہے... براہِ کرم انتظار فرمائیں۔");
    try {
      const newArt = await generateNewArticle(selectedTopic || undefined, selectedLang);
      setArticles(getSavedArticles());
      setMessage(`کامیابی! نیا آرٹیکل "${newArt.title}" کامیابی سے تیار کر کے سیو کر دیا گیا ہے۔`);
      setSelectedTopic("");
    } catch (err) {
      setMessage(`خرابی: ${err instanceof Error ? err.message : "آرٹیکل جنریٹ نہیں ہو سکا"}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="p-6 max-w-4xl mx-auto bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-800"
      style={{ direction: "rtl" }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
        <h2 className="text-2xl font-bold text-amber-400">🤖 خودکار AI آرٹیکل جنریٹر</h2>
        <span className="bg-amber-500/20 text-amber-300 px-3 py-1 rounded-full text-xs font-semibold">
          AI Key Pool Active
        </span>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="md:col-span-2">
          <label className="block text-sm text-slate-300 mb-1">موضوع (اختیاری):</label>
          <input
            type="text"
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            placeholder="مثال: عصرِ غیبت میں اخلاقی اقدار..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-amber-500"
          />
        </div>
        <div>
          <label className="block text-sm text-slate-300 mb-1">زبان منتخب کریں:</label>
          <select
            value={selectedLang}
            onChange={(e) => setSelectedLang(e.target.value as "urdu" | "english" | "arabic")}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-amber-500"
          >
            <option value="urdu">اردو (Urdu)</option>
            <option value="english">انگریزی (English)</option>
            <option value="arabic">عربی (Arabic)</option>
          </select>
        </div>
      </div>

      {/* Button */}
      <button
        onClick={handleGenerate}
        disabled={loading}
        className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold py-3 rounded-lg shadow-lg transition-all duration-200 disabled:opacity-50"
      >
        {loading ? "آرٹیکل جنریٹ ہو رہا ہے..." : "✨ نیا آرٹیکل جنریٹ کریں"}
      </button>

      {/* Message */}
      {message && (
        <div
          className={`mt-4 p-3 rounded-lg text-sm ${message.includes("کامیابی") ? "bg-emerald-900/50 text-emerald-300 border border-emerald-700" : "bg-slate-800 text-amber-300"}`}
        >
          {message}
        </div>
      )}

      {/* Recent Articles */}
      <div className="mt-8">
        <h3 className="text-xl font-semibold mb-4 text-slate-200">
          تازہ ترین خودکار مضامین ({articles.length})
        </h3>
        <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
          {articles.length === 0 ? (
            <p className="text-slate-500 text-sm">ابھی تک کوئی آرٹیکل جنریٹ نہیں ہوا ہے۔</p>
          ) : (
            articles.map((art) => (
              <div key={art.id} className="bg-slate-800/80 p-4 rounded-lg border border-slate-700">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-amber-300 text-lg">{art.title}</h4>
                  <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded uppercase">
                    {art.language}
                  </span>
                </div>
                <p className="text-slate-300 text-sm mb-3">{art.excerpt}</p>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>زمرہ: {art.category}</span>
                  <span>{new Date(art.createdAt).toLocaleDateString("ur-PK")}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
