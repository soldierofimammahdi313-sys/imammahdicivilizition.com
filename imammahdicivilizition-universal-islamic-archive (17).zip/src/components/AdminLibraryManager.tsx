import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LoaderCircle, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  LIBRARY_CATEGORIES,
  createLibraryItem,
  deleteLibraryItem,
  fetchAllLibraryItems,
  slugify,
  updateLibraryItem,
  type LibraryItem,
  type LibraryItemInput,
} from "@/lib/library-items";

const EMPTY: LibraryItemInput = {
  slug: "",
  title: "",
  arabic_title: "",
  author: "",
  category: "Tafsir",
  era: "",
  language: "en",
  summary: "",
  body: "",
  cover_url: "",
  sort_order: 0,
  is_published: true,
};

/**
 * Admin panel for the digital library: add, edit and remove entries.
 * Write access is enforced by the database (admin role only).
 */
export function AdminLibraryManager() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<LibraryItem | null>(null);
  const [form, setForm] = useState<LibraryItemInput>(EMPTY);

  const itemsQuery = useQuery({ queryKey: ["admin-library-items"], queryFn: fetchAllLibraryItems });

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["admin-library-items"] });
    void qc.invalidateQueries({ queryKey: ["library-items"] });
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload: LibraryItemInput = {
        ...form,
        slug: form.slug.trim() || slugify(form.title),
        title: form.title.trim(),
      };
      if (!payload.title) throw new Error("A title is required.");
      if (editing) await updateLibraryItem(editing.id, payload);
      else await createLibraryItem(payload);
    },
    onSuccess: () => {
      toast.success(editing ? "Entry updated" : "Entry added to the library");
      setOpen(false);
      setEditing(null);
      setForm(EMPTY);
      refresh();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save this entry"),
  });

  const removeMutation = useMutation({
    mutationFn: (id: string) => deleteLibraryItem(id),
    onSuccess: () => {
      toast.success("Entry removed");
      refresh();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not remove this entry"),
  });

  const startNew = () => {
    setEditing(null);
    setForm(EMPTY);
    setOpen(true);
  };

  const startEdit = (item: LibraryItem) => {
    setEditing(item);
    setForm({
      slug: item.slug,
      title: item.title,
      arabic_title: item.arabic_title ?? "",
      author: item.author ?? "",
      category: item.category,
      era: item.era ?? "",
      language: item.language,
      summary: item.summary ?? "",
      body: item.body ?? "",
      cover_url: item.cover_url ?? "",
      sort_order: item.sort_order,
      is_published: item.is_published,
    });
    setOpen(true);
  };

  const items = itemsQuery.data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <p className="text-xs text-muted-foreground">
          {items.length} library entr{items.length === 1 ? "y" : "ies"} — published items appear on the public Library page.
        </p>
        <button
          onClick={startNew}
          className="inline-flex items-center gap-2 px-4 py-2 border border-gold text-gold text-[10px] uppercase tracking-[0.25em] hover:bg-gold-soft transition-colors"
        >
          <Plus className="size-3" /> Add content
        </button>
      </div>

      {itemsQuery.isLoading ? (
        <div className="flex items-center justify-center gap-3 p-10 text-sm text-muted-foreground">
          <LoaderCircle className="size-4 animate-spin" /> Loading library…
        </div>
      ) : items.length === 0 ? (
        <p className="p-10 text-center text-sm text-muted-foreground">No entries yet — add the first one.</p>
      ) : (
        <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
          {items.map((item) => (
            <li key={item.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
              <div className="min-w-0">
                <div className="font-display italic text-lg truncate">{item.title}</div>
                <div className="text-[11px] text-muted-foreground">
                  {item.category} · {item.language.toUpperCase()}
                  {item.author ? ` · ${item.author}` : ""}
                  {item.is_published ? "" : " · draft"}
                </div>
              </div>
              <div className="flex gap-4 text-[10px] uppercase tracking-[0.2em]">
                <button className="inline-flex items-center gap-1 text-gold hover:text-foreground" onClick={() => startEdit(item)}>
                  <Pencil className="size-3" /> Edit
                </button>
                <button
                  className="inline-flex items-center gap-1 text-destructive hover:text-foreground"
                  onClick={() => {
                    if (confirm(`Remove “${item.title}” from the library?`)) removeMutation.mutate(item.id);
                  }}
                >
                  <Trash2 className="size-3" /> Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div className="fixed inset-0 z-50 bg-obsidian/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto p-4 sm:p-8">
          <div className="w-full max-w-2xl bg-card ring-1 ring-border p-6 sm:p-8">
            <h3 className="font-display italic text-2xl text-gold">{editing ? "Edit entry" : "Add library content"}</h3>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="Title" value={form.title} onChange={(v) => setForm((f) => ({ ...f, title: v }))} />
              <Field label="Original title (Arabic/Urdu)" value={form.arabic_title ?? ""} onChange={(v) => setForm((f) => ({ ...f, arabic_title: v }))} />
              <Field label="Author" value={form.author ?? ""} onChange={(v) => setForm((f) => ({ ...f, author: v }))} />
              <Field label="Era" value={form.era ?? ""} onChange={(v) => setForm((f) => ({ ...f, era: v }))} />
              <label className="text-sm">
                <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">Category</span>
                <select
                  value={form.category}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="w-full bg-background border border-border px-3 py-2 text-sm"
                >
                  {LIBRARY_CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">Language</span>
                <select
                  value={form.language}
                  onChange={(e) => setForm((f) => ({ ...f, language: e.target.value }))}
                  className="w-full bg-background border border-border px-3 py-2 text-sm"
                >
                  <option value="en">English</option>
                  <option value="ur">اردو</option>
                  <option value="ar">العربية</option>
                  <option value="fa">فارسی</option>
                </select>
              </label>
              <Field label="Cover image link (optional)" value={form.cover_url ?? ""} onChange={(v) => setForm((f) => ({ ...f, cover_url: v }))} />
              <Field
                label="Order"
                value={String(form.sort_order ?? 0)}
                onChange={(v) => setForm((f) => ({ ...f, sort_order: Number(v) || 0 }))}
              />
            </div>
            <label className="mt-4 block text-sm">
              <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">Summary</span>
              <textarea
                value={form.summary ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, summary: e.target.value }))}
                rows={3}
                className="w-full bg-background border border-border px-3 py-2 text-sm"
              />
            </label>
            <label className="mt-4 block text-sm">
              <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">Full text (optional)</span>
              <textarea
                value={form.body ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
                rows={8}
                className="w-full bg-background border border-border px-3 py-2 text-sm"
              />
            </label>
            <label className="mt-4 flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.is_published ?? true}
                onChange={(e) => setForm((f) => ({ ...f, is_published: e.target.checked }))}
              />
              Visible on the public Library page
            </label>

            <div className="mt-8 flex justify-end gap-3">
              <button
                onClick={() => { setOpen(false); setEditing(null); }}
                className="px-5 py-2 border border-border text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground"
              >
                Cancel
              </button>
              <button
                onClick={() => saveMutation.mutate()}
                disabled={saveMutation.isPending}
                className="px-5 py-2 bg-gold text-primary-foreground text-[10px] uppercase tracking-[0.25em] disabled:opacity-50"
              >
                {saveMutation.isPending ? "Saving…" : editing ? "Save changes" : "Add to library"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-sm">
      <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-background border border-border px-3 py-2 text-sm"
      />
    </label>
  );
}
