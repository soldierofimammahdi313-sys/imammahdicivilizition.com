import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { abs } from "@/lib/site";

export const Route = createFileRoute("/disclaimer")({
  head: () => ({
    meta: [
      { title: "Disclaimer — Imam Mahdi Civilization" },
      { name: "description", content: "Editorial, religious-content, AI and calculator disclaimers for the Imam Mahdi Civilization platform, including third-party data sources." },
      { property: "og:title", content: "Disclaimer — Imam Mahdi Civilization" },
      { property: "og:description", content: "Religious content, AI output and calculator disclaimers for this platform." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: abs("/disclaimer") },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: abs("/disclaimer") }],
  }),
  component: Disclaimer,
});

const SECTIONS = [
  {
    h: "General information only",
    p: "The material on this website is published for general educational and devotional benefit. It is offered in good faith, but we make no warranty that every page is complete, current or free of error.",
  },
  {
    h: "Religious content and sources",
    p: "Quranic text, translations, narrations, tafsir and supplications are reproduced from established published sources and third-party scholarly APIs. We do not author scripture or narrations. Where a source is shown, it belongs to that source; where you find a mistake in transcription or attribution, please contact us so it can be corrected.",
  },
  {
    h: "Not a religious ruling",
    p: "Nothing on this site is a fatwa. For any matter affecting your worship, obligations, family or wealth, refer to your marjaʿ or a qualified scholar. Our summaries are not a substitute for that.",
  },
  {
    h: "AI assistants",
    p: "The AI assistants answer in line with Fiqh Jaʿfariyya (Ithnā ʿAsharī) to the best of their ability, but they are software and can be wrong or incomplete. Verify anything important with a scholar or a primary source before acting on it.",
  },
  {
    h: "Calculators and tools",
    p: "Zakat, Khums, inheritance, prayer-time, Hijri-date and Qibla tools give estimates based on standard published methods and your own inputs or device location. Results can differ from a scholar's calculation or your local mosque's timetable. Verify before acting.",
  },
  {
    h: "No professional advice",
    p: "Nothing here is financial, legal, medical or tax advice.",
  },
  {
    h: "External links and third parties",
    p: "We link to external books, videos, mosque data, maps and scholarly APIs. We do not control that content and are not responsible for it. Visiting an external site is subject to that site's own terms and privacy policy.",
  },
  {
    h: "User-submitted content",
    p: "Discussions, comments and applications are written by their authors and do not represent the views of Imam Mahdi Civilization. We may remove content that is unlawful, abusive, inflammatory or disrespectful of sanctities.",
  },
  {
    h: "Advertising",
    p: "We may display advertising to keep the platform free. Adverts are supplied by third-party networks and their presence is not an endorsement by us of any product or service shown.",
  },
  {
    h: "Contact",
    p: "Corrections and questions: imammahdicivilization@gmail.com.",
  },
];

function Disclaimer() {
  return (
    <div className="bg-background text-foreground min-h-dvh">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Disclaimer" }]} />
      <main className="max-w-3xl mx-auto px-6 pt-10 pb-24">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Legal</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-5xl">Disclaimer</h1>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          Please read this before relying on anything published on Imam Mahdi Civilization.
        </p>
        <div className="mt-12 space-y-10">
          {SECTIONS.map((s) => (
            <section key={s.h}>
              <h2 className="text-lg font-bold uppercase tracking-[0.15em] text-gold">{s.h}</h2>
              <p className="mt-3 text-muted-foreground leading-relaxed">{s.p}</p>
            </section>
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}