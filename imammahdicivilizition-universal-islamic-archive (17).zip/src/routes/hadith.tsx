import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { InlineError, ListSkeleton } from "@/components/site/States";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/hadith.jpg";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/hadith")({
  head: () => ({
    meta: [
      { title: "Hadith Library — Imam Mahdi Civilization" },
      { name: "description", content: "Hadith library of narrations from the Ahl al-Bayt (a.s) — Al-Kafi, Nahj al-Balagha and Sahifa Sajjadiya, alongside the six major Sunni collections." },
      { property: "og:title", content: "Hadith Library — Ahl al-Bayt (a.s) Narrations" },
      { property: "og:description", content: "Read narrations of the Ahl al-Bayt (a.s) from Al-Kafi, Nahj al-Balagha and Sahifa Sajjadiya, plus the six major Sunni collections." },

      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/hadith" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/hadith" }],
  }),
  component: HadithPage,
});

const BOOKS = [
  { id: "bukhari", name: "Sahih al-Bukhari", arabic: "صحيح البخاري", count: "7,563", section: 1 },
  { id: "muslim", name: "Sahih Muslim", arabic: "صحيح مسلم", count: "7,500", section: 1 },
  { id: "abudawud", name: "Sunan Abi Dawud", arabic: "سنن أبي داود", count: "5,274", section: 1 },
  { id: "tirmidhi", name: "Jami` at-Tirmidhi", arabic: "جامع الترمذي", count: "3,956", section: 1 },
  { id: "nasai", name: "Sunan an-Nasa'i", arabic: "سنن النسائي", count: "5,761", section: 1 },
  { id: "ibnmajah", name: "Sunan Ibn Majah", arabic: "سنن ابن ماجه", count: "4,341", section: 1 },
];

const CDN = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1";

function HadithPage() {
  const [book, setBook] = useState<string>("bukhari");
  const [section, setSection] = useState<number>(1);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    setLoading(true); setErr(null);
    fetch(`${CDN}/editions/eng-${book}/sections/${section}.json`)
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => setData(d))
      .catch(e => setErr(`Could not load (${e})`))
      .finally(() => setLoading(false));
  }, [book, section, attempt]);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Hadith" }]} />
      <PageBanner src={bannerImg} alt="Hadith Library" eyebrow="Narrations" title="Words of the Infallibles" subtitle="Authenticated narrations with complete text and sources." />
      <section className="pt-8 pb-20 px-6 max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">As-Sunnah</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Hadith Library</h1>
        </div>

        <h2 className="font-display text-2xl mb-4">Collections</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-10">
          {BOOKS.map(b => (
            <button key={b.id} onClick={() => { setBook(b.id); setSection(1); }}
              className={`text-left p-4 border transition-colors ${book === b.id ? "border-gold bg-emerald-soft" : "border-border bg-card hover:border-gold/50"}`}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-display text-lg">{b.name}</div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{b.count} narrations</div>
                </div>
                <span className="font-arabic text-xl text-gold/70">{b.arabic}</span>
              </div>
            </button>
          ))}
        </div>

        <h2 className="font-display text-2xl mb-4">Narrations of the Ahl al-Bayt (a.s)</h2>
        <p className="text-sm text-muted-foreground mb-4">
          The core Ahl al-Bayt (a.s) collections — Al-Kafi, Nahj al-Balagha and Sahifa Sajjadiya — are available to read in full
          in the Digital Library.
        </p>
        <div className="grid sm:grid-cols-3 gap-3 mb-10">
          {[
            { name: "Al-Kafi", arabic: "الكافي" },
            { name: "Nahj al-Balagha", arabic: "نهج البلاغة" },
            { name: "Sahifa Sajjadiya", arabic: "الصحيفة السجادية" },
          ].map((b) => (
            <Link key={b.name} to="/library" className="p-4 border border-border bg-card hover:border-gold/50 transition-colors flex justify-between items-start">
              <span className="font-display text-lg">{b.name}</span>
              <span className="font-arabic text-xl text-gold/70">{b.arabic}</span>
            </Link>
          ))}
        </div>



        <h2 className="font-display text-2xl mb-4">Narrations</h2>
        <div className="flex items-center gap-3 mb-6">
          <label className="text-[11px] uppercase tracking-widest text-muted-foreground">Chapter</label>
          <input type="number" min={1} value={section} onChange={e => setSection(Math.max(1, Number(e.target.value)))}
            className="bg-card border border-border px-3 py-2 w-24 text-sm focus:border-gold outline-none" />
        </div>

        {loading && <ListSkeleton rows={5} />}
        {err && !loading && <InlineError message={err} onRetry={() => setAttempt(a => a + 1)} />}
        {!loading && !err && data && (data.hadiths?.length ?? 0) === 0 && (
          <p className="text-sm text-muted-foreground">No narrations found in this chapter.</p>
        )}

        <div className="space-y-6">
          {data?.hadiths?.slice(0, 30).map((h: any) => (
            <div key={h.hadithnumber} className="border border-border bg-card p-6">
              <div className="text-[10px] text-gold uppercase tracking-widest mb-3">#{h.hadithnumber}</div>
              <p className="text-sm leading-relaxed">{h.text}</p>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}