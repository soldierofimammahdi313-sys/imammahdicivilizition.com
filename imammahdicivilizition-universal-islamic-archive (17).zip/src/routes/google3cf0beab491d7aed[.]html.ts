import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const TOKEN = "google-site-verification: google3cf0beab491d7aed.html";

export const Route = createFileRoute("/google3cf0beab491d7aed.html")({
  server: {
    handlers: {
      GET: () =>
        new Response(TOKEN, {
          headers: {
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        }),
    },
  },
});
