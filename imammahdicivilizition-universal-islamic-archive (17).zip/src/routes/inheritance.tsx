import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/inheritance")({
  head: () => ({
    meta: [
      { title: "Mirath — Islamic Inheritance Calculator" },
      { name: "description", content: "Approximate shares of inheritance according to the rules of Mirath." },
      { property: "og:title", content: "Mirath — Islamic Inheritance Calculator" },
      { property: "og:description", content: "Approximate shares of inheritance according to the rules of Mirath." },
      { property: "og:url", content: "https://imammahdicivilizition.com/inheritance" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/inheritance" }],
  }),
  component: InheritancePage,
});

// Simplified illustrative shares per common Sunni fiqh rulings (excludes redd/`awl edge cases).
function calculate(estate: number, p: {
  husband: boolean; wife: boolean;
  sons: number; daughters: number;
  father: boolean; mother: boolean;
}) {
  let remaining = estate;
  const shares: { who: string; amount: number; basis: string }[] = [];
  const hasChildren = p.sons + p.daughters > 0;

  if (p.husband) {
    const frac = hasChildren ? 1 / 4 : 1 / 2;
    const a = estate * frac;
    shares.push({ who: "Husband", amount: a, basis: hasChildren ? "1/4 (with children)" : "1/2 (no children)" });
    remaining -= a;
  }
  if (p.wife) {
    const frac = hasChildren ? 1 / 8 : 1 / 4;
    const a = estate * frac;
    shares.push({ who: "Wife", amount: a, basis: hasChildren ? "1/8 (with children)" : "1/4 (no children)" });
    remaining -= a;
  }
  if (p.mother) {
    const frac = hasChildren ? 1 / 6 : 1 / 3;
    const a = estate * frac;
    shares.push({ who: "Mother", amount: a, basis: hasChildren ? "1/6 (with children)" : "1/3 (no children)" });
    remaining -= a;
  }
  if (p.father) {
    const a = estate * (1 / 6);
    shares.push({ who: "Father", amount: a, basis: hasChildren ? "1/6 (with children)" : "1/6 + residue" });
    remaining -= a;
  }

  // Children take residue: son = 2 × daughter
  if (hasChildren && remaining > 0) {
    const units = p.sons * 2 + p.daughters;
    const per = remaining / units;
    if (p.sons > 0) shares.push({ who: `Sons (${p.sons})`, amount: per * 2 * p.sons, basis: "residue, son = 2 × daughter" });
    if (p.daughters > 0) shares.push({ who: `Daughters (${p.daughters})`, amount: per * p.daughters, basis: "residue" });
    remaining = 0;
  } else if (!hasChildren && p.father && remaining > 0) {
    const last = shares.find(s => s.who === "Father");
    if (last) last.amount += remaining;
    remaining = 0;
  }

  return { shares, residue: remaining };
}

function InheritancePage() {
  const [estate, setEstate] = useState(100000);
  const [husband, setHusband] = useState(false);
  const [wife, setWife] = useState(false);
  const [sons, setSons] = useState(0);
  const [daughters, setDaughters] = useState(0);
  const [father, setFather] = useState(false);
  const [mother, setMother] = useState(false);

  const result = useMemo(
    () => calculate(estate, { husband, wife, sons, daughters, father, mother }),
    [estate, husband, wife, sons, daughters, father, mother],
  );

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Inheritance" }]} />
      <section className="pt-8 pb-20 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Mirāth</span>
          <h1 className="mt-4 font-display italic text-5xl">Inheritance Calculator</h1>
          <p className="mt-3 text-sm text-muted-foreground">Illustrative shares — consult a qualified scholar for binding rulings.</p>
        </div>
        <div className="bg-card border border-border p-6 space-y-5">
          <label className="block">
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground">Total estate</span>
            <input type="number" value={estate} onChange={e => setEstate(Number(e.target.value) || 0)}
              className="mt-1 w-full bg-background border border-border px-3 py-2 focus:border-gold outline-none" />
          </label>
          <div className="grid grid-cols-2 gap-4">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={husband} onChange={e => { setHusband(e.target.checked); if (e.target.checked) setWife(false); }} /> Husband alive</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={wife} onChange={e => { setWife(e.target.checked); if (e.target.checked) setHusband(false); }} /> Wife alive</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={father} onChange={e => setFather(e.target.checked)} /> Father alive</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={mother} onChange={e => setMother(e.target.checked)} /> Mother alive</label>
            <label className="block text-sm"><span className="text-[11px] uppercase tracking-widest text-muted-foreground">Sons</span>
              <input type="number" min={0} value={sons} onChange={e => setSons(Math.max(0, Number(e.target.value) || 0))} className="mt-1 w-full bg-background border border-border px-3 py-2 focus:border-gold outline-none" /></label>
            <label className="block text-sm"><span className="text-[11px] uppercase tracking-widest text-muted-foreground">Daughters</span>
              <input type="number" min={0} value={daughters} onChange={e => setDaughters(Math.max(0, Number(e.target.value) || 0))} className="mt-1 w-full bg-background border border-border px-3 py-2 focus:border-gold outline-none" /></label>
          </div>
        </div>
        <div className="mt-8 bg-card border border-border p-6">
          <h2 className="font-display text-xl text-gold mb-4">Distribution</h2>
          {result.shares.length === 0 && <p className="text-sm text-muted-foreground">Add eligible heirs above.</p>}
          <ul className="divide-y divide-border">
            {result.shares.map((s, i) => (
              <li key={i} className="py-3 flex justify-between items-center">
                <div>
                  <div className="font-display">{s.who}</div>
                  <div className="text-[11px] text-muted-foreground uppercase tracking-widest">{s.basis}</div>
                </div>
                <div className="font-mono-display text-gold">{s.amount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
              </li>
            ))}
          </ul>
          {result.residue > 0 && <p className="mt-4 text-xs text-muted-foreground">Residue undistributed: {result.residue.toLocaleString()} (would go to extended `asabah heirs not modeled here).</p>}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}