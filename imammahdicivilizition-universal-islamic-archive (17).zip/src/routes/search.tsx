import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Search as SearchIcon, ExternalLink, Loader2 } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { InlineEmpty } from "@/components/site/States";
import {
  LOCAL_DOCS,
  searchArticles,
  searchDiscussions,
  searchQuran,
} from "@/lib/search-sources";
import {
  SEARCH_TYPES,
  TYPE_LABELS,
  highlight,
  rank,
  snippet,
  type SearchDoc,
  type SearchType,
} from "@/lib/search-engine";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  type: fallback(z.string(), "all").default("all"),
  sort: fallback(z.string(), "relevance").default("relevance"),
});

export const Route = createFileRoute("/search")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Advanced Search — Mahdi Civilization" },
      {
        name: "description",
        content:
          "Search the entire civilization at once — Qur'an verses, hadith, articles, books, videos and community discussions, with filters and intelligent ranking.",
      },
      { property: "og:title", content: "Advanced Search — Mahdi Civilization" },
      {
        property: "og:description",
        content:
          "One search across Qur'an, hadith, articles, books, videos and discussions with filters and ranking.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/search" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/search" }],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q, type, sort } = Route.useSearch();
  const navigate = useNavigate({ from: "/search" });
  const [draft, setDraft] = useState(q);

  useEffect(() => setDraft(q), [q]);

  const query = q.trim().slice(0, 120);
  const activeType: SearchType | "all" = (SEARCH_TYPES as string[]).includes(type)
    ? (type as SearchType)
    : "all";

  const articles = useQuery({
    queryKey: ["search", "articles", query],
    queryFn: () => searchArticles(query),
    enabled: query.length > 1,
    staleTime: 60_000,
  });
  const discussions = useQuery({
    queryKey: ["search", "discussions", query],
    queryFn: () => searchDiscussions(query),
    enabled: query.length > 1,
    staleTime: 60_000,
  });
  const quran = useQuery({
    queryKey: ["search", "quran", query],
    queryFn: () => searchQuran(query),
    enabled: query.length > 2,
    staleTime: 300_000,
  });

  const loading =
    query.length > 1 &&
    (articles.isLoading || discussions.isLoading || quran.isLoading);

  const all = useMemo<SearchDoc[]>(
    () => [
      ...LOCAL_DOCS,
      ...(articles.data ?? []),
      ...(discussions.data ?? []),
      ...(quran.data ?? []),
    ],
    [articles.data, discussions.data, quran.data],
  );

  const ranked = useMemo(() => rank(all, query), [all, query]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: ranked.length };
    for (const t of SEARCH_TYPES) map[t] = 0;
    for (const r of ranked) map[r.type] = (map[r.type] ?? 0) + 1;
    return map;
  }, [ranked]);

  const results = useMemo(() => {
    const filtered =
      activeType === "all" ? ranked : ranked.filter((r) => r.type === activeType);
    if (sort === "newest") {
      return [...filtered].sort(
        (a, b) =>
          (b.date ? Date.parse(b.date) : 0) - (a.date ? Date.parse(a.date) : 0) ||
          b.score - a.score,
      );
    }
    return filtered;
  }, [ranked, activeType, sort]);

  const setParams = (patch: Partial<{ q: string; type: string; sort: string }>) =>
    navigate({
      search: (prev: { q: string; type: string; sort: string }) => ({ ...prev, ...patch }),
    });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Search" }]} />
      <section className="mx-auto max-w-5xl px-6 pt-8 pb-24">
        <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-gold">
          Global Index
        </span>
        <h1 className="mt-4 font-display text-4xl italic md:text-5xl">Search Everything</h1>
        <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
          Qur'an verses, hadith, articles, books, video collections, tools and community
          discussions — ranked by relevance in one place.
        </p>

        <form
          className="mt-8 flex items-center gap-3 rounded-xl border border-gold/25 bg-card/70 px-4 py-3 shadow-luxe backdrop-blur"
          onSubmit={(e) => {
            e.preventDefault();
            setParams({ q: draft });
          }}
        >
          <SearchIcon className="h-4 w-4 shrink-0 text-gold" aria-hidden />
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Try “patience”, “Imam Mahdi”, “zakat”, “knowledge”…"
            aria-label="Search the civilization"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/70"
          />
          {loading && <Loader2 className="h-4 w-4 animate-spin text-gold" aria-hidden />}
          <button
            type="submit"
            className="rounded-md bg-gold/15 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-gold transition hover:bg-gold/25"
          >
            Search
          </button>
        </form>

        {/* Facets */}
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <FacetChip
            active={activeType === "all"}
            label="All"
            count={counts["all"] ?? 0}
            onClick={() => setParams({ type: "all" })}
          />
          {SEARCH_TYPES.map((t) => (
            <FacetChip
              key={t}
              active={activeType === t}
              label={TYPE_LABELS[t]}
              count={counts[t] ?? 0}
              onClick={() => setParams({ type: t })}
            />
          ))}
          <div className="ml-auto flex items-center gap-2 text-[11px] text-muted-foreground">
            <span className="uppercase tracking-[0.2em]">Sort</span>
            <select
              value={sort}
              onChange={(e) => setParams({ sort: e.target.value })}
              aria-label="Sort results"
              className="rounded-md border border-border bg-card px-2 py-1 text-xs text-foreground"
            >
              <option value="relevance">Relevance</option>
              <option value="newest">Newest</option>
            </select>
          </div>
        </div>

        {/* Results */}
        <div className="mt-8 space-y-3">
          {query.length < 2 ? (
            <p className="py-16 text-center text-sm text-muted-foreground">
              Type at least two characters to search the civilization.
            </p>
          ) : results.length === 0 && !loading ? (
            <InlineEmpty
              title="Nothing found"
              hint={`No results for “${query}”. Try a different word or clear the filter.`}
            />
          ) : (
            results.map((r) => <ResultRow key={r.id} doc={r} query={query} />)
          )}
        </div>
      </section>
    </div>
  );
}

function FacetChip({
  active,
  label,
  count,
  onClick,
}: {
  active: boolean;
  label: string;
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full border px-3 py-1.5 text-[11px] font-medium transition ${
        active
          ? "border-gold/60 bg-gold/15 text-gold"
          : "border-border bg-card/50 text-muted-foreground hover:border-gold/30 hover:text-foreground"
      }`}
    >
      {label}
      <span className="ml-2 font-mono-display text-[10px] opacity-70">{count}</span>
    </button>
  );
}

function Highlighted({ text, query }: { text: string; query: string }) {
  return (
    <>
      {highlight(text, query).map((part, i) =>
        part.hit ? (
          <mark key={i} className="rounded bg-gold/25 px-0.5 text-foreground">
            {part.text}
          </mark>
        ) : (
          <span key={i}>{part.text}</span>
        ),
      )}
    </>
  );
}

function ResultRow({
  doc,
  query,
}: {
  doc: SearchDoc & { score: number };
  query: string;
}) {
  const body = doc.body ? snippet(doc.body, query) : doc.subtitle;

  const inner = (
    <>
      <div className="flex items-center gap-3">
        <span className="rounded-full border border-emerald/30 bg-emerald-soft px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.2em] text-emerald">
          {TYPE_LABELS[doc.type]}
        </span>
        {doc.meta && (
          <span className="font-mono-display text-[10px] text-muted-foreground/70">
            {doc.meta}
          </span>
        )}
        {doc.date && (
          <span className="ml-auto font-mono-display text-[10px] text-muted-foreground/60">
            {new Date(doc.date).toLocaleDateString()}
          </span>
        )}
      </div>
      <h2 className="mt-2 flex items-center gap-2 font-display text-lg leading-snug group-hover:text-gold">
        <Highlighted text={doc.title} query={query} />
        {doc.href && <ExternalLink className="h-3.5 w-3.5 opacity-60" aria-hidden />}
      </h2>
      {doc.arabic && (
        <p className="mt-1 font-arabic text-base text-gold/80">{doc.arabic}</p>
      )}
      {body && (
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <Highlighted text={body} query={query} />
        </p>
      )}
    </>
  );

  const cls =
    "group block rounded-xl border border-border bg-card/60 p-5 transition hover:border-gold/40 hover:bg-emerald-soft/40";

  if (doc.href) {
    return (
      <a href={doc.href} target="_blank" rel="noreferrer" className={cls}>
        {inner}
      </a>
    );
  }
  return (
    <Link to={doc.to ?? "/"} className={cls}>
      {inner}
    </Link>
  );
}