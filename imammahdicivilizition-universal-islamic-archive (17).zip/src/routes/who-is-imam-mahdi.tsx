import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { abs, breadcrumbLd, SITE_NAME } from "@/lib/site";

const TITLE = "Who Is Imam Mahdi? A Clear Twelver Introduction";
const DESCRIPTION =
  "Who is Imam Mahdi in Islam? A clear Twelver (Ja'fari) introduction to his name, lineage, birth in Samarra, the minor and major occultation, and his awaited reappearance.";
const URL = abs("/who-is-imam-mahdi");

export const Route = createFileRoute("/who-is-imam-mahdi")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { name: "keywords", content: "imam mahdi, twelfth imam, awaited mahdi" },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "article" },
      { property: "og:url", content: URL },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(breadcrumbLd([{ label: "Who Is Imam Mahdi?", to: "/who-is-imam-mahdi" }])),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: TITLE,
          description: DESCRIPTION,
          mainEntityOfPage: URL,
          publisher: { "@type": "Organization", name: SITE_NAME, url: abs("/") },
        }),
      },
    ],
  }),
  component: WhoIsImamMahdiPage,
});

const IDENTITY = [
  { k: "Name", v: "Muhammad ibn al-Hasan al-Mahdi (a.t.f.s.)" },
  { k: "Father", v: "Imam Hasan al-Askari (a.s.), the eleventh Imam" },
  { k: "Mother", v: "Lady Narjis (s.a.)" },
  { k: "Birth", v: "15 Sha'ban 255 AH (869 CE), Samarra, Iraq" },
  { k: "Titles", v: "al-Qa'im, al-Hujjah, Sahib al-Zaman, Baqiyyat Allah" },
  { k: "Status", v: "Twelfth and final Imam, alive in occultation (ghaybah)" },
];

const OCCULTATION = [
  {
    n: "I",
    t: "Minor Occultation (260–329 AH)",
    d: "After the martyrdom of his father in 260 AH, the Imam remained hidden from public view while communicating with the community through four successive appointed deputies (al-nuwwab al-arba'ah): Uthman ibn Sa'id al-Amri, Muhammad ibn Uthman, Husayn ibn Ruh al-Nawbakhti, and Ali ibn Muhammad al-Samarri.",
  },
  {
    n: "II",
    t: "The Final Letter (329 AH)",
    d: "Shortly before his death, the fourth deputy received a written instruction stating that no deputy would be appointed after him. With that, the era of direct deputyship closed.",
  },
  {
    n: "III",
    t: "Major Occultation (329 AH – present)",
    d: "The Imam remains alive but concealed. Twelver scholarship holds that during this period the community refers to qualified jurists in matters of religious practice, while awaiting the Imam's reappearance by the permission of Allah.",
  },
];

const SOURCES = [
  { t: "Kitab al-Kafi", a: "Shaykh al-Kulayni (d. 329 AH)" },
  { t: "Kamal al-Din wa Tamam al-Ni'mah", a: "Shaykh al-Saduq (d. 381 AH)" },
  { t: "Kitab al-Ghaybah", a: "Shaykh al-Tusi (d. 460 AH)" },
  { t: "Bihar al-Anwar", a: "Allamah al-Majlisi (d. 1110 AH)" },
];

function WhoIsImamMahdiPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Who Is Imam Mahdi?" }]} jsonLd={false} />

      <article className="pt-8 pb-24 px-6 max-w-3xl mx-auto">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Doctrine</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-6xl leading-[1.05] text-balance">
          Who is <em className="text-gold/85">Imam Mahdi</em>?
        </h1>
        <p className="mt-8 text-lg text-muted-foreground leading-relaxed">
          Imam Muhammad al-Mahdi (may Allah hasten his reappearance) is, in Twelver Shia (Ja'fari)
          belief, the twelfth and final divinely appointed Imam — the son of Imam Hasan al-Askari
          (a.s.), born in Samarra in 255 AH. He is alive today in a state of concealment
          (<span className="italic">ghaybah</span>), and Muslims await his reappearance, by the
          permission of Allah, to establish justice upon the earth.
        </p>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          The expectation of a guided saviour called the Mahdi is shared broadly across Muslim
          traditions on the basis of prophetic narrations. The distinguishing point of the Twelver
          position is identity: the Mahdi is not a figure yet to be born, but a living Imam already
          born, whose lineage, birth, and occultation are recorded in the earliest Imami sources.
        </p>

        <h2 className="mt-16 font-display italic text-3xl">Identity at a glance</h2>
        <dl className="mt-6 grid sm:grid-cols-2 gap-px bg-border ring-1 ring-border">
          {IDENTITY.map((row) => (
            <div key={row.k} className="bg-card p-6">
              <dt className="text-[10px] uppercase tracking-[0.3em] text-emerald">{row.k}</dt>
              <dd className="mt-2 text-sm text-foreground/90 leading-relaxed">{row.v}</dd>
            </div>
          ))}
        </dl>

        <h2 className="mt-16 font-display italic text-3xl">The two occultations</h2>
        <div className="mt-6 space-y-px bg-border ring-1 ring-border">
          {OCCULTATION.map((o) => (
            <section key={o.n} className="bg-card p-7">
              <span className="font-mono-display text-[10px] text-emerald tracking-widest">{o.n}</span>
              <h3 className="mt-3 font-display text-2xl">{o.t}</h3>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{o.d}</p>
            </section>
          ))}
        </div>

        <h2 className="mt-16 font-display italic text-3xl">Why the belief matters</h2>
        <p className="mt-5 text-muted-foreground leading-relaxed">
          Belief in the living Imam is not treated as a passive wait. Classical Imami teaching frames
          the period of occultation as one of preparation: cultivating knowledge, justice, and moral
          discipline so that the community is ready to support the Imam. Practices connected to this
          belief include the recitation of Du'a al-Nudbah, Du'a al-Faraj, and Du'a al-Ahd, and the
          weekly emphasis on Friday as the day associated with his reappearance.
        </p>

        <h2 className="mt-16 font-display italic text-3xl">Primary sources</h2>
        <ul className="mt-6 space-y-3">
          {SOURCES.map((s) => (
            <li key={s.t} className="border-b border-border pb-3">
              <span className="font-display text-lg">{s.t}</span>
              <span className="ml-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">{s.a}</span>
            </li>
          ))}
        </ul>
        <p className="mt-6 text-xs text-muted-foreground leading-relaxed">
          This page is an introductory summary. For rulings and detailed doctrinal questions, refer to
          the primary texts above and to your marja'.
        </p>

        <div className="mt-14 flex flex-col sm:flex-row gap-3">
          <Link
            to="/articles"
            className="px-8 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors text-center"
          >
            Read the Archive
          </Link>
          <Link
            to="/ai"
            className="px-8 py-4 border border-border font-bold uppercase text-xs tracking-[0.3em] hover:bg-emerald-soft transition-colors text-center"
          >
            Ask the Knowledge Engine
          </Link>
        </div>
      </article>

      <SiteFooter />
    </div>
  );
}
