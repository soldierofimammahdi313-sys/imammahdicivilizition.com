import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const Route = createFileRoute("/realms")({
  head: () => ({
    meta: [
      { title: "The Eight Realms — Imam Mahdi Civilization" },
      { name: "description", content: "Knowledge, Video, Library, AI, Daily Devotion, Community, Academy, and the Vanguard." },
      { property: "og:title", content: "The Eight Realms — Imam Mahdi Civilization" },
      { property: "og:description", content: "Knowledge, Video, Library, AI, Daily Devotion, Community, Academy, and the Vanguard." },
      { property: "og:url", content: "https://imammahdicivilizition.com/realms" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/realms" }],
  }),
  component: RealmsPage,
});

const REALMS = [
  { n: "01", a: "علم", t: "Knowledge", to: "/articles", d: "Articles, research, scholar directory, encyclopedia." },
  { n: "02", a: "مرئي", t: "Video", to: "/videos", d: "Cinematic media: featured, trending, live, shorts." },
  { n: "03", a: "قرآن", t: "Quran Reader", to: "/quran", d: "All 114 Surahs — Arabic, translation, recitation." },
  { n: "04", a: "ذكاء", t: "AI Engine", to: "/ai", d: "Voice chat, research mode, summaries, translation." },
  { n: "05", a: "يومي", t: "Daily Devotion", to: "/daily", d: "Verse, hadith, dua, prayer times — every day." },
  { n: "06", a: "حديث", t: "Hadith Library", to: "/hadith", d: "Bukhari, Muslim, Tirmidhi, Abu Dawud, Nasai, Ibn Majah." },
  { n: "07", a: "دعاء", t: "Duas & Adhkar", to: "/duas", d: "Morning, evening, and daily supplications." },
  { n: "08", a: "امام", t: "Vanguard", to: "/join", d: "Enlist in the team building the civilization." },
] as const;

const TOOLS = [
  { t: "99 Names of Allah", to: "/names", d: "Al-Asma al-Husna with meaning." },
  { t: "Qibla Compass", to: "/qibla", d: "Direction of the Kaaba from your location." },
  { t: "Zakat Calculator", to: "/zakat", d: "Compute your zakat at 2.5% above nisab." },
  { t: "Inheritance (Mirath)", to: "/inheritance", d: "Estimate shares per Islamic law." },
  { t: "Digital Tasbih", to: "/tasbih", d: "Counter for dhikr with presets." },
  { t: "Khatam Tracker", to: "/khatam", d: "30 juz Quran completion progress." },
  { t: "Islamic Calendar", to: "/events", d: "Sacred dates throughout the Hijri year." },
  { t: "Mosque Finder", to: "/mosques", d: "Find masajid near you." },
  { t: "Donate (Sadaqah)", to: "/donate", d: "Support the platform." },
] as const;

function RealmsPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "The Eight Realms" }]} />
      <section className="pt-8 pb-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Eight Realms</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">The Map of the Civilization</h1>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border ring-1 ring-border">
          {REALMS.map((r) => (
            <Link key={r.n} to={r.to} className="group bg-card p-8 hover:bg-emerald-soft transition-colors flex flex-col justify-between min-h-[220px]">
              <div className="flex justify-between items-start">
                <span className="font-mono-display text-[10px] text-emerald tracking-widest">{r.n}</span>
                <span className="font-arabic text-2xl text-gold/60">{r.a}</span>
              </div>
              <div>
                <h3 className="font-display text-2xl group-hover:text-gold transition-colors">{r.t}</h3>
                <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{r.d}</p>
              </div>
            </Link>
          ))}
        </div>
        <div className="mt-20 text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Sacred Tools</span>
          <h2 className="mt-4 font-display italic text-4xl">Instruments of Practice</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {TOOLS.map((r) => (
            <Link key={r.to} to={r.to} className="group bg-card p-6 hover:bg-emerald-soft transition-colors">
              <h3 className="font-display text-xl group-hover:text-gold transition-colors">{r.t}</h3>
              <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{r.d}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}