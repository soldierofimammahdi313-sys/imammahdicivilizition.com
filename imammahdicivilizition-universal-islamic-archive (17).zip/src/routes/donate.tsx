import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/donate.jpg";
import { SiteFooter } from "@/components/site/SiteFooter";
import { CONTACT } from "@/lib/social-links";
import { SadaqahTrigger } from "@/components/site/SadaqahModal";

export const Route = createFileRoute("/donate")({
  head: () => ({
    meta: [
      { title: "Sadaqah — Support the Civilization" },
      { name: "description", content: "Support the Imam Mahdi Civilization platform with sadaqah jariyah." },
      { property: "og:title", content: "Sadaqah — Support the Civilization" },
      { property: "og:description", content: "Support the Imam Mahdi Civilization platform with sadaqah jariyah." },
      { property: "og:url", content: "https://imammahdicivilizition.com/donate" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/donate" }],
  }),
  component: DonatePage,
});

const CAUSES = [
  { t: "Da'wah & Content", d: "Fund original articles, videos, and translation work that reaches millions." },
  { t: "Free Library Access", d: "Help us digitize and host Islamic books without paywalls." },
  { t: "AI for Knowledge", d: "Sustain the N-Eyes engine and keep it free for seekers worldwide." },
  { t: "Orphans & Hardship", d: "Channeled to verified relief partners for those in need." },
];

function DonatePage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Donate" }]} />
      <PageBanner src={bannerImg} alt="Sadaqah" eyebrow="Sadaqah Jariyah" title="Give ongoing charity" subtitle="Every contribution keeps this knowledge free for the whole Ummah." />
      <section className="pt-8 pb-20 px-6 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Ṣadaqah Jāriyah</span>
          <h1 className="mt-4 font-display italic text-5xl">Continuing Charity</h1>
          <p className="mt-5 font-arabic text-2xl text-gold/80">إِنَّ الْمُصَّدِّقِينَ وَالْمُصَّدِّقَاتِ … يُضَاعَفُ لَهُمْ</p>
          <p className="mt-2 text-sm text-muted-foreground italic">Indeed those who give charity… it will be multiplied for them. (al-Hadid 57:18)</p>
        </div>

        <div className="grid sm:grid-cols-2 gap-px bg-border ring-1 ring-border mb-10">
          {CAUSES.map(c => (
            <div key={c.t} className="bg-card p-6">
              <h3 className="font-display text-xl text-gold">{c.t}</h3>
              <p className="text-sm text-muted-foreground mt-2">{c.d}</p>
            </div>
          ))}
        </div>

        <div className="border border-gold/40 bg-card p-8 text-center">
          <h2 className="font-display italic text-3xl text-gold">Contribute Directly</h2>
          <p className="mt-3 text-sm text-muted-foreground max-w-lg mx-auto">
            Support the platform through Binance Pay — your sadaqah funds Quran, Hadith, articles, and free Islamic AI for seekers worldwide.
          </p>
          <div className="mt-6 flex flex-col items-center gap-4">
            <SadaqahTrigger label="Donate via Binance Pay" />
            <div className="text-xs text-muted-foreground">
              Prefer to write first? Email:{" "}
              <a href="mailto:imammahdicivilization@gmail.com" className="text-gold hover:underline">imammahdicivilization@gmail.com</a>
            </div>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}