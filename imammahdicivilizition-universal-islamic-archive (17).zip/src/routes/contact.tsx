import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SocialIcons } from "@/components/site/SocialIcons";
import { CONTACT } from "@/lib/social-links";
import { SITE_EMAIL, abs } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Imam Mahdi Civilization" },
      { name: "description", content: "Contact the Imam Mahdi Civilization team by email for questions, corrections, partnerships or content feedback." },
      { property: "og:title", content: "Contact Us — Imam Mahdi Civilization" },
      { property: "og:description", content: "Reach the team by email — questions, corrections and partnerships." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: abs("/contact") },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: abs("/contact") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ContactPage",
          name: "Contact Imam Mahdi Civilization",
          url: abs("/contact"),
          mainEntity: {
            "@type": "Organization",
            name: "Imam Mahdi Civilization",
            email: SITE_EMAIL,
          },
        }),
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = name.trim().slice(0, 100);
    const m = message.trim().slice(0, 1000);
    if (!n || !m) {
      toast.error("Please add your name and a message.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      toast.error("Please enter a valid email address.");
      return;
    }
    const subject = encodeURIComponent(`Website enquiry from ${n}`);
    const body = encodeURIComponent(`${m}\n\n— ${n} (${email.trim()})`);
    window.location.href = `mailto:${SITE_EMAIL}?subject=${subject}&body=${body}`;
    toast.success("Opening your email app…");
  }

  return (
    <div className="bg-background text-foreground min-h-dvh">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Contact" }]} />
      <main className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Get in touch</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-5xl">Contact Us</h1>
        <p className="mt-6 text-muted-foreground leading-relaxed max-w-2xl">
          Questions about the platform, corrections to a page, partnership requests or feedback on our
          content — we read every message. Corrections to religious content are especially welcome and
          are reviewed before publishing.
        </p>

        <div className="mt-12 grid gap-px bg-border ring-1 ring-border sm:grid-cols-2">
          <div className="bg-card p-6">
            <h2 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Email</h2>
            <a href={`mailto:${SITE_EMAIL}`} className="mt-3 block text-sm break-all hover:text-gold">{SITE_EMAIL}</a>
          </div>
          <div className="bg-card p-6">
            <h2 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Managed by</h2>
            <p className="mt-3 text-sm">{CONTACT.admin}</p>
          </div>
        </div>

        <div className="mt-10">
          <h2 className="text-[10px] uppercase tracking-[0.3em] text-gold font-bold">Social channels</h2>
          <SocialIcons className="mt-4" iconClass="size-5" />
        </div>

        <form onSubmit={submit} className="mt-14 max-w-xl space-y-5">
          <h2 className="font-display italic text-2xl">Send a message</h2>
          <div>
            <label htmlFor="c-name" className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Your name</label>
            <input id="c-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} required
              className="mt-2 w-full bg-card border border-border px-4 py-3 text-sm outline-none focus:border-gold" />
          </div>
          <div>
            <label htmlFor="c-email" className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Email</label>
            <input id="c-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} required
              className="mt-2 w-full bg-card border border-border px-4 py-3 text-sm outline-none focus:border-gold" />
          </div>
          <div>
            <label htmlFor="c-msg" className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Message</label>
            <textarea id="c-msg" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={1000} rows={6} required
              className="mt-2 w-full bg-card border border-border px-4 py-3 text-sm outline-none focus:border-gold" />
          </div>
          <button type="submit"
            className="bg-gold text-primary-foreground px-8 py-3 text-[11px] uppercase tracking-[0.3em] font-bold hover:opacity-90 transition-opacity">
            Send message
          </button>
          <p className="text-xs text-muted-foreground">
            This form opens your own email app with the message pre-filled — nothing is stored on our servers.
          </p>
        </form>
      </main>
      <SiteFooter />
    </div>
  );
}