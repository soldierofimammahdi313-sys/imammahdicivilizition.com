import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/media")({
  head: () => ({
    meta: [
      { title: "Media Center — Podcasts, Audiobooks, Noha & Nasheed | Imam Mahdi Civilization" },
      { name: "description", content: "Curated Islamic audio and video: podcast programmes, narrated audiobooks, documentaries, lecture archives, elegies of Karbala and devotional nasheed." },
      { property: "og:title", content: "Media Center" },
      { property: "og:description", content: "Podcasts, audiobooks, documentaries, lectures, noha and nasheed — one curated shelf." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/media" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/media" }],
  }),
  component: MediaPage,
});

type Tab = "podcast" | "audiobook" | "documentary" | "lecture" | "noha" | "nasheed";
type Item = { t: string; by: string; d: string; len: string; url: string };

const TABS: { k: Tab; label: string; arabic: string; blurb: string }[] = [
  { k: "podcast", label: "Podcasts", arabic: "بودكاست", blurb: "Serialized audio programmes on belief, history and daily practice." },
  { k: "audiobook", label: "Audiobooks", arabic: "كتب صوتية", blurb: "Classics of the tradition, narrated end to end." },
  { k: "documentary", label: "Documentaries", arabic: "وثائقي", blurb: "Long-form visual history of the Ummah." },
  { k: "lecture", label: "Lectures", arabic: "محاضرات", blurb: "Scholarly talks and majalis, searchable by theme." },
  { k: "noha", label: "Noha & Latmiyat", arabic: "نوحة", blurb: "Elegies for the martyrs of Karbala." },
  { k: "nasheed", label: "Nasheed", arabic: "نشيد", blurb: "Devotional song in praise of the Prophet and his household." },
];

const LIBRARY: Record<Tab, Item[]> = {
  podcast: [
    { t: "Nahj al-Balagha Weekly", by: "Imam Mahdi Civilization Studio", d: "One sermon of Imam Ali unpacked line by line.", len: "Weekly · 30 min", url: "https://youtube.com/@imammahdicivilization" },
    { t: "The Occultation Files", by: "Imam Mahdi Civilization Studio", d: "What the tradition says about waiting, preparation and the Ghaybah.", len: "12 episodes", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Fiqh in Practice", by: "Imam Mahdi Civilization Studio", d: "Everyday rulings in Ja'fari jurisprudence, explained simply.", len: "Ongoing", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Reverts' Road", by: "Imam Mahdi Civilization Studio", d: "Conversations with new Muslims across four continents.", len: "20 episodes", url: "https://youtube.com/@imammahdicivilization" },
  ],
  audiobook: [
    { t: "Nahj al-Balagha", by: "Imam Ali ibn Abi Talib", d: "Sermons, letters and aphorisms of Amir al-Mu'minin.", len: "24 h", url: "https://www.al-islam.org/nahjul-balagha-part-1-sermons" },
    { t: "Al-Sahifa al-Sajjadiyya", by: "Imam Zayn al-Abidin", d: "The Psalms of the Household — 54 supplications.", len: "9 h", url: "https://www.al-islam.org/sahifa-al-sajjadiyya" },
    { t: "Peshawar Nights", by: "Sultanu'l-Wa'izin Shirazi", d: "Ten nights of recorded dialogue between schools.", len: "18 h", url: "https://www.al-islam.org/peshawar-nights" },
    { t: "The Message", by: "Ja'far Subhani", d: "A full biography of the Prophet ﷺ.", len: "26 h", url: "https://www.al-islam.org/message-ayatullah-jafar-subhani" },
  ],
  documentary: [
    { t: "Karbala: The Untold Ground", by: "Imam Mahdi Civilization Studio", d: "The plain, the blockade and the ten days of Muharram 61 AH.", len: "72 min", url: "https://youtube.com/@imammahdicivilization" },
    { t: "The Hawza of Najaf", by: "Imam Mahdi Civilization Studio", d: "A thousand years of continuous teaching.", len: "48 min", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Cities of Light", by: "Archive", d: "Islamic Spain and the transmission of science to Europe.", len: "115 min", url: "https://youtube.com/@imammahdicivilization" },
    { t: "The Twelve", by: "Imam Mahdi Civilization Studio", d: "One episode for each Imam.", len: "12 × 25 min", url: "https://youtube.com/@imammahdicivilization" },
  ],
  lecture: [
    { t: "Tafsir al-Mizan Series", by: "Hawza teachers", d: "Verse-by-verse study following Allama Tabatabai.", len: "Ongoing", url: "https://almizan.org" },
    { t: "Muharram Majalis", by: "Various speakers", d: "Ten nights, recorded annually.", len: "10 × 60 min", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Aqaid Foundations", by: "Imam Mahdi Civilization Academy", d: "Tawhid, Adl, Nubuwwa, Imama, Ma'ad.", len: "5 modules", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Youth & Modernity", by: "Imam Mahdi Civilization Academy", d: "Faith, technology and identity for the next generation.", len: "8 talks", url: "https://youtube.com/@imammahdicivilization" },
  ],
  noha: [
    { t: "Labbayk Ya Husayn", by: "Various reciters", d: "The call answered every Muharram.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Ya Abbas — The Water Bearer", by: "Various reciters", d: "Elegy for the standard-bearer of Karbala.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Zaynab's Lament", by: "Various reciters", d: "The voice that carried Karbala into the courts of tyranny.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Arbaeen Walk", by: "Various reciters", d: "Recitations of the twenty-million-strong march.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
  ],
  nasheed: [
    { t: "Salawat Compilation", by: "Various", d: "Blessings upon Muhammad and the family of Muhammad.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Dua al-Faraj", by: "Various", d: "The daily supplication for the hastening of the relief.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Madad Ya Mahdi", by: "Various", d: "Anthems of the awaited one.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
    { t: "Ramadan Nights", by: "Various", d: "Munajat for the nights of the holy month.", len: "Collection", url: "https://youtube.com/@imammahdicivilization" },
  ],
};

function MediaPage() {
  const [tab, setTab] = useState<Tab>("podcast");
  const meta = TABS.find((t) => t.k === tab)!;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Media Center" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-6xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Media Center</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Sound & Cinema of the Ummah</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            Six shelves of curated listening and watching — from serialized podcasts to the elegies of Karbala.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {TABS.map((t) => (
            <button
              key={t.k}
              onClick={() => setTab(t.k)}
              aria-pressed={tab === t.k}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                tab === t.k ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
              }`}
            >
              {t.label} <span className="font-arabic text-sm ms-1 opacity-60">{t.arabic}</span>
            </button>
          ))}
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">{meta.blurb}</p>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border ring-1 ring-border">
          {LIBRARY[tab].map((item) => (
            <a
              key={item.t}
              href={item.url}
              target="_blank"
              rel="noreferrer"
              className="group bg-card p-6 min-h-[190px] flex flex-col hover:bg-emerald-soft transition-colors"
            >
              <span className="text-[9px] uppercase tracking-[0.3em] text-gold">{item.len}</span>
              <h2 className="mt-3 font-display text-xl leading-tight group-hover:text-gold transition-colors">{item.t}</h2>
              <p className="mt-1 text-[10px] uppercase tracking-[0.22em] text-emerald">{item.by}</p>
              <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{item.d}</p>
              <span className="mt-auto pt-4 text-[10px] uppercase tracking-[0.3em] text-gold">Listen ▸</span>
            </a>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}