import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/family-tree")({
  head: () => ({
    meta: [
      { title: "The Blessed Lineage — Prophet & Twelve Imams" },
      { name: "description", content: "The family tree of the Messenger of Allah ﷺ and the Fourteen Infallibles: titles, mothers, birthplaces, years of imamate and resting places." },
      { property: "og:title", content: "The Blessed Lineage" },
      { property: "og:description", content: "Prophet Muhammad ﷺ, Fatima al-Zahra and the Twelve Imams — one interactive lineage." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/family-tree" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/family-tree" }],
  }),
  component: FamilyTreePage,
});

type Figure = {
  n: number | null;
  name: string;
  arabic: string;
  title: string;
  born: string;
  father: string;
  mother: string;
  imamate: string;
  shrine: string;
  note: string;
};

const FIGURES: Figure[] = [
  { n: null, name: "Muhammad al-Mustafa ﷺ", arabic: "محمد المصطفى", title: "The Messenger of Allah", born: "570 CE, Makkah", father: "Abdullah ibn Abd al-Muttalib", mother: "Amina bint Wahb", imamate: "Prophethood 610–632 CE", shrine: "Masjid al-Nabawi, Madinah", note: "The Seal of the Prophets; left behind the Qur'an and his Ahl al-Bayt as the two weighty things." },
  { n: null, name: "Fatima al-Zahra", arabic: "فاطمة الزهراء", title: "Sayyidat Nisa al-Alamin", born: "615 CE, Makkah", father: "The Messenger ﷺ", mother: "Khadija al-Kubra", imamate: "—", shrine: "Madinah (concealed)", note: "The Radiant; mother of the Imams and the measure by which the household is known." },
  { n: 1, name: "Ali ibn Abi Talib", arabic: "علي المرتضى", title: "Amir al-Mu'minin", born: "600 CE, inside the Kaaba", father: "Abu Talib", mother: "Fatima bint Asad", imamate: "632–661 CE", shrine: "Najaf, Iraq", note: "The Gate of the City of Knowledge; author of the sermons of Nahj al-Balagha." },
  { n: 2, name: "Hasan al-Mujtaba", arabic: "الحسن المجتبى", title: "The Chosen", born: "625 CE, Madinah", father: "Imam Ali", mother: "Fatima al-Zahra", imamate: "661–670 CE", shrine: "Jannat al-Baqi, Madinah", note: "Made the treaty that preserved the community and exposed Mu'awiya's rule." },
  { n: 3, name: "Husayn Sayyid al-Shuhada", arabic: "الحسين سيد الشهداء", title: "Master of Martyrs", born: "626 CE, Madinah", father: "Imam Ali", mother: "Fatima al-Zahra", imamate: "670–680 CE", shrine: "Karbala, Iraq", note: "Martyred on Ashura with 72 companions rather than pledge to tyranny." },
  { n: 4, name: "Ali Zayn al-Abidin", arabic: "زين العابدين", title: "Ornament of the Worshippers", born: "659 CE, Madinah", father: "Imam Husayn", mother: "Shahrbanu", imamate: "680–713 CE", shrine: "Jannat al-Baqi, Madinah", note: "Author of al-Sahifa al-Sajjadiyya, the Psalms of the Household." },
  { n: 5, name: "Muhammad al-Baqir", arabic: "محمد الباقر", title: "Splitter of Knowledge", born: "677 CE, Madinah", father: "Imam Sajjad", mother: "Fatima bint Hasan", imamate: "713–733 CE", shrine: "Jannat al-Baqi, Madinah", note: "Opened the systematic teaching of the sciences of the Ahl al-Bayt." },
  { n: 6, name: "Ja'far al-Sadiq", arabic: "جعفر الصادق", title: "The Truthful", born: "702 CE, Madinah", father: "Imam al-Baqir", mother: "Umm Farwa", imamate: "733–765 CE", shrine: "Jannat al-Baqi, Madinah", note: "Four thousand students; the Ja'fari school of jurisprudence bears his name." },
  { n: 7, name: "Musa al-Kadhim", arabic: "موسى الكاظم", title: "The Forbearing", born: "745 CE, Abwa", father: "Imam al-Sadiq", mother: "Hamida", imamate: "765–799 CE", shrine: "Kadhimayn, Baghdad", note: "Years in the prisons of the Abbasids; taught through letters and deputies." },
  { n: 8, name: "Ali al-Rida", arabic: "علي الرضا", title: "The Pleasing One", born: "765 CE, Madinah", father: "Imam al-Kadhim", mother: "Najma", imamate: "799–818 CE", shrine: "Mashhad, Iran", note: "Forced into heir apparency by al-Ma'mun; debated scholars of every religion." },
  { n: 9, name: "Muhammad al-Jawad", arabic: "محمد الجواد", title: "The Generous", born: "811 CE, Madinah", father: "Imam al-Rida", mother: "Sabika", imamate: "818–835 CE", shrine: "Kadhimayn, Baghdad", note: "Became Imam as a child and silenced the jurists of Baghdad in open debate." },
  { n: 10, name: "Ali al-Hadi", arabic: "علي الهادي", title: "The Guide", born: "828 CE, Madinah", father: "Imam al-Jawad", mother: "Samana", imamate: "835–868 CE", shrine: "Samarra, Iraq", note: "Author of Ziyarat al-Jamia al-Kabira; kept under surveillance in the garrison city." },
  { n: 11, name: "Hasan al-Askari", arabic: "الحسن العسكري", title: "Of the Garrison", born: "846 CE, Madinah", father: "Imam al-Hadi", mother: "Hudayth", imamate: "868–874 CE", shrine: "Samarra, Iraq", note: "Prepared the community for the occultation of his son." },
  { n: 12, name: "Muhammad al-Mahdi", arabic: "محمد المهدي", title: "Sahib al-Zaman — may Allah hasten his relief", born: "869 CE, Samarra", father: "Imam al-Askari", mother: "Narjis", imamate: "874 CE — present", shrine: "Living, in occultation", note: "The awaited one who will fill the earth with justice as it was filled with oppression." },
];

function FamilyTreePage() {
  const [sel, setSel] = useState<Figure | null>(null);

  return (
    <div className="bg-background text-foreground min-h-screen overflow-x-hidden">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Family Tree" }]} />
      <section className="pt-8 pb-16 px-4 md:px-6 max-w-6xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Knowledge / Lineage</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">The Blessed Lineage</h1>
          <span className="mt-4 font-arabic text-2xl text-gold/60 block">الأئمة الأربعة عشر المعصومون</span>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            The Fourteen Infallibles — tap any name for lineage, imamate and resting place.
          </p>
        </div>

        <div className="mt-14 space-y-3">
          {FIGURES.map((f, i) => (
            <button
              key={f.name}
              onClick={() => setSel(f)}
              className="group w-full text-start relative bg-card border border-border hover:border-gold p-5 flex items-center gap-5 transition-colors"
              style={{ marginInlineStart: `${Math.min(i, 6) * 10}px` }}
            >
              <span className="size-11 shrink-0 rounded-full ring-1 ring-gold/40 flex items-center justify-center font-mono-display text-sm text-gold">
                {f.n === null ? "✦" : f.n}
              </span>
              <span className="flex-1 min-w-0">
                <span className="block font-display text-xl truncate group-hover:text-gold transition-colors">{f.name}</span>
                <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground truncate">{f.title} · {f.shrine}</span>
              </span>
              <span className="font-arabic text-2xl text-gold/50 shrink-0">{f.arabic}</span>
            </button>
          ))}
        </div>
      </section>

      {sel && (
        <div
          className="fixed inset-0 z-[80] bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setSel(null)}
        >
          <div className="bg-card border border-gold/40 max-w-lg w-full p-8" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display italic text-3xl">{sel.name}</h2>
                <p className="mt-1 text-[10px] uppercase tracking-[0.3em] text-gold">{sel.title}</p>
              </div>
              <span className="font-arabic text-3xl text-gold/60">{sel.arabic}</span>
            </div>
            <dl className="mt-6 space-y-3 text-sm">
              {[
                ["Born", sel.born],
                ["Father", sel.father],
                ["Mother", sel.mother],
                ["Imamate", sel.imamate],
                ["Resting place", sel.shrine],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-4 border-b border-border pb-2">
                  <dt className="w-32 shrink-0 text-[10px] uppercase tracking-[0.25em] text-muted-foreground pt-1">{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-5 text-sm text-muted-foreground leading-relaxed">{sel.note}</p>
            <button
              onClick={() => setSel(null)}
              className="mt-7 w-full py-3 border border-gold text-gold text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-gold-soft/30 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
      <SiteFooter />
    </div>
  );
}