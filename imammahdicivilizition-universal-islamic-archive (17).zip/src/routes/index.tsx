import { createFileRoute, Link } from "@tanstack/react-router";
import { Youtube, Facebook, MapPin, ShieldCheck, Quote } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import pillarImg from "@/assets/pillar-knowledge.jpg";
import pillarAiImg from "@/assets/pillar-ai.jpg";
import pillarDailyImg from "@/assets/pillar-daily.jpg";
import adminPortrait from "@/assets/admin-founder-portrait.webp";
import { SiteHeader } from "@/components/site/SiteHeader";
import { NavHub } from "@/components/site/NavHub";
import { ObservatoryHero } from "@/components/site/ObservatoryHero";
import { PrayerTimes } from "@/components/site/PrayerTimes";
import { FeaturedContent } from "@/components/site/FeaturedContent";
import { Testimonials } from "@/components/site/Testimonials";
import { SOCIAL_LINKS } from "@/lib/social-links";
import { maybeRunDailyAutopilot } from "@/lib/autopilot-trigger.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Quran, Hadith & Islamic AI — Imam Mahdi Civilization" },
      { name: "description", content: "A global digital civilization uniting knowledge, media, AI, and community in service of truth." },
      { property: "og:title", content: "Imam Mahdi Civilization — Quran, Hadith & Islamic AI Platform" },
      { property: "og:description", content: "The world's first Islamic digital civilization." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Imam Mahdi Civilization",
          url: "https://imammahdicivilizition.com/",
          inLanguage: ["en", "ar", "ur", "fa", "tr", "fr", "de"],
          potentialAction: {
            "@type": "SearchAction",
            target: "https://imammahdicivilizition.com/articles?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }),
      },
    ],
  }),
  component: Index,
});

const FAQS = [
  {
    q: "Is Imam Mahdi Civilization free to use?",
    a: "Yes. The Quran reader, hadith collections, duas, tafsir, prayer times, Qibla, Tasbih, calculators and the AI assistant are all free. The platform is sustained by voluntary sadaqah and volunteers.",
  },
  {
    q: "Which school of jurisprudence does the AI assistant follow?",
    a: "The N-EYES AI assistant answers according to Fiqh Jaʿfariyya (Ithnā ʿAsharī), and cites the Quran, authentic narrations of the Ahl al-Bayt (a.s), and recognised scholarly works wherever possible.",
  },
  {
    q: "Which languages does the platform support?",
    a: "Seven: English, Urdu, Farsi, Arabic, Turkish, French and German — switchable instantly from the header.",
  },
  {
    q: "How can I contribute to the civilization?",
    a: "Writers, researchers, designers, video editors, translators, developers, moderators and volunteers can apply through the Join Imam Mahdi Civilization page. Financial support is possible through the Donate page.",
  },
];

const PILLARS = [
  { n: "01", t: "Knowledge Center", d: "Articles, research papers, scholar directory & Islamic encyclopedia.", to: "/articles" },
  { n: "02", t: "Video Center", d: "Netflix-style media: featured, trending, playlists, shorts, live streams.", to: "/media" },
  { n: "03", t: "Digital Library", d: "Thousands of books with PDF reader, audio, highlights & collections.", to: "/library" },
  { n: "04", t: "AI Knowledge Engine", d: "Voice chat, research mode, summaries & translation.", to: "/ai" },
  { n: "05", t: "AI Fatwa Finder", d: "Live Ja'fari rulings by marja' and topic, with sources.", to: "/ai-tools/fatwa" },
  { n: "06", t: "AI Timeline & Debate", d: "Ask any year of Islamic history — or dissect any argument.", to: "/ai-tools/timeline" },
  { n: "07", t: "AI Academy & Voice Teacher", d: "Ustad Mahdi AI teaches youth; tajwid coaching for every verse.", to: "/academy-ai" },
  { n: "08", t: "Global Community", d: "Forums, study circles, events & a worldwide network of believers.", to: "/community" },
];

const SOCIALS = [
  { icon: Youtube, label: "YouTube", href: "https://youtube.com/@imammahdicivilization" },
  { icon: Facebook, label: "Facebook", href: "https://www.facebook.com/share/1PWhUxSdSm/" },
];


const STATS = [
  { v: "114", l: "Surahs · full reader" },
  { v: "6", l: "Hadith collections" },
  { v: "99", l: "Names of Allah" },
  { v: "24+", l: "Modules & tools" },
];

const HIGHLIGHTS = [
  { to: "/quran", k: "Quran", ar: "القرآن", d: "Arabic, translations, tafsir panel and Alafasy recitation for all 114 surahs." },
  { to: "/hadith", k: "Hadith", ar: "الحدیث", d: "Six major collections, searchable, with references you can verify." },
  { to: "/ai", k: "N-EYES AI", ar: "ن-آيز", d: "Ask anything — answered according to Fiqh Jaʿfariyya, with sources." },
  { to: "/articles", k: "Articles", ar: "المقالات", d: "Research, reflections and essays from the writers of Imam Mahdi Civilization." },
  { to: "/community", k: "Community", ar: "المجتمع", d: "Study circles, events and a global network of believers." },
  { to: "/donate", k: "Sadaqah", ar: "الصدقة", d: "Support the civilization — every contribution builds the platform." },
];

function ScrollReveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "0px 0px -8% 0px" },
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`${className} transition-all duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)] ${
        visible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
      }`}
    >
      {children}
    </div>
  );
}

function Index() {
  useEffect(() => {
    const storageKey = "last_autopilot_run";
    const interval = 24 * 60 * 60 * 1000;
    let lastRun = 0;

    try {
      lastRun = Number(localStorage.getItem(storageKey) ?? 0);
    } catch {
      return;
    }

    if (Date.now() - lastRun < interval) return;

    const run = async () => {
      try {
        await maybeRunDailyAutopilot({});

      } finally {
        try {
          localStorage.setItem(storageKey, String(Date.now()));
        } catch {
          // Storage can be unavailable in privacy-restricted browsers.
        }
      }
    };

    const timeout = window.setTimeout(() => void run(), 0);
    return () => window.clearTimeout(timeout);
  }, []);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <a
        href="#mission"
        className="sr-only focus:not-sr-only focus:fixed focus:top-24 focus:left-4 focus:z-[60] focus:bg-gold focus:text-primary-foreground focus:px-4 focus:py-2 focus:text-xs focus:font-bold focus:uppercase focus:tracking-widest"
      >
        Skip to content
      </a>
      <main>

      {/* HERO — digital observatory */}
      <ObservatoryHero />


      {/* COMMAND CENTER — all gateways */}
      <NavHub />

      {/* STATISTICS */}
      <section aria-label="Platform statistics" className="border-y border-border bg-card/30">
        <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          {STATS.map((s) => (
            <div key={s.l} className="text-center">
              <div className="font-display text-4xl md:text-5xl text-gold">{s.v}</div>
              <p className="mt-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground leading-snug">{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* LIVE PRAYER TIMES */}
      <PrayerTimes />

      {/* HIGHLIGHTS */}
      <section aria-labelledby="highlights-title" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em] block mb-4">Explore</span>
          <h2 id="highlights-title" className="font-display italic text-4xl md:text-5xl">Where to begin</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {HIGHLIGHTS.map((h) => (
            <Link
              key={h.to}
              to={h.to}
              className="group relative overflow-hidden bg-card/60 ring-1 ring-border p-7 min-h-[172px] flex flex-col rounded-lg backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:ring-gold/50 hover:shadow-[0_20px_50px_-25px_hsl(var(--gold)/0.5)]"
            >
              <div className="flex items-baseline justify-between">
                <h3 className="text-sm font-bold uppercase tracking-[0.18em] group-hover:text-gold transition-colors">{h.k}</h3>
                <span className="font-arabic text-xl text-gold/50">{h.ar}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{h.d}</p>
              <span aria-hidden className="mt-auto pt-4 text-[11px] font-mono-display text-muted-foreground group-hover:text-gold transition-colors">Enter ↗</span>
            </Link>
          ))}
        </div>
      </section>

      <FeaturedContent />

      {/* MISSION */}
      <section id="mission" className="py-24 px-6 border-y border-border">
        <div className="max-w-6xl mx-auto grid md:grid-cols-12 gap-12 items-start">
          <div className="md:col-span-4">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">The Mission</span>
          </div>
          <div className="md:col-span-8">
            <h2 className="font-display text-3xl md:text-5xl leading-tight text-balance">
              We are not building a website.<br />
              <em className="text-gold/80">We are building a civilization.</em>
            </h2>
            <p className="mt-8 text-muted-foreground text-lg leading-relaxed max-w-[60ch]">
              The Imam Mahdi Civilization unite knowledge, education, media, research,
              technology, spirituality, and community into a single living ecosystem — a digital
              sanctuary where every interaction is meaningful, premium, and built to serve the
              Ummah for years to come.
            </p>
          </div>
        </div>
      </section>

      {/* PILLARS BENTO */}
      <section id="pillars" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em] mb-4 block">Eight Realms</span>
          <h2 className="font-display text-4xl md:text-5xl">The Pillars of the Civilization</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:auto-rows-[280px]">
          {/* Featured: Knowledge */}
          <div className="md:col-span-8 md:row-span-2 group relative overflow-hidden rounded-2xl ring-1 ring-border bg-card min-h-[320px] md:min-h-0">
            <img src={pillarImg} alt="Digital Islamic library with shelves of manuscripts and Quranic texts in the Knowledge Center" loading="lazy" width={1280} height={800} className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:scale-105 group-hover:opacity-55 transition-all duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <p className="text-emerald text-[10px] font-bold tracking-[0.3em] uppercase mb-2">01 / Core</p>
              <h3 className="font-display text-3xl md:text-4xl mb-3">Knowledge Center</h3>
              <p className="text-muted-foreground max-w-md">Articles, research, scholar directory, courses, and a living Islamic encyclopedia — the intellectual heart of Imam Mahdi Civilization.</p>
            </div>
          </div>

          {/* AI */}
          <Link to="/ai" className="md:col-span-4 group relative overflow-hidden rounded-2xl bg-emerald-soft ring-1 ring-emerald/20 hover:ring-gold/40 flex flex-col justify-between p-8 transition min-h-[240px] md:min-h-0">
            <img src={pillarAiImg} alt="Glowing emerald dome of light formed by a neural network above an open Quran — the AI Knowledge Engine" loading="lazy" width={1024} height={1024} className="absolute inset-0 w-full h-full object-cover opacity-35 group-hover:scale-105 group-hover:opacity-50 transition-all duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
            <span className="relative font-mono-display text-[10px] text-gold">// N-EYES · LIVE</span>
            <div className="relative">
              <h3 className="text-xl font-bold uppercase tracking-tight">AI Assistant</h3>
              <p className="text-sm text-muted-foreground mt-2">Voice chat, research, fatwa finder, debate analysis, summaries & translation.</p>
            </div>
          </Link>

          {/* Daily */}
          <Link to="/daily" className="md:col-span-4 group relative overflow-hidden rounded-2xl bg-gold-soft ring-1 ring-gold/20 hover:ring-gold/40 flex flex-col justify-between p-8 transition min-h-[240px] md:min-h-0">
            <img src={pillarDailyImg} alt="Golden crescent, prayer beads and a lit lantern beside an open book — daily devotion" loading="lazy" width={1024} height={1024} className="absolute inset-0 w-full h-full object-cover opacity-35 group-hover:scale-105 group-hover:opacity-50 transition-all duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
            <span className="relative font-arabic text-3xl text-gold/80">يومي</span>
            <div className="relative">
              <h3 className="text-xl font-bold uppercase tracking-tight">Daily Devotion</h3>
              <p className="text-sm text-muted-foreground mt-2">Quran · Hadith · Dua · Prayer Times · Live Islamic events on the ticker</p>
            </div>
          </Link>

          {PILLARS.slice(4).map((p) => (
            <Link key={p.n} to={p.to} className="md:col-span-3 bg-card ring-1 ring-border p-7 flex flex-col justify-between hover:ring-gold/40 hover:-translate-y-1 transition-all duration-300 group">
              <span className="font-mono-display text-[10px] text-emerald">{p.n}</span>
              <div>
                <h3 className="text-base font-bold uppercase tracking-tight group-hover:text-gold transition-colors">{p.t}</h3>
                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{p.d}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* DAILY TRIO */}
      <section id="daily" className="py-24 px-6 bg-card/40 border-y border-border">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-px bg-border ring-1 ring-border">
          <div className="bg-background p-10 space-y-4">
            <span className="font-mono-display text-[10px] text-emerald tracking-widest">DAILY_QURAN</span>
            <p className="font-arabic text-2xl leading-relaxed text-gold/85 text-right">
              وَنُرِيدُ أَن نَّمُنَّ عَلَى الَّذِينَ اسْتُضْعِفُوا فِي الْأَرْضِ
            </p>
            <p className="text-sm text-muted-foreground">"And We willed to confer favor upon those who were oppressed in the land…"</p>
            <p className="text-[10px] text-muted-foreground/70 uppercase tracking-widest">Surah Al-Qasas · 28:5</p>
          </div>
          <div className="bg-background p-10 space-y-4">
            <span className="font-mono-display text-[10px] text-emerald tracking-widest">DAILY_HADITH</span>
            <p className="font-display italic text-xl leading-relaxed">"The best among you is the one who is most beneficial to others."</p>
            <p className="text-[10px] text-muted-foreground/70 uppercase tracking-widest">Prophetic Narration ﷺ</p>
          </div>
          <div className="bg-background p-10 space-y-4">
            <span className="font-mono-display text-[10px] text-emerald tracking-widest">DAILY_DUA</span>
            <p className="text-base leading-relaxed">Allāhumma kun li-waliyyika-l-Ḥujjati-bni-l-Ḥasan… ṣalawātuka ʿalayhi wa ʿalā ābāʾih.</p>
            <p className="text-[10px] text-muted-foreground/70 uppercase tracking-widest">Duʿāʾ al-Faraj</p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section aria-labelledby="faq-title" className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em] block mb-4">Questions</span>
            <h2 id="faq-title" className="font-display italic text-3xl md:text-5xl">Before you enter</h2>
          </div>
          <div className="space-y-3">
            {FAQS.map((f) => (
              <details key={f.q} className="surface-card group rounded-lg px-6 py-5 open:border-gold/40">
                <summary className="cursor-pointer list-none flex items-center justify-between gap-4 text-sm md:text-base font-semibold text-foreground marker:hidden">
                  <span>{f.q}</span>
                  <span aria-hidden className="text-gold transition-transform group-open:rotate-45 text-lg leading-none">+</span>
                </summary>
                <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* SADAQAH / DONATION */}
      <section aria-labelledby="donate-title" className="py-24 px-6 border-y border-border bg-card/25">
        <div className="max-w-6xl mx-auto grid md:grid-cols-12 gap-10 items-center">
          <div className="md:col-span-7">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Sadaqah Jariyah</span>
            <h2 id="donate-title" className="mt-5 font-display italic text-3xl md:text-5xl leading-tight text-balance">
              Every line of code is <span className="text-gradient-gold not-italic font-sans font-extrabold">an act of worship</span>
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed max-w-[58ch]">
              This platform is free for the whole Ummah — no paywalls on the Quran, hadith, duas or
              tools. Servers, AI inference, translation and research are carried by the believers who
              support it. Contribute once, and every recitation read here continues for you.
            </p>
            <div className="mt-9 flex flex-col sm:flex-row gap-3">
              <Link to="/donate" className="px-8 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.2em] hover:bg-foreground transition-colors text-center">
                Give Sadaqah
              </Link>
              <Link to="/join" className="px-8 py-4 border border-border text-foreground font-bold uppercase text-xs tracking-[0.2em] hover:bg-emerald-soft transition-colors text-center">
                Give Your Skills Instead
              </Link>
            </div>
          </div>
          <div className="md:col-span-5 grid grid-cols-1 gap-3">
            {[
              { t: "Servers & bandwidth", d: "Keeping the Quran, hadith and library reachable worldwide, 24/7." },
              { t: "AI knowledge engine", d: "Every N-EYES answer costs inference — your support keeps it open." },
              { t: "Translation & research", d: "Seven languages, verified references, real scholarship." },
            ].map((c) => (
              <div key={c.t} className="surface-card hover-lift rounded-lg p-6">
                <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-gold">{c.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{c.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OFFICIAL ADMIN PROFILE */}
      <section aria-labelledby="admin-profile-title" className="relative overflow-hidden border-y border-gold/15 bg-card/25 px-5 py-24 sm:px-6 sm:py-32">
        <div aria-hidden className="pointer-events-none absolute inset-0 admin-profile-grid opacity-30" />
        <div className="relative mx-auto max-w-7xl">
          <ScrollReveal className="mb-12 text-center md:mb-16">
            <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-gold">Official Leadership Profile</span>
            <h2 id="admin-profile-title" className="mt-4 font-display text-4xl italic sm:text-5xl md:text-6xl">
              ABOUT THE ADMIN
            </h2>
            <p className="mt-4 text-sm font-medium text-muted-foreground sm:text-base">
              The Vision Behind Imam Mahdi Civilization
            </p>
          </ScrollReveal>

          <ScrollReveal className="grid items-stretch overflow-hidden border border-gold/25 bg-background/75 shadow-luxe backdrop-blur-xl lg:grid-cols-[minmax(320px,0.82fr)_minmax(0,1.18fr)]">
            <figure className="group relative min-h-[480px] overflow-hidden sm:min-h-[620px] lg:min-h-full">
              <img
                src={adminPortrait}
                alt="Syed Ahmad Raza Shamsi, Founder and Administrator of Imam Mahdi Civilization"
                width={928}
                height={1152}
                loading="lazy"
                decoding="async"
                className="absolute inset-0 h-full w-full object-cover object-top transition-transform duration-1000 ease-out group-hover:scale-[1.025]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/5 to-transparent" />
              <figcaption className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                <div className="flex items-end justify-between gap-4 border-t border-gold/25 pt-5">
                  <div>
                    <p className="font-display text-2xl text-foreground">Syed Ahmad Raza Shamsi</p>
                    <p className="mt-1 text-xs font-bold uppercase tracking-[0.22em] text-gold">Founder &amp; Administrator</p>
                  </div>
                  <ShieldCheck aria-label="Official platform founder" className="size-6 shrink-0 text-gold" />
                </div>
              </figcaption>
            </figure>

            <article className="relative flex flex-col justify-center p-7 sm:p-10 lg:p-14 xl:p-16">
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-2 border border-gold/35 bg-gold-soft px-3 py-2 text-[10px] font-bold uppercase tracking-[0.24em] text-gold">
                  <ShieldCheck aria-hidden className="size-4" /> Founder Verified
                </span>
                <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Official platform profile</span>
              </div>

              <h3 className="mt-7 font-display text-3xl sm:text-4xl">Syed Ahmad Raza Shamsi</h3>
              <p className="mt-2 text-sm font-semibold uppercase tracking-[0.18em] text-gold">
                Founder &amp; Administrator · Imam Mahdi Civilization
              </p>
              <p className="mt-4 flex items-start gap-2 text-sm leading-relaxed text-muted-foreground">
                <MapPin aria-hidden className="mt-0.5 size-4 shrink-0 text-emerald" />
                <span>Chunian, Kasur District, Punjab, Pakistan</span>
              </p>

              <div className="mt-8 space-y-5 text-base leading-8 text-muted-foreground">
                <p>
                  Syed Ahmad Raza Shamsi is the Founder and Administrator of Imam Mahdi Civilization, an ambitious digital initiative dedicated to exploring the intersection of Islamic knowledge, technology, education, research, and global community.
                </p>
                <p>
                  Based in Chunian, Kasur District, Punjab, Pakistan, he established Imam Mahdi Civilization with a vision to develop a meaningful digital ecosystem where people can explore knowledge, access educational resources, engage with modern technology, and connect with a growing global community.
                </p>
                <p>
                  His vision is built around the belief that the digital age presents powerful opportunities for knowledge, learning, research, and meaningful human connection. Through Imam Mahdi Civilization, he aims to contribute toward the development of a modern and accessible platform that brings together Islamic knowledge and emerging technology.
                </p>
                <p>
                  The project continues to grow as a long-term digital initiative focused on education, innovation, research, and the creation of meaningful digital experiences for a global audience.
                </p>
              </div>

              <blockquote className="relative mt-9 border-l-2 border-gold bg-gold-soft px-6 py-5 sm:px-8">
                <Quote aria-hidden className="absolute right-5 top-4 size-7 text-gold/25" />
                <p className="pr-7 font-display text-xl italic leading-relaxed text-foreground sm:text-2xl">
                  “We are not merely building a website. We are building a vision for the future.”
                </p>
              </blockquote>
            </article>
          </ScrollReveal>
        </div>
      </section>

      {/* CTA / JOIN */}
      <section id="join" className="py-32 px-6">
        <div className="max-w-4xl mx-auto border border-gold/30 p-10 md:p-20 text-center relative overflow-hidden">
          <div className="absolute -top-32 -left-32 size-72 bg-gold/10 blur-[120px] rounded-full" />
          <div className="absolute -bottom-32 -right-32 size-72 bg-emerald/10 blur-[120px] rounded-full" />
          <div className="relative">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Recruitment Active</span>
            <h2 className="mt-6 text-4xl md:text-6xl font-display italic">Join Imam Mahdi Civilization</h2>
            <p className="mt-6 text-muted-foreground text-lg max-w-2xl mx-auto">
              We seek writers, researchers, designers, video editors, translators, developers,
              moderators, social-media managers, and volunteers. Apply for your placement in the
              vanguard.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center">
              <Link to="/join" className="px-10 py-4 bg-foreground text-background font-bold uppercase text-xs tracking-[0.3em] hover:bg-gold transition-colors">
                Open Application
              </Link>
              <a href="mailto:imammahdicivilization@gmail.com" className="px-10 py-4 border border-border text-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-emerald-soft transition-colors">
                Apply via Email
              </a>
            </div>
          </div>
        </div>
      </section>
      </main>

      <Testimonials />

      {/* FOOTER */}
      <footer className="border-t border-border pt-20 pb-10 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-12 gap-12 mb-16">
            <div className="md:col-span-5">
              <div className="size-12 ring-1 ring-emerald/40 flex items-center justify-center font-bold text-emerald tracking-tighter rounded-full mb-6">IM</div>
              <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
                Architecting the digital frontier of the Ummah. A living Islamic civilization
                uniting knowledge, media, technology, and community.
              </p>
            </div>

            <div className="md:col-span-3">
              <span className="block text-[10px] font-bold uppercase tracking-[0.3em] text-gold mb-6">Contact</span>
              <ul className="space-y-3 text-sm">
                <li><a href="mailto:imammahdicivilization@gmail.com" className="hover:text-gold transition-colors">imammahdicivilization@gmail.com</a></li>
                <li><Link to="/about" className="hover:text-gold transition-colors">About the civilization</Link></li>
                <li className="text-muted-foreground">Admin · Syed Ahmad Raza Shamsi</li>
              </ul>
            </div>

            <div className="md:col-span-4">
              <span className="block text-[10px] font-bold uppercase tracking-[0.3em] text-gold mb-6">Connect</span>
              <div className="flex flex-wrap gap-2">
                {SOCIALS.map((s) => {
                  const Icon = s.icon;
                  return (
                    <a
                      key={s.label}
                      href={s.href}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={s.label}
                      className="size-11 border border-border flex items-center justify-center hover:bg-gold hover:text-primary-foreground hover:border-gold transition-colors"
                    >
                      <Icon className="size-5" />
                    </a>
                  );
                })}
              </div>
              <p className="mt-6 text-[11px] text-muted-foreground leading-relaxed">
                Follow the official channels for daily wisdom, lectures, and updates from the vanguard.
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
            <span className="text-[10px] font-mono-display text-muted-foreground uppercase tracking-widest">© Imam Mahdi Civilization · All sovereignty belongs to Allah.</span>
            <nav aria-label="Legal" className="flex items-center gap-3 text-[10px] font-mono-display uppercase tracking-widest text-muted-foreground">
              <Link to="/privacy" className="hover:text-gold transition-colors">Privacy Policy</Link>
              <span className="text-border">•</span>
              <Link to="/terms" className="hover:text-gold transition-colors">Terms of Service</Link>
            </nav>
            <span className="text-[10px] font-mono-display text-muted-foreground uppercase tracking-widest">Developed &amp; Managed by Syed Ahmad Raza Shamsi</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
