import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { abs } from "@/lib/site";

export const Route = createFileRoute("/cookies")({
  head: () => ({
    meta: [
      { title: "Cookie Policy — Imam Mahdi Civilization" },
      { name: "description", content: "What cookies and local storage Imam Mahdi Civilization uses, why they are needed, and how you can control or remove them." },
      { property: "og:title", content: "Cookie Policy — Imam Mahdi Civilization" },
      { property: "og:description", content: "Cookies and local storage we use, and how to control them." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: abs("/cookies") },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: abs("/cookies") }],
  }),
  component: Cookies,
});

const ROWS = [
  { k: "Essential / authentication", d: "Keeps you signed in and secures your session. The site cannot work without these." },
  { k: "Preferences", d: "Remembers your theme (light/dark), chosen language and reading settings, stored in your browser." },
  { k: "Feature storage", d: "Tasbih counts, Khatam progress and similar tools store progress locally in your browser, and in your account when you are signed in." },
  { k: "Advertising", d: "If advertising is enabled, third-party ad networks such as Google may set cookies to measure and personalise ads. We do not receive your personal data from them." },
];

function Cookies() {
  return (
    <div className="bg-background text-foreground min-h-dvh">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Cookie Policy" }]} />
      <main className="max-w-3xl mx-auto px-6 pt-10 pb-24">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Legal</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-5xl">Cookie Policy</h1>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          Cookies and browser storage are small pieces of data saved on your device. This page explains
          what we use and how you stay in control.
        </p>

        <div className="mt-12 grid gap-px bg-border ring-1 ring-border">
          {ROWS.map((r) => (
            <div key={r.k} className="bg-card p-6">
              <h2 className="text-sm font-bold uppercase tracking-[0.15em] text-gold">{r.k}</h2>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{r.d}</p>
            </div>
          ))}
        </div>

        <section className="mt-12">
          <h2 className="text-lg font-bold uppercase tracking-[0.15em] text-gold">Managing cookies</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">
            Every major browser lets you view, block or delete cookies from its privacy settings. Blocking
            essential cookies will sign you out and disable account features. You can also opt out of
            personalised advertising in your Google Ads settings.
          </p>
        </section>

        <section className="mt-10">
          <h2 className="text-lg font-bold uppercase tracking-[0.15em] text-gold">Location data</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">
            Prayer times, the Qibla compass and the mosque finder ask your browser for your location.
            It is used on your device to calculate results and is not stored on our servers.
          </p>
        </section>

        <p className="mt-12 text-sm text-muted-foreground">
          See also our <Link to="/privacy" className="text-gold hover:underline">Privacy Policy</Link> and{" "}
          <Link to="/disclaimer" className="text-gold hover:underline">Disclaimer</Link>.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}