import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import { ArrowLeft, Bookmark, BookmarkCheck } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";
import { SocialIcons } from "@/components/site/SocialIcons";
import { AiAssist } from "@/components/site/AiAssist";
import { RelatedProducts } from "@/components/site/RelatedProducts";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";
import { recordReading } from "@/lib/user-data";
import { getPublicArticle } from "@/lib/articles.functions";
import { coverFor } from "@/lib/article-covers";
import { SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/articles/$slug")({
  loader: ({ params }) => getPublicArticle({ data: { slug: params.slug } }),
  head: ({ params, loaderData }) => {
    const readable =
      loaderData?.title ??
      params.slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    const url = `https://imammahdicivilizition.com/articles/${params.slug}`;
    const description =
      loaderData?.excerpt ??
      `${readable} — an in-depth article from the Imam Mahdi Civilization knowledge archive on Islamic thought, history and practice.`;
    const cover = coverFor({
      cover_url: loaderData?.cover_url,
      slug: params.slug,
      title: loaderData?.title,
      tags: loaderData?.tags,
      category: loaderData?.category,
    });
    const coverAbs = cover.startsWith("http") ? cover : `${SITE_URL}${cover}`;
    return {
      meta: [
        { title: `${readable} — Imam Mahdi Civilization` },
        { name: "description", content: description.slice(0, 158) },
        { property: "og:title", content: readable },
        { property: "og:description", content: description.slice(0, 158) },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { name: "twitter:card", content: "summary_large_image" },
        { property: "og:image", content: coverAbs },
        { name: "twitter:image", content: coverAbs },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: readable,
            description: description.slice(0, 158),
            mainEntityOfPage: url,
            url,
            ...(loaderData?.published_at ? { datePublished: loaderData.published_at } : {}),
            author: { "@type": "Organization", name: "Imam Mahdi Civilization" },
            publisher: {
              "@type": "Organization",
              name: "Imam Mahdi Civilization",
              url: "https://imammahdicivilizition.com",
            },
          }),
        },
      ],
    };
  },
  component: ArticleDetail,
});

function ArticleDetail() {
  const { slug } = Route.useParams();
  const article = Route.useLoaderData();
  const [user, setUser] = useState<User | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
  }, []);

  useEffect(() => {
    if (!article) return;
    void recordReading({ itemType: "article", itemId: article.id, title: article.title, href: `/articles/${slug}` });
  }, [article, slug]);

  useEffect(() => {
    if (!user || !article) return;
    supabase
      .from("saved_items")
      .select("id")
      .eq("user_id", user.id)
      .eq("item_type", "article")
      .eq("item_id", article.id)
      .maybeSingle()
      .then(({ data }) => setSaved(!!data));
  }, [user, article]);

  async function toggleSave() {
    if (!user || !article) {
      toast.error("Sign in to save articles");
      return;
    }
    if (saved) {
      await supabase.from("saved_items").delete().eq("user_id", user.id).eq("item_type", "article").eq("item_id", article.id);
      setSaved(false);
      toast.success("Removed from your library");
    } else {
      const { error } = await supabase.from("saved_items").insert({ user_id: user.id, item_type: "article", item_id: article.id });
      if (error) { toast.error(error.message); return; }
      setSaved(true);
      toast.success("Saved to your library");
    }
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Articles", to: "/articles" }, { label: article?.title ?? "Article" }]} />
      <article className="pt-4 pb-20 px-6 max-w-3xl mx-auto">
        {!article && <p className="text-muted-foreground">Article not found.</p>}
        {article && (
          <>
            <Link
              to="/articles"
              className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] border border-border px-4 py-2.5 rounded-full text-muted-foreground hover:text-gold hover:border-gold/50 transition-all group"
            >
              <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
              Back to Articles
            </Link>
            <div className="mt-6 flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-emerald">
              <span>{article.category ?? "Essay"}</span>
              {article.reading_minutes && <><span className="text-border">·</span><span>{article.reading_minutes} min</span></>}
              {article.published_at && <><span className="text-border">·</span><span>{new Date(article.published_at).toLocaleDateString()}</span></>}
            </div>
            <h1 className="mt-4 font-display italic text-4xl md:text-6xl leading-tight">{article.title}</h1>
            {article.excerpt && <p className="mt-5 text-lg text-muted-foreground leading-relaxed">{article.excerpt}</p>}

            <figure className="mt-8 overflow-hidden border border-border">
              <img
                src={coverFor({
                  cover_url: article.cover_url,
                  slug,
                  title: article.title,
                  tags: article.tags,
                  category: article.category,
                })}
                alt={article.title}
                width={1280}
                height={720}
                className="w-full object-cover aspect-[16/9]"
              />
            </figure>

            <div className="mt-8 flex items-center justify-between border-y border-border py-4">
              <span className="text-xs text-muted-foreground">By Imam Mahdi Civilization</span>
              <div className="flex items-center gap-4">
                <SocialIcons />
                <button
                  onClick={toggleSave}
                  className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-gold hover:text-foreground transition-colors"
                >
                  {saved ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
                  {saved ? "Saved" : "Save"}
                </button>
              </div>
            </div>

            <div className="prose prose-invert prose-lg mt-10 max-w-none prose-headings:font-display prose-headings:italic prose-a:text-gold prose-strong:text-gold">
              <ReactMarkdown components={{ h1: ({ children }) => <h2>{children}</h2> }}>
                {article.content}
              </ReactMarkdown>
            </div>

            <div className="mt-10">
              <AiAssist title={article.title} text={article.content} />
            </div>

            <RelatedProducts
              topic={[article.title, article.category ?? "", (article.tags ?? []).join(" "), article.excerpt ?? ""].join(" ")}
            />


            {article.tags && article.tags.length > 0 && (
              <div className="mt-12 flex flex-wrap gap-2">
                {article.tags.map((t: string) => (
                  <span key={t} className="text-[10px] uppercase tracking-[0.2em] border border-border px-3 py-1.5 text-muted-foreground">
                    {t}
                  </span>
                ))}
              </div>
            )}
          </>
        )}
      </article>
      <SiteFooter />
    </div>
  );
}