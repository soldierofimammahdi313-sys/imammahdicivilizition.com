import { createFileRoute } from "@tanstack/react-router";

/** Constant-time string comparison so the secret can't be recovered by timing. */
function secretsMatch(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/**
 * Cron entry point for the daily Islamic content autopilot.
 * Authenticated with a high-entropy, server-only secret that is never shipped
 * to the browser (never a publishable/VITE_ key). The run itself is bounded,
 * single-flight and idempotent per day.
 */
export const Route = createFileRoute("/api/public/daily-autopilot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const accepted = [process.env["AUTOPILOT_TRIGGER_KEY"], process.env["CRON_SECRET"]].filter(
          (v): v is string => typeof v === "string" && v.length > 0,
        );
        const provided =
          request.headers.get("x-cron-secret") ??
          (request.headers.get("authorization") ?? "").replace(/^Bearer /, "");

        const authorized = provided.length > 0 && accepted.some((s) => secretsMatch(provided, s));
        if (!authorized) {
          return Response.json(
            { success: false, article: null, message: "Unauthorized autopilot request" },
            { status: 401 },
          );
        }




        const { hasVendor } = await import("@/lib/ai-pool.server");
        if (!hasVendor("gemini") && !hasVendor("openai")) {
          return Response.json(
            { success: false, article: null, message: "No AI API key is configured" },
            { status: 503 },
          );
        }

        const { runDailyAutopilot } = await import("@/lib/autopilot.server");
        const result = await runDailyAutopilot();
        const success = result.status === "ok" || result.status === "skipped";
        const status = result.status === "failed" ? 500 : result.status === "paused" ? 503 : 200;

        return Response.json(
          {
            success,
            article: result.article ?? null,
            message: result.detail,
            status: result.status,
            tickerItems: result.tickerItems ?? 0,
          },
          { status },
        );
      },
    },
  },
});
