import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { useI18n } from "@/lib/i18n";
import { sanitizeHtml } from "@/lib/sanitize";
import { recordReading } from "@/lib/user-data";
import { SURAH_META } from "@/lib/quran-meta";

export const Route = createFileRoute("/quran/$num")({
  head: ({ params }) => {
    const m = SURAH_META[params.num];
    const title = m
      ? `Surah ${m.en} (${m.meaning}) — Quran Majeed`
      : `Surah ${params.num} — Quran Majeed`;
    const desc = m
      ? `Read Surah ${m.en} — ${m.ayahs} verses with Arabic text, English and Urdu translation, audio recitation and tafsir.`
      : "Read this surah with Arabic, English translation, Urdu translation, audio recitation, and tafsir.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `https://imammahdicivilizition.com/quran/${params.num}` },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: `https://imammahdicivilizition.com/quran/${params.num}` }],
    };
  },
  component: SurahPage,
});

type Ayah = { number: number; numberInSurah: number; ar: string; en: string; ur: string };
type SurahData = { number: number; name: string; englishName: string; englishNameTranslation: string; numberOfAyahs: number; ayahs: Ayah[] };

/** Recitation audio is served per-ayah from a static CDN; all Quran text is local to this site. */
const ayahAudio = (globalAyahNumber: number) =>
  `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyahNumber}.mp3`;

type TafsirItem = { verse_key: string; text: string };
type TafsirOption = { id: number; name: string; language_name: string; author_name: string };

const BUILT_IN_TAFSIRS: TafsirOption[] = [
  { id: 169, name: "Ibn Kathir (Abridged)", language_name: "english", author_name: "Hafiz Ibn Kathir" },
  { id: 14, name: "Tafsir Ibn Kathir", language_name: "arabic", author_name: "Hafiz Ibn Kathir" },
  { id: 90, name: "Al-Qurtubi", language_name: "arabic", author_name: "Qurtubi" },
  { id: 91, name: "Al-Sa'di", language_name: "arabic", author_name: "Saddi" },
  { id: 94, name: "Al-Baghawi", language_name: "arabic", author_name: "Baghawy" },
  { id: 168, name: "Ma'arif al-Qur'an", language_name: "english", author_name: "Mufti Muhammad Shafi" },
  { id: 160, name: "Tafsir Ibn Kathir", language_name: "urdu", author_name: "Tawheed Publication" },
  { id: 157, name: "Fi Zilal al-Quran", language_name: "urdu", author_name: "Sayyid Ibrahim Qutb" },
  { id: 159, name: "Bayan ul Quran", language_name: "urdu", author_name: "Dr. Israr Ahmad" },
];

function SurahPage() {
  const { num } = Route.useParams();
  const { t, dir } = useI18n();
  const [surah, setSurah] = useState<SurahData | null>(null);

  const [selectedTafsir, setSelectedTafsir] = useState<string>("");
  const [tafsirData, setTafsirData] = useState<TafsirItem[]>([]);
  const [tafsirLoading, setTafsirLoading] = useState(false);
  const [showTafsir, setShowTafsir] = useState(false);

  useEffect(() => {
    let active = true;
    setSurah(null);
    fetch(`/quran/${num}.json`)
      .then(r => r.json())
      .then(d => { if (active) setSurah(d as SurahData); })
      .catch(() => {});
    return () => { active = false; };
  }, [num]);

  useEffect(() => {
    const ar = surah;
    if (!ar) return;
    void recordReading({
      itemType: "quran",
      itemId: String(num),
      title: `Surah ${ar.englishName} (${ar.name})`,
      href: `/quran/${num}`,
    });
  }, [surah, num]);

  // Fetch built-in tafsir when selected
  useEffect(() => {
    if (!showTafsir || !selectedTafsir || selectedTafsir === "mizan") {
      setTafsirData([]);
      return;
    }
    setTafsirLoading(true);
    fetch(`https://api.quran.com/api/v4/tafsirs/${selectedTafsir}/by_chapter/${num}`)
      .then(r => r.json())
      .then(d => {
        setTafsirData(d.tafsirs || []);
        setTafsirLoading(false);
      })
      .catch(() => setTafsirLoading(false));
  }, [selectedTafsir, num, showTafsir]);

  const tafsirMap = useMemo(() => {
    const map: Record<string, string> = {};
    for (const item of tafsirData) {
      map[item.verse_key] = item.text;
    }
    return map;
  }, [tafsirData]);

  const verseKey = (ayahNum: number) => `${num}:${ayahNum}`;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <section className="pt-32 pb-20 px-6 max-w-3xl mx-auto">
        <Link to="/quran" className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground hover:text-gold">← All Surahs</Link>
        {surah && (
          <div className="text-center my-12 border-b border-border pb-10">
            <div className="font-arabic text-5xl text-gold">{surah.name}</div>
            <h1 className="mt-4 font-display italic text-4xl">{surah.englishName}</h1>
            <div className="mt-2 text-xs text-muted-foreground uppercase tracking-widest">{surah.englishNameTranslation} · {surah.numberOfAyahs} verses</div>
          </div>
        )}

        {/* Tafsir toolbar */}
        <div className="mb-8 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between bg-card border border-border p-4">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.3em]">{t("tafsir.panel.title")}</span>
            <button
              onClick={() => setShowTafsir(v => !v)}
              className={`text-[10px] uppercase tracking-[0.2em] px-3 py-1.5 transition-colors ${showTafsir ? "bg-gold text-primary-foreground" : "ring-1 ring-border hover:ring-gold"}`}
            >
              {showTafsir ? "Hide" : "Show"}
            </button>
          </div>
          {showTafsir && (
            <select
              value={selectedTafsir}
              onChange={e => setSelectedTafsir(e.target.value)}
              className="bg-background border border-border px-3 py-2 text-sm focus:border-gold outline-none"
              dir={dir}
            >
              <option value="">{t("tafsir.panel.select")}</option>
              {BUILT_IN_TAFSIRS.map(taf => (
                <option key={taf.id} value={String(taf.id)}>{taf.name} — {taf.author_name} ({taf.language_name})</option>
              ))}
              <option value="mizan">{t("tafsir.panel.mizan")}</option>
            </select>
          )}
        </div>

        {showTafsir && selectedTafsir === "mizan" && surah && (
          <div className="mb-8 bg-emerald-soft border border-emerald/20 p-6 text-center">
            <p className="text-sm text-emerald mb-3">{t("tafsir.panel.mizanNote")}</p>
            <a
              href={`https://almizan.org/chapter/${num}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-5 py-2.5 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors"
            >
              {t("tafsir.panel.mizan")} — {surah.englishName}
            </a>
          </div>
        )}

        {showTafsir && selectedTafsir && selectedTafsir !== "mizan" && tafsirLoading && (
          <div className="mb-8 text-center text-muted-foreground text-sm">Loading tafsir…</div>
        )}

        <div className="space-y-8">
          {surah?.ayahs.map((a) => (
            <div key={a.number} className="border-b border-border pb-6">
              <div className="flex items-center justify-between mb-3">
                <span className="size-8 rounded-full ring-1 ring-gold/40 flex items-center justify-center text-[10px] font-mono-display text-gold">{a.numberInSurah}</span>
                <audio controls preload="none" src={ayahAudio(a.number)} className="h-8" />
              </div>
              <p dir="rtl" className="font-arabic text-3xl leading-loose text-right">{a.ar}</p>
              {a.en && <p className="mt-4 text-sm text-muted-foreground italic">{a.en}</p>}
              {a.ur && <p dir="rtl" className="mt-3 text-base text-right leading-loose text-foreground/90">{a.ur}</p>}

              {/* Inline tafsir */}
              {showTafsir && selectedTafsir && selectedTafsir !== "mizan" && tafsirMap[verseKey(a.numberInSurah)] && (
                <div className="mt-5 bg-card border border-border p-5">
                  <div className="text-[10px] font-bold text-gold uppercase tracking-[0.3em] mb-2">{t("tafsir.panel.title")}</div>
                  <div
                    className="text-sm text-muted-foreground leading-relaxed tafsir-text"
                    dangerouslySetInnerHTML={{ __html: sanitizeHtml(tafsirMap[verseKey(a.numberInSurah)]) }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
