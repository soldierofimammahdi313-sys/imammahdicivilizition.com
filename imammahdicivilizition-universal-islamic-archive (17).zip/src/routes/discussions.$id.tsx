import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";
import { Heart, Flag, Lock, Trash2 } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/discussions/$id")({
  head: ({ params }) => ({
    meta: [
      { title: "Discussion — Mahdi Civilization Community" },
      { name: "description", content: "Read and join this community discussion on Quran, hadith, fiqh and the path of Ahl al-Bayt." },
      { property: "og:title", content: "Discussion — Mahdi Civilization Community" },
      { property: "og:description", content: "Join the conversation in the global Ummah majlis." },
      { property: "og:type", content: "article" },
      { property: "og:url", content: `https://imammahdicivilizition.com/discussions/${params.id}` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex, follow" },
    ],
    links: [{ rel: "canonical", href: `https://imammahdicivilizition.com/discussions/${params.id}` }],
  }),
  component: ThreadPage,
});

function ThreadPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const postQuery = useQuery({
    queryKey: ["discussion", id],
    queryFn: async () => (await supabase.from("community_posts").select("*").eq("id", id).maybeSingle()).data,
  });
  const commentsQuery = useQuery({
    queryKey: ["discussion-comments", id],
    queryFn: async () =>
      (await supabase.from("community_comments").select("*").eq("post_id", id).order("created_at")).data ?? [],
  });
  const likesQuery = useQuery({
    queryKey: ["discussion-likes", id],
    queryFn: async () =>
      (await supabase.from("community_post_like_counts").select("like_count").eq("post_id", id).maybeSingle()).data
        ?.like_count ?? 0,
  });
  const myLikeQuery = useQuery({
    queryKey: ["discussion-my-like", id, user?.id ?? "anon"],
    enabled: Boolean(user),
    queryFn: async () =>
      Boolean(
        (await supabase.from("community_likes").select("id").eq("post_id", id).eq("user_id", user!.id).maybeSingle())
          .data,
      ),
  });

  const likeCount = likesQuery.data ?? 0;
  const likes = { length: likeCount } as { length: number };
  const liked = Boolean(myLikeQuery.data);

  async function toggleLike() {
    if (!user) return toast.error("Sign in to like");
    if (liked) {
      await supabase.from("community_likes").delete().eq("post_id", id).eq("user_id", user.id);
    } else {
      await supabase.from("community_likes").insert({ post_id: id, user_id: user.id });
    }
    qc.invalidateQueries({ queryKey: ["discussion-likes", id] });
    qc.invalidateQueries({ queryKey: ["discussion-my-like", id, user.id] });
  }

  async function submitReply(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return toast.error("Sign in to reply");
    const body = reply.trim();
    if (body.length < 2 || body.length > 4000) return toast.error("Reply must be between 2 and 4000 characters");
    setBusy(true);
    const { error } = await supabase.from("community_comments").insert({
      post_id: id,
      author_id: user.id,
      body,
      author_name: (user.user_metadata?.full_name as string) ?? user.email?.split("@")[0] ?? "Member",
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    setReply("");
    qc.invalidateQueries({ queryKey: ["discussion-comments", id] });
  }

  async function report(targetType: "post" | "comment", targetId: string) {
    if (!user) return toast.error("Sign in to report");
    const reason = window.prompt("Why are you reporting this? (max 300 characters)")?.trim();
    if (!reason) return;
    const { error } = await supabase.from("community_reports").insert({
      reporter_id: user.id,
      target_type: targetType,
      target_id: targetId,
      reason: reason.slice(0, 300),
    });
    if (error) return toast.error(error.message);
    toast.success("Reported — a moderator will review it shortly.");
  }

  async function deleteComment(commentId: string) {
    const { error } = await supabase.from("community_comments").delete().eq("id", commentId);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["discussion-comments", id] });
  }

  const post = postQuery.data;
  const comments = commentsQuery.data ?? [];

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <div className="pt-8 pb-20 px-4 md:px-6 max-w-4xl mx-auto">
        <Breadcrumbs items={[{ label: "Discussions", to: "/discussions" }, { label: post?.title ?? "Thread" }]} />

        {postQuery.isLoading ? (
          <p className="mt-8 text-sm text-muted-foreground">Loading discussion…</p>
        ) : !post ? (
          <div className="mt-8 border border-dashed border-border p-12 text-center">
            <h1 className="font-display italic text-3xl">Discussion not found</h1>
            <Link to="/discussions" className="mt-4 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">Back to the majlis ▸</Link>
          </div>
        ) : (
          <>
            <article className="mt-6 border border-border bg-card/40 p-7">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-gold">
                {post.is_locked && <Lock className="size-3" />} {post.category}
              </div>
              <h1 className="mt-3 font-display italic text-3xl md:text-4xl">{post.title}</h1>
              <p className="mt-2 text-[11px] text-muted-foreground">
                {post.author_name ?? "Member"} · {new Date(post.created_at).toLocaleString()}
              </p>
              <div className="mt-5 whitespace-pre-wrap text-sm leading-relaxed">{post.body}</div>
              <div className="mt-6 flex items-center gap-5 text-[10px] uppercase tracking-[0.25em]">
                <button onClick={toggleLike} className={`inline-flex items-center gap-2 ${liked ? "text-gold" : "text-muted-foreground hover:text-gold"}`}>
                  <Heart className={`size-4 ${liked ? "fill-current" : ""}`} /> {likes.length}
                </button>
                <button onClick={() => report("post", post.id)} className="inline-flex items-center gap-2 text-muted-foreground hover:text-destructive">
                  <Flag className="size-4" /> Report
                </button>
              </div>
            </article>

            <h2 className="mt-12 mb-4 font-display italic text-2xl">{comments.length} Replies</h2>
            <ul className="divide-y divide-border ring-1 ring-border bg-card/30">
              {comments.map((c) => (
                <li key={c.id} className="p-5">
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-[11px] text-muted-foreground">
                      {c.author_name ?? "Member"} · {new Date(c.created_at).toLocaleString()}
                    </p>
                    <div className="flex items-center gap-3">
                      <button onClick={() => report("comment", c.id)} aria-label="Report reply" className="text-muted-foreground hover:text-destructive">
                        <Flag className="size-3.5" />
                      </button>
                      {user?.id === c.author_id && (
                        <button onClick={() => deleteComment(c.id)} aria-label="Delete reply" className="text-muted-foreground hover:text-destructive">
                          <Trash2 className="size-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{c.body}</p>
                </li>
              ))}
              {comments.length === 0 && <li className="p-6 text-sm text-muted-foreground">No replies yet — be the first.</li>}
            </ul>

            {post.is_locked ? (
              <p className="mt-8 text-sm text-muted-foreground">This discussion is locked by a moderator.</p>
            ) : user ? (
              <form onSubmit={submitReply} className="mt-8 border border-border bg-card/40 p-5">
                <textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  rows={4}
                  maxLength={4000}
                  placeholder="Write your reply with adab…"
                  className="w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
                />
                <button
                  type="submit"
                  disabled={busy}
                  className="mt-3 px-6 py-3 bg-gold text-primary-foreground text-[11px] font-bold uppercase tracking-[0.25em] disabled:opacity-50"
                >
                  Post reply
                </button>
              </form>
            ) : (
              <Link to="/auth" className="mt-8 inline-block px-6 py-3 border border-gold text-gold text-[10px] uppercase tracking-[0.25em]">
                Sign in to reply
              </Link>
            )}
          </>
        )}
      </div>
      <SiteFooter />
    </div>
  );
}