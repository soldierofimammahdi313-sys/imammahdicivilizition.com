import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/journal")({
  head: () => ({
    meta: [
      { title: "Dua & Reflection Journal — Private Tadabbur | Imam Mahdi Civilization" },
      { name: "description", content: "Record your supplications, mark the ones answered, and keep private reflections on the verses you read. Stored only on your own device." },
      { property: "og:title", content: "Dua & Reflection Journal" },
      { property: "og:description", content: "Write your supplications and reflections; mark what Allah answered." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/journal" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/journal" }],
  }),
  component: JournalPage,
});

type Kind = "dua" | "reflection" | "note";
type Entry = { id: string; kind: Kind; title: string; body: string; at: number; answered?: boolean };

const KEY = "mc.journal.v1";
const KINDS: { k: Kind; label: string; arabic: string }[] = [
  { k: "dua", label: "Supplication", arabic: "دعاء" },
  { k: "reflection", label: "Reflection", arabic: "تدبر" },
  { k: "note", label: "Study note", arabic: "ملاحظة" },
];

function JournalPage() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [kind, setKind] = useState<Kind>("dua");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [filter, setFilter] = useState<Kind | "all">("all");

  useEffect(() => {
    try {
      setEntries(JSON.parse(localStorage.getItem(KEY) ?? "[]") as Entry[]);
    } catch { /* ignore */ }
  }, []);

  function persist(next: Entry[]) {
    setEntries(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch { /* storage unavailable */ }
  }

  function add(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim()) return;
    persist([
      { id: crypto.randomUUID(), kind, title: title.trim() || KINDS.find((x) => x.k === kind)!.label, body: body.trim(), at: Date.now() },
      ...entries,
    ]);
    setTitle("");
    setBody("");
  }

  const shown = filter === "all" ? entries : entries.filter((e) => e.kind === filter);
  const answered = entries.filter((e) => e.answered).length;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Journal" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-4xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Personal / Journal</span>
          <h1 className="mt-4 font-display italic text-5xl">Dua & Reflection Journal</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-xl mx-auto">
            Ask, reflect, and return later to see what was answered. Entries never leave this device.
          </p>
        </div>

        <form onSubmit={add} className="mt-12 bg-card border border-border p-6">
          <div className="flex flex-wrap gap-2">
            {KINDS.map((k) => (
              <button
                key={k.k}
                type="button"
                onClick={() => setKind(k.k)}
                aria-pressed={kind === k.k}
                className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                  kind === k.k ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
                }`}
              >
                {k.label} <span className="font-arabic text-sm ms-1 opacity-60">{k.arabic}</span>
              </button>
            ))}
          </div>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title (optional) — e.g. For my parents' health"
            className="mt-4 w-full bg-background border border-border focus:border-gold/60 focus:outline-none px-4 py-3 text-sm"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={4}
            placeholder="Write here…"
            className="mt-3 w-full bg-background border border-border focus:border-gold/60 focus:outline-none px-4 py-3 text-sm resize-y"
          />
          <button
            type="submit"
            disabled={!body.trim()}
            className="mt-4 px-8 py-3 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] disabled:opacity-40 hover:bg-foreground transition-colors"
          >
            Save entry
          </button>
        </form>

        <div className="mt-10 flex flex-wrap items-center gap-2">
          {(["all", ...KINDS.map((k) => k.k)] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              aria-pressed={filter === f}
              className={`px-3 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                filter === f ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
              }`}
            >
              {f === "all" ? "All" : KINDS.find((k) => k.k === f)!.label}
            </button>
          ))}
          <span className="ms-auto text-[10px] uppercase tracking-[0.28em] text-emerald">{answered} answered</span>
        </div>

        <div className="mt-6 space-y-3">
          {shown.map((e) => (
            <article key={e.id} className="bg-card border border-border p-6">
              <div className="flex items-center gap-3">
                <span className="text-[9px] uppercase tracking-[0.28em] text-gold">{KINDS.find((k) => k.k === e.kind)!.label}</span>
                <span className="text-[10px] text-muted-foreground">{new Date(e.at).toLocaleDateString()}</span>
                {e.answered && <span className="text-[9px] uppercase tracking-[0.28em] text-emerald">Answered — الحمد لله</span>}
              </div>
              <h2 className="mt-2 font-display text-xl">{e.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">{e.body}</p>
              <div className="mt-4 flex gap-4 text-[10px] uppercase tracking-[0.25em]">
                {e.kind === "dua" && (
                  <button
                    onClick={() => persist(entries.map((x) => (x.id === e.id ? { ...x, answered: !x.answered } : x)))}
                    className="text-emerald hover:underline"
                  >
                    {e.answered ? "Mark unanswered" : "Mark answered"}
                  </button>
                )}
                <button onClick={() => persist(entries.filter((x) => x.id !== e.id))} className="text-muted-foreground hover:text-destructive">
                  Delete
                </button>
              </div>
            </article>
          ))}
          {shown.length === 0 && (
            <div className="border border-dashed border-border p-14 text-center">
              <span className="font-arabic text-3xl text-gold/40 block">ادعُ ربك</span>
              <p className="mt-3 text-sm text-muted-foreground">No entries yet — write the first one above.</p>
            </div>
          )}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}