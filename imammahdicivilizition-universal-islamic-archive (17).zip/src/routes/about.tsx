import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/about.jpg";
import { breadcrumbLd } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Imam Mahdi Civilization" },
      { name: "description", content: "The mission, vision, and architecture of the world's first Islamic digital civilization." },
      { property: "og:title", content: "About Imam Mahdi Civilization" },
      { property: "og:description", content: "A worldwide collective architecting the digital frontier of the Ummah." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/about" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/about" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(breadcrumbLd([{ label: "About", to: "/about" }])) }],
  }),
  component: AboutPage,
});

const PRINCIPLES = [
  { n: "I", t: "Knowledge as Worship", d: "Every article, lecture, and dataset is curated to elevate the intellect of the Ummah." },
  { n: "II", t: "Premium by Default", d: "Cinematic interfaces, world-class design, and uncompromising attention to detail." },
  { n: "III", t: "Sovereign Technology", d: "AI, video, library, and community — owned and stewarded by the community itself." },
  { n: "IV", t: "Service to Truth", d: "Every line of code, every word published, is in service of the awaited one." },
];

function AboutPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "About" }]} jsonLd={false} />
      <PageBanner src={bannerImg} alt="About the Civilization" eyebrow="Mission" title="A digital civilization" subtitle="Knowledge, technology, and service to truth — united in one platform." />
      <section className="pt-8 pb-24 px-6 max-w-5xl mx-auto">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Doctrine</span>
        <h1 className="mt-4 font-display italic text-5xl md:text-7xl leading-[1.05] text-balance">
          We are the architects <br />of a <em className="text-gold/85">digital civilization</em>.
        </h1>
        <p className="mt-10 text-lg text-muted-foreground max-w-[60ch] leading-relaxed">
          The Imam Mahdi Civilization are not a website, not a blog, not a social network. We are
          a living infrastructure — uniting knowledge, education, media, research, technology,
          spirituality, and community into a single platform that can serve people globally for years
          to come.
        </p>
      </section>

      <section className="py-24 px-6 border-y border-border bg-card/30">
        <div className="max-w-6xl mx-auto grid md:grid-cols-12 gap-12">
          <div className="md:col-span-4">
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">The Four Principles</span>
            <h2 className="mt-4 font-display text-3xl md:text-4xl italic">The Four Principles</h2>
            <p className="mt-6 text-muted-foreground text-sm leading-relaxed">
              Every decision in the civilization is measured against these four pillars.
            </p>
          </div>
          <div className="md:col-span-8 grid sm:grid-cols-2 gap-px bg-border ring-1 ring-border">
            {PRINCIPLES.map((p) => (
              <div key={p.n} className="bg-background p-8">
                <span className="font-mono-display text-[10px] text-emerald tracking-widest">{p.n}</span>
                <h3 className="mt-3 font-display text-2xl">{p.t}</h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-6 max-w-5xl mx-auto text-center">
        <span className="font-arabic text-3xl text-gold/40 block">يا صاحب الزمان</span>
        <h2 className="mt-4 font-display text-4xl md:text-5xl italic">Join the vanguard of Imam Mahdi Civilization.</h2>
        <p className="mt-6 text-muted-foreground max-w-xl mx-auto">
          Writers, researchers, designers, developers, translators — every skill has a place in the
          civilization.
        </p>
        <div className="mt-10 flex gap-3 justify-center flex-col sm:flex-row">
          <Link to="/join" className="px-10 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors">
            Enlist Now
          </Link>
          <Link to="/who-is-imam-mahdi" className="px-10 py-4 border border-border font-bold uppercase text-xs tracking-[0.3em] hover:bg-emerald-soft transition-colors">
            Who Is Imam Mahdi?
          </Link>
          <Link to="/" className="px-10 py-4 border border-border font-bold uppercase text-xs tracking-[0.3em] hover:bg-emerald-soft transition-colors">
            Return Home
          </Link>
        </div>
      </section>
    </div>
  );
}