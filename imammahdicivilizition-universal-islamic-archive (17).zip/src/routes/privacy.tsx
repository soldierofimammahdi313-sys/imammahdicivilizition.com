import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Imam Mahdi Civilization" },
      { name: "description", content: "How Imam Mahdi Civilization collects, uses and protects your data across the Islamic digital civilization platform." },
      { property: "og:title", content: "Privacy Policy — Imam Mahdi Civilization" },
      { property: "og:description", content: "How we collect, use and protect your data on the Mahdi Civilization platform." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/privacy" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/privacy" }],
  }),
  component: Privacy,
});

const SECTIONS = [
  {
    h: "Who we are",
    p: "Imam Mahdi Civilization is an independent Islamic knowledge platform operated by Syed Ahmad Raza Shamsi from Chunian, Kasur District, Punjab, Pakistan. For any privacy question, write to imammahdicivilization@gmail.com. This policy was last reviewed in 2026.",
  },
  {
    h: "Information we collect",
    p: "Account data: if you create an account we store your email address and any profile details you choose to add (display name, country, short bio, avatar). Activity data: bookmarks, reading history, Tasbih counts, Khatam progress, daily tasks, quiz and academy progress, all linked to your account. Submitted content: reviews, discussion posts, contact messages and volunteer applications you send us. Technical data: our hosting and security layer processes your IP address, browser type and requested pages to serve the site and prevent abuse. You can browse the Quran, Hadith, Duas, articles and tools without an account.",
  },
  {
    h: "How we use your information",
    p: "We use your data only to operate the platform: to sign you in, to save your bookmarks and worship progress, to publish content you deliberately submit, to reply to your messages, to keep the service secure, and to understand which pages are useful so we can improve them. We do not sell personal data and we do not share it for unrelated marketing.",
  },
  {
    h: "Legal basis and retention",
    p: "We process account and activity data to perform the service you asked for, security data on the basis of our legitimate interest in protecting the site, and optional analytics or advertising cookies on the basis of your consent where local law requires it. Account data is kept while your account exists and is deleted on request; submitted content stays published until you ask us to remove it.",
  },
  {
    h: "Location data",
    p: "Prayer times and the Qibla compass ask your browser for your location. The coordinates are used in your own browser to calculate prayer timings and the direction of the Qibla; they are not sent to or stored on our servers. You may refuse the permission and enter a city manually instead.",
  },
  {
    h: "Cookies and similar technologies",
    p: "Essential cookies keep you signed in and remember your language and theme; the site cannot work without them. Analytics cookies, where enabled, help us count page visits in aggregate. Advertising cookies may be set by third-party ad partners if advertising is switched on, to limit repeated ads and measure performance. You can block or delete cookies in your browser settings at any time; only the essential ones affect core functionality. See our Cookie Policy page for the full breakdown.",
  },
  {
    h: "Advertising",
    p: "This site may display advertising from third-party networks such as Google AdSense. Ad partners and their vendors may use cookies or device identifiers to serve and measure ads. Google's use of advertising cookies is described in Google's own privacy and advertising policies, and you can control personalised advertising through Google's Ads Settings. We do not give advertisers your email address, account data or worship records.",
  },
  {
    h: "AI processing",
    p: "When you ask the AI assistant a question, the text of your message is sent to our servers and forwarded to third-party AI providers (such as OpenAI and Google) purely to generate the answer. Do not include private, medical, financial or identifying information in your questions. Conversation history is stored in your own browser so you can return to it; if you are signed in, a record may be kept to protect against abuse. AI answers are informational and are not a religious ruling.",
  },
  {
    h: "Third-party services we rely on",
    p: "Authentication and database hosting (Supabase), site hosting and content delivery, Quran, Hadith, Hijri calendar and prayer-time data APIs, AI providers as described above, and — if enabled — advertising and analytics providers. Each receives only the data required to perform its function.",
  },
  {
    h: "Children",
    p: "The platform, including the Academy section, is intended for general and family use. We do not knowingly collect personal information from children under 13 without parental involvement. If you believe a child has created an account, write to us and we will remove it.",
  },
  {
    h: "Security",
    p: "Data is stored with row-level access rules so that your records are readable only by you and, where necessary, by the site administrator. No online service can promise perfect security, but we apply current best practice and review access regularly.",
  },
  {
    h: "Your rights",
    p: "You may request access to, correction of, export of, or deletion of your account data, withdraw consent for optional cookies, and ask us to remove any content you submitted. Email imammahdicivilization@gmail.com and we will respond as quickly as we can.",
  },
  {
    h: "Changes to this policy",
    p: "If we change how data is handled we will update this page and the review date above. Continued use of the platform after a change means you accept the updated policy.",
  },
];

function Privacy() {
  return (
    <div className="bg-background text-foreground min-h-dvh">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Privacy Policy" }]} />
      <main className="max-w-3xl mx-auto px-6 pt-8 pb-24">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Legal</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-5xl">Privacy Policy</h1>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          This policy explains what information Imam Mahdi Civilization collects and how it is used.
        </p>
        <div className="mt-12 space-y-10">
          {SECTIONS.map((s) => (
            <section key={s.h}>
              <h2 className="text-lg font-bold uppercase tracking-[0.15em] text-gold">{s.h}</h2>
              <p className="mt-3 text-muted-foreground leading-relaxed">{s.p}</p>
            </section>
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}