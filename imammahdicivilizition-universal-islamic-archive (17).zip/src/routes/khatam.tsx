import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/khatam")({
  head: () => ({
    meta: [
      { title: "Khatam Tracker — Quran Completion Progress" },
      { name: "description", content: "Track your Quran reading across all 30 juz toward completion." },
      { property: "og:title", content: "Khatam Tracker — Quran Completion Progress" },
      { property: "og:description", content: "Track your Quran reading across all 30 juz toward completion." },
      { property: "og:url", content: "https://imammahdicivilizition.com/khatam" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/khatam" }],
  }),
  component: KhatamPage,
});

function KhatamPage() {
  const [done, setDone] = useState<boolean[]>(() => {
    if (typeof window === "undefined") return new Array(30).fill(false);
    try { return JSON.parse(localStorage.getItem("khatam") || "null") ?? new Array(30).fill(false); } catch { return new Array(30).fill(false); }
  });
  useEffect(() => { localStorage.setItem("khatam", JSON.stringify(done)); }, [done]);
  const completed = done.filter(Boolean).length;
  const pct = Math.round((completed / 30) * 100);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Khatam Tracker" }]} />
      <section className="pt-8 pb-20 px-6 max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Khatm al-Qur'ān</span>
          <h1 className="mt-4 font-display italic text-5xl">Quran Completion Tracker</h1>
          <p className="mt-3 text-sm text-muted-foreground">Mark each juz as you read. <Link to="/quran" className="text-gold hover:underline">Open the reader →</Link></p>
        </div>
        <div className="bg-card border border-border p-6 mb-8">
          <div className="flex justify-between items-end mb-3">
            <div className="font-display text-3xl">{completed} <span className="text-muted-foreground text-base">/ 30 juz</span></div>
            <div className="text-gold font-mono-display">{pct}%</div>
          </div>
          <div className="h-2 bg-border">
            <div className="h-full bg-gold transition-all" style={{ width: `${pct}%` }} />
          </div>
        </div>
        <div className="grid grid-cols-5 sm:grid-cols-6 lg:grid-cols-10 gap-2">
          {done.map((d, i) => (
            <button key={i} onClick={() => setDone(arr => arr.map((v, j) => j === i ? !v : v))}
              className={`aspect-square border font-display text-lg transition-colors ${d ? "bg-gold text-primary-foreground border-gold" : "bg-card border-border hover:border-gold/50"}`}>
              {i + 1}
            </button>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}