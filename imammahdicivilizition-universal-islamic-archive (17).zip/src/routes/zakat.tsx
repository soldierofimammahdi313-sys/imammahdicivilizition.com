import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/zakat")({
  head: () => ({
    meta: [
      { title: "Zakat Calculator — Imam Mahdi Civilization" },
      { name: "description", content: "Calculate your zakat based on the silver nisab." },
      { property: "og:title", content: "Zakat Calculator — Imam Mahdi Civilization" },
      { property: "og:description", content: "Calculate your zakat based on the silver nisab." },
      { property: "og:url", content: "https://imammahdicivilizition.com/zakat" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/zakat" }],
  }),
  component: ZakatPage,
});

function ZakatPage() {
  const [cash, setCash] = useState(0);
  const [gold, setGold] = useState(0);
  const [silver, setSilver] = useState(0);
  const [investments, setInvestments] = useState(0);
  const [debts, setDebts] = useState(0);
  const [nisab, setNisab] = useState(450); // silver nisab ~ 595g × current ≈ varies

  const total = useMemo(() => Math.max(0, cash + gold + silver + investments - debts), [cash, gold, silver, investments, debts]);
  const due = total >= nisab ? total * 0.025 : 0;

  const fields: [string, number, (v: number) => void][] = [
    ["Cash & bank balance", cash, setCash],
    ["Gold value", gold, setGold],
    ["Silver value", silver, setSilver],
    ["Investments & business assets", investments, setInvestments],
    ["Outstanding debts (to subtract)", debts, setDebts],
  ];

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Zakat Calculator" }]} />
      <section className="pt-8 pb-20 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Zakāh</span>
          <h1 className="mt-4 font-display italic text-5xl">Zakat Calculator</h1>
          <p className="mt-3 text-sm text-muted-foreground">2.5% of qualifying wealth held a full lunar year above nisab.</p>
        </div>
        <div className="bg-card border border-border p-6 space-y-4">
          {fields.map(([label, value, set]) => (
            <label key={label} className="block">
              <span className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</span>
              <input type="number" value={value} onChange={e => set(Number(e.target.value) || 0)}
                className="mt-1 w-full bg-background border border-border px-3 py-2 focus:border-gold outline-none" />
            </label>
          ))}
          <label className="block">
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground">Nisab threshold (silver, your currency)</span>
            <input type="number" value={nisab} onChange={e => setNisab(Number(e.target.value) || 0)}
              className="mt-1 w-full bg-background border border-border px-3 py-2 focus:border-gold outline-none" />
          </label>
          <div className="border-t border-border pt-4 mt-2 grid grid-cols-2 gap-4">
            <div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Net zakatable wealth</div>
              <div className="font-display text-2xl">{total.toLocaleString()}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-gold">Zakat due (2.5%)</div>
              <div className="font-display text-3xl text-gold">{due.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
            </div>
          </div>
          {total > 0 && total < nisab && <p className="text-xs text-muted-foreground">Wealth is below nisab — no zakat is due this year.</p>}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}