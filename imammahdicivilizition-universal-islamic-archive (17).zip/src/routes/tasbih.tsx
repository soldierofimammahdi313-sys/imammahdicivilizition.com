import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/tasbih")({
  head: () => ({
    meta: [
      { title: "Digital Tasbih — Imam Mahdi Civilization" },
      { name: "description", content: "Digital dhikr counter to track your remembrance." },
      { property: "og:title", content: "Digital Tasbih — Imam Mahdi Civilization" },
      { property: "og:description", content: "Digital dhikr counter to track your remembrance." },
      { property: "og:url", content: "https://imammahdicivilizition.com/tasbih" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/tasbih" }],
  }),
  component: TasbihPage,
});

const PRESETS = [
  { name: "SubhanAllah", a: "سُبْحَانَ ٱللَّٰه" },
  { name: "Alhamdulillah", a: "ٱلْحَمْدُ لِلَّٰه" },
  { name: "Allahu Akbar", a: "ٱللَّٰهُ أَكْبَر" },
  { name: "La ilaha illa Allah", a: "لَا إِلَٰهَ إِلَّا ٱللَّٰه" },
  { name: "Astaghfirullah", a: "أَسْتَغْفِرُ ٱللَّٰه" },
];

function TasbihPage() {
  const [active, setActive] = useState(0);
  const [counts, setCounts] = useState<number[]>(() => {
    if (typeof window === "undefined") return PRESETS.map(() => 0);
    try { return JSON.parse(localStorage.getItem("tasbih") || "null") ?? PRESETS.map(() => 0); } catch { return PRESETS.map(() => 0); }
  });
  const [target, setTarget] = useState(33);

  useEffect(() => { localStorage.setItem("tasbih", JSON.stringify(counts)); }, [counts]);

  const inc = () => setCounts(c => c.map((x, i) => i === active ? x + 1 : x));
  const reset = () => setCounts(c => c.map((x, i) => i === active ? 0 : x));

  const value = counts[active];
  const completed = Math.floor(value / target);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Digital Tasbih" }]} />
      <section className="pt-8 pb-20 px-6 max-w-2xl mx-auto text-center">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Tasbīḥ</span>
        <h1 className="mt-4 font-display italic text-5xl">Digital Tasbih</h1>

        <div className="mt-8 flex flex-wrap justify-center gap-2">
          {PRESETS.map((p, i) => (
            <button key={p.name} onClick={() => setActive(i)}
              className={`px-3 py-2 text-[11px] uppercase tracking-widest border transition-colors ${active === i ? "border-gold text-gold" : "border-border text-muted-foreground hover:border-gold/50"}`}>
              {p.name}
            </button>
          ))}
        </div>

        <div className="mt-10 p-10 border border-gold/40 bg-card">
          <div className="font-arabic text-4xl text-gold">{PRESETS[active].a}</div>
          <div className="mt-2 text-xs text-muted-foreground uppercase tracking-widest">{PRESETS[active].name}</div>
          <button onClick={inc} className="mt-8 size-44 rounded-full bg-gold text-primary-foreground font-display text-6xl mx-auto hover:bg-foreground transition-colors active:scale-95">
            {value}
          </button>
          <div className="mt-6 text-[11px] uppercase tracking-widest text-muted-foreground">{completed} sets of {target} completed</div>
          <div className="mt-4 flex justify-center items-center gap-4">
            <label className="text-[11px] uppercase tracking-widest text-muted-foreground">Target
              <input type="number" min={1} value={target} onChange={e => setTarget(Math.max(1, Number(e.target.value) || 1))}
                className="ml-2 w-16 bg-background border border-border px-2 py-1 text-center focus:border-gold outline-none" />
            </label>
            <button onClick={reset} className="text-[11px] uppercase tracking-widest text-muted-foreground hover:text-gold">Reset</button>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}