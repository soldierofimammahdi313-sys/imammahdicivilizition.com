import { createFileRoute, Link } from "@tanstack/react-router";
import { cloneElement, isValidElement, useEffect, useId, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { breadcrumbLd } from "@/lib/site";
import type { User } from "@supabase/supabase-js";

export const Route = createFileRoute("/join")({
  head: () => ({
    meta: [
      { title: "Enlist — Imam Mahdi Civilization" },
      { name: "description", content: "Apply to join the vanguard. Writers, researchers, designers, developers, and more." },
      { property: "og:title", content: "Join Imam Mahdi Civilization" },
      { property: "og:description", content: "Apply to join the vanguard of the Imam Mahdi Civilization." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/join" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/join" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(breadcrumbLd([{ label: "Join", to: "/join" }])) }],
  }),
  component: JoinPage,
});

const ROLES = [
  "Writer / Researcher",
  "Designer",
  "Video Editor",
  "Translator",
  "Developer / Engineer",
  "Moderator",
  "Social Media Manager",
  "Volunteer",
];

function JoinPage() {
  const [user, setUser] = useState<User | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    country: "",
    languages: "",
    role: ROLES[0],
    skills: "",
    experience: "",
    portfolio_url: "",
    motivation: "",
  });

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      if (data.user) {
        setForm((f) => ({
          ...f,
          email: data.user!.email ?? f.email,
          full_name: (data.user!.user_metadata?.full_name as string) ?? f.full_name,
        }));
      }
    });
  }, []);

  function update<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { error } = await supabase.from("team_applications").insert({
        ...form,
        user_id: user?.id ?? null,
      });
      if (error) throw error;

      // Keep the member profile in sync with what they entered when applying.
      if (user) {
        await supabase.from("profiles").upsert(
          { id: user.id, full_name: form.full_name, email: form.email, country: form.country },
          { onConflict: "id" },
        );
      }

      setDone(true);
      toast.success("Application received. We will be in touch.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Submission failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Join" }]} jsonLd={false} />
      <section className="pt-8 pb-20 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-14">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Recruitment Active</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Enlist in Imam Mahdi Civilization</h1>
          <p className="mt-5 text-muted-foreground max-w-xl mx-auto">
            Submit your application below. Every skill — from calligraphy to code — has a place.
          </p>
        </div>

        {done ? (
          <div className="border border-gold/30 p-12 text-center">
            <span className="font-arabic text-4xl text-gold/60 block">الحمد لله</span>
            <h2 className="mt-4 font-display text-3xl italic">Application received.</h2>
            <p className="mt-4 text-muted-foreground">
              We review every submission personally. Expect contact within 7 days via the email
              address you shared.
            </p>
            <Link to="/" className="mt-8 inline-block px-8 py-3 bg-gold text-primary-foreground text-xs uppercase tracking-[0.3em] font-bold hover:bg-foreground transition-colors">
              Return Home
            </Link>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-5 border border-border p-8 md:p-10 bg-card/30">
            <Field label="Full Name" required>
              <input type="text" required value={form.full_name} onChange={(e) => update("full_name", e.target.value)} className={inputCls} />
            </Field>
            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Email" required>
                <input type="email" required value={form.email} onChange={(e) => update("email", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Country" required>
                <input type="text" required value={form.country} onChange={(e) => update("country", e.target.value)} className={inputCls} />
              </Field>
            </div>
            <Field label="Languages spoken">
              <input type="text" value={form.languages} onChange={(e) => update("languages", e.target.value)} placeholder="English, Urdu, Arabic…" className={inputCls} />
            </Field>
            <Field label="Desired Role" required>
              <select required value={form.role} onChange={(e) => update("role", e.target.value)} className={inputCls}>
                {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </Field>
            <Field label="Skills">
              <input type="text" value={form.skills} onChange={(e) => update("skills", e.target.value)} placeholder="Editing, Arabic typography, React…" className={inputCls} />
            </Field>
            <Field label="Experience">
              <textarea rows={3} value={form.experience} onChange={(e) => update("experience", e.target.value)} className={inputCls} />
            </Field>
            <Field label="Portfolio URL">
              <input type="url" value={form.portfolio_url} onChange={(e) => update("portfolio_url", e.target.value)} placeholder="https://" className={inputCls} />
            </Field>
            <Field label="Why do you want to join Imam Mahdi Civilization?" required>
              <textarea rows={5} required value={form.motivation} onChange={(e) => update("motivation", e.target.value)} className={inputCls} />
            </Field>
            <button type="submit" disabled={submitting} className="w-full py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors disabled:opacity-50">
              {submitting ? "Submitting..." : "Submit Application"}
            </button>
            {!user && (
              <p className="text-center text-xs text-muted-foreground">
                Tip: <Link to="/auth" className="text-gold hover:underline">create an account</Link> to track your application.
              </p>
            )}
          </form>
        )}
      </section>
    </div>
  );
}

const inputCls = "mt-1 w-full bg-background border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none";

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
        {label}{required && <span className="text-gold ml-1">*</span>}
      </label>
      {isValidElement(children)
        ? cloneElement(children as React.ReactElement<{ id?: string; "aria-label"?: string }>, { id, "aria-label": label })
        : children}
    </div>
  );
}