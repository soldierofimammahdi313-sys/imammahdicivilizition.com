import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Islamic Calendar & Events — Imam Mahdi Civilization" },
      { name: "description", content: "Key dates in the Islamic year: Ramadan, the two Eids, Hajj, and sacred months." },
      { property: "og:title", content: "Islamic Calendar & Events — Imam Mahdi Civilization" },
      { property: "og:description", content: "Key dates in the Islamic year: Ramadan, the two Eids, Hajj, and sacred months." },
      { property: "og:url", content: "https://imammahdicivilizition.com/events" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/events" }],
  }),
  component: EventsPage,
});

const EVENTS = [
  { date: "1 Muharram", name: "Islamic New Year", desc: "Beginning of the Hijri year." },
  { date: "10 Muharram", name: "Day of Ashura", desc: "Fast recommended; commemorates Musa (a.s) and the martyrdom of Imam Husayn (a.s)." },
  { date: "12 Rabi al-Awwal", name: "Mawlid an-Nabi", desc: "Commemoration of the birth of the Prophet ﷺ." },
  { date: "27 Rajab", name: "Isra & Mi'raj", desc: "The Night Journey and Ascension of the Prophet ﷺ." },
  { date: "15 Sha'ban", name: "Laylat al-Bara'ah", desc: "Night of forgiveness; many keep extra worship." },
  { date: "1 Ramadan", name: "Beginning of Ramadan", desc: "Month of fasting, Quran, and night prayer." },
  { date: "27 Ramadan", name: "Laylat al-Qadr (most likely)", desc: "Better than a thousand months; seek in last ten odd nights." },
  { date: "1 Shawwal", name: "Eid al-Fitr", desc: "Festival marking the end of Ramadan." },
  { date: "8–13 Dhul Hijjah", name: "Hajj & Day of Arafah", desc: "The annual pilgrimage; Arafah is on the 9th." },
  { date: "10 Dhul Hijjah", name: "Eid al-Adha", desc: "Festival of sacrifice." },
];

function EventsPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Islamic Calendar" }]} />
      <section className="pt-8 pb-20 px-6 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Taqwīm</span>
          <h1 className="mt-4 font-display italic text-5xl">Islamic Calendar & Events</h1>
        </div>
        <ul className="divide-y divide-border border border-border bg-card">
          {EVENTS.map((e, i) => (
            <li key={i} className="p-6 hover:bg-emerald-soft transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-baseline sm:gap-6">
                <div className="text-gold font-mono-display text-sm uppercase tracking-widest min-w-[180px]">{e.date}</div>
                <div>
                  <div className="font-display text-xl">{e.name}</div>
                  <p className="text-sm text-muted-foreground mt-1">{e.desc}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </section>
      <SiteFooter />
    </div>
  );
}