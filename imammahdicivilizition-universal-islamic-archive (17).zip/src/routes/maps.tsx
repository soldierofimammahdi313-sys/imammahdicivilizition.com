import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/maps")({
  head: () => ({
    meta: [
      { title: "Sacred Maps — Karbala, Makkah, Madinah, Najaf, Samarra | Imam Mahdi Civilization" },
      { name: "description", content: "Interactive maps of the holy cities with the significance of every site, plus a step-by-step guide to Hajj, Umrah and Ziyarat." },
      { property: "og:title", content: "Sacred Maps of the Holy Cities" },
      { property: "og:description", content: "Walk Karbala, Makkah, Madinah, Najaf and Samarra — site by site." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/maps" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/maps" }],
  }),
  component: MapsPage,
});

type Site = { name: string; arabic: string; x: number; y: number; desc: string };
type City = { id: string; name: string; arabic: string; country: string; blurb: string; sites: Site[] };

const CITIES: City[] = [
  {
    id: "karbala", name: "Karbala", arabic: "كربلاء", country: "Iraq",
    blurb: "The plain where Imam Husayn and 72 companions were martyred on the tenth of Muharram, 61 AH.",
    sites: [
      { name: "Shrine of Imam Husayn", arabic: "حرم الحسين", x: 34, y: 46, desc: "Built over the grave of the Master of Martyrs; the Zarih stands where he fell." },
      { name: "Shrine of Abbas", arabic: "حرم العباس", x: 66, y: 40, desc: "The standard-bearer who fell carrying water to the children." },
      { name: "Bayn al-Haramayn", arabic: "بین الحرمین", x: 50, y: 43, desc: "The 378-metre courtyard between the two shrines, never empty of pilgrims." },
      { name: "Tal al-Zaynabiyya", arabic: "تل الزینبیة", x: 41, y: 63, desc: "The mound from which Sayyida Zaynab watched the field on Ashura." },
      { name: "Camp of Husayn (Mukhayyam)", arabic: "المخیم", x: 58, y: 68, desc: "The site of the tents burned after the massacre." },
      { name: "Al-Alqami (Euphrates branch)", arabic: "العلقمي", x: 80, y: 24, desc: "The blocked river; the army denied the household water for three days." },
    ],
  },
  {
    id: "makkah", name: "Makkah", arabic: "مكة المكرمة", country: "Saudi Arabia",
    blurb: "The first house appointed for mankind, and the direction of every prayer on earth.",
    sites: [
      { name: "The Kaaba", arabic: "الكعبة", x: 50, y: 50, desc: "The House built by Ibrahim and Isma'il; tawaf begins at the Black Stone." },
      { name: "Maqam Ibrahim", arabic: "مقام إبراهيم", x: 56, y: 46, desc: "The standing place of Ibrahim; two rak'ahs follow the tawaf." },
      { name: "Safa & Marwa", arabic: "الصفا والمروة", x: 72, y: 60, desc: "The sa'y between the two hills retraces Hajar's search for water." },
      { name: "Zamzam", arabic: "زمزم", x: 58, y: 55, desc: "The well that has not run dry since it sprang beneath Isma'il's feet." },
      { name: "Cave of Hira", arabic: "غار حراء", x: 84, y: 18, desc: "On Jabal al-Nur, where the first revelation descended." },
      { name: "Mina & Arafat", arabic: "منى وعرفات", x: 26, y: 76, desc: "The stations of Hajj: standing at Arafat, then Muzdalifah and the stoning at Mina." },
    ],
  },
  {
    id: "madinah", name: "Madinah", arabic: "المدينة المنورة", country: "Saudi Arabia",
    blurb: "The city of the Prophet ﷺ — first capital of Islam and his resting place.",
    sites: [
      { name: "Masjid al-Nabawi", arabic: "المسجد النبوي", x: 48, y: 48, desc: "The Prophet's mosque, expanded from the courtyard of his own house." },
      { name: "Rawdah al-Sharifa", arabic: "الروضة", x: 53, y: 44, desc: "'A garden from the gardens of Paradise' — between the pulpit and the grave." },
      { name: "Jannat al-Baqi", arabic: "البقيع", x: 68, y: 58, desc: "Resting place of four Imams, Sayyida Fatima's contested grave, and the companions." },
      { name: "Masjid Quba", arabic: "مسجد قباء", x: 32, y: 76, desc: "The first mosque of Islam; two rak'ahs there equal an Umrah in reward." },
      { name: "Masjid al-Qiblatayn", arabic: "القبلتین", x: 24, y: 32, desc: "Where the qibla turned from Jerusalem to the Kaaba mid-prayer." },
      { name: "Mount Uhud", arabic: "أحد", x: 62, y: 16, desc: "The field of the second battle; Hamza and 70 martyrs rest at its foot." },
    ],
  },
  {
    id: "najaf", name: "Najaf", arabic: "النجف الأشرف", country: "Iraq",
    blurb: "City of Amir al-Mu'minin and of the oldest continuously teaching hawza in Islam.",
    sites: [
      { name: "Shrine of Imam Ali", arabic: "حرم أمير المؤمنين", x: 50, y: 46, desc: "The golden dome over the grave of Ali ibn Abi Talib." },
      { name: "Wadi al-Salam", arabic: "وادي السلام", x: 74, y: 26, desc: "The largest cemetery on earth — the Valley of Peace." },
      { name: "The Hawza", arabic: "الحوزة العلمية", x: 36, y: 58, desc: "Founded by Shaykh al-Tusi in the 5th century AH; still teaching today." },
      { name: "Masjid al-Kufa", arabic: "مسجد الكوفة", x: 22, y: 74, desc: "Where Imam Ali was struck in the mihrab during Ramadan of 40 AH." },
      { name: "Maqam of Muslim ibn Aqil", arabic: "مسلم بن عقيل", x: 28, y: 82, desc: "The Imam's envoy to Kufa, martyred before Karbala." },
    ],
  },
  {
    id: "samarra", name: "Samarra", arabic: "سامراء", country: "Iraq",
    blurb: "The garrison city where the tenth and eleventh Imams lived under watch, and where the Mahdi was born.",
    sites: [
      { name: "Al-Askari Shrine", arabic: "حرم العسكريين", x: 50, y: 44, desc: "Resting place of Imam al-Hadi and Imam al-Askari." },
      { name: "The Sardab", arabic: "السرداب", x: 58, y: 56, desc: "The cellar associated with the beginning of the occultation." },
      { name: "Shrine of Narjis Khatun", arabic: "نرجس خاتون", x: 44, y: 55, desc: "Mother of the awaited Imam." },
      { name: "Malwiya Minaret", arabic: "الملوية", x: 76, y: 24, desc: "The spiral minaret of the Great Mosque, built in the 3rd century AH." },
    ],
  },
];

const PILGRIMAGE = [
  { step: "01", t: "Ihram", d: "Enter the state of consecration at the miqat; two white cloths, no stitching, no adornment." },
  { step: "02", t: "Talbiyah", d: "Labbayk Allahumma labbayk — the answer that opens every rite." },
  { step: "03", t: "Tawaf", d: "Seven circuits of the Kaaba beginning and ending at the Black Stone." },
  { step: "04", t: "Salat al-Tawaf", d: "Two rak'ahs behind Maqam Ibrahim." },
  { step: "05", t: "Sa'y", d: "Seven passes between Safa and Marwa." },
  { step: "06", t: "Taqsir / Halq", d: "Trimming or shaving, releasing the state of ihram for Umrah." },
  { step: "07", t: "Arafat", d: "The standing on the ninth of Dhul-Hijjah — the essence of Hajj." },
  { step: "08", t: "Muzdalifah", d: "Night under the open sky; gathering the pebbles." },
  { step: "09", t: "Mina", d: "Stoning the pillars, the sacrifice, and the days of tashriq." },
  { step: "10", t: "Ziyarat", d: "Travel on to Madinah, Najaf, Karbala, Kadhimayn, Samarra and Mashhad." },
];

function MapsPage() {
  const [cityId, setCityId] = useState(CITIES[0]!.id);
  const [site, setSite] = useState<Site | null>(null);
  const city = CITIES.find((c) => c.id === cityId)!;

  return (
    <div className="bg-background text-foreground min-h-screen overflow-x-hidden">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Sacred Maps" }]} />
      <section className="pt-8 pb-16 px-4 md:px-6 max-w-6xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Sacred Geography</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Walk the Holy Cities</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            Five interactive maps — tap any marker to read what happened on that ground.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {CITIES.map((c) => (
            <button
              key={c.id}
              onClick={() => { setCityId(c.id); setSite(null); }}
              aria-pressed={cityId === c.id}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                cityId === c.id ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
              }`}
            >
              {c.name} <span className="font-arabic text-sm ms-1 opacity-60">{c.arabic}</span>
            </button>
          ))}
        </div>

        <div className="mt-10 grid lg:grid-cols-[1fr_320px] gap-px bg-border ring-1 ring-border">
          <div className="relative bg-card aspect-[4/3]">
            <div
              aria-hidden
              className="absolute inset-0 opacity-[0.12] [background-image:linear-gradient(to_right,currentColor_1px,transparent_1px),linear-gradient(to_bottom,currentColor_1px,transparent_1px)] [background-size:40px_40px]"
            />
            <div aria-hidden className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,hsl(var(--gold)/0.12),transparent_60%)]" />
            <span className="absolute top-4 start-4 font-arabic text-3xl text-gold/40">{city.arabic}</span>
            <span className="absolute top-4 end-4 text-[9px] uppercase tracking-[0.3em] text-muted-foreground">{city.country}</span>

            {city.sites.map((s) => (
              <button
                key={s.name}
                onClick={() => setSite(s)}
                aria-label={s.name}
                className="absolute -translate-x-1/2 -translate-y-1/2 group"
                style={{ left: `${s.x}%`, top: `${s.y}%` }}
              >
                <span className={`block size-3.5 rounded-full ring-4 transition-all ${site?.name === s.name ? "bg-gold ring-gold/30 scale-125" : "bg-emerald ring-emerald/20 group-hover:scale-125"}`} />
                <span className="absolute start-1/2 -translate-x-1/2 mt-2 whitespace-nowrap text-[9px] uppercase tracking-[0.2em] text-muted-foreground group-hover:text-gold">
                  {s.name}
                </span>
              </button>
            ))}
          </div>

          <aside className="bg-card p-6">
            <h2 className="font-display italic text-3xl">{city.name}</h2>
            <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{city.blurb}</p>
            <div className="mt-6 border-t border-border pt-5">
              {site ? (
                <>
                  <span className="text-[9px] uppercase tracking-[0.3em] text-gold">Selected site</span>
                  <h3 className="mt-2 font-display text-xl">{site.name}</h3>
                  <span className="font-arabic text-lg text-gold/60 block">{site.arabic}</span>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{site.desc}</p>
                </>
              ) : (
                <p className="text-xs text-muted-foreground">Tap a marker on the map to read about it.</p>
              )}
            </div>
            <ul className="mt-6 space-y-2">
              {city.sites.map((s) => (
                <li key={s.name}>
                  <button onClick={() => setSite(s)} className="text-start text-xs text-muted-foreground hover:text-gold transition-colors">
                    <span className="text-gold/60 me-1.5">▸</span>{s.name}
                  </button>
                </li>
              ))}
            </ul>
          </aside>
        </div>

        <h2 className="mt-20 font-display italic text-3xl">Pilgrimage Guide</h2>
        <p className="mt-2 text-sm text-muted-foreground">Hajj, Umrah and Ziyarat in ten stations.</p>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-5 gap-px bg-border ring-1 ring-border">
          {PILGRIMAGE.map((p) => (
            <div key={p.step} className="bg-card p-5">
              <span className="font-mono-display text-[10px] text-emerald tracking-[0.3em]">{p.step}</span>
              <h3 className="mt-2 font-display text-lg">{p.t}</h3>
              <p className="mt-1.5 text-[11px] text-muted-foreground leading-snug">{p.d}</p>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}