import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/mosques")({
  head: () => ({
    meta: [
      { title: "Mosque Finder — Imam Mahdi Civilization" },
      { name: "description", content: "Find masajid near your location using open data." },
      { property: "og:title", content: "Mosque Finder — Imam Mahdi Civilization" },
      { property: "og:description", content: "Find masajid near your location using open data." },
      { property: "og:url", content: "https://imammahdicivilizition.com/mosques" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/mosques" }],
  }),
  component: MosquesPage,
});

type Mosque = { id: number; name: string; lat: number; lon: number; address?: string };

async function nearby(lat: number, lon: number, radius = 5000): Promise<Mosque[]> {
  const q = `[out:json][timeout:25];(node["amenity"="place_of_worship"]["religion"="muslim"](around:${radius},${lat},${lon});way["amenity"="place_of_worship"]["religion"="muslim"](around:${radius},${lat},${lon}););out center 50;`;
  const r = await fetch("https://overpass-api.de/api/interpreter", { method: "POST", body: q });
  const d = await r.json();
  return (d.elements || []).map((e: any) => ({
    id: e.id,
    name: e.tags?.name || e.tags?.["name:en"] || "Masjid (unnamed)",
    lat: e.lat ?? e.center?.lat,
    lon: e.lon ?? e.center?.lon,
    address: [e.tags?.["addr:street"], e.tags?.["addr:city"]].filter(Boolean).join(", "),
  }));
}

function distanceKm(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLon = ((b.lon - a.lon) * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function MosquesPage() {
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [list, setList] = useState<Mosque[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const find = () => {
    setErr(null);
    if (!navigator.geolocation) { setErr("Geolocation not supported."); return; }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(async p => {
      const c = { lat: p.coords.latitude, lon: p.coords.longitude };
      setCoords(c);
      try {
        const m = await nearby(c.lat, c.lon);
        m.sort((a, b) => distanceKm(c, a) - distanceKm(c, b));
        setList(m);
      } catch (e: any) {
        setErr(e?.message || "Could not load mosques.");
      } finally { setLoading(false); }
    }, e => { setErr(e.message); setLoading(false); });
  };

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Mosque Finder" }]} />
      <section className="pt-8 pb-20 px-6 max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Masājid</span>
          <h1 className="mt-4 font-display italic text-5xl">Mosque Finder</h1>
          <p className="mt-3 text-sm text-muted-foreground">Discover masajid near you. Powered by OpenStreetMap.</p>
          <button onClick={find} className="mt-6 px-6 py-3 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors">
            {loading ? "Searching…" : "Find Mosques Near Me"}
          </button>
          {err && <p className="mt-4 text-sm text-destructive">{err}</p>}
        </div>
        {list.length > 0 && coords && (
          <ul className="divide-y divide-border border border-border bg-card">
            {list.map(m => (
              <li key={m.id} className="p-5 flex justify-between items-center gap-4">
                <div>
                  <div className="font-display text-lg">{m.name}</div>
                  {m.address && <div className="text-xs text-muted-foreground">{m.address}</div>}
                  <div className="text-[10px] text-gold uppercase tracking-widest mt-1 font-mono-display">{distanceKm(coords, m).toFixed(2)} km away</div>
                </div>
                <a href={`https://www.openstreetmap.org/?mlat=${m.lat}&mlon=${m.lon}#map=18/${m.lat}/${m.lon}`} target="_blank" rel="noreferrer"
                  className="text-[11px] uppercase tracking-[0.2em] text-gold hover:underline">Map →</a>
              </li>
            ))}
          </ul>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}