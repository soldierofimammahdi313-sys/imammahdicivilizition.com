import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { LIBRARY_BOOKS, bookBySlug } from "@/lib/library-books";
import { libraryCover } from "@/lib/library-covers";
import { bookTextFor } from "@/lib/library-text";

export const Route = createFileRoute("/library/$slug")({
  loader: ({ params }) => {
    const book = bookBySlug(params.slug);
    if (!book) throw notFound();
    return book;
  },
  head: ({ loaderData }) => {
    const b = loaderData;
    const title = b ? `${b.title} — Digital Library` : "Digital Library";
    const desc = b?.summary ?? "A book in our digital library.";
    const url = `https://imammahdicivilizition.com/library/${b?.slug ?? ""}`;
    return {
      meta: [
        { title },
        { name: "description", content: desc.slice(0, 155) },
        { property: "og:title", content: title },
        { property: "og:description", content: desc.slice(0, 155) },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: url }],
    };
  },
  component: BookPage,
});

function BookPage() {
  const b = Route.useLoaderData();
  const chapters = bookTextFor(b.slug);
  const related = LIBRARY_BOOKS.filter((x) => x.slug !== b.slug && x.category === b.category).slice(0, 3);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Digital Library", to: "/library" }, { label: b.title }]} />

      <article className="pt-4 pb-20 px-6 max-w-4xl mx-auto">
        <div className="overflow-hidden ring-1 ring-border">
          <img
            src={libraryCover(b.slug)}
            alt={`Cover artwork for ${b.title}`}
            width={1280}
            height={640}
            decoding="async"
            className="w-full aspect-[2/1] object-cover"
          />
        </div>

        <header className="mt-8">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">{b.category}</span>
          <h1 className="mt-3 font-display italic text-4xl md:text-5xl leading-tight">{b.title}</h1>
          <p className="mt-2 text-2xl text-muted-foreground" dir="rtl">{b.arabic}</p>
          <p className="mt-3 text-sm text-muted-foreground">{b.author} · {b.era}</p>
          <p className="mt-6 text-lg">{b.summary}</p>
        </header>

        <section className="mt-10">
          <h2 className="font-display text-2xl">About this book</h2>
          <div className="mt-4 space-y-4 text-muted-foreground leading-relaxed">
            {b.about.map((p, i) => <p key={i}>{p}</p>)}
          </div>
        </section>

        <section className="mt-10">
          <h2 className="font-display text-2xl">How it is arranged</h2>
          <ul className="mt-4 space-y-2 text-muted-foreground">
            {b.structure.map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="text-gold">▸</span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </section>

        {chapters.length > 0 && (
          <section className="mt-14 border-t border-border pt-10">
            <h2 className="font-display italic text-3xl">Full reading</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Written for this library in our own words — {chapters.length} chapters.
            </p>
            <div className="mt-8 space-y-10">
              {chapters.map((c, i) => (
                <div key={c.title + i}>
                  <h3 className="font-display text-xl text-gold">
                    {i + 1}. {c.title}
                  </h3>
                  <p className="mt-3 leading-8 text-muted-foreground whitespace-pre-line">{c.body}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="mt-10">
          <h2 className="font-display text-2xl">Read it on this site</h2>
          <div className="mt-4 flex flex-wrap gap-3">
            {b.readOn.map((r) => (
              <Link
                key={r.to + r.label}
                to={r.to}
                className="px-5 py-3 ring-1 ring-border bg-card hover:bg-emerald-soft transition-colors text-sm"
              >
                {r.label} ▸
              </Link>
            ))}
          </div>
        </section>


        {related.length > 0 && (
          <section className="mt-14">
            <h2 className="font-display text-2xl">More in {b.category}</h2>
            <div className="mt-4 grid sm:grid-cols-3 gap-px bg-border ring-1 ring-border">
              {related.map((r) => (
                <Link
                  key={r.slug}
                  to="/library/$slug"
                  params={{ slug: r.slug }}
                  className="bg-card p-5 hover:bg-emerald-soft transition-colors"
                >
                  <h3 className="font-display text-base leading-tight">{r.title}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{r.author}</p>
                </Link>
              ))}
            </div>
          </section>
        )}

        <div className="mt-14">
          <Link to="/library" className="text-sm text-gold uppercase tracking-[0.3em]">◂ Back to the library</Link>
        </div>
      </article>
    </div>
  );
}
