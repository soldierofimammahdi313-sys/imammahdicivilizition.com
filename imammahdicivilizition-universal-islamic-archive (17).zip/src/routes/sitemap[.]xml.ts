import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

import { createClient } from "@supabase/supabase-js";

import { LIBRARY_BOOKS } from "@/lib/library-books";
import { FIQH_SCHOOLS } from "@/lib/fiqh";


const BASE_URL = "https://imammahdicivilizition.com";

interface SitemapEntry {
  path: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const ENTRIES: SitemapEntry[] = [
  { path: "/", changefreq: "daily", priority: "1.0" },
  { path: "/about", changefreq: "monthly", priority: "0.7" },
  { path: "/who-is-imam-mahdi", changefreq: "monthly", priority: "0.9" },
  { path: "/contact", changefreq: "yearly", priority: "0.5" },
  { path: "/quran", changefreq: "weekly", priority: "0.9" },
  { path: "/tafsir-al-mizan", changefreq: "weekly", priority: "0.8" },
  { path: "/hadith", changefreq: "weekly", priority: "0.9" },
  { path: "/duas", changefreq: "weekly", priority: "0.8" },
  { path: "/names", changefreq: "monthly", priority: "0.7" },
  { path: "/articles", changefreq: "daily", priority: "0.9" },
  { path: "/ai", changefreq: "weekly", priority: "0.8" },
  { path: "/academy-ai", changefreq: "weekly", priority: "0.8" },
  { path: "/academy", changefreq: "monthly", priority: "0.6" },
  { path: "/library", changefreq: "weekly", priority: "0.8" },
  { path: "/fiqh", changefreq: "monthly", priority: "0.9" },
  { path: "/founder", changefreq: "yearly", priority: "0.5" },
  { path: "/shop", changefreq: "monthly", priority: "0.5" },
  { path: "/videos", changefreq: "weekly", priority: "0.7" },
  { path: "/daily", changefreq: "daily", priority: "0.8" },
  { path: "/qibla", changefreq: "monthly", priority: "0.7" },
  { path: "/tasbih", changefreq: "monthly", priority: "0.7" },
  { path: "/khatam", changefreq: "monthly", priority: "0.6" },
  { path: "/events", changefreq: "weekly", priority: "0.7" },
  { path: "/zakat", changefreq: "monthly", priority: "0.7" },
  { path: "/inheritance", changefreq: "monthly", priority: "0.7" },
  { path: "/mosques", changefreq: "monthly", priority: "0.6" },
  { path: "/realms", changefreq: "monthly", priority: "0.7" },
  { path: "/modules", changefreq: "weekly", priority: "0.8" },
  { path: "/simulator", changefreq: "monthly", priority: "0.7" },
  { path: "/media", changefreq: "monthly", priority: "0.7" },
  { path: "/isnad", changefreq: "monthly", priority: "0.7" },
  { path: "/timeline", changefreq: "monthly", priority: "0.7" },
  { path: "/battles", changefreq: "monthly", priority: "0.7" },
  { path: "/family-tree", changefreq: "monthly", priority: "0.7" },
  { path: "/flashcards", changefreq: "monthly", priority: "0.7" },
  { path: "/journal", changefreq: "monthly", priority: "0.7" },
  { path: "/citation", changefreq: "monthly", priority: "0.7" },
  { path: "/maps", changefreq: "monthly", priority: "0.7" },
  { path: "/community", changefreq: "weekly", priority: "0.6" },
  { path: "/discussions", changefreq: "daily", priority: "0.8" },
  { path: "/search", changefreq: "weekly", priority: "0.6" },
  { path: "/join", changefreq: "monthly", priority: "0.7" },
  { path: "/donate", changefreq: "monthly", priority: "0.6" },
  { path: "/privacy", changefreq: "yearly", priority: "0.3" },
  { path: "/terms", changefreq: "yearly", priority: "0.3" },
  { path: "/disclaimer", changefreq: "yearly", priority: "0.3" },
  { path: "/cookies", changefreq: "yearly", priority: "0.3" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const dynamic: SitemapEntry[] = [];

        for (let n = 1; n <= 114; n++) {
          dynamic.push({ path: `/quran/${n}`, changefreq: "yearly", priority: "0.6" });
        }

        try {
          const url = process.env["SUPABASE_URL"];
          const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
          if (url && key) {
            const client = createClient(url, key, {
              auth: { persistSession: false },
              global: {
                fetch: (input, init) => {
                  const h = new Headers(init?.headers);
                  if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
                  h.set("apikey", key);
                  return fetch(input, { ...init, headers: h });
                },
              },
            });
            const { data } = await client
              .from("articles")
              .select("slug")
              .eq("status", "published")
              .limit(1000);
            for (const row of data ?? []) {
              dynamic.push({ path: `/articles/${row.slug}`, changefreq: "monthly", priority: "0.8" });
            }

            const { data: posts } = await client
              .from("community_posts")
              .select("id")
              .eq("is_hidden", false)
              .limit(1000);
            for (const row of posts ?? []) {
              dynamic.push({ path: `/discussions/${row.id}`, changefreq: "weekly", priority: "0.5" });
            }
          }
        } catch {
          // A failed database lookup must not break the sitemap.
        }

        for (const school of FIQH_SCHOOLS) {
          dynamic.push({ path: `/fiqh/${school.slug}`, changefreq: "monthly", priority: "0.8" });
        }

        for (const book of LIBRARY_BOOKS) {
          dynamic.push({ path: `/library/${book.slug}`, changefreq: "monthly", priority: "0.6" });
        }

        const urls = [...ENTRIES, ...dynamic].map((e) =>

          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});