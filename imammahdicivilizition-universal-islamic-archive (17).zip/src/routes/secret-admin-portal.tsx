import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  unlockAdmin,
  lockAdmin,
  adminStatus,
  adminListArticles,
  adminSaveArticle,
  adminDeleteArticle,
  adminBackfillCovers,
} from "@/lib/secret-admin.functions";

export const Route = createFileRoute("/secret-admin-portal")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Portal — Imam Mahdi Civilization" },
      { name: "description", content: "Private content portal." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: SecretAdminPortal,
});

type Article = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  content: string;
  status: string;
};

type Draft = { id?: string; slug: string; title: string; excerpt: string; content: string };

const emptyDraft: Draft = { slug: "", title: "", excerpt: "", content: "" };

function SecretAdminPortal() {
  const [unlocked, setUnlocked] = useState(false);
  const [checking, setChecking] = useState(true);
  const [pass, setPass] = useState("");
  const [rows, setRows] = useState<Article[]>([]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [imgBusy, setImgBusy] = useState(false);
  const [imgNote, setImgNote] = useState("");
  const stopRef = useRef(false);

  async function runCoverJob() {
    stopRef.current = false;
    setImgBusy(true);
    let made = 0;
    let missed = 0;
    try {
      for (;;) {
        if (stopRef.current) break;
        const r = await adminBackfillCovers({ data: { limit: 3 } });
        made += r.done;
        missed += r.failed;
        setImgNote(`Images created: ${made} · failed: ${missed} · remaining: ${r.remaining}`);
        if (r.remaining === 0 || (r.done === 0 && r.failed === 0)) break;
        if (r.done === 0 && r.failed > 0) break;
      }
      void load();
    } catch (e) {
      setImgNote(e instanceof Error ? e.message : "Image job failed");
    } finally {
      setImgBusy(false);
    }
  }

  useEffect(() => {
    adminStatus()
      .then((s) => setUnlocked(s.unlocked))
      .finally(() => setChecking(false));
  }, []);

  async function load() {
    try {
      setRows((await adminListArticles()) as Article[]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not load articles");
    }
  }

  useEffect(() => {
    if (unlocked) void load();
  }, [unlocked]);

  if (checking)
    return (
      <Shell>
        <p className="text-sm text-muted-foreground">Checking access…</p>
      </Shell>
    );

  if (!unlocked) {
    return (
      <Shell>
        <form
          className="space-y-3 max-w-sm"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            const res = await unlockAdmin({ data: { password: pass } });
            setBusy(false);
            if (!res.ok) return toast.error("Incorrect passcode");
            setUnlocked(true);
          }}
        >
          <label className="block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            Passcode
          </label>
          <input
            type="password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            className="w-full bg-background border border-border px-3 py-2 text-sm"
            autoFocus
          />
          <button
            type="submit"
            disabled={busy}
            className="border border-gold text-gold px-4 py-2 text-[10px] uppercase tracking-[0.25em]"
          >
            {busy ? "Checking…" : "Unlock"}
          </button>
        </form>
      </Shell>
    );
  }

  async function publish() {
    if (!draft) return;
    setBusy(true);
    try {
      await adminSaveArticle({
        data: {
          id: draft.id,
          slug: draft.slug,
          title: draft.title,
          excerpt: draft.excerpt,
          content: draft.content,
        },
      });
      toast.success("Published");
      setDraft(null);
      void load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Publish failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this article permanently?")) return;
    try {
      await adminDeleteArticle({ data: { id } });
      toast.success("Deleted");
      void load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  }

  return (
    <Shell>
      <div className="mb-6 flex justify-end">
        <button
          onClick={async () => {
            await lockAdmin();
            setUnlocked(false);
            setRows([]);
          }}
          className="border border-border text-muted-foreground px-3 py-1.5 text-[10px] uppercase tracking-[0.25em]"
        >
          Lock
        </button>
      </div>
      {draft ? (
        <div className="space-y-3 max-w-3xl">
          <Field label="Title" value={draft.title} onChange={(v) => setDraft({ ...draft, title: v })} />
          <Field label="Slug (optional)" value={draft.slug} onChange={(v) => setDraft({ ...draft, slug: v })} />
          <Field label="Excerpt" value={draft.excerpt} onChange={(v) => setDraft({ ...draft, excerpt: v })} />
          <label className="block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Content</label>
          <textarea
            value={draft.content}
            onChange={(e) => setDraft({ ...draft, content: e.target.value })}
            rows={16}
            className="w-full bg-background border border-border px-3 py-2 text-sm font-mono"
          />
          <div className="flex gap-3">
            <button
              onClick={publish}
              disabled={busy}
              className="border border-gold text-gold px-4 py-2 text-[10px] uppercase tracking-[0.25em]"
            >
              {busy ? "Publishing…" : "Publish"}
            </button>
            <button
              onClick={() => setDraft(null)}
              className="border border-border text-muted-foreground px-4 py-2 text-[10px] uppercase tracking-[0.25em]"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="mb-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setDraft({ ...emptyDraft })}
              className="border border-gold text-gold px-4 py-2 text-[10px] uppercase tracking-[0.25em]"
            >
              Add New Article
            </button>
            <button
              onClick={imgBusy ? () => (stopRef.current = true) : runCoverJob}
              className="border border-border text-muted-foreground px-4 py-2 text-[10px] uppercase tracking-[0.25em]"
            >
              {imgBusy ? "Stop image job" : "Generate missing images"}
            </button>
            {imgNote && <span className="text-[11px] text-muted-foreground">{imgNote}</span>}
          </div>
          <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
            {rows.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
                <div className="min-w-0">
                  <div className="font-display italic text-lg truncate">{a.title}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {a.status} · /{a.slug}
                  </div>
                </div>
                <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                  <button
                    className="text-gold hover:text-foreground"
                    onClick={() =>
                      setDraft({
                        id: a.id,
                        slug: a.slug,
                        title: a.title,
                        excerpt: a.excerpt ?? "",
                        content: a.content,
                      })
                    }
                  >
                    Edit
                  </button>
                  <button className="text-destructive hover:text-foreground" onClick={() => remove(a.id)}>
                    Delete
                  </button>
                </div>
              </li>
            ))}
            {rows.length === 0 && <li className="p-5 text-sm text-muted-foreground">No articles yet.</li>}
          </ul>
        </>
      )}
    </Shell>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-background border border-border px-3 py-2 text-sm"
      />
    </div>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <main className="mx-auto max-w-5xl px-5 py-16">
      <h1 className="font-display italic text-4xl text-gold mb-8">Secret Admin Portal</h1>
      {children}
    </main>
  );
}
