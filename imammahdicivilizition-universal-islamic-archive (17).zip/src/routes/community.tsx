import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/community.jpg";

export const Route = createFileRoute("/community")({
  head: () => ({
    meta: [
      { title: "Global Community — Imam Mahdi Civilization" },
      { name: "description", content: "Connect with the global Ummah — email, social channels, prayer circles, and regional chapters." },
      { property: "og:title", content: "Global Community — Imam Mahdi Civilization" },
      { property: "og:description", content: "Connect with the global Ummah — channels, prayer circles, and regional chapters." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/community" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/community" }],
  }),
  component: CommunityPage,
});

const CHANNELS = [
  { t: "Email — Join Imam Mahdi Civilization", d: "Direct line to the admin & vanguard.", u: "mailto:imammahdicivilization@gmail.com", k: "Email" },
  { t: "YouTube", d: "Lectures, recitations, documentaries.", u: "https://youtube.com/@imammahdicivilization", k: "YouTube" },
  { t: "Facebook", d: "Community discussion & regional events.", u: "https://www.facebook.com/share/1PWhUxSdSm/", k: "Facebook" },
];

const CIRCLES = [
  { t: "Daily Duʿāʾ al-Faraj", d: "Recite together — every dawn." },
  { t: "Weekly Nahj al-Balagha Circle", d: "One sermon, every Friday." },
  { t: "Tafsir Halaqa", d: "One ayah, deep study, every Sunday." },
  { t: "Youth Vanguard", d: "Under-25 leaders building the future." },
  { t: "Sisters' Halaqa", d: "Women-led study circle." },
  { t: "Reverts' Circle", d: "Support, learning & brotherhood for new Muslims." },
];

function CommunityPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Community" }]} />
      <PageBanner src={bannerImg} alt="Global Community" eyebrow="Ummah" title="One global community" subtitle="Members across continents, united by knowledge and service." />
      <section className="pt-8 pb-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">06 / Global Community</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">One Ummah. Every Continent.</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">Open channels for connection, learning, and shared worship.</p>
        </div>

        <h2 className="mt-4 mb-6 font-display italic text-3xl">Official Channels</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {CHANNELS.map((c) => (
            <a key={c.t} href={c.u} target="_blank" rel="noreferrer"
               className="group bg-card p-7 hover:bg-emerald-soft transition-colors">
              <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{c.k}</span>
              <h3 className="mt-3 font-display text-xl group-hover:text-gold transition-colors">{c.t}</h3>
              <p className="mt-2 text-xs text-muted-foreground">{c.d}</p>
              <span className="mt-3 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">Open ▸</span>
            </a>
          ))}
        </div>

        <h2 className="mt-20 mb-6 font-display italic text-3xl">Prayer & Study Circles</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {CIRCLES.map((c) => (
            <div key={c.t} className="bg-card p-7">
              <h3 className="font-display text-xl">{c.t}</h3>
              <p className="mt-2 text-xs text-muted-foreground">{c.d}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Link to="/discussions" className="inline-block me-4 px-10 py-4 border border-gold text-gold font-bold uppercase text-xs tracking-[0.3em] hover:bg-gold-soft/30 transition-colors">
            Open Discussions
          </Link>
          <Link to="/join" className="inline-block px-10 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors">
            Enlist in the Vanguard
          </Link>
        </div>
      </section>
    </div>
  );
}