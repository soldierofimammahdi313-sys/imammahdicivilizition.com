import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/names")({
  head: () => ({
    meta: [
      { title: "Asma-ul-Husna — The 99 Names of Allah" },
      { name: "description", content: "The 99 beautiful names of Allah with meaning and transliteration." },
      { property: "og:title", content: "Asma-ul-Husna — The 99 Names of Allah" },
      { property: "og:description", content: "The 99 beautiful names of Allah with meaning and transliteration." },
      { property: "og:url", content: "https://imammahdicivilizition.com/names" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/names" }],
  }),
  component: NamesPage,
});

type Name = { number: number; name: string; transliteration: string; en: { meaning: string } };

function NamesPage() {
  const [names, setNames] = useState<Name[]>([]);
  useEffect(() => {
    fetch("https://api.aladhan.com/v1/asmaAlHusna").then(r => r.json()).then(d => setNames(d.data || []));
  }, []);
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "99 Names of Allah" }]} />
      <section className="pt-8 pb-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Asma ul-Husna</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">The 99 Beautiful Names</h1>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {names.map(n => (
            <div key={n.number} className="bg-card p-6 hover:bg-emerald-soft transition-colors">
              <div className="flex justify-between items-center mb-3">
                <span className="font-mono-display text-[10px] text-gold tracking-widest">{String(n.number).padStart(2, "0")}</span>
                <span className="font-arabic text-3xl text-gold">{n.name}</span>
              </div>
              <div className="font-display text-lg">{n.transliteration}</div>
              <div className="text-xs text-muted-foreground mt-1">{n.en.meaning}</div>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}