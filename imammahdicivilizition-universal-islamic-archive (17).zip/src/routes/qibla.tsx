import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";
import { getCoordsSilently, requestCoords } from "@/lib/geo";

export const Route = createFileRoute("/qibla")({
  head: () => ({
    meta: [
      { title: "Qibla Compass — Imam Mahdi Civilization" },
      { name: "description", content: "Find the direction of the Kaaba in Makkah from your location." },
      { property: "og:title", content: "Qibla Compass — Find the Direction of the Kaaba" },
      { property: "og:description", content: "Live compass that points to Makkah from your current location." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/qibla" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/qibla" }],
  }),
  component: QiblaPage,
});

const KAABA = { lat: 21.4225, lng: 39.8262 };

function bearing(lat1: number, lng1: number, lat2: number, lng2: number) {
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

function QiblaPage() {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [heading, setHeading] = useState<number>(0);

  // Location is requested only when the visitor taps the button below, so the
  // page never fires a permission popup on load. If permission was granted in
  // an earlier visit we use it straight away, silently.
  useEffect(() => {
    void getCoordsSilently({ lat: NaN, lng: NaN }).then((c) => {
      if (!Number.isNaN(c.lat)) setCoords(c);
    });
    const onOri = (e: DeviceOrientationEvent) => {
      // @ts-ignore — iOS proprietary
      const h = e.webkitCompassHeading ?? (e.alpha != null ? 360 - e.alpha : 0);
      setHeading(h);
    };
    window.addEventListener("deviceorientation", onOri);
    return () => window.removeEventListener("deviceorientation", onOri);
  }, []);

  const locate = async () => {
    setErr(null);
    try {
      setCoords(await requestCoords());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not read your location.");
    }
  };

  const qibla = coords ? bearing(coords.lat, coords.lng, KAABA.lat, KAABA.lng) : null;
  const rotation = qibla != null ? qibla - heading : 0;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Qibla Compass" }]} />
      <section className="pt-8 pb-20 px-6 max-w-2xl mx-auto text-center">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Al-Qibla</span>
        <h1 className="mt-4 font-display italic text-5xl">Qibla Compass</h1>
        {err && <p className="mt-6 text-sm text-destructive">{err}</p>}
        {!coords && (
          <div className="mt-8">
            <p className="text-sm text-muted-foreground">
              To point the compass towards the Kaaba we need your position — nothing is stored.
            </p>
            <button
              onClick={locate}
              className="mt-4 px-6 py-3 border border-gold text-gold text-[11px] uppercase tracking-[0.3em] hover:bg-gold-soft transition-colors"
            >
              Use my location
            </button>
          </div>
        )}
        {coords && qibla != null && (
          <>
            <div className="mt-12 relative w-72 h-72 mx-auto rounded-full border border-gold/40 bg-card flex items-center justify-center">
              <div className="absolute top-2 text-[10px] text-muted-foreground uppercase tracking-widest">N</div>
              <div className="absolute bottom-2 text-[10px] text-muted-foreground uppercase tracking-widest">S</div>
              <div className="absolute left-2 text-[10px] text-muted-foreground uppercase tracking-widest">W</div>
              <div className="absolute right-2 text-[10px] text-muted-foreground uppercase tracking-widest">E</div>
              <div className="transition-transform duration-300" style={{ transform: `rotate(${rotation}deg)` }}>
                <div className="text-gold text-6xl">↑</div>
                <div className="text-[10px] text-gold uppercase tracking-widest mt-1">Kaaba</div>
              </div>
            </div>
            <p className="mt-8 text-sm text-muted-foreground">Qibla bearing: <span className="text-gold font-mono-display">{qibla.toFixed(1)}°</span></p>
            <p className="text-xs text-muted-foreground mt-2">On mobile, allow motion sensors for live compass rotation.</p>
          </>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}