import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/tafsir-al-mizan")({
  head: () => ({
    meta: [
      { title: "Tafsir al-Mizan — Allamah Tabatabai" },
      { name: "description", content: "Tafsir al-Mizan by Allamah Sayyid Muhammad Husayn Tabatabai — the celebrated Shia exegesis of the Holy Quran." },
      { property: "og:title", content: "Tafsir al-Mizan — Allamah Tabatabai" },
      { property: "og:description", content: "The celebrated Shia exegesis of the Holy Quran by Allamah Sayyid Muhammad Husayn Tabatabai." },
      { property: "og:url", content: "https://imammahdicivilizition.com/tafsir-al-mizan" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/tafsir-al-mizan" }],
  }),
  component: TafsirAlMizanPage,
});

type Surah = { number: number; name: string; englishName: string; englishNameTranslation: string; numberOfAyahs: number; revelationType: string };

function TafsirAlMizanPage() {
  const { t, dir } = useI18n();
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [q, setQ] = useState("");
  useEffect(() => {
    fetch("https://api.alquran.cloud/v1/surah").then(r => r.json()).then(d => setSurahs(d.data || []));
  }, []);

  const filtered = surahs.filter(s =>
    `${s.number} ${s.englishName} ${s.englishNameTranslation} ${s.name}`.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Tafsir al-Mizan" }]} />
      <section className="pt-8 pb-20 px-6 max-w-6xl mx-auto">
        {/* Hero */}
        <div className="text-center mb-16">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">{t("tafsir.hero.label")}</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">{t("tafsir.hero.title")}</h1>
          <p className="mt-4 text-muted-foreground text-sm max-w-2xl mx-auto leading-relaxed">
            {t("tafsir.hero.desc")}
          </p>
          <div className="mt-6 inline-flex items-center gap-3 text-xs text-muted-foreground">
            <span className="px-3 py-1 ring-1 ring-gold/30 text-gold">{t("tafsir.hero.author")}</span>
            <span className="px-3 py-1 ring-1 ring-border">{t("tafsir.hero.lang")}</span>
            <span className="px-3 py-1 ring-1 ring-border">{t("tafsir.hero.volumes")}</span>
          </div>
        </div>

        {/* Author card */}
        <div className="max-w-3xl mx-auto mb-16 bg-card border border-border p-8 md:p-10">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <div className="shrink-0 size-20 rounded-full ring-1 ring-gold/40 flex items-center justify-center bg-gold-soft text-gold font-arabic text-3xl">
              ط
            </div>
            <div>
              <h2 className="font-display italic text-2xl">{t("tafsir.author.name")}</h2>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                {t("tafsir.author.bio")}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="text-[10px] uppercase tracking-widest px-2 py-1 bg-emerald-soft text-emerald">{t("tafsir.tag.philosophy")}</span>
                <span className="text-[10px] uppercase tracking-widest px-2 py-1 bg-emerald-soft text-emerald">{t("tafsir.tag.irfan")}</span>
                <span className="text-[10px] uppercase tracking-widest px-2 py-1 bg-emerald-soft text-emerald">{t("tafsir.tag.fiqh")}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Surah grid */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
          <h3 className="font-display italic text-2xl">{t("tafsir.surahs.title")}</h3>
          <input
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder={t("tafsir.surahs.search")}
            className="w-full sm:w-72 bg-card border border-border px-4 py-2.5 text-sm focus:border-gold outline-none"
            dir={dir}
          />
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {filtered.map(s => (
            <a
              key={s.number}
              href={`https://almizan.org/chapter/${s.number}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-card p-5 hover:bg-emerald-soft transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-4">
                <span className="size-9 rounded-full ring-1 ring-gold/40 flex items-center justify-center text-[11px] font-mono-display text-gold">{s.number}</span>
                <div>
                  <div className="font-display text-lg group-hover:text-gold">{s.englishName}</div>
                  <div className="text-[11px] text-muted-foreground uppercase tracking-widest">{s.englishNameTranslation} · {s.numberOfAyahs} ayat</div>
                </div>
              </div>
              <span className="font-arabic text-2xl text-gold/70 group-hover:text-gold transition-colors">{s.name}</span>
            </a>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground text-sm">{t("tafsir.surahs.empty")}</div>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}
