import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { useI18n } from "@/lib/i18n";
import { FIQH_SCHOOLS, fiqhName, fiqhTagline, useFiqh } from "@/lib/fiqh";
import { openPreferences } from "@/components/site/PreferencesModal";
import { pageHead } from "@/lib/seo";
import { SITE_NAME, SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/fiqh/")({
  head: () => {
    const base = pageHead("/fiqh");
    return {
      ...base,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: "Schools of Islamic Jurisprudence",
            url: `${SITE_URL}/fiqh`,
            isPartOf: { "@type": "WebSite", name: SITE_NAME, url: SITE_URL },
            about: FIQH_SCHOOLS.filter((s) => s.id !== "general").map((s) => ({
              "@type": "Thing",
              name: `${s.name.en} school of jurisprudence`,
              url: `${SITE_URL}/fiqh/${s.slug}`,
            })),
          }),
        },
      ],
    };
  },
  component: FiqhIndexPage,
});

function FiqhIndexPage() {
  const { t, lang } = useI18n();
  const { fiqh, setFiqh } = useFiqh();

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: t("nav.fiqh") }]} />

      <section className="pt-4 pb-16 px-6 max-w-7xl mx-auto">
        <header className="max-w-3xl">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">
            {t("nav.fiqh")}
          </span>
          <h1 className="mt-4 font-display italic text-4xl md:text-5xl leading-tight">
            {t("fiqh.title")}
          </h1>
          <p className="mt-4 text-muted-foreground leading-relaxed">{t("fiqh.subtitle")}</p>
          <p className="mt-4 text-sm text-muted-foreground border-s-2 border-gold/50 ps-4">
            {t("fiqh.note")}
          </p>
        </header>

        <div className="mt-10 grid gap-px bg-border ring-1 ring-border sm:grid-cols-2 lg:grid-cols-3">
          {FIQH_SCHOOLS.map((s) => {
            const active = s.id === fiqh;
            return (
              <article key={s.id} className="bg-card p-7 flex flex-col">
                <div className="flex items-start justify-between gap-3">
                  <h2 className="font-display text-2xl leading-tight">{fiqhName(s, lang)}</h2>
                  {active && (
                    <span className="shrink-0 text-[9px] uppercase tracking-[0.25em] text-gold border border-gold/40 px-2 py-1">
                      {t("fiqh.current")}
                    </span>
                  )}
                </div>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed flex-1">
                  {fiqhTagline(s, lang)}
                </p>
                {s.attributedTo && (
                  <dl className="mt-4 space-y-1 text-xs text-muted-foreground">
                    <div className="flex gap-2">
                      <dt className="uppercase tracking-[0.18em] opacity-70">{t("fiqh.attributedTo")}</dt>
                      <dd className="text-foreground/80">{s.attributedTo}</dd>
                    </div>
                    {s.era && (
                      <div className="flex gap-2">
                        <dt className="uppercase tracking-[0.18em] opacity-70">{t("fiqh.era")}</dt>
                        <dd className="text-foreground/80">{s.era}</dd>
                      </div>
                    )}
                  </dl>
                )}
                <div className="mt-6 flex flex-wrap items-center gap-2">
                  <Link
                    to="/fiqh/$school"
                    params={{ school: s.slug }}
                    className="inline-flex min-h-10 items-center px-3 border border-border text-[10px] uppercase tracking-[0.25em] text-gold hover:border-gold/60 transition-colors"
                  >
                    {t("common.readMore")}
                  </Link>
                  {!active && (
                    <button
                      type="button"
                      onClick={() => setFiqh(s.id)}
                      className="inline-flex min-h-10 items-center px-3 border border-border text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground hover:border-gold/40 transition-colors"
                    >
                      {t("common.apply")}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={openPreferences}
            className="inline-flex min-h-11 items-center px-5 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors"
          >
            {t("nav.preferences")}
          </button>
          <Link
            to="/library"
            className="inline-flex min-h-11 items-center px-5 border border-border text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors"
          >
            {t("nav.library")}
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
