import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { InlineError, ListSkeleton } from "@/components/site/States";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/quran.jpg";
import { breadcrumbLd } from "@/lib/site";
import { SiteFooter } from "@/components/site/SiteFooter";
import { RelatedProducts } from "@/components/site/RelatedProducts";

export const Route = createFileRoute("/quran/")({
  head: () => ({
    meta: [
      { title: "Quran Majeed — All 114 Surahs with Translation" },
      { name: "description", content: "Read all 114 Surahs with Arabic, translation, and recitation." },
      { property: "og:title", content: "Quran Majeed — Read, Translate & Listen" },
      { property: "og:description", content: "All 114 Surahs with Arabic text, translations, tafsir and recitation." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/quran" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/quran" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(breadcrumbLd([{ label: "Quran", to: "/quran" }])) }],
  }),
  component: QuranIndex,
});

type Surah = { number: number; name: string; englishName: string; englishNameTranslation: string; numberOfAyahs: number; revelationType: string };

function QuranIndex() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(false);
    fetch("/quran/index.json")
      .then((r) => r.json())
      .then((d) => {
        if (!active) return;
        setSurahs(Array.isArray(d) ? d : []);
      })
      .catch(() => active && setError(true))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [attempt]);
  const filtered = surahs.filter(s => `${s.number} ${s.englishName} ${s.englishNameTranslation}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Quran" }]} jsonLd={false} />
      <PageBanner src={bannerImg} alt="Quran Majeed" eyebrow="Quran Majeed" title="The Noble Quran" subtitle="All 114 Surahs with translation, tafsir and recitation." />
      <section className="pt-8 pb-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Kitab Allah</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Quran Majeed</h1>
          <div className="mt-3 font-arabic text-3xl text-gold" dir="rtl">القرآن المجيد</div>
          <p className="mt-4 text-muted-foreground text-sm">114 Surahs · 6,236 verses · Arabic with English &amp; Urdu translation and recitation</p>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/tafsir-al-mizan" className="px-5 py-2.5 ring-1 ring-gold/40 text-gold text-[11px] uppercase tracking-[0.2em] hover:bg-gold-soft transition-colors">
              Tafsir al-Mizan
            </Link>
          </div>
        </div>
        <input
          value={q}
          onChange={e => setQ(e.target.value)}
          placeholder="Search surahs…"
          aria-label="Search surahs by name or number"
          className="w-full bg-card border border-border px-4 py-3 mb-6 text-sm focus:border-gold outline-none"
        />
        {loading && <ListSkeleton rows={6} />}
        {error && !loading && <InlineError message="The Quran service is unreachable right now." onRetry={() => setAttempt(a => a + 1)} />}
        {!loading && !error && filtered.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-12">No surah matches “{q}”.</p>
        )}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {filtered.map(s => (
            <Link key={s.number} to="/quran/$num" params={{ num: String(s.number) }} className="bg-card p-5 hover:bg-emerald-soft transition-colors flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <span className="size-9 rounded-full ring-1 ring-gold/40 flex items-center justify-center text-[11px] font-mono-display text-gold">{s.number}</span>
                <div>
                  <div className="font-display text-lg group-hover:text-gold">{s.englishName}</div>
                  <div className="text-[11px] text-muted-foreground uppercase tracking-widest">{s.englishNameTranslation} · {s.numberOfAyahs} ayat</div>
                </div>
              </div>
              <span className="font-arabic text-2xl text-gold/70">{s.name}</span>
            </Link>
          ))}
        </div>
      </section>
      <section className="max-w-5xl mx-auto px-6 pb-16">
        <RelatedProducts topic="quran arabic calligraphy tafsir gift" />
      </section>
      <SiteFooter />
    </div>
  );
}