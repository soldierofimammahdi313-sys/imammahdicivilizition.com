import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Imam Mahdi Civilization" },
      { name: "description", content: "The terms governing your use of the Imam Mahdi Civilization Islamic knowledge platform, its tools, AI assistant and community features." },
      { property: "og:title", content: "Terms of Service — Imam Mahdi Civilization" },
      { property: "og:description", content: "Terms governing use of the Mahdi Civilization Islamic knowledge platform." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/terms" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/terms" }],
  }),
  component: Terms,
});

const SECTIONS = [
  {
    h: "Acceptance",
    p: "By using this platform you agree to these terms. If you do not agree, please discontinue use.",
  },
  {
    h: "Religious content",
    p: "Quranic text, narrations, tafsir and supplications are presented from established sources and third-party scholarly APIs. For rulings that affect your worship or obligations, always refer to your marjaʿ or a qualified scholar.",
  },
  {
    h: "AI assistance",
    p: "The AI assistants answer according to Fiqh Jaʿfariyya (Ithnā ʿAsharī) to the best of their ability, but they are software and can err. AI output is not a fatwa and must not be relied upon as a religious ruling.",
  },
  {
    h: "Calculators and tools",
    p: "Zakat, Khums, inheritance, prayer-time and Qibla tools provide estimates based on standard methods. Verify important calculations with a qualified authority.",
  },
  {
    h: "Accounts and conduct",
    p: "You are responsible for the security of your account and for the content you submit. Content that is unlawful, abusive, sectarian in an inflammatory way, or disrespectful of sanctities may be removed.",
  },
  {
    h: "Contact",
    p: "Questions about these terms may be sent to imammahdicivilization@gmail.com.",
  },
];

function Terms() {
  return (
    <div className="bg-background text-foreground min-h-dvh">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Terms of Service" }]} />
      <main className="max-w-3xl mx-auto px-6 pt-8 pb-24">
        <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Legal</span>
        <h1 className="mt-4 font-display italic text-4xl md:text-5xl">Terms of Service</h1>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          These terms govern your use of the Imam Mahdi Civilization platform.
        </p>
        <div className="mt-12 space-y-10">
          {SECTIONS.map((s) => (
            <section key={s.h}>
              <h2 className="text-lg font-bold uppercase tracking-[0.15em] text-gold">{s.h}</h2>
              <p className="mt-3 text-muted-foreground leading-relaxed">{s.p}</p>
            </section>
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}