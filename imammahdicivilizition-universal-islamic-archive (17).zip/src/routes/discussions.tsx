import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";
import { MessageSquare, Heart, Pin, Lock } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/discussions")({
  head: () => ({
    meta: [
      { title: "Community Discussions — Mahdi Civilization" },
      { name: "description", content: "Ask, answer and reflect together — a moderated space for the global Ummah to discuss Quran, hadith, fiqh and daily life." },
      { property: "og:title", content: "Community Discussions — Mahdi Civilization" },
      { property: "og:description", content: "A moderated discussion space for the global Ummah." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/discussions" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/discussions" }],
  }),
  component: DiscussionsPage,
});

export const CATEGORIES = ["general", "quran", "hadith", "fiqh", "history", "youth", "questions"] as const;

function DiscussionsPage() {
  const qc = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [category, setCategory] = useState<string>("all");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [postCategory, setPostCategory] = useState<string>("general");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const postsQuery = useQuery({
    queryKey: ["discussions", category],
    queryFn: async () => {
      let q = supabase
        .from("community_posts")
        .select("id,title,body,category,author_name,created_at,is_pinned,is_locked")
        .eq("is_hidden", false)
        .order("is_pinned", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(60);
      if (category !== "all") q = q.eq("category", category);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  });

  async function createPost(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return toast.error("Sign in to start a discussion");
    const t = title.trim();
    const b = body.trim();
    if (t.length < 5 || t.length > 160) return toast.error("Title must be between 5 and 160 characters");
    if (b.length < 10 || b.length > 5000) return toast.error("Message must be between 10 and 5000 characters");
    setBusy(true);
    const { error } = await supabase.from("community_posts").insert({
      author_id: user.id,
      title: t,
      body: b,
      category: postCategory,
      author_name: (user.user_metadata?.full_name as string) ?? user.email?.split("@")[0] ?? "Member",
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    setTitle("");
    setBody("");
    toast.success("Discussion published");
    qc.invalidateQueries({ queryKey: ["discussions"] });
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <div className="pt-8 pb-20 px-4 md:px-6 max-w-6xl mx-auto">
          <Breadcrumbs items={[{ label: "Community", to: "/community" }, { label: "Discussions" }]} />
        <header className="mt-6 mb-10">
          <span className="font-arabic text-2xl text-gold/60 block">مجلس النقاش</span>
          <h1 className="mt-2 font-display italic text-4xl md:text-5xl">Community Discussions</h1>
          <p className="mt-3 text-sm text-muted-foreground max-w-2xl">
            A moderated majlis for the global Ummah. Speak with adab, cite your sources, and respect every seeker.
          </p>
        </header>

        <div className="grid lg:grid-cols-[1fr_320px] gap-10">
          <div>
            <div className="flex flex-wrap gap-2 mb-6">
              {["all", ...CATEGORIES].map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`px-3 py-1.5 text-[10px] uppercase tracking-[0.25em] border transition-colors ${
                    category === c ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {postsQuery.isLoading ? (
              <p className="text-sm text-muted-foreground">Loading the majlis…</p>
            ) : (postsQuery.data ?? []).length === 0 ? (
              <div className="border border-dashed border-border p-12 text-center">
                <h3 className="font-display italic text-2xl">No discussions yet</h3>
                <p className="mt-2 text-sm text-muted-foreground">Be the first to open a topic in this category.</p>
              </div>
            ) : (
              <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
                {(postsQuery.data ?? []).map((p) => (
                  <li key={p.id}>
                    <Link to="/discussions/$id" params={{ id: p.id }} className="block p-6 hover:bg-card transition-colors">
                      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-gold">
                        {p.is_pinned && <Pin className="size-3" />}
                        {p.is_locked && <Lock className="size-3" />}
                        {p.category}
                      </div>
                      <h2 className="mt-2 font-display italic text-2xl">{p.title}</h2>
                      <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{p.body}</p>
                      <p className="mt-3 text-[11px] text-muted-foreground">
                        {p.author_name ?? "Member"} · {new Date(p.created_at).toLocaleDateString()}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <aside className="space-y-8">
            <section className="border border-border bg-card/40 p-6">
              <h2 className="font-display italic text-2xl mb-4">Start a discussion</h2>
              {user ? (
                <form onSubmit={createPost} className="space-y-3">
                  <input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Title"
                    maxLength={160}
                    className="w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
                  />
                  <select
                    value={postCategory}
                    onChange={(e) => setPostCategory(e.target.value)}
                    className="w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
                  >
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <textarea
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    rows={5}
                    maxLength={5000}
                    placeholder="Share your question or reflection…"
                    className="w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
                  />
                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full py-3 bg-gold text-primary-foreground text-[11px] font-bold uppercase tracking-[0.25em] disabled:opacity-50"
                  >
                    Publish
                  </button>
                </form>
              ) : (
                <div className="text-sm text-muted-foreground">
                  <p>Sign in to post and reply.</p>
                  <Link to="/auth" className="mt-4 inline-block px-5 py-2.5 border border-gold text-gold text-[10px] uppercase tracking-[0.25em]">
                    Sign in
                  </Link>
                </div>
              )}
            </section>

            <section className="border border-border bg-card/40 p-6 text-xs text-muted-foreground space-y-2">
              <h2 className="font-display italic text-xl text-foreground mb-2">Community guidelines</h2>
              <p>· Speak with adab — no insults, sectarian abuse or takfir.</p>
              <p>· Cite authentic sources when quoting Quran or hadith.</p>
              <p>· No politics of hate, spam, or self-promotion.</p>
              <p>· Respect privacy — never share others' personal data.</p>
              <p>· Moderators may hide, lock or remove any content.</p>
            </section>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1"><MessageSquare className="size-4 text-gold" /> Replies</span>
              <span className="inline-flex items-center gap-1"><Heart className="size-4 text-gold" /> Likes</span>
            </div>
          </aside>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}