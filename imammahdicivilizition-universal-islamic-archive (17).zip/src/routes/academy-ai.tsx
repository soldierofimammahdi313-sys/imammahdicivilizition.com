import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/academy.jpg";
import { AiCreditsNotice } from "@/components/site/AiCreditsNotice";
import { classifyAiError } from "@/lib/ai-errors";
import { createChatTransport } from "@/lib/chat-transport";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { LESSONS, QUIZ_BANK, type Lesson } from "@/lib/academy-curriculum";
import {
  addXp, completeLesson, completeQuiz, last7Days, levelFor, loadProgress, saveProgress,
  type AcademyProgress, EMPTY,
} from "@/lib/academy-progress";
import {
  Send, Square, Sparkles, Trophy, Award, Shield, BookOpen, RotateCcw,
  GraduationCap, Star, Zap, Brain, CheckCircle2, Users, TrendingUp,
} from "lucide-react";

export const Route = createFileRoute("/academy-ai")({
  head: () => ({
    meta: [
      { title: "Mahdi AI Academy — AI Tutor & Tech School for Muslim Kids" },
      { name: "description", content: "Learn Prompt Engineering, AI ethics and digital skills with Ustad Mahdi AI — a live Islamic AI tutor, daily quizzes, XP badges and a parent portal." },
      { property: "og:title", content: "Mahdi AI Academy — Live AI Tutor for Muslim Kids" },
      { property: "og:description", content: "Five guided lessons, a live AI tutor, quizzes and XP tracking — rooted in the values of Ahl al-Bayt (a.s)." },
      { property: "og:url", content: "https://imammahdicivilizition.com/academy-ai" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/academy-ai" }],
  }),
  component: AcademyAiPage,
});

const BADGES = [
  { icon: Star, name: "First Step", desc: "Earn your first XP", need: (p: AcademyProgress) => p.xp > 0 },
  { icon: Sparkles, name: "Prompt Apprentice", desc: "Reach 100 XP", need: (p: AcademyProgress) => p.xp >= 100 },
  { icon: Brain, name: "Quiz Thinker", desc: "Pass 3 quizzes", need: (p: AcademyProgress) => p.quizzesDone.length >= 3 },
  { icon: Shield, name: "Ethical Thinker", desc: "Finish AI Ethics lesson", need: (p: AcademyProgress) => p.lessonsDone.includes("ai-ethics") },
  { icon: Zap, name: "Streak Keeper", desc: "3-day study streak", need: (p: AcademyProgress) => p.streakDays >= 3 },
  { icon: BookOpen, name: "Scholar", desc: "Complete all 5 lessons", need: (p: AcademyProgress) => p.lessonsDone.length >= LESSONS.length },
  { icon: Award, name: "Quiz Master", desc: "Pass every quiz", need: (p: AcademyProgress) => p.quizzesDone.length >= QUIZ_BANK.length },
  { icon: Trophy, name: "AI Scholar", desc: "Reach 1,200 XP", need: (p: AcademyProgress) => p.xp >= 1200 },
];

const LEADERBOARD = [
  { name: "Aisha K.", city: "Istanbul", xp: 4820, avatar: "🌙" },
  { name: "Hussein M.", city: "Karbala", xp: 4610, avatar: "⭐" },
  { name: "Fatima R.", city: "London", xp: 4390, avatar: "🌸" },
  { name: "Ali A.", city: "Tehran", xp: 4120, avatar: "🦁" },
  { name: "Zainab S.", city: "Detroit", xp: 3980, avatar: "🌺" },
  { name: "Yusuf B.", city: "Kuala Lumpur", xp: 3765, avatar: "🌴" },
  { name: "Maryam D.", city: "Cairo", xp: 3540, avatar: "🕊️" },
  { name: "Ibrahim T.", city: "Toronto", xp: 3310, avatar: "🍁" },
];

/* ---------------- progress hook ---------------- */
function useAcademyProgress() {
  const [progress, setProgress] = useState<AcademyProgress>(EMPTY);
  useEffect(() => setProgress(loadProgress()), []);
  const update = useCallback((fn: (p: AcademyProgress) => AcademyProgress) => {
    setProgress((prev) => saveProgress(fn(prev)));
  }, []);
  return { progress, update };
}

function AcademyAiPage() {
  const { progress, update } = useAcademyProgress();
  const lvl = levelFor(progress.xp);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Mahdi AI Academy" }]} />
      <PageBanner src={bannerImg} alt="Mahdi AI Academy" eyebrow="Academy" title="The AI classroom" subtitle="Automated Islamic + technology education for children worldwide." />
      <div className="pt-8 pb-24 px-4 sm:px-6 max-w-7xl mx-auto">
        <Header progress={progress} lvl={lvl} />
        <Tabs defaultValue="classroom" className="mt-8">
          <TabsList className="w-full sm:w-auto grid grid-cols-3 sm:inline-flex h-auto p-1 bg-card border border-gold/20 rounded-xl">
            <TabsTrigger value="classroom" className="gap-2 py-2.5 px-4 data-[state=active]:bg-emerald data-[state=active]:text-primary-foreground rounded-lg">
              <GraduationCap className="size-4" /> <span className="hidden sm:inline">AI Classroom</span><span className="sm:hidden">Class</span>
            </TabsTrigger>
            <TabsTrigger value="parent" className="gap-2 py-2.5 px-4 data-[state=active]:bg-emerald data-[state=active]:text-primary-foreground rounded-lg">
              <Users className="size-4" /> <span className="hidden sm:inline">Parent Portal</span><span className="sm:hidden">Parent</span>
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="gap-2 py-2.5 px-4 data-[state=active]:bg-emerald data-[state=active]:text-primary-foreground rounded-lg">
              <Trophy className="size-4" /> <span className="hidden sm:inline">Leaderboard</span><span className="sm:hidden">Ranks</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classroom" className="mt-6">
            <h2 className="sr-only">AI Classroom</h2>
            <Classroom progress={progress} update={update} />
          </TabsContent>
          <TabsContent value="parent" className="mt-6">
            <h2 className="sr-only">Parent Portal</h2>
            <ParentPortal progress={progress} update={update} lvl={lvl} />
          </TabsContent>
          <TabsContent value="leaderboard" className="mt-6">
            <h2 className="sr-only">Leaderboard</h2>
            <Leaderboard progress={progress} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function Header({ progress, lvl }: { progress: AcademyProgress; lvl: ReturnType<typeof levelFor> }) {
  return (
    <div className="relative overflow-hidden rounded-3xl border border-gold/30 bg-gradient-to-br from-emerald/20 via-card to-background p-6 sm:p-10">
      <div className="absolute -top-24 -right-24 size-64 rounded-full bg-gold/10 blur-3xl" />
      <div className="absolute -bottom-32 -left-16 size-80 rounded-full bg-emerald/20 blur-3xl" />
      <div className="relative flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
        <div>
          <span className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-gold">
            <Sparkles className="size-3" /> Mahdi AI Academy
          </span>
          <h1 className="mt-3 font-display italic text-3xl sm:text-5xl leading-tight">
            A Live <span className="text-gold">AI Tutor</span><br className="hidden sm:block" /> for Muslim Kids.
          </h1>
          <p className="mt-3 text-sm text-muted-foreground max-w-xl">
            Ustad Mahdi AI teaches Prompt Engineering, digital safety and the ethics of technology — 24/7, in your language, rooted in the values of Ahl al-Bayt (a.s).
          </p>
        </div>
        <div className="shrink-0 w-full lg:w-64 rounded-2xl border border-gold/25 bg-background/60 backdrop-blur p-4">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
            <span>Level {lvl.level}</span><span className="text-gold">{progress.xp} XP</span>
          </div>
          <div className="mt-1 font-display italic text-xl text-gold">{lvl.name}</div>
          <Progress value={lvl.pct} className="mt-3 h-2" />
          <div className="mt-2 text-[11px] text-muted-foreground">
            {lvl.next ? `${lvl.next.min - progress.xp} XP to ${lvl.next.name}` : "Highest rank reached 🏆"}
            {progress.streakDays > 0 && <> · 🔥 {progress.streakDays}-day streak</>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- CLASSROOM ---------------- */
const transport = createChatTransport("ustad");

function Classroom({ progress, update }: { progress: AcademyProgress; update: (fn: (p: AcademyProgress) => AcademyProgress) => void }) {
  const [input, setInput] = useState("");
  const [lesson, setLesson] = useState<Lesson>(LESSONS[0]);
  const [aiError, setAiError] = useState<{ kind: "credits" | "rate-limit" | "other"; message: string } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const awardedRef = useRef<Set<string>>(new Set());

  const { messages, sendMessage, setMessages, status, stop } = useChat({
    transport,
    onError: (err) => {
      const kind = classifyAiError(err);
      setAiError({ kind, message: err.message || "Ustad Mahdi could not reply. Please try again." });
      if (kind !== "credits") toast.error("Ustad Mahdi could not reply. Please try again.");
    },
  });

  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  // Award XP whenever the tutor grants a badge ("Badge XP +10").
  useEffect(() => {
    if (busy) return;
    for (const m of messages) {
      if (m.role !== "assistant" || awardedRef.current.has(m.id)) continue;
      const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
      const match = text.match(/XP\s*\+\s*(\d{1,3})/i);
      awardedRef.current.add(m.id);
      if (match) {
        const amount = Math.min(25, parseInt(match[1], 10) || 0);
        if (amount > 0) {
          update((p) => addXp(p, amount));
          toast.success(`MashaAllah! +${amount} XP earned 🏆`);
        }
      }
    }
  }, [messages, busy, update]);

  function submit(text?: string) {
    const v = (text ?? input).trim();
    if (!v || busy) return;
    setAiError(null);
    sendMessage({ text: v });
    if (!text) setInput("");
  }

  function startLesson(l: Lesson) {
    setLesson(l);
    setMessages([]);
    awardedRef.current = new Set();
    setAiError(null);
    sendMessage({ text: l.opener });
  }

  function finishLesson() {
    update((p) => completeLesson(p, lesson.id));
    toast.success(`Lesson complete: ${lesson.title} · +25 XP 🎓`);
  }

  return (
    <div className="grid lg:grid-cols-[1fr_320px] gap-6">
      <div className="rounded-3xl border border-gold/20 bg-card overflow-hidden flex flex-col h-[70vh] min-h-[540px]">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-gradient-to-r from-emerald/20 to-transparent">
          <div className="size-11 rounded-full bg-gradient-to-br from-gold to-amber-600 flex items-center justify-center text-primary-foreground font-bold shadow-lg">
            <GraduationCap className="size-5" />
          </div>
          <div className="min-w-0">
            <div className="font-bold flex items-center gap-2">Ustad Mahdi AI <span className="size-2 rounded-full bg-emerald animate-pulse" /></div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground truncate">
              {lesson.emoji} {lesson.title} · Lesson {LESSONS.indexOf(lesson) + 1} of {LESSONS.length}
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {messages.length > 0 && (
              <button onClick={finishLesson} disabled={progress.lessonsDone.includes(lesson.id)}
                className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest px-3 py-2 rounded-lg bg-emerald/15 text-emerald hover:bg-emerald/25 disabled:opacity-40">
                <CheckCircle2 className="size-3.5" /> {progress.lessonsDone.includes(lesson.id) ? "Done" : "Finish"}
              </button>
            )}
            <button onClick={() => { setMessages([]); awardedRef.current = new Set(); setAiError(null); }}
              aria-label="Restart conversation"
              className="size-9 rounded-lg text-muted-foreground hover:text-gold flex items-center justify-center">
              <RotateCcw className="size-4" />
            </button>
          </div>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 sm:px-6 py-5 space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-10">
              <div className="mx-auto size-14 rounded-2xl bg-gold/15 text-gold flex items-center justify-center"><Sparkles className="size-6" /></div>
              <p className="mt-4 text-sm text-muted-foreground max-w-sm mx-auto">
                Assalamu Alaikum! 🌙 Pick a lesson on the right, or just ask Ustad Mahdi anything about AI, coding or online safety.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {["What is AI?", "Teach me a good prompt", "Is using AI for homework halal?"].map((s) => (
                  <button key={s} onClick={() => submit(s)}
                    className="text-xs px-3 py-2 rounded-full border border-gold/25 hover:border-gold/60 hover:text-gold transition-colors">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => {
            const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
            if (!text) return null;
            if (m.role === "user") {
              return (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[80%] bg-emerald text-primary-foreground px-4 py-2.5 rounded-2xl rounded-br-sm text-sm whitespace-pre-wrap shadow-md">{text}</div>
                </div>
              );
            }
            return (
              <div key={m.id} className="flex gap-3">
                <div className="size-8 rounded-full bg-gradient-to-br from-gold to-amber-600 flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0 shadow-md">M</div>
                <div className="max-w-[85%] px-4 py-3 bg-muted/40 border border-gold/10 rounded-2xl rounded-bl-sm text-sm leading-relaxed prose prose-sm dark:prose-invert prose-p:my-1.5 prose-li:my-0.5 prose-strong:text-gold max-w-none">
                  <ReactMarkdown>{text}</ReactMarkdown>
                </div>
              </div>
            );
          })}

          {status === "submitted" && (
            <div className="flex gap-3">
              <div className="size-8 rounded-full bg-gradient-to-br from-gold to-amber-600 flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0">M</div>
              <div className="flex items-center gap-1 px-4 py-3 bg-muted/40 rounded-2xl rounded-bl-sm">
                <span className="size-1.5 bg-gold/70 rounded-full animate-pulse" />
                <span className="size-1.5 bg-gold/70 rounded-full animate-pulse [animation-delay:.2s]" />
                <span className="size-1.5 bg-gold/70 rounded-full animate-pulse [animation-delay:.4s]" />
              </div>
            </div>
          )}

          {aiError && (
            <AiCreditsNotice
              kind={aiError.kind}
              message={aiError.message}
              onRetry={() => {
                const lastUser = [...messages].reverse().find((m) => m.role === "user");
                const t = lastUser?.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
                setAiError(null);
                if (t) sendMessage({ text: t });
              }}
            />
          )}
        </div>

        <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="border-t border-border p-3 bg-card/60">
          <div className="flex items-center gap-2 border border-border rounded-2xl bg-background pl-4 pr-2 py-1.5 focus-within:border-gold/60">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              aria-label="Message Ustad Mahdi AI"
              placeholder="Type your prompt or question..."
              className="flex-1 bg-transparent text-sm py-2 focus:outline-none"
            />
            {busy ? (
              <button type="button" onClick={() => stop()} aria-label="Stop generating"
                className="size-9 bg-muted text-foreground rounded-full flex items-center justify-center hover:scale-105 transition-transform">
                <Square className="size-3.5" />
              </button>
            ) : (
              <button type="submit" aria-label="Send message" disabled={!input.trim()}
                className="size-9 bg-emerald text-primary-foreground rounded-full flex items-center justify-center disabled:opacity-40 hover:scale-105 transition-transform">
                <Send className="size-4" />
              </button>
            )}
          </div>
          <p className="mt-2 text-center text-[10px] text-muted-foreground">
            Ustad Mahdi AI can make mistakes — always verify religious rulings with your parents or a scholar.
          </p>
        </form>
      </div>

      <div className="space-y-4">
        <LessonList lesson={lesson} progress={progress} onStart={startLesson} />
        <DailyQuiz progress={progress} update={update} />
        <BadgeWall progress={progress} />
      </div>
    </div>
  );
}

function LessonList({ lesson, progress, onStart }: { lesson: Lesson; progress: AcademyProgress; onStart: (l: Lesson) => void }) {
  return (
    <div className="rounded-3xl border border-gold/20 bg-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="size-8 rounded-lg bg-emerald/20 text-emerald flex items-center justify-center"><BookOpen className="size-4" /></div>
        <div className="text-[10px] uppercase tracking-widest text-emerald">Curriculum · {progress.lessonsDone.length}/{LESSONS.length} done</div>
      </div>
      <ul className="space-y-2">
        {LESSONS.map((l, i) => {
          const done = progress.lessonsDone.includes(l.id);
          const active = l.id === lesson.id;
          return (
            <li key={l.id}>
              <button onClick={() => onStart(l)}
                className={`w-full text-left flex items-start gap-3 p-2.5 rounded-xl border transition-colors ${active ? "border-gold/50 bg-gold/5" : "border-transparent hover:bg-muted/40"}`}>
                <span className={`size-6 shrink-0 rounded-full flex items-center justify-center text-[10px] ${done ? "bg-emerald text-primary-foreground" : "border border-border text-muted-foreground"}`}>
                  {done ? "✓" : i + 1}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-medium">{l.emoji} {l.title}</span>
                  <span className="block text-[11px] text-muted-foreground">{l.summary}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function DailyQuiz({ progress, update }: { progress: AcademyProgress; update: (fn: (p: AcademyProgress) => AcademyProgress) => void }) {
  const [open, setOpen] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);
  const nextQuiz = useMemo(() => {
    const remaining = QUIZ_BANK.filter((q) => !progress.quizzesDone.includes(q.id));
    return (remaining.length ? remaining : QUIZ_BANK)[0]!;
  }, [progress.quizzesDone]);
  // The question stays frozen while the dialog is open, so answering it never
  // swaps the wording, the options or the explanation under the child's eyes.
  const [activeQuiz, setActiveQuiz] = useState(nextQuiz);
  const quiz = open ? activeQuiz : nextQuiz;

  function pick(i: number) {
    if (picked !== null) return;
    setPicked(i);
    if (quiz.a[i]!.correct) {
      update((p) => completeQuiz(p, quiz.id));
      toast.success("Correct! +5 XP 🎉");
    }
  }

  return (
    <>
      <button onClick={() => { setActiveQuiz(nextQuiz); setOpen(true); setPicked(null); }}

        className="w-full text-left rounded-3xl border border-gold/20 bg-gradient-to-br from-card to-emerald/10 p-5 hover:border-gold/50 hover:scale-[1.01] transition-all">
        <div className="flex items-center gap-2 mb-3">
          <div className="size-8 rounded-lg bg-gold/20 text-gold flex items-center justify-center"><Brain className="size-4" /></div>
          <div>
            <div className="text-[10px] uppercase tracking-widest text-gold">Daily Quiz</div>
            <div className="text-xs text-muted-foreground">{progress.quizzesDone.length}/{QUIZ_BANK.length} passed · +5 XP</div>
          </div>
        </div>
        <p className="text-sm font-medium">{quiz.q}</p>
        <p className="mt-3 text-[10px] uppercase tracking-widest text-emerald">▶ Start Quiz</p>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="border-gold/30 bg-gradient-to-br from-card via-card to-emerald/10 sm:rounded-2xl max-w-md">
          <DialogHeader>
            <div className="flex items-center gap-2 mb-1">
              <div className="size-8 rounded-lg bg-gold/20 text-gold flex items-center justify-center"><Brain className="size-4" /></div>
              <span className="text-[10px] uppercase tracking-widest text-gold">Daily Quiz · +5 XP</span>
            </div>
            <DialogTitle className="font-display italic text-2xl">{quiz.q}</DialogTitle>
            <DialogDescription>Pick the best answer. You have one try!</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 mt-2">
            {quiz.a.map((opt, i) => {
              const state = picked === null ? "" : opt.correct
                ? "border-emerald bg-emerald/10 text-emerald"
                : picked === i ? "border-destructive/50 bg-destructive/10" : "opacity-50";
              return (
                <button key={i} onClick={() => pick(i)}
                  className={`w-full text-left text-sm p-3.5 rounded-xl border border-border hover:border-gold/50 transition-all ${state}`}>
                  {opt.correct && picked !== null && <CheckCircle2 className="inline size-4 mr-1.5 text-emerald" />}
                  {opt.t}
                </button>
              );
            })}
          </div>
          {picked !== null && (
            <div className={`mt-2 p-3 rounded-xl text-sm font-medium ${quiz.a[picked].correct ? "bg-emerald/15 text-emerald" : "bg-destructive/10 text-destructive"}`}>
              {quiz.a[picked].correct ? "Correct! +5 XP earned 🎉 " : "Not quite — "}{quiz.explain}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function BadgeWall({ progress }: { progress: AcademyProgress }) {
  return (
    <div className="rounded-3xl border border-gold/20 bg-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="size-8 rounded-lg bg-gold/20 text-gold flex items-center justify-center"><Award className="size-4" /></div>
        <div className="text-[10px] uppercase tracking-widest text-gold">Badges</div>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {BADGES.map((b) => {
          const unlocked = b.need(progress);
          const Icon = b.icon;
          return (
            <div key={b.name} title={`${b.name} — ${b.desc}`}
              className={`aspect-square rounded-xl flex items-center justify-center border ${unlocked ? "border-gold/40 bg-gold/10 text-gold" : "border-border bg-muted/20 text-muted-foreground/40"}`}>
              <Icon className="size-5" />
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- PARENT PORTAL ---------------- */
function ParentPortal({ progress, update, lvl }: { progress: AcademyProgress; update: (fn: (p: AcademyProgress) => AcademyProgress) => void; lvl: ReturnType<typeof levelFor> }) {
  const week = last7Days(progress.activity);
  const maxXp = Math.max(20, ...week.map((d) => d.xp));
  const weeklyXp = week.reduce((s, d) => s + d.xp, 0);
  const lessonPct = Math.round((progress.lessonsDone.length / LESSONS.length) * 100);
  const quizPct = Math.round((progress.quizzesDone.length / QUIZ_BANK.length) * 100);
  const unlocked = BADGES.filter((b) => b.need(progress));

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-gold/20 bg-card p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="size-16 rounded-2xl bg-gradient-to-br from-emerald to-emerald/60 flex items-center justify-center text-3xl">🌙</div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-gold">Student</div>
              <input
                value={progress.studentName}
                onChange={(e) => update((p) => ({ ...p, studentName: e.target.value }))}
                placeholder="Add your child's name"
                aria-label="Student name"
                className="text-2xl font-bold bg-transparent border-b border-transparent focus:border-gold/40 focus:outline-none w-full max-w-xs"
              />
              <div className="text-xs text-muted-foreground mt-1">Level {lvl.level} · {lvl.name} · {progress.xp} XP · 🔥 {progress.streakDays}-day streak</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={TrendingUp} label="XP This Week" value={`${weeklyXp}`} tone="emerald">
          <Progress value={Math.min(100, weeklyXp / 2)} className="mt-3 h-2" />
        </StatCard>
        <StatCard icon={BookOpen} label="Lessons Completed" value={`${progress.lessonsDone.length} / ${LESSONS.length}`} tone="gold">
          <Progress value={lessonPct} className="mt-3 h-2" />
        </StatCard>
        <StatCard icon={Shield} label="Quizzes Passed" value={`${progress.quizzesDone.length} / ${QUIZ_BANK.length}`} tone="emerald">
          <Progress value={quizPct} className="mt-3 h-2" />
        </StatCard>
        <StatCard icon={Zap} label="Study Streak" value={`${progress.streakDays} days`} tone="gold">
          <div className="mt-3 flex gap-1">
            {week.map((d) => (
              <div key={d.day} className={`h-2 flex-1 rounded-full ${d.xp > 0 ? "bg-gold" : "bg-muted"}`} />
            ))}
          </div>
        </StatCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-3xl border border-gold/20 bg-card p-6">
          <h3 className="font-display italic text-xl mb-4">Weekly Activity</h3>
          <div className="flex items-end gap-2 h-40">
            {week.map((d) => (
              <div key={d.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                <span className="text-[10px] text-muted-foreground">{d.xp || ""}</span>
                <div className="w-full bg-gradient-to-t from-emerald to-gold rounded-t-lg transition-all"
                  style={{ height: `${Math.max(4, (d.xp / maxXp) * 100)}%` }} />
                <span className="text-[10px] text-muted-foreground">{d.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-gold/20 bg-card p-6">
          <h3 className="font-display italic text-xl mb-4">Badges Earned</h3>
          {unlocked.length === 0 ? (
            <p className="text-sm text-muted-foreground">No badges yet — start Lesson 1 in the AI Classroom to earn the first one.</p>
          ) : (
            <ul className="space-y-3">
              {unlocked.map((b) => (
                <li key={b.name} className="flex items-center gap-3 p-3 rounded-xl bg-muted/30">
                  <span className="size-9 rounded-lg bg-gold/15 text-gold flex items-center justify-center"><b.icon className="size-4" /></span>
                  <div className="flex-1">
                    <div className="text-sm">{b.name}</div>
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest">{b.desc}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Progress is stored privately on this device — no child data leaves the browser.
      </p>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, tone, children }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; tone: "gold" | "emerald"; children?: React.ReactNode }) {
  const color = tone === "gold" ? "text-gold" : "text-emerald";
  const bg = tone === "gold" ? "bg-gold/10" : "bg-emerald/10";
  return (
    <div className="rounded-2xl border border-gold/20 bg-card p-5">
      <div className={`size-9 rounded-lg ${bg} ${color} flex items-center justify-center mb-3`}>
        <Icon className="size-4" />
      </div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={`text-2xl font-bold ${color} mt-1`}>{value}</div>
      {children}
    </div>
  );
}

/* ---------------- LEADERBOARD ---------------- */
function Leaderboard({ progress }: { progress: AcademyProgress }) {
  const rows = useMemo(() => {
    const you = { name: progress.studentName || "You", city: "Your device", xp: progress.xp, avatar: "🎓", you: true };
    return [...LEADERBOARD.map((r) => ({ ...r, you: false })), you].sort((a, b) => b.xp - a.xp);
  }, [progress.studentName, progress.xp]);

  return (
    <div className="grid lg:grid-cols-[1fr_1.1fr] gap-6">
      <div className="rounded-3xl border border-gold/20 bg-card overflow-hidden">
        <div className="p-5 border-b border-border bg-gradient-to-r from-gold/10 to-transparent">
          <div className="flex items-center gap-2">
            <Trophy className="size-5 text-gold" />
            <h3 className="font-display italic text-xl">Global Top Students</h3>
          </div>
          <p className="text-[11px] text-muted-foreground mt-1">Sample cohort · your own XP is tracked live</p>
        </div>
        <ul>
          {rows.map((s, i) => (
            <li key={s.name + i}
              className={`flex items-center gap-3 px-5 py-3 border-b border-border/50 last:border-0 ${s.you ? "bg-emerald/10" : ""}`}>
              <span className={`w-6 text-sm font-bold ${i < 3 ? "text-gold" : "text-muted-foreground"}`}>{i + 1}</span>
              <span className="text-xl">{s.avatar}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{s.name}{s.you && <span className="ml-2 text-[10px] uppercase tracking-widest text-emerald">You</span>}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest">{s.city}</div>
              </div>
              <span className="text-sm font-bold text-gold">{s.xp.toLocaleString()}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-3xl border border-gold/20 bg-card p-6">
        <h3 className="font-display italic text-xl mb-4">Badge Collection</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {BADGES.map((b) => {
            const unlocked = b.need(progress);
            const Icon = b.icon;
            return (
              <div key={b.name}
                className={`rounded-2xl border p-4 text-center ${unlocked ? "border-gold/40 bg-gold/5" : "border-border bg-muted/20 opacity-60"}`}>
                <div className={`mx-auto size-10 rounded-xl flex items-center justify-center ${unlocked ? "bg-gold/15 text-gold" : "bg-muted text-muted-foreground"}`}>
                  <Icon className="size-5" />
                </div>
                <div className="mt-2 text-xs font-semibold">{b.name}</div>
                <div className="text-[10px] text-muted-foreground">{b.desc}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
