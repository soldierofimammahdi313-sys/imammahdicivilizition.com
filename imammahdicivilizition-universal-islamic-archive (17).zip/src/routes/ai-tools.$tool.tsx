import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { createChatTransport } from "@/lib/chat-transport";
import { useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { Send, Square, Volume2, Sparkles, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site/SiteHeader";
import { AiCreditsNotice } from "@/components/site/AiCreditsNotice";
import { classifyAiError } from "@/lib/ai-errors";

type ToolConfig = {
  persona: string;
  name: string;
  arabic: string;
  tagline: string;
  placeholder: string;
  suggestions: string[];
};

const TOOLS: Record<string, ToolConfig> = {
  timeline: {
    persona: "timeline",
    name: "AI Islamic Timeline",
    arabic: "الخط الزمني",
    tagline: "Ask any year — CE or Hijri — and receive the events that shaped it.",
    placeholder: "e.g. 61 AH, or 680 CE, or “the year of Ghadir”…",
    suggestions: ["61 AH — the year of Karbala", "10 AH — Ghadir Khumm", "What happened in 260 AH?", "Timeline of Imam al-Mahdi's occultation"],
  },
  debate: {
    persona: "debate",
    name: "AI Debate Analyzer",
    arabic: "محلل المناظرة",
    tagline: "Paste any argument — get claims, evidence, and fallacies, laid bare.",
    placeholder: "Paste the argument or claim you want analyzed…",
    suggestions: ["Analyze: “Islam spread only by the sword.”", "Analyze this claim about the caliphate after the Prophet (s)"],
  },
  fatwa: {
    persona: "fatwa",
    name: "AI Fatwa Finder",
    arabic: "باحث الفتاوى",
    tagline: "Ja'fari rulings by marja' and topic — with sources.",
    placeholder: "e.g. “khums on savings — Sistani”…",
    suggestions: ["Khums on savings — Sistani", "Fasting while traveling — Khamenei", "Tattoo ruling — Makarem Shirazi", "Combining prayers in Ja'fari fiqh"],
  },
  grammar: {
    persona: "grammar",
    name: "AI Arabic Grammar Assistant",
    arabic: "الإعراب",
    tagline: "I'rab, morphology and root analysis of any Arabic text.",
    placeholder: "Paste an Arabic word, phrase or verse…",
    suggestions: ["إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ", "بسم الله الرحمن الرحيم — full i'rab", "Analyze the verb كَتَبَ"],
  },
  voice: {
    persona: "voice",
    name: "AI Voice Teacher",
    arabic: "معلم التلاوة",
    tagline: "Tajwid coaching — segment any verse and practice it slowly.",
    placeholder: "Paste the verse you want to recite correctly…",
    suggestions: ["Teach me Surah Al-Fatiha with tajwid", "آية الكرسي — recitation drill", "Common mistakes in Surah Al-Ikhlas"],
  },
  summarize: {
    persona: "summarize",
    name: "AI Summarizer & Scanner",
    arabic: "الملخص",
    tagline: "Paste long texts or OCR scans — receive the argument, condensed.",
    placeholder: "Paste a long article, book excerpt, or scanned text…",
    suggestions: [],
  },
};

export const Route = createFileRoute("/ai-tools/$tool")({
  beforeLoad: ({ params }) => {
    if (!TOOLS[params.tool]) throw notFound();
  },
  head: ({ params }) => {
    const t = TOOLS[params.tool];
    return {
      meta: [
        { title: `${t?.name ?? "AI Tool"} — Imam Mahdi Civilization` },
        { name: "description", content: t?.tagline ?? "Live AI tool of Imam Mahdi Civilization." },
        { property: "og:title", content: `${t?.name ?? "AI Tool"} — Imam Mahdi Civilization` },
        { property: "og:description", content: t?.tagline ?? "" },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
      ],
      links: [{ rel: "canonical", href: `https://imammahdicivilizition.com/ai-tools/${params.tool}` }],
    };
  },
  component: AiToolPage,
});

function messageText(m: { parts?: Array<{ type: string; text?: string }> }): string {
  return (m.parts ?? []).filter((p) => p.type === "text").map((p) => p.text ?? "").join("");
}

function speak(text: string) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text.slice(0, 1200));
  u.lang = /[؀-ۿ]/.test(text) ? "ar-SA" : "en-US";
  u.rate = 0.85;
  window.speechSynthesis.speak(u);
}

function AiToolPage() {
  const { tool } = Route.useParams();
  const config = TOOLS[tool];
  const transport = useMemo(() => createChatTransport(config.persona), [config.persona]);
  const [input, setInput] = useState("");
  const [aiError, setAiError] = useState<{ kind: "credits" | "rate-limit" | "other"; message: string } | null>(null);
  const { messages, sendMessage, status, stop } = useChat({
    transport,
    onError: (err) => {
      const kind = classifyAiError(err);
      setAiError({ kind, message: err.message || "AI could not respond. Please try again." });
      if (kind !== "credits") toast.error(err.message || "AI could not respond.");
    },
  });
  const scrollRef = useRef<HTMLDivElement>(null);
  const busy = status === "streaming" || status === "submitted";

  function submit(text: string) {
    const v = text.trim();
    if (!v || busy) return;
    setAiError(null);
    sendMessage({ text: v });
    setInput("");
    setTimeout(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }), 100);
  }

  return (
    <div className="bg-background text-foreground min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1 max-w-3xl w-full mx-auto px-6 pt-10 pb-40 flex flex-col">
        <Link to="/modules" className="inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-gold transition-colors mb-6 w-fit">
          <ArrowLeft size={14} /> All modules
        </Link>
        <div className="flex items-start justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Live AI Tool</span>
            <h1 className="mt-3 font-display text-3xl sm:text-4xl">{config.name}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{config.tagline}</p>
          </div>
          <span className="font-arabic text-3xl text-gold/70 shrink-0">{config.arabic}</span>
        </div>

        {aiError?.kind === "credits" && <div className="mt-6"><AiCreditsNotice kind="credits" message={aiError.message} /></div>}

        <div ref={scrollRef} className="mt-8 flex-1 space-y-6 overflow-y-auto">
          {messages.length === 0 && (
            <div className="surface-card p-8 text-center">
              <Sparkles className="mx-auto text-gold/70" size={22} />
              <p className="mt-4 text-sm text-muted-foreground">This tool is live — ask below.</p>
              {config.suggestions.length > 0 && (
                <div className="mt-6 flex flex-wrap justify-center gap-2">
                  {config.suggestions.map((s) => (
                    <button
                      key={s}
                      onClick={() => submit(s)}
                      className="px-4 py-2 text-xs ring-1 ring-border hover:ring-gold/50 hover:text-gold transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}>
              <div className={m.role === "user" ? "max-w-[85%] bg-gold-soft ring-1 ring-gold/25 px-5 py-3 text-sm" : "w-full surface-card px-6 py-5"}>
                {m.role === "user" ? (
                  <p className="whitespace-pre-wrap">{messageText(m)}</p>
                ) : (
                  <>
                    <div className="prose prose-invert prose-sm max-w-none [&_table]:text-xs">
                      <ReactMarkdown>{messageText(m)}</ReactMarkdown>
                    </div>
                    <button
                      onClick={() => speak(messageText(m))}
                      className="mt-3 inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground hover:text-gold transition-colors"
                      title="Listen"
                    >
                      <Volume2 size={12} /> Listen
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
          {busy && <p className="text-xs text-muted-foreground animate-pulse">AI is thinking…</p>}
        </div>

        <div className="sticky bottom-0 mt-6 bg-background pt-3 pb-4 border-t border-border">
          <div className="flex gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  submit(input);
                }
              }}
              rows={2}
              placeholder={config.placeholder}
              className="flex-1 bg-card ring-1 ring-border focus:ring-gold/50 outline-none px-4 py-3 text-sm resize-none"
            />
            {busy ? (
              <button onClick={stop} aria-label="Stop" className="px-4 bg-destructive/20 ring-1 ring-destructive/40 text-destructive-foreground">
                <Square size={16} />
              </button>
            ) : (
              <button onClick={() => submit(input)} aria-label="Send" className="px-5 bg-gold text-primary-foreground font-bold hover:opacity-90 transition-opacity">
                <Send size={16} />
              </button>
            )}
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground/70">Answers are AI-generated — verify religious rulings with your marja'.</p>
        </div>
      </main>
    </div>
  );
}
