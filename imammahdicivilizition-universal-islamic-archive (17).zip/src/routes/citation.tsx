import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/citation")({
  head: () => ({
    meta: [
      { title: "Citation Generator — Qur'an, Hadith & Books | Imam Mahdi Civilization" },
      { name: "description", content: "Generate correctly formatted references to the Qur'an, hadith collections and Islamic books in Chicago, APA, MLA and classical hawza style." },
      { property: "og:title", content: "Islamic Citation Generator" },
      { property: "og:description", content: "Format references to Qur'an, hadith and classical books in four citation styles." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/citation" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/citation" }],
  }),
  component: CitationPage,
});

type Source = "quran" | "hadith" | "book";
type Style = "chicago" | "apa" | "mla" | "hawza";

const STYLES: { s: Style; label: string }[] = [
  { s: "chicago", label: "Chicago" },
  { s: "apa", label: "APA" },
  { s: "mla", label: "MLA" },
  { s: "hawza", label: "Hawza" },
];

function CitationPage() {
  const [source, setSource] = useState<Source>("quran");
  const [style, setStyle] = useState<Style>("chicago");
  const [copied, setCopied] = useState(false);

  const [surah, setSurah] = useState("Al-Baqarah");
  const [surahNo, setSurahNo] = useState("2");
  const [ayah, setAyah] = useState("255");
  const [translator, setTranslator] = useState("Ali Quli Qarai");

  const [collection, setCollection] = useState("al-Kafi");
  const [compiler, setCompiler] = useState("Muhammad ibn Ya'qub al-Kulayni");
  const [volume, setVolume] = useState("1");
  const [page, setPage] = useState("32");
  const [hadithNo, setHadithNo] = useState("4");

  const [bookTitle, setBookTitle] = useState("Al-Mizan fi Tafsir al-Qur'an");
  const [author, setAuthor] = useState("Muhammad Husayn Tabatabai");
  const [publisher, setPublisher] = useState("WOFIS");
  const [city, setCity] = useState("Tehran");
  const [year, setYear] = useState("1983");

  const citation = useMemo(() => {
    if (source === "quran") {
      const ref = `${surah} ${surahNo}:${ayah}`;
      if (style === "apa") return `The Qur'an (${translator}, Trans.). (n.d.). ${ref}.`;
      if (style === "mla") return `The Qur'an. Translated by ${translator}, ${ref}.`;
      if (style === "hawza") return `القرآن الكريم، سورة ${surah} (${surahNo})، الآية ${ayah}.`;
      return `Qur'an ${surahNo}:${ayah} (${surah}), trans. ${translator}.`;
    }
    if (source === "hadith") {
      if (style === "apa") return `${compiler}. ${collection} (Vol. ${volume}, p. ${page}, hadith ${hadithNo}).`;
      if (style === "mla") return `${compiler}. ${collection}. Vol. ${volume}, hadith ${hadithNo}, p. ${page}.`;
      if (style === "hawza") return `${compiler}، ${collection}، ج${volume}، ص${page}، ح${hadithNo}.`;
      return `${compiler}, ${collection}, vol. ${volume} (hadith ${hadithNo}), ${page}.`;
    }
    if (style === "apa") return `${author}. (${year}). ${bookTitle}. ${city}: ${publisher}.`;
    if (style === "mla") return `${author}. ${bookTitle}. ${publisher}, ${year}.`;
    if (style === "hawza") return `${author}، ${bookTitle}، ${city}: ${publisher}، ${year}م.`;
    return `${author}, ${bookTitle} (${city}: ${publisher}, ${year}).`;
  }, [source, style, surah, surahNo, ayah, translator, collection, compiler, volume, page, hadithNo, bookTitle, author, publisher, city, year]);

  function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
    return (
      <label className="block">
        <span className="text-[9px] uppercase tracking-[0.28em] text-muted-foreground">{label}</span>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="mt-1.5 w-full bg-background border border-border focus:border-gold/60 focus:outline-none px-3 py-2.5 text-sm"
        />
      </label>
    );
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Citation Generator" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-4xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Research / Citation</span>
          <h1 className="mt-4 font-display italic text-5xl">Cite It Correctly</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-xl mx-auto">
            Qur'an, hadith and classical books — formatted in four scholarly styles.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap gap-2 justify-center">
          {(["quran", "hadith", "book"] as Source[]).map((s) => (
            <button
              key={s}
              onClick={() => setSource(s)}
              aria-pressed={source === s}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                source === s ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
              }`}
            >
              {s === "quran" ? "Qur'an" : s === "hadith" ? "Hadith" : "Book"}
            </button>
          ))}
        </div>

        <div className="mt-8 bg-card border border-border p-6 grid sm:grid-cols-2 gap-4">
          {source === "quran" && (
            <>
              <Field label="Surah name" value={surah} onChange={setSurah} />
              <Field label="Surah number" value={surahNo} onChange={setSurahNo} />
              <Field label="Ayah(s)" value={ayah} onChange={setAyah} />
              <Field label="Translator" value={translator} onChange={setTranslator} />
            </>
          )}
          {source === "hadith" && (
            <>
              <Field label="Collection" value={collection} onChange={setCollection} />
              <Field label="Compiler" value={compiler} onChange={setCompiler} />
              <Field label="Volume" value={volume} onChange={setVolume} />
              <Field label="Page" value={page} onChange={setPage} />
              <Field label="Hadith number" value={hadithNo} onChange={setHadithNo} />
            </>
          )}
          {source === "book" && (
            <>
              <Field label="Title" value={bookTitle} onChange={setBookTitle} />
              <Field label="Author" value={author} onChange={setAuthor} />
              <Field label="Publisher" value={publisher} onChange={setPublisher} />
              <Field label="City" value={city} onChange={setCity} />
              <Field label="Year" value={year} onChange={setYear} />
            </>
          )}
        </div>

        <div className="mt-6 flex flex-wrap gap-2 justify-center">
          {STYLES.map((s) => (
            <button
              key={s.s}
              onClick={() => setStyle(s.s)}
              aria-pressed={style === s.s}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                style === s.s ? "border-emerald text-emerald bg-emerald-soft" : "border-border text-muted-foreground hover:text-emerald"
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="mt-6 bg-card border border-gold/40 p-7">
          <span className="text-[9px] uppercase tracking-[0.3em] text-gold">Formatted reference</span>
          <p className="mt-3 text-lg leading-relaxed" dir={style === "hawza" ? "rtl" : "ltr"}>{citation}</p>
          <button
            onClick={() => {
              void navigator.clipboard.writeText(citation).then(() => {
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
              });
            }}
            className="mt-5 px-8 py-3 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-foreground transition-colors"
          >
            {copied ? "Copied ✓" : "Copy citation"}
          </button>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}