import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/duas")({
  head: () => ({
    meta: [
      { title: "Duas & Adhkar — Imam Mahdi Civilization" },
      { name: "description", content: "Daily supplications, morning and evening remembrance from the Sunnah." },
      { property: "og:title", content: "Duas & Adhkar — Imam Mahdi Civilization" },
      { property: "og:description", content: "Daily supplications, morning and evening remembrance from the Sunnah." },
      { property: "og:url", content: "https://imammahdicivilizition.com/duas" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/duas" }],
  }),
  component: DuasPage,
});

const DUAS = [
  { t: "Upon Waking", a: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", e: "Praise is to Allah who gave us life after death, and to Him is the resurrection." },
  { t: "Before Eating", a: "بِسْمِ اللَّهِ", e: "In the name of Allah." },
  { t: "After Eating", a: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ", e: "Praise is to Allah who fed me this and provided it for me." },
  { t: "Entering the Home", a: "بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى رَبِّنَا تَوَكَّلْنَا", e: "In Allah's name we enter, in Allah's name we leave, and upon our Lord we rely." },
  { t: "Leaving the Home", a: "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", e: "In Allah's name, I rely upon Allah, there is no might or power except with Allah." },
  { t: "Before Sleep", a: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", e: "In Your name, O Allah, I die and I live." },
  { t: "Anxiety & Distress", a: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ", e: "O Allah, I seek refuge in You from anxiety and sorrow." },
  { t: "Seeking Forgiveness", a: "أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ", e: "I seek the forgiveness of Allah, none has the right to be worshipped except Him, the Living, the Sustainer, and I repent to Him." },
];

const MORNING = [
  { a: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ", e: "We have reached the morning and at this very time all sovereignty belongs to Allah." },
  { a: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ", e: "O Allah, by You we enter the morning, by You we enter the evening, by You we live and die, and to You is the resurrection." },
];

const EVENING = [
  { a: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ", e: "We have reached the evening and at this very time all sovereignty belongs to Allah." },
  { a: "اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ", e: "O Allah, what blessing I have this evening is from You alone, without partner." },
];

function Section({ title, items }: { title: string; items: { t?: string; a: string; e: string }[] }) {
  return (
    <div className="mb-16">
      <h2 className="font-display italic text-3xl mb-6 text-gold">{title}</h2>
      <div className="space-y-4">
        {items.map((d, i) => (
          <div key={i} className="border border-border bg-card p-6">
            {d.t && <div className="text-[10px] text-gold uppercase tracking-widest mb-3">{d.t}</div>}
            <p dir="rtl" className="font-arabic text-2xl leading-loose text-right">{d.a}</p>
            <p className="mt-4 text-sm text-muted-foreground italic">{d.e}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function DuasPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Duas & Adhkar" }]} />
      <section className="pt-8 pb-20 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Adʿiyah</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Duas & Adhkar</h1>
          <p className="mt-4 text-sm text-muted-foreground">Also explore <Link to="/names" className="text-gold hover:underline">the 99 Names of Allah</Link>.</p>
        </div>
        <Section title="Morning Remembrance" items={MORNING} />
        <Section title="Evening Remembrance" items={EVENING} />
        <Section title="Daily Supplications" items={DUAS} />
      </section>
      <SiteFooter />
    </div>
  );
}