import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { VIDEO_CHANNELS as CHANNELS, VIDEO_COLLECTIONS as COLLECTIONS } from "@/lib/catalog";

export const Route = createFileRoute("/videos")({
  head: () => ({
    meta: [
      { title: "Video Center — Imam Mahdi Civilization" },
      { name: "description", content: "Curated Islamic lectures, recitations, and documentaries from the world's leading scholars." },
      { property: "og:title", content: "Video Center — Imam Mahdi Civilization" },
      { property: "og:description", content: "Curated Islamic lectures, recitations and documentaries across twelve themes." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/videos" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/videos" }],
  }),
  component: VideosPage,
});



function VideosPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Video Center" }]} />
      <section className="pt-8 pb-16 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">02 / Video Center</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Cinema of the Ummah</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">Hand-picked playlists across 12 themes — opens in YouTube. Curated weekly by Imam Mahdi Civilization.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {COLLECTIONS.map((c, i) => (
            <a key={c.t} href={`https://www.youtube.com/results?search_query=${encodeURIComponent(c.q)}`} target="_blank" rel="noreferrer"
               className="group bg-card p-7 hover:bg-emerald-soft transition-colors flex flex-col justify-between min-h-[180px]">
              <div className="flex justify-between items-start">
                <span className="font-mono-display text-[10px] text-emerald tracking-widest">{String(i + 1).padStart(2, "0")}</span>
                <span className="font-arabic text-2xl text-gold/60">{c.a}</span>
              </div>
              <div className="mt-6">
                <h3 className="font-display text-2xl group-hover:text-gold transition-colors">{c.t}</h3>
                <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{c.c}</p>
                <span className="mt-3 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">Watch ▸</span>
              </div>
            </a>
          ))}
        </div>

        <h2 className="mt-24 mb-8 text-center font-display italic text-3xl">Official Channels</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {CHANNELS.map((ch) => (
            <a key={ch.n} href={ch.u} target="_blank" rel="noreferrer"
               className="border border-border p-5 hover:border-gold/50 hover:bg-card transition-colors">
              <span className="text-[10px] uppercase tracking-[0.3em] text-gold">YouTube</span>
              <p className="mt-2 font-bold text-sm">{ch.n}</p>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}