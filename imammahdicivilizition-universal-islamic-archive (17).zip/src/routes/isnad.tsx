import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/isnad")({
  head: () => ({
    meta: [
      { title: "Chain of Narrators (Isnad) Viewer | Imam Mahdi Civilization" },
      { name: "description", content: "Visualise the chain of transmission behind famous narrations — every narrator, their status in rijal, and the grade of the resulting report." },
      { property: "og:title", content: "Chain of Narrators Viewer" },
      { property: "og:description", content: "See the isnad of Thaqalayn, Ghadir, Kisa and more — narrator by narrator." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/isnad" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/isnad" }],
  }),
  component: IsnadPage,
});

type Narrator = { name: string; era: string; status: "thiqa" | "reliable" | "debated"; note: string };
type Report = { title: string; arabic: string; grade: string; source: string; matn: string; chain: Narrator[] };

const REPORTS: Report[] = [
  {
    title: "Hadith al-Thaqalayn", arabic: "حدیث الثقلین", grade: "Mutawatir — mass-transmitted",
    source: "Al-Kafi, Musnad Ahmad, Sahih Muslim, Sunan al-Tirmidhi and dozens more",
    matn: "I leave among you the two weighty things: the Book of Allah and my family, my Ahl al-Bayt. They shall never separate until they return to me at the Pool.",
    chain: [
      { name: "The Messenger of Allah ﷺ", era: "d. 11 AH", status: "thiqa", note: "The source of the report." },
      { name: "Zayd ibn Arqam", era: "d. 68 AH", status: "thiqa", note: "Companion; heard it at Ghadir Khumm and in Madinah." },
      { name: "Yazid ibn Hayyan", era: "Tabi'i", status: "thiqa", note: "Narrated in Sahih Muslim." },
      { name: "Multiple parallel chains", era: "2nd–4th c. AH", status: "thiqa", note: "Over twenty companions transmit it, which raises it to tawatur." },
    ],
  },
  {
    title: "Hadith al-Ghadir", arabic: "حدیث الغدیر", grade: "Mutawatir — mass-transmitted",
    source: "Reported by 110 companions across Sunni and Shi'i collections",
    matn: "Whoever's mawla I am, this Ali is his mawla. O Allah, befriend whoever befriends him and oppose whoever opposes him.",
    chain: [
      { name: "The Messenger of Allah ﷺ", era: "10 AH", status: "thiqa", note: "Declared at Ghadir Khumm before the returning pilgrims." },
      { name: "Bara ibn Azib · Zayd ibn Arqam · Abu Sa'id", era: "Companions", status: "thiqa", note: "Among the 110 companion narrators." },
      { name: "Abu al-Tufayl Amir ibn Wathila", era: "d. 110 AH", status: "thiqa", note: "The last living companion; transmitted it widely in Kufa." },
      { name: "Ahmad ibn Hanbal / al-Nasa'i / al-Kulayni", era: "3rd–4th c. AH", status: "thiqa", note: "Recorded it in their respective collections." },
    ],
  },
  {
    title: "Hadith al-Kisa", arabic: "حدیث الکساء", grade: "Sahih in content, widely narrated",
    source: "Sahih Muslim (Umm Salama), Awalim al-Ulum, Mustadrak al-Hakim",
    matn: "The Prophet gathered Ali, Fatima, Hasan and Husayn beneath a cloak and said: O Allah, these are my Ahl al-Bayt — remove impurity from them and purify them completely.",
    chain: [
      { name: "The Messenger of Allah ﷺ", era: "d. 11 AH", status: "thiqa", note: "Under the Yemeni cloak in the house of Umm Salama." },
      { name: "Umm Salama", era: "d. 62 AH", status: "thiqa", note: "Mother of the believers; direct eyewitness." },
      { name: "Shahr ibn Hawshab", era: "d. 100 AH", status: "debated", note: "Some rijal scholars weaken him, but the report is corroborated by other chains." },
      { name: "Al-Hakim al-Naysaburi", era: "d. 405 AH", status: "reliable", note: "Graded it authentic in al-Mustadrak." },
    ],
  },
  {
    title: "Hadith of the Twelve Successors", arabic: "الأئمة اثنا عشر", grade: "Sahih (Bukhari & Muslim)",
    source: "Sahih al-Bukhari, Sahih Muslim, al-Kafi",
    matn: "This affair will continue as long as there are twelve successors, all of them from Quraysh.",
    chain: [
      { name: "The Messenger of Allah ﷺ", era: "d. 11 AH", status: "thiqa", note: "Spoken publicly in a sermon." },
      { name: "Jabir ibn Samura", era: "d. 74 AH", status: "thiqa", note: "Companion who heard the sermon directly." },
      { name: "Amir al-Sha'bi", era: "d. 103 AH", status: "thiqa", note: "Prominent Kufan tabi'i." },
      { name: "Al-Bukhari / Muslim", era: "3rd c. AH", status: "thiqa", note: "Both recorded it in their Sahih collections." },
    ],
  },
];

const STATUS: Record<Narrator["status"], { label: string; cls: string }> = {
  thiqa: { label: "Thiqa — trustworthy", cls: "text-emerald border-emerald/40" },
  reliable: { label: "Reliable", cls: "text-gold border-gold/40" },
  debated: { label: "Debated in rijal", cls: "text-muted-foreground border-border" },
};

function IsnadPage() {
  const [idx, setIdx] = useState(0);
  const r = REPORTS[idx]!;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Chain of Narrators" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-5xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Research / Isnad</span>
          <h1 className="mt-4 font-display italic text-5xl">The Chain Behind the Word</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            A narration is only as strong as the men who carried it. Follow the chain, narrator by narrator.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {REPORTS.map((x, i) => (
            <button
              key={x.title}
              onClick={() => setIdx(i)}
              aria-pressed={idx === i}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.2em] transition-colors ${
                idx === i ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
              }`}
            >
              {x.title}
            </button>
          ))}
        </div>

        <article className="mt-10 bg-card border border-border p-7 md:p-10">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="font-display italic text-3xl">{r.title}</h2>
              <p className="mt-1 text-[10px] uppercase tracking-[0.3em] text-emerald">{r.grade}</p>
            </div>
            <span className="font-arabic text-3xl text-gold/50">{r.arabic}</span>
          </div>

          <blockquote className="mt-6 border-s-2 border-gold ps-5 py-2 text-lg leading-relaxed italic">{r.matn}</blockquote>
          <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Source: {r.source}</p>

          <h3 className="mt-10 text-[10px] uppercase tracking-[0.3em] text-gold">Chain of transmission</h3>
          <ol className="mt-5 relative border-s border-border ps-6 space-y-5">
            {r.chain.map((n, i) => (
              <li key={n.name} className="relative">
                <span className="absolute -start-[31px] top-3 size-3 rounded-full bg-emerald ring-4 ring-card" />
                <div className="bg-background border border-border p-5">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-mono-display text-[10px] text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                    <h4 className="font-display text-lg">{n.name}</h4>
                    <span className={`ms-auto border px-2 py-1 text-[9px] uppercase tracking-[0.22em] ${STATUS[n.status].cls}`}>
                      {STATUS[n.status].label}
                    </span>
                  </div>
                  <p className="mt-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{n.era}</p>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{n.note}</p>
                </div>
              </li>
            ))}
          </ol>
        </article>
      </section>
      <SiteFooter />
    </div>
  );
}