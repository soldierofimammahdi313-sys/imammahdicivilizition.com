import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { MapPin, Cpu, Compass, Scale } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { breadcrumbLd } from "@/lib/site";
import founderAsset from "@/assets/founder.jpg.asset.json";

export const Route = createFileRoute("/founder")({
  head: () => ({
    meta: [
      { title: "The Founder — Syed Ahmad Raza Shamsi" },
      {
        name: "description",
        content:
          "Syed Ahmad Raza Shamsi, founder and web developer of Imam Mahdi Civilization — a humble journey of using technology in the service of knowledge, faith and justice.",
      },
      { property: "og:title", content: "The Founder — Imam Mahdi Civilization" },
      {
        property: "og:description",
        content: "Founder & Web Developer Syed Ahmad Raza Shamsi on faith, knowledge, technology and civilization.",
      },
      { property: "og:type", content: "profile" },
      { property: "og:url", content: "https://imammahdicivilizition.com/founder" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/founder" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(breadcrumbLd([{ label: "Founder", to: "/founder" }])),
      },
    ],
  }),
  component: FounderPage,
});

/** Fade-up on scroll, cheap and mobile friendly. */
function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -10% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${
        shown ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
      } ${className}`}
    >
      {children}
    </div>
  );
}

const PILLARS = [
  {
    n: "01",
    t: "Faith × Technology",
    Icon: Cpu,
    d: "Using modern technology to make beneficial knowledge more accessible, meaningful, and impactful.",
  },
  {
    n: "02",
    t: "Preparation",
    Icon: Compass,
    d: "Encouraging self-refinement, knowledge, patience, responsibility, and moral excellence.",
  },
  {
    n: "03",
    t: "Justice & Humanity",
    Icon: Scale,
    d: "Promoting a vision of a world where truth, justice, compassion, and human dignity are valued.",
  },
];

const STATS = [
  { v: "01", l: "Founder" },
  { v: "01", l: "Digital Civilization Platform" },
  { v: "∞", l: "Knowledge to Share" },
  { v: "∞", l: "A Journey of Service" },
];

function Gold({ children }: { children: React.ReactNode }) {
  return <span className="text-gold/90 font-medium">{children}</span>;
}

function FounderPage() {
  return (
    <div className="bg-background text-foreground min-h-screen overflow-x-hidden">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Founder" }]} jsonLd={false} />

      {/* Atmospheric backdrop */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute left-1/2 top-24 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-emerald/10 blur-[140px]" />
        <div className="absolute right-[-10%] top-1/2 h-[420px] w-[420px] rounded-full bg-gold/10 blur-[150px]" />
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(45deg, currentColor 0 1px, transparent 1px 22px), repeating-linear-gradient(-45deg, currentColor 0 1px, transparent 1px 22px)",
            color: "var(--gold)",
          }}
        />
      </div>

      {/* HERO */}
      <section className="px-6 pt-14 pb-20 sm:pt-20 text-center max-w-4xl mx-auto">
        <Reveal>
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.45em]">The Founder</span>
          <h1 className="mt-6 font-display italic text-4xl sm:text-6xl md:text-7xl leading-[1.05] text-balance">
            Syed Ahmad Raza Shamsi
          </h1>
          <p className="mt-5 text-xs sm:text-sm uppercase tracking-[0.3em] text-muted-foreground">
            Founder &amp; Web Developer — Imam Mahdi Civilization
          </p>
          <p className="mt-10 font-display text-lg sm:text-2xl italic text-foreground/85 max-w-[46ch] mx-auto leading-relaxed">
            “A humble servant using technology in the service of truth, knowledge, and faith.”
          </p>
          <div className="mt-10 mx-auto w-40 divider-glow" />
        </Reveal>
      </section>

      {/* PROFILE CARD */}
      <section className="px-6 pb-24">
        <Reveal className="max-w-6xl mx-auto">
          <div className="surface-card shadow-luxe ring-1 ring-gold/15 p-8 sm:p-12 grid gap-12 md:grid-cols-[minmax(0,320px)_minmax(0,1fr)] items-start">
            <div className="flex flex-col items-center text-center">
              <div className="relative h-52 w-52 sm:h-60 sm:w-60">
                <div className="absolute inset-0 rounded-full border border-gold/40 animate-orbit-slow [border-top-color:var(--gold)]" />
                <div className="absolute inset-[6px] rounded-full ring-1 ring-gold/25 overflow-hidden bg-card">
                  <img
                    src={founderAsset.url}
                    alt="Portrait of Syed Ahmad Raza Shamsi, founder of Imam Mahdi Civilization"
                    width={480}
                    height={480}
                    loading="lazy"
                    className="h-full w-full object-cover object-top"
                  />
                </div>
              </div>
              <h2 className="mt-8 text-sm font-bold uppercase tracking-[0.28em] text-gold">
                Syed Ahmad Raza Shamsi
              </h2>
              <p className="mt-3 inline-flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin size={14} className="shrink-0 text-emerald" />
                Kasur, Pakistan
              </p>
            </div>

            <div className="min-w-0">
              <h3 className="font-display text-3xl sm:text-4xl italic">A Journey of Humble Service</h3>
              <div className="mt-4 w-24 divider-glow" />
              <div className="mt-8 space-y-6 text-[15px] sm:text-base leading-[1.9] text-muted-foreground max-w-[62ch]">
                <p>
                  “I am Syed Ahmad Raza Shamsi, a web developer from Kasur, Pakistan, striving to use my modest
                  technical abilities for a purpose greater than technology itself.
                </p>
                <p>
                  I believe technology is not merely a tool for entertainment or information. It can become a means of
                  spreading <Gold>knowledge</Gold>, encouraging reflection, strengthening moral character, and
                  inspiring positive change.
                </p>
                <p>
                  Through Imam Mahdi Civilization, I seek to build a digital space dedicated to <Gold>knowledge</Gold>,
                  spiritual awareness and <Gold>faith</Gold>, moral development, and preparation for a world founded
                  upon <Gold>justice</Gold> and <Gold>truth</Gold>.”
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* PILLARS */}
      <section className="px-6 pb-24">
        <div className="max-w-6xl mx-auto grid gap-6 md:grid-cols-3">
          {PILLARS.map((p, i) => (
            <Reveal key={p.n} delay={i * 120}>
              <article className="surface-card hover-lift h-full p-8 sm:p-9">
                <div className="flex items-center justify-between">
                  <span className="font-mono-display text-[11px] tracking-[0.3em] text-emerald">{p.n}</span>
                  <p.Icon size={20} className="text-gold/80" />
                </div>
                <h3 className="mt-6 font-display text-2xl">{p.t}</h3>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{p.d}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* PRINCIPLE */}
      <section className="relative border-y border-gold/15 bg-card/30 px-6 py-24 sm:py-32">
        <Reveal className="max-w-4xl mx-auto text-center">
          <span className="font-display text-6xl sm:text-8xl leading-none text-gold/25">“</span>
          <p className="-mt-6 font-display italic text-2xl sm:text-4xl leading-snug text-balance">
            Technology is only a tool. Its true value lies in what we choose to serve with it.
          </p>
          <p className="mt-8 text-[11px] uppercase tracking-[0.35em] text-muted-foreground">
            — Syed Ahmad Raza Shamsi
          </p>
        </Reveal>
      </section>

      {/* HUMBLE INTENTION */}
      <section className="relative px-6 py-24 sm:py-32">
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-1/2 h-72 w-[36rem] max-w-[90vw] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/10 blur-[130px]"
        />
        <Reveal className="relative max-w-3xl mx-auto text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.45em]">A Humble Intention</span>
          <p className="mt-8 text-lg sm:text-2xl leading-relaxed text-foreground/90 font-display italic">
            “May every line of code, every piece of knowledge, and every effort made through this platform become a
            small contribution toward truth, justice, and the preparation of a generation worthy of a just global
            civilization.”
          </p>
        </Reveal>
      </section>

      {/* STATS */}
      <section className="px-6 pb-24">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-px bg-border ring-1 ring-border">
          {STATS.map((s, i) => (
            <Reveal key={s.l} delay={i * 90}>
              <div className="bg-background h-full p-8 text-center">
                <div className="font-display text-4xl sm:text-5xl text-gradient-gold">{s.v}</div>
                <p className="mt-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground leading-relaxed">
                  {s.l}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 pb-32 text-center">
        <Reveal className="max-w-3xl mx-auto">
          <h2 className="font-display italic text-4xl sm:text-5xl">The Work Continues.</h2>
          <p className="mt-5 text-sm text-muted-foreground">
            A digital journey dedicated to knowledge, reflection, preparation, and service.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/"
              className="px-10 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] transition-colors hover:bg-foreground"
            >
              Explore the Civilization →
            </Link>
            <Link
              to="/about"
              className="px-10 py-4 border border-gold/40 font-bold uppercase text-xs tracking-[0.3em] transition-colors hover:bg-emerald-soft hover:border-gold"
            >
              Explore the Mission →
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
