import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { breadcrumbLd } from "@/lib/site";

export const Route = createFileRoute("/academy")({
  head: () => ({
    meta: [
      { title: "Islamic Academy — Structured Learning Tracks" },
      { name: "description", content: "Structured Islamic learning tracks across creed, fiqh, history, Arabic, and Quran sciences." },
      { property: "og:title", content: "Islamic Academy — Structured Learning Tracks" },
      { property: "og:description", content: "Nine guided tracks: creed, fiqh, sirah, the 14 Infallibles, Quranic Arabic and more." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://imammahdicivilizition.com/academy" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/academy" }],
    scripts: [
      { type: "application/ld+json", children: JSON.stringify(breadcrumbLd([{ label: "Academy", to: "/academy" }])) },
      {

        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Islamic Academy — Structured Learning Tracks",
          url: "https://imammahdicivilizition.com/academy",
          hasPart: [
            "ʿAqīdah (Creed)",
            "Fiqh of Daily Life",
            "Sirah of the Prophet ﷺ",
            "The 14 Infallibles",
            "Quran Sciences",
            "Quranic Arabic",
            "Nahj al-Balagha Study",
            "Imam Mahdi (a.t.f.s.) Studies",
            "Islamic History",
          ].map((t) => ({
            "@type": "Course",
            name: t,
            url: "https://imammahdicivilizition.com/academy",
            provider: { "@type": "Organization", name: "Imam Mahdi Civilization", url: "https://imammahdicivilizition.com" },
          })),
        }),
      },
    ],
  }),
  component: AcademyPage,
});

const TRACKS = [
  { n: "01", t: "ʿAqīdah (Creed)", d: "Tawhid, ʿAdl, Nubuwwah, Imamah, Maʿad — the five principles of faith.", lessons: 12, to: "/articles" },
  { n: "02", t: "Fiqh of Daily Life", d: "Taharah, Salah, Sawm, Zakat, Khums, Hajj — practical rulings explained.", lessons: 18, to: "/articles" },
  { n: "03", t: "Sirah of the Prophet ﷺ", d: "From the year of the elephant to the farewell pilgrimage.", lessons: 14, to: "/videos" },
  { n: "04", t: "The 14 Infallibles", d: "Lives, teachings & legacies of the Prophet ﷺ, Fatima (s.a.) and the 12 Imams.", lessons: 16, to: "/videos" },
  { n: "05", t: "Quran Sciences", d: "Revelation, abrogation, asbāb al-nuzūl, methods of tafsir.", lessons: 10, to: "/tafsir-al-mizan" },
  { n: "06", t: "Quranic Arabic", d: "Read, parse, and understand the Quran in its own tongue.", lessons: 20, to: "/quran" },
  { n: "07", t: "Nahj al-Balagha Study", d: "Sermons, letters, and aphorisms of Imam Ali (a.s.).", lessons: 12, to: "/library" },
  { n: "08", t: "Imam Mahdi (a.t.f.s.) Studies", d: "Proofs, signs of reappearance, duties during occultation.", lessons: 9, to: "/articles" },
  { n: "09", t: "Islamic History", d: "From Saqifah to the Safavids to today — the long arc of the Ummah.", lessons: 15, to: "/videos" },
];

function AcademyPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Academy" }]} jsonLd={false} />
      <section className="pt-8 pb-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">07 / Academy</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Learn the Deen — Properly.</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">Nine structured tracks. Open any module and start learning today.</p>
        </div>
        <h2 className="sr-only">Learning tracks</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {TRACKS.map((tr) => (
            <Link key={tr.n} to={tr.to} className="group bg-card p-7 hover:bg-emerald-soft transition-colors flex flex-col justify-between min-h-[200px]">
              <div className="flex justify-between items-start">
                <span className="font-mono-display text-[10px] text-emerald tracking-widest">{tr.n}</span>
                <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{tr.lessons} lessons</span>
              </div>
              <div className="mt-6">
                <h3 className="font-display text-2xl group-hover:text-gold transition-colors">{tr.t}</h3>
                <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{tr.d}</p>
                <span className="mt-3 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">Start ▸</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}