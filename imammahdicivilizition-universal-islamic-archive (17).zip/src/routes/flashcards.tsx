import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/flashcards")({
  head: () => ({
    meta: [
      { title: "Flashcards — Spaced Repetition for Qur'anic Arabic | Imam Mahdi Civilization" },
      { name: "description", content: "Memorise Qur'anic vocabulary, hadith terms and fiqh definitions with a spaced-repetition deck that remembers your progress." },
      { property: "og:title", content: "Flashcards — Spaced Repetition" },
      { property: "og:description", content: "Qur'anic vocabulary, hadith terminology and fiqh definitions, scheduled by your own recall." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/flashcards" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/flashcards" }],
  }),
  component: FlashcardsPage,
});

type Deck = "quran" | "hadith" | "fiqh";
type Card = { id: string; front: string; back: string; hint?: string; deck: Deck };

const CARDS: Card[] = [
  { id: "q1", deck: "quran", front: "رَبّ", back: "Lord, Sustainer, Nurturer", hint: "Al-Fatiha 1:2" },
  { id: "q2", deck: "quran", front: "رَحْمَة", back: "Mercy — encompassing compassion" },
  { id: "q3", deck: "quran", front: "تَقْوَى", back: "God-consciousness, protective awareness" },
  { id: "q4", deck: "quran", front: "صَبْر", back: "Patient perseverance" },
  { id: "q5", deck: "quran", front: "هُدَى", back: "Guidance" },
  { id: "q6", deck: "quran", front: "نُور", back: "Light" },
  { id: "q7", deck: "quran", front: "عَدْل", back: "Justice, balance" },
  { id: "q8", deck: "quran", front: "شُكْر", back: "Gratitude expressed in action" },
  { id: "q9", deck: "quran", front: "ذِكْر", back: "Remembrance, mention of God" },
  { id: "q10", deck: "quran", front: "أَمَانَة", back: "Trust, that which is entrusted" },
  { id: "q11", deck: "quran", front: "فَلَاح", back: "Success, flourishing" },
  { id: "q12", deck: "quran", front: "ظُلْم", back: "Oppression, placing a thing where it does not belong" },
  { id: "h1", deck: "hadith", front: "Isnad — إسناد", back: "The chain of narrators supporting a report" },
  { id: "h2", deck: "hadith", front: "Matn — متن", back: "The text or content of a narration" },
  { id: "h3", deck: "hadith", front: "Sahih — صحیح", back: "Authentic: an unbroken chain of upright, accurate narrators" },
  { id: "h4", deck: "hadith", front: "Muwaththaq — موثق", back: "Reliable: trustworthy narrators, though not all Imami" },
  { id: "h5", deck: "hadith", front: "Mursal — مرسل", back: "A report with a narrator omitted from the chain" },
  { id: "h6", deck: "hadith", front: "Thiqa — ثقة", back: "A narrator judged trustworthy in both integrity and precision" },
  { id: "h7", deck: "hadith", front: "The Four Books", back: "Al-Kafi · Man la yahduruhu al-Faqih · Tahdhib al-Ahkam · al-Istibsar" },
  { id: "h8", deck: "hadith", front: "Thaqalayn — ثقلین", back: "The two weighty things: the Qur'an and the Ahl al-Bayt" },
  { id: "f1", deck: "fiqh", front: "Wajib — واجب", back: "Obligatory; rewarded when done, punished when abandoned" },
  { id: "f2", deck: "fiqh", front: "Mustahabb — مستحب", back: "Recommended; rewarded when done, no sin when left" },
  { id: "f3", deck: "fiqh", front: "Mubah — مباح", back: "Permitted; neutral in reward" },
  { id: "f4", deck: "fiqh", front: "Makruh — مکروه", back: "Discouraged but not forbidden" },
  { id: "f5", deck: "fiqh", front: "Haram — حرام", back: "Forbidden" },
  { id: "f6", deck: "fiqh", front: "Khums — خمس", back: "One fifth of annual surplus, divided between the share of the Imam and the sadat" },
  { id: "f7", deck: "fiqh", front: "Taqlid — تقلید", back: "Following a qualified living mujtahid in matters of practical law" },
  { id: "f8", deck: "fiqh", front: "Ijtihad — اجتهاد", back: "Deriving rulings from the sources through disciplined reasoning" },
  { id: "f9", deck: "fiqh", front: "Nisab — نصاب", back: "The threshold of wealth at which zakat becomes due" },
  { id: "f10", deck: "fiqh", front: "Qada — قضاء", back: "Making up a missed obligatory act" },
];

const KEY = "mc.flashcards.v1";
const INTERVALS = [0, 1, 2, 4, 7, 15, 30]; // days per box

type Progress = Record<string, { box: number; due: number }>;

function loadProgress(): Progress {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "{}") as Progress;
  } catch {
    return {};
  }
}

function FlashcardsPage() {
  const [deck, setDeck] = useState<Deck | "all">("all");
  const [progress, setProgress] = useState<Progress>({});
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setProgress(loadProgress());
    setHydrated(true);
  }, []);

  const pool = useMemo(() => {
    const base = deck === "all" ? CARDS : CARDS.filter((c) => c.deck === deck);
    if (!hydrated) return base;
    const now = Date.now();
    const due = base.filter((c) => (progress[c.id]?.due ?? 0) <= now);
    return due.length > 0 ? due : base;
  }, [deck, progress, hydrated]);

  const card = pool[i % Math.max(pool.length, 1)];

  function grade(known: boolean) {
    if (!card) return;
    const prev = progress[card.id]?.box ?? 0;
    const box = known ? Math.min(prev + 1, INTERVALS.length - 1) : 0;
    const next: Progress = { ...progress, [card.id]: { box, due: Date.now() + INTERVALS[box]! * 86400000 } };
    setProgress(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch { /* storage unavailable */ }
    setFlipped(false);
    setI((v) => v + 1);
  }

  const mastered = hydrated ? Object.values(progress).filter((p) => p.box >= 4).length : 0;
  const started = hydrated ? Object.keys(progress).length : 0;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Flashcards" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-3xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Learning / Flashcards</span>
          <h1 className="mt-4 font-display italic text-5xl">Memorise by Recall</h1>
          <p className="mt-4 text-sm text-muted-foreground">
            Spaced repetition across {CARDS.length} cards. Progress is stored privately on this device.
          </p>
        </div>

        <div className="mt-8 flex flex-wrap justify-center gap-2">
          {(["all", "quran", "hadith", "fiqh"] as const).map((d) => (
            <button
              key={d}
              onClick={() => { setDeck(d); setI(0); setFlipped(false); }}
              aria-pressed={deck === d}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                deck === d ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
              }`}
            >
              {d === "all" ? "All decks" : d === "quran" ? "Qur'anic Arabic" : d === "hadith" ? "Hadith terms" : "Fiqh terms"}
            </button>
          ))}
        </div>

        {card && (
          <div className="mt-10">
            <button
              onClick={() => setFlipped((v) => !v)}
              className="w-full min-h-[260px] bg-card border border-gold/30 hover:border-gold p-10 flex flex-col items-center justify-center text-center transition-colors"
            >
              <span className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground">
                {flipped ? "Meaning" : "Tap to reveal"}
              </span>
              {flipped ? (
                <p className="mt-5 font-display italic text-3xl leading-snug">{card.back}</p>
              ) : (
                <p className="mt-5 font-arabic text-5xl text-gold">{card.front}</p>
              )}
              {card.hint && <p className="mt-4 text-[10px] uppercase tracking-[0.25em] text-emerald">{card.hint}</p>}
            </button>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <button
                onClick={() => grade(false)}
                className="py-4 border border-border text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground hover:border-destructive hover:text-destructive transition-colors"
              >
                Again
              </button>
              <button
                onClick={() => grade(true)}
                className="py-4 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-foreground transition-colors"
              >
                I knew it
              </button>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-px bg-border ring-1 ring-border">
              {[
                { k: "In rotation", v: pool.length },
                { k: "Started", v: started },
                { k: "Mastered", v: mastered },
              ].map((s) => (
                <div key={s.k} className="bg-card py-5 text-center">
                  <div className="font-mono-display text-2xl text-gold">{s.v}</div>
                  <div className="mt-1 text-[9px] uppercase tracking-[0.25em] text-muted-foreground">{s.k}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}