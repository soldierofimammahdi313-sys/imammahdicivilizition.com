import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site/SiteHeader";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string } => ({
    next:
      typeof s.next === "string" && s.next.startsWith("/") && !s.next.startsWith("//")
        ? s.next
        : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Enter the Vanguard — Imam Mahdi Civilization" },
      { name: "description", content: "Sign in or create your account to join Imam Mahdi Civilization." },
      { property: "og:title", content: "Enter the Vanguard — Imam Mahdi Civilization" },
      { property: "og:description", content: "Sign in or create your account to join Imam Mahdi Civilization." },
      { property: "og:url", content: "https://imammahdicivilizition.com/auth" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/auth" }],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { next } = Route.useSearch();
  const returnTo = () =>
    typeof window === "undefined" ? undefined : next ? `${window.location.origin}${next}` : window.location.origin;
  const goBack = () => {
    if (next) window.location.href = next;
    else navigate({ to: "/" });
  };
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        if (next) window.location.href = next;
        else navigate({ to: "/" });
      }
    });
  }, [navigate, next]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: returnTo(),
            data: { full_name: name },
          },
        });
        if (error) throw error;
        toast.success("Account created. Check your email to confirm.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back.");
        goBack();
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  async function google() {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: returnTo(),
    });
    if (result.error) {
      toast.error("Google sign-in failed");
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    goBack();
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <div className="pt-32 pb-20 px-6 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-10">
            <span className="font-arabic text-3xl text-gold/40 block">يا صاحب الزمان</span>
            <h1 className="mt-2 font-display italic text-4xl">
              {mode === "signin" ? "Welcome back" : "Enter the Vanguard"}
            </h1>
            <p className="mt-3 text-sm text-muted-foreground">
              {mode === "signin" ? "Sign in to access your dashboard." : "Create your account in the civilization."}
            </p>
          </div>

          <button
            onClick={google}
            disabled={loading}
            className="w-full py-3.5 border border-border bg-card hover:border-gold/50 transition-colors text-sm font-medium uppercase tracking-[0.2em] disabled:opacity-50"
          >
            Continue with Google
          </button>

          <div className="flex items-center gap-4 my-6">
            <div className="h-px bg-border flex-1" />
            <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">or</span>
            <div className="h-px bg-border flex-1" />
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 w-full bg-card border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none"
                />
              </div>
            )}
            <div>
              <label className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full bg-card border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full bg-card border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors disabled:opacity-50"
            >
              {loading ? "..." : mode === "signin" ? "Sign In" : "Create Account"}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            {mode === "signin" ? "New to Imam Mahdi Civilization?" : "Already enlisted?"}{" "}
            <button
              type="button"
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
              className="text-gold hover:underline font-medium"
            >
              {mode === "signin" ? "Create an account" : "Sign in"}
            </button>
          </p>

          <p className="mt-8 text-center">
            <Link to="/" className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground hover:text-gold">
              ← Back to civilization
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}