import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Bookmark, Trash2 } from "lucide-react";
import { AccountShell, EmptyState } from "@/components/account/AccountShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/bookmarks")({
  head: () => ({
    meta: [
      { title: "My Bookmarks — Mahdi Civilization" },
      { name: "description", content: "Every article, hadith, duʿāʾ and surah you saved across the platform, in one library." },
    ],
  }),
  component: BookmarksPage,
});

const FILTERS = ["all", "article", "hadith", "dua", "quran", "book", "video"] as const;

type SavedRow = { id: string; item_type: string; item_id: string; created_at: string };

function labelFor(row: SavedRow, articles: Record<string, { title: string; slug: string }>) {
  if (row.item_type === "article") return articles[row.item_id]?.title ?? "Article";
  if (row.item_type === "quran") return `Surah ${row.item_id}`;
  return `${row.item_type} · ${row.item_id}`;
}

function hrefFor(row: SavedRow, articles: Record<string, { title: string; slug: string }>) {
  if (row.item_type === "article") return articles[row.item_id] ? `/articles/${articles[row.item_id].slug}` : "/articles";
  if (row.item_type === "quran") return `/quran/${row.item_id}`;
  if (row.item_type === "hadith") return "/hadith";
  if (row.item_type === "dua") return "/duas";
  if (row.item_type === "book") return "/library";
  if (row.item_type === "video") return "/videos";
  return "/";
}

function BookmarksPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");

  const savedQuery = useQuery({
    queryKey: ["saved", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("saved_items")
        .select("id,item_type,item_id,created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as SavedRow[];
    },
  });

  const articleIds = (savedQuery.data ?? []).filter((r) => r.item_type === "article").map((r) => r.item_id);
  const articlesQuery = useQuery({
    queryKey: ["saved-articles", articleIds.join(",")],
    enabled: articleIds.length > 0,
    queryFn: async () => {
      const { data } = await supabase.from("articles").select("id,title,slug").in("id", articleIds);
      const map: Record<string, { title: string; slug: string }> = {};
      for (const a of data ?? []) map[a.id] = { title: a.title, slug: a.slug };
      return map;
    },
  });

  const articles = articlesQuery.data ?? {};
  const rows = (savedQuery.data ?? []).filter((r) => filter === "all" || r.item_type === filter);

  async function remove(row: SavedRow) {
    const { error } = await supabase.from("saved_items").delete().eq("id", row.id);
    if (error) return toast.error(error.message);
    toast.success("Removed from your library");
    qc.invalidateQueries({ queryKey: ["saved", user.id] });
  }

  return (
    <AccountShell
      kicker="Saved Library"
      title="My Bookmarks"
      subtitle="Articles, hadith, supplications and surahs you saved — kept safe across every device."
    >
      <div className="flex flex-wrap gap-2 mb-8">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 text-[10px] uppercase tracking-[0.25em] border transition-colors ${
              filter === f ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {savedQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Loading your library…</div>
      ) : rows.length === 0 ? (
        <EmptyState title="Nothing saved yet" body="Tap the bookmark icon on any article, hadith or duʿāʾ to build your personal library." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
          {rows.map((row) => (
            <div key={row.id} className="bg-card p-6 flex flex-col justify-between gap-4">
              <div>
                <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{row.item_type}</span>
                <h3 className="mt-2 font-display italic text-xl">{labelFor(row, articles)}</h3>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Saved {new Date(row.created_at).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <Link to={hrefFor(row, articles)} className="text-[10px] uppercase tracking-[0.3em] text-gold hover:text-foreground">
                  Open ▸
                </Link>
                <button
                  onClick={() => remove(row)}
                  aria-label="Remove bookmark"
                  className="text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-10 flex items-center gap-2 text-xs text-muted-foreground">
        <Bookmark className="size-4 text-gold" />
        {(savedQuery.data ?? []).length} total saved items
      </div>
    </AccountShell>
  );
}