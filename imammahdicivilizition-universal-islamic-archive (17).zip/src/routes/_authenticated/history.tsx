import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { History as HistoryIcon, Trash2 } from "lucide-react";
import { AccountShell, EmptyState } from "@/components/account/AccountShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({
    meta: [
      { title: "Reading History — Mahdi Civilization" },
      { name: "description", content: "Everything you have recently read across Quran, hadith, articles and supplications." },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();

  const historyQuery = useQuery({
    queryKey: ["history", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reading_history")
        .select("id,item_type,item_id,title,href,progress,viewed_at")
        .eq("user_id", user.id)
        .order("viewed_at", { ascending: false })
        .limit(120);
      if (error) throw error;
      return data ?? [];
    },
  });

  async function clearAll() {
    const { error } = await supabase.from("reading_history").delete().eq("user_id", user.id);
    if (error) return toast.error(error.message);
    toast.success("Reading history cleared");
    qc.invalidateQueries({ queryKey: ["history", user.id] });
  }

  const rows = historyQuery.data ?? [];

  return (
    <AccountShell
      kicker="Continue where you left"
      title="Reading History"
      subtitle="Your journey through the sacred sciences — automatically tracked as you read."
    >
      {rows.length === 0 ? (
        <EmptyState title="No reading recorded yet" body="Open a surah, hadith or article and it will appear here so you can continue instantly." />
      ) : (
        <>
          <div className="flex justify-end mb-4">
            <button onClick={clearAll} className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-destructive">
              <Trash2 className="size-3.5" /> Clear history
            </button>
          </div>
          <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
            {rows.map((row) => (
              <li key={row.id} className="flex items-center justify-between gap-4 p-5">
                <div className="min-w-0">
                  <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{row.item_type}</span>
                  <div className="font-display italic text-lg truncate">{row.title ?? row.item_id}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {new Date(row.viewed_at).toLocaleString()}
                    {row.progress > 0 && ` · ${row.progress}% complete`}
                  </div>
                </div>
                {row.href && (
                  <Link to={row.href} className="shrink-0 text-[10px] uppercase tracking-[0.3em] text-gold hover:text-foreground">
                    Continue ▸
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </>
      )}
      <div className="mt-10 flex items-center gap-2 text-xs text-muted-foreground">
        <HistoryIcon className="size-4 text-gold" /> {rows.length} recent items
      </div>
    </AccountShell>
  );
}