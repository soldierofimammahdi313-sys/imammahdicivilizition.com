import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { BellRing, LoaderCircle, Play } from "lucide-react";
import { toast } from "sonner";
import { AccountShell, EmptyState } from "@/components/account/AccountShell";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { fetchRoles } from "@/lib/user-data";
import { runAutopilotNow as triggerAutopilot } from "@/lib/autopilot-admin.functions";
import { AdminUsersList } from "@/components/AdminUsersList";
import { AutoArticleGenerator } from "@/components/AutoArticleGenerator";
import { AdminLibraryManager } from "@/components/AdminLibraryManager";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin Console — Mahdi Civilization" },
      { name: "description", content: "Moderate community content, review applications and monitor platform analytics." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const ADMIN_EMAIL = "s.ahmad.raza.shamsi.official@gmail.com";

type Tab = "overview" | "members" | "generator" | "library" | "moderation" | "reports" | "security" | "applications" | "articles";
const TABS: { key: Tab; label: string }[] = [
  { key: "overview", label: "Analytics" },
  { key: "members", label: "Members" },
  { key: "generator", label: "AI Generator" },
  { key: "library", label: "Library" },
  { key: "moderation", label: "Discussions" },
  { key: "reports", label: "Reports" },
  { key: "security", label: "Security Alerts" },
  { key: "applications", label: "Applications" },
  { key: "articles", label: "Articles" },
];

function AdminPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>("overview");
  const [autopilotRunning, setAutopilotRunning] = useState(false);

  const isOwner = (user.email ?? "").toLowerCase() === ADMIN_EMAIL;

  const rolesQuery = useQuery({
    queryKey: ["roles", user.id],
    queryFn: () => fetchRoles(user.id),
    enabled: isOwner,
  });

  const statsQuery = useQuery({
    queryKey: ["admin-stats"],
    enabled: rolesQuery.data?.isModerator === true,
    queryFn: async () => {
      const count = (table: "community_posts" | "community_comments" | "community_reports" | "articles" | "team_applications") =>
        supabase.from(table).select("id", { count: "exact", head: true });
      const [posts, comments, reports, articles, applications] = await Promise.all([
        count("community_posts"),
        count("community_comments"),
        count("community_reports"),
        count("articles"),
        count("team_applications"),
      ]);
      return {
        posts: posts.count ?? 0,
        comments: comments.count ?? 0,
        reports: reports.count ?? 0,
        articles: articles.count ?? 0,
        applications: applications.count ?? 0,
      };
    },
  });

  const postsQuery = useQuery({
    queryKey: ["admin-posts"],
    enabled: rolesQuery.data?.isModerator === true && tab === "moderation",
    queryFn: async () =>
      (await supabase.from("community_posts").select("*").order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  const reportsQuery = useQuery({
    queryKey: ["admin-reports"],
    enabled: rolesQuery.data?.isModerator === true && tab === "reports",
    queryFn: async () =>
      (await supabase.from("community_reports").select("*").order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  const appsQuery = useQuery({
    queryKey: ["admin-apps"],
    enabled: rolesQuery.data?.isModerator === true && tab === "applications",
    queryFn: async () =>
      (await supabase.from("team_applications").select("*").order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  const articlesQuery = useQuery({
    queryKey: ["admin-articles"],
    enabled: rolesQuery.data?.isModerator === true && tab === "articles",
    queryFn: async () =>
      (await supabase.from("articles").select("id,title,slug,status,published_at").order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  const securityQuery = useQuery({
    queryKey: ["admin-security-events"],
    enabled: rolesQuery.data?.isModerator === true,
    refetchInterval: 60_000,
    queryFn: async () =>
      (await supabase
        .from("security_events")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100)).data ?? [],
  });

  const openAlerts = (securityQuery.data ?? []).filter((e) => !e.reviewed).length;

  // Visual alert: pending /join applications, polled so a new signup shows up
  // in the console without a manual refresh.
  const newApplicationsQuery = useQuery({
    queryKey: ["admin-new-applications"],
    enabled: rolesQuery.data?.isModerator === true,
    refetchInterval: 60_000,
    queryFn: async () =>
      (await supabase
        .from("team_applications")
        .select("id, full_name, role, created_at")
        .eq("status", "pending")
        .order("created_at", { ascending: false })
        .limit(20)).data ?? [],
  });
  const pendingApplications = newApplicationsQuery.data ?? [];

  if (!isOwner) {
    return (
      <AccountShell kicker="Restricted" title="Admin Console" subtitle="This area is reserved for the site owner.">
        <EmptyState title="Access denied" body="This account is not authorised to manage the site." />
      </AccountShell>
    );
  }

  if (rolesQuery.isLoading) {
    return <AccountShell kicker="Restricted" title="Admin Console"><p className="text-sm text-muted-foreground">Verifying access…</p></AccountShell>;
  }

  if (!rolesQuery.data?.isModerator) {
    return (
      <AccountShell kicker="Restricted" title="Admin Console" subtitle="This area is reserved for platform moderators and administrators.">
        <EmptyState title="Access denied" body="Your account does not carry the reviewer or admin role. Contact the administration if you believe this is a mistake." />
      </AccountShell>
    );
  }

  async function moderatePost(id: string, patch: { is_hidden?: boolean; is_pinned?: boolean; is_locked?: boolean }) {
    const { error } = await supabase.from("community_posts").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Discussion updated");
    qc.invalidateQueries({ queryKey: ["admin-posts"] });
  }

  async function resolveReport(id: string, status: string) {
    const { error } = await supabase.from("community_reports").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Report marked ${status}`);
    qc.invalidateQueries({ queryKey: ["admin-reports"] });
  }

  async function setApplicationStatus(id: string, status: string) {
    const { error } = await supabase.from("team_applications").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Application ${status}`);
    qc.invalidateQueries({ queryKey: ["admin-apps"] });
  }

  async function setArticleStatus(id: string, status: string) {
    const { error } = await supabase
      .from("articles")
      .update({ status, published_at: status === "published" ? new Date().toISOString() : null })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Article ${status}`);
    qc.invalidateQueries({ queryKey: ["admin-articles"] });
  }

  async function deleteArticle(id: string) {
    if (!confirm("Delete this article permanently?")) return;
    const { error } = await supabase.from("articles").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Article deleted");
    qc.invalidateQueries({ queryKey: ["admin-articles"] });
  }

  async function markEventReviewed(id: string) {
    const { error } = await supabase.from("security_events").update({ reviewed: true }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Alert marked reviewed");
    qc.invalidateQueries({ queryKey: ["admin-security-events"] });
  }

  async function runAutopilotNow() {
    setAutopilotRunning(true);
    try {
      const payload = await triggerAutopilot({});
      const message = payload.message ?? "Autopilot request failed";

      if (!payload.success) {
        toast.error(message);
        return;
      }

      toast.success(message);
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["admin-stats"] }),
        qc.invalidateQueries({ queryKey: ["admin-articles"] }),
      ]);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Autopilot request failed");
    } finally {
      setAutopilotRunning(false);
    }
  }


  const stats = statsQuery.data;

  return (
    <AccountShell kicker="Command & Control" title="Admin Console" subtitle="Moderate content, review applications and monitor the platform.">
      {rolesQuery.data.isAdmin && (
        <div className="mb-6">
          <Button onClick={runAutopilotNow} disabled={autopilotRunning}>
            {autopilotRunning ? <LoaderCircle className="animate-spin" /> : <Play />}
            {autopilotRunning ? "Running AI Autopilot…" : "Run AI Autopilot Now"}
          </Button>
        </div>
      )}
      {pendingApplications.length > 0 && (
        <div className="mb-6 flex items-start gap-3 border border-gold/40 bg-gold-soft/20 p-4">
          <BellRing className="size-4 text-gold mt-0.5 shrink-0" />
          <div className="text-sm">
            <strong className="text-gold">{pendingApplications.length} new member application{pendingApplications.length > 1 ? "s" : ""}</strong>
            <span className="text-muted-foreground">
              {" "}— latest: {pendingApplications[0]!.full_name} ({pendingApplications[0]!.role}) on{" "}
              {new Date(pendingApplications[0]!.created_at).toLocaleDateString()}.
            </span>
            <button onClick={() => setTab("applications")} className="ms-2 text-gold underline underline-offset-4">
              Review now
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-2 mb-8">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-[10px] uppercase tracking-[0.25em] border transition-colors ${
              tab === t.key ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold"
            }`}
          >
            {t.label}
            {t.key === "applications" && pendingApplications.length > 0 && (
              <span className="ms-2 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-gold text-primary-foreground text-[9px] tracking-normal">
                {pendingApplications.length}
              </span>
            )}
            {t.key === "security" && openAlerts > 0 && (
              <span className="ms-2 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[9px] tracking-normal">
                {openAlerts}
              </span>
            )}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-px bg-border ring-1 ring-border">
          <Stat label="Discussions" value={stats?.posts ?? 0} />
          <Stat label="Replies" value={stats?.comments ?? 0} />
          <Stat label="Open reports" value={stats?.reports ?? 0} />
          <Stat label="Articles" value={stats?.articles ?? 0} />
          <Stat label="Applications" value={stats?.applications ?? 0} />
        </div>
      )}

      {tab === "members" && <AdminUsersList />}

      {tab === "generator" && <AutoArticleGenerator />}

      {tab === "library" && <AdminLibraryManager />}

      {tab === "moderation" && (
        <Table
          empty="No discussions yet."
          rows={(postsQuery.data ?? []).map((p) => ({
            id: p.id,
            main: p.title,
            sub: `${p.author_name ?? "Member"} · ${new Date(p.created_at).toLocaleDateString()}${p.is_hidden ? " · hidden" : ""}${p.is_pinned ? " · pinned" : ""}`,
            actions: (
              <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                <button className="text-gold hover:text-foreground" onClick={() => moderatePost(p.id, { is_pinned: !p.is_pinned })}>{p.is_pinned ? "Unpin" : "Pin"}</button>
                <button className="text-gold hover:text-foreground" onClick={() => moderatePost(p.id, { is_locked: !p.is_locked })}>{p.is_locked ? "Unlock" : "Lock"}</button>
                <button className="text-destructive hover:text-foreground" onClick={() => moderatePost(p.id, { is_hidden: !p.is_hidden })}>{p.is_hidden ? "Restore" : "Hide"}</button>
              </div>
            ),
          }))}
        />
      )}

      {tab === "reports" && (
        <Table
          empty="No reports filed."
          rows={(reportsQuery.data ?? []).map((r) => ({
            id: r.id,
            main: `${r.target_type}: ${r.reason}`,
            sub: `${r.status} · ${new Date(r.created_at).toLocaleString()}`,
            actions: (
              <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                <button className="text-emerald hover:text-foreground" onClick={() => resolveReport(r.id, "resolved")}>Resolve</button>
                <button className="text-muted-foreground hover:text-foreground" onClick={() => resolveReport(r.id, "dismissed")}>Dismiss</button>
              </div>
            ),
          }))}
        />
      )}

      {tab === "security" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">
            Search inputs that were sanitized because they looked like an attempt to inject database
            filter syntax. Each entry is also written to the server logs. Refreshes every minute.
          </p>
          <Table
            empty="No suspicious search inputs detected."
            rows={(securityQuery.data ?? []).map((e) => ({
              id: e.id,
              main: `${e.severity.toUpperCase()} · ${e.source} — ${e.raw_input.slice(0, 120)}`,
              sub: `${(e.reasons ?? []).join(", ") || "sanitized input"} · ${new Date(e.created_at).toLocaleString()}${e.reviewed ? " · reviewed" : ""}`,
              actions: e.reviewed ? null : (
                <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                  <button className="text-emerald hover:text-foreground" onClick={() => markEventReviewed(e.id)}>
                    Mark reviewed
                  </button>
                </div>
              ),
            }))}
          />
        </div>
      )}

      {tab === "applications" && (
        <Table
          empty="No applications received."
          rows={(appsQuery.data ?? []).map((a) => ({
            id: a.id,
            main: `${a.full_name} — ${a.role}`,
            sub: `${a.country} · ${a.email} · ${a.status}`,
            actions: (
              <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                <button className="text-emerald hover:text-foreground" onClick={() => setApplicationStatus(a.id, "accepted")}>Accept</button>
                <button className="text-destructive hover:text-foreground" onClick={() => setApplicationStatus(a.id, "rejected")}>Reject</button>
              </div>
            ),
          }))}
        />
      )}

      {tab === "articles" && (
        <Table
          empty="No articles published yet."
          rows={(articlesQuery.data ?? []).map((a) => ({
            id: a.id,
            main: a.title,
            sub: `${a.status}${a.published_at ? ` · ${new Date(a.published_at).toLocaleDateString()}` : ""} · /${a.slug}`,
            actions: (
              <div className="flex gap-3 text-[10px] uppercase tracking-[0.2em]">
                <button className="text-gold hover:text-foreground" onClick={() => setArticleStatus(a.id, a.status === "published" ? "draft" : "published")}>
                  {a.status === "published" ? "Unpublish" : "Publish"}
                </button>
                <button className="text-destructive hover:text-foreground" onClick={() => deleteArticle(a.id)}>Delete</button>
              </div>
            ),
          }))}
        />
      )}
    </AccountShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-card p-6">
      <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
      <div className="mt-2 font-display italic text-4xl text-gold">{value}</div>
    </div>
  );
}

function Table({ rows, empty }: { rows: { id: string; main: string; sub: string; actions: React.ReactNode }[]; empty: string }) {
  if (rows.length === 0) return <EmptyState title="Nothing here" body={empty} />;
  return (
    <ul className="divide-y divide-border ring-1 ring-border bg-card/40">
      {rows.map((r) => (
        <li key={r.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="min-w-0">
            <div className="font-display italic text-lg truncate">{r.main}</div>
            <div className="text-[11px] text-muted-foreground">{r.sub}</div>
          </div>
          {r.actions}
        </li>
      ))}
    </ul>
  );
}