import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AccountShell } from "@/components/account/AccountShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Account Settings — Mahdi Civilization" },
      { name: "description", content: "Manage your profile, language, notifications, privacy and security settings." },
    ],
  }),
  component: SettingsPage,
});

const LANGS = [
  { code: "en", label: "English" },
  { code: "ur", label: "اردو" },
  { code: "ar", label: "العربية" },
  { code: "fa", label: "فارسی" },
  { code: "tr", label: "Türkçe" },
  { code: "fr", label: "Français" },
  { code: "de", label: "Deutsch" },
];

type PrefsPatch = {
  language?: string;
  direction?: string;
  theme?: string;
  notify_email?: boolean;
  notify_daily?: boolean;
  notify_community?: boolean;
  public_profile?: boolean;
};

function SettingsPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();

  const profileQuery = useQuery({
    queryKey: ["profile", user.id],
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()).data,
  });
  const settingsQuery = useQuery({
    queryKey: ["settings", user.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_settings").select("*").eq("user_id", user.id).maybeSingle();
      if (data) return data;
      const { data: created } = await supabase.from("user_settings").insert({ user_id: user.id }).select().single();
      return created;
    },
  });

  const [fullName, setFullName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [bio, setBio] = useState("");
  const [country, setCountry] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    const p = profileQuery.data;
    if (!p) return;
    setFullName(p.full_name ?? "");
    setAvatarUrl(p.avatar_url ?? "");
    setBio(p.bio ?? "");
    setCountry(p.country ?? "");
  }, [profileQuery.data]);

  const saveProfile = useMutation({
    mutationFn: async () => {
      const payload = {
        id: user.id,
        full_name: fullName.trim().slice(0, 120) || null,
        avatar_url: avatarUrl.trim().slice(0, 500) || null,
        bio: bio.trim().slice(0, 600) || null,
        country: country.trim().slice(0, 80) || null,
      };
      const { error } = await supabase.from("profiles").upsert(payload);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Profile updated");
      qc.invalidateQueries({ queryKey: ["profile", user.id] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const savePrefs = useMutation({
    mutationFn: async (patch: PrefsPatch) => {
      const { error } = await supabase.from("user_settings").update(patch).eq("user_id", user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Preferences saved");
      qc.invalidateQueries({ queryKey: ["settings", user.id] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const changePassword = useMutation({
    mutationFn: async () => {
      if (password.length < 8) throw new Error("Password must be at least 8 characters");
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
    },
    onSuccess: () => {
      setPassword("");
      toast.success("Password updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const s = settingsQuery.data;

  return (
    <AccountShell kicker="Your account" title="Settings" subtitle="Profile, language, notifications, privacy and security — all in one place.">
      <div className="grid lg:grid-cols-2 gap-8">
        <section className="border border-border bg-card/40 p-6">
          <h2 className="font-display italic text-2xl mb-6">Profile</h2>
          <div className="flex items-center gap-4 mb-6">
            <div className="size-16 rounded-full ring-1 ring-gold/40 overflow-hidden bg-background flex items-center justify-center text-gold font-bold">
              {avatarUrl ? (
                <img loading="lazy" decoding="async" src={avatarUrl} alt="Your profile picture" className="size-full object-cover" />
              ) : (
                (fullName || user.email || "IM").slice(0, 2).toUpperCase()
              )}
            </div>
            <Field label="Profile picture URL" value={avatarUrl} onChange={setAvatarUrl} placeholder="https://…" />
          </div>
          <div className="space-y-4">
            <Field label="Full name" value={fullName} onChange={setFullName} placeholder="Your name" />
            <Field label="Country" value={country} onChange={setCountry} placeholder="e.g. Pakistan" />
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Bio</span>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
                maxLength={600}
                className="mt-2 w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
              />
            </label>
            <button
              onClick={() => saveProfile.mutate()}
              disabled={saveProfile.isPending}
              className="px-6 py-3 bg-gold text-primary-foreground text-[11px] font-bold uppercase tracking-[0.25em] disabled:opacity-50"
            >
              Save profile
            </button>
          </div>
        </section>

        <div className="space-y-8">
          <section className="border border-border bg-card/40 p-6">
            <h2 className="font-display italic text-2xl mb-6">Language & Reading</h2>
            <label className="block mb-4">
              <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Preferred language</span>
              <select
                value={s?.language ?? "en"}
                onChange={(e) => savePrefs.mutate({ language: e.target.value })}
                className="mt-2 w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
              >
                {LANGS.map((l) => (
                  <option key={l.code} value={l.code}>{l.label}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Text direction</span>
              <select
                value={s?.direction ?? "auto"}
                onChange={(e) => savePrefs.mutate({ direction: e.target.value })}
                className="mt-2 w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
              >
                <option value="auto">Automatic (RTL for Arabic/Urdu/Farsi)</option>
                <option value="ltr">Always left-to-right</option>
                <option value="rtl">Always right-to-left</option>
              </select>
            </label>
          </section>

          <section className="border border-border bg-card/40 p-6">
            <h2 className="font-display italic text-2xl mb-6">Notifications & Privacy</h2>
            <Toggle label="Email announcements" checked={s?.notify_email ?? true} onChange={(v) => savePrefs.mutate({ notify_email: v })} />
            <Toggle label="Daily devotion reminders" checked={s?.notify_daily ?? true} onChange={(v) => savePrefs.mutate({ notify_daily: v })} />
            <Toggle label="Community replies" checked={s?.notify_community ?? true} onChange={(v) => savePrefs.mutate({ notify_community: v })} />
            <Toggle label="Show my name on community posts" checked={s?.public_profile ?? true} onChange={(v) => savePrefs.mutate({ public_profile: v })} />
          </section>

          <section className="border border-border bg-card/40 p-6">
            <h2 className="font-display italic text-2xl mb-6">Security</h2>
            <p className="text-xs text-muted-foreground mb-4">Signed in as {user.email}</p>
            <label className="block mb-4">
              <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">New password</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                className="mt-2 w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
              />
            </label>
            <button
              onClick={() => changePassword.mutate()}
              disabled={changePassword.isPending || !password}
              className="px-6 py-3 border border-gold text-gold text-[11px] font-bold uppercase tracking-[0.25em] disabled:opacity-40"
            >
              Update password
            </button>
            <button
              onClick={() => supabase.auth.signOut()}
              className="ms-3 px-6 py-3 border border-border text-muted-foreground text-[11px] font-bold uppercase tracking-[0.25em] hover:text-destructive hover:border-destructive"
            >
              Sign out
            </button>
          </section>
        </div>
      </div>
    </AccountShell>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block flex-1">
      <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</span>
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full bg-background border border-border px-3 py-2 text-sm focus:outline-none focus:border-gold/60"
      />
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-4 py-3 border-b border-border last:border-0 cursor-pointer">
      <span className="text-sm">{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="size-4 accent-[hsl(var(--gold))]" />
    </label>
  );
}