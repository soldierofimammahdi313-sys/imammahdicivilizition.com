import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo } from "react";
import { toast } from "sonner";
import { Flame, Sparkles, BookOpen, Sun, Moon, Star, Check, Trophy } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Imam Mahdi Civilization Command Dashboard" }] }),
  component: Dashboard,
});

const RANKS = [
  { name: "Sālik", en: "Seeker", min: 0, color: "text-muted-foreground" },
  { name: "Ṭālib", en: "Student", min: 100, color: "text-emerald" },
  { name: "Muḥibb", en: "Devotee", min: 300, color: "text-emerald" },
  { name: "Nāṣir", en: "Helper", min: 700, color: "text-gold" },
  { name: "Mujāhid", en: "Striver", min: 1500, color: "text-gold" },
  { name: "Anṣār Vanguard", en: "Elite Vanguard", min: 3000, color: "text-gold" },
];
function getRank(xp: number) {
  let cur = RANKS[0], next = RANKS[1];
  for (let i = 0; i < RANKS.length; i++) {
    if (xp >= RANKS[i].min) { cur = RANKS[i]; next = RANKS[i + 1]; }
  }
  return { cur, next };
}

const TASKS = [
  { key: "fajr", label: "Pray Fajr on time", ar: "الفجر", xp: 20, icon: Sun },
  { key: "quran", label: "Read 1 page of Quran", ar: "قراءة القرآن", xp: 15, icon: BookOpen },
  { key: "dhikr", label: "100 dhikr / tasbīḥ", ar: "الذكر", xp: 10, icon: Sparkles },
  { key: "salawat", label: "Send 100 Ṣalawāt", ar: "الصلوات", xp: 10, icon: Star },
  { key: "night", label: "Night reflection / muḥāsabah", ar: "المحاسبة", xp: 15, icon: Moon },
];
const todayStr = () => new Date().toISOString().slice(0, 10);

function Dashboard() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();

  const xpQuery = useQuery({
    queryKey: ["xp", user.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_xp").select("*").eq("user_id", user.id).maybeSingle();
      if (!data) {
        const { data: created } = await supabase.from("user_xp").insert({ user_id: user.id, xp: 0, streak_days: 0 }).select().single();
        return created;
      }
      return data;
    },
  });

  const tasksQuery = useQuery({
    queryKey: ["tasks", user.id, todayStr()],
    queryFn: async () => {
      const { data } = await supabase.from("daily_task_progress")
        .select("task_key").eq("user_id", user.id).eq("completed_on", todayStr());
      return new Set((data ?? []).map((t) => t.task_key));
    },
  });

  const profileQuery = useQuery({
    queryKey: ["profile", user.id],
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()).data,
  });

  const complete = useMutation({
    mutationFn: async (t: typeof TASKS[number]) => {
      const { error } = await supabase.from("daily_task_progress")
        .insert({ user_id: user.id, task_key: t.key, xp_awarded: t.xp, completed_on: todayStr() });
      if (error && !error.message.includes("duplicate")) throw error;
      const currentXp = xpQuery.data?.xp ?? 0;
      const last = xpQuery.data?.last_active_date;
      const streak = xpQuery.data?.streak_days ?? 0;
      const today = todayStr();
      let newStreak = streak;
      if (last !== today) {
        const y = new Date(); y.setDate(y.getDate() - 1);
        newStreak = last === y.toISOString().slice(0, 10) ? streak + 1 : 1;
      }
      await supabase.from("user_xp").update({
        xp: currentXp + t.xp, streak_days: newStreak, last_active_date: today,
      }).eq("user_id", user.id);
      return t;
    },
    onSuccess: (t) => {
      toast.success(`+${t.xp} XP — ${t.label}`, { description: "Barakallāhu fīk" });
      qc.invalidateQueries({ queryKey: ["xp", user.id] });
      qc.invalidateQueries({ queryKey: ["tasks", user.id, todayStr()] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const xp = xpQuery.data?.xp ?? 0;
  const streak = xpQuery.data?.streak_days ?? 0;
  const completed = tasksQuery.data ?? new Set<string>();
  const { cur, next } = useMemo(() => getRank(xp), [xp]);
  const progress = next ? Math.min(100, ((xp - cur.min) / (next.min - cur.min)) * 100) : 100;
  const name = profileQuery.data?.full_name ?? (user.user_metadata?.full_name as string) ?? user.email;
  const todayCount = completed.size;

  return (
    <div className="bg-background text-foreground min-h-screen relative overflow-hidden">
      {/* Cyber-islamic animated background */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute top-1/4 -left-40 size-96 bg-emerald/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-1/4 -right-40 size-96 bg-gold/20 blur-[120px] rounded-full animate-pulse [animation-delay:1s]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 size-[80vw] border border-gold/5 rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 size-[50vw] border border-emerald/5 rounded-full" />
      </div>

      <SiteHeader />
      <div className="relative pt-32 pb-16 px-4 md:px-6 max-w-7xl mx-auto">
        {/* Header hero */}
        <div className="border border-gold/30 bg-card/50 backdrop-blur-sm p-6 md:p-10 relative overflow-hidden">
          <div className="absolute -top-24 -right-24 size-64 bg-gold/10 blur-[100px] rounded-full" />
          <div className="relative flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
            <div>
              <span className="font-arabic text-3xl text-gold/50 block">السلام عليكم</span>
              <h1 className="mt-2 font-display italic text-3xl md:text-5xl">{name}</h1>
              <div className="mt-3 flex items-center gap-3 text-xs uppercase tracking-widest">
                <span className={`px-3 py-1 border border-gold/40 ${cur.color}`}>
                  <Trophy className="size-3 inline mr-1.5" /> {cur.name} · {cur.en}
                </span>
                {next && <span className="text-muted-foreground">{next.min - xp} XP to {next.name}</span>}
              </div>
            </div>
            <div className="flex gap-4">
              <StatBox icon={<Sparkles className="size-4" />} label="Total XP" value={xp} />
              <StatBox icon={<Flame className="size-4 text-gold" />} label="Streak" value={`${streak}d`} />
              <StatBox icon={<Check className="size-4 text-emerald" />} label="Today" value={`${todayCount}/${TASKS.length}`} />
            </div>
          </div>

          {/* Rank progress */}
          <div className="relative mt-8">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
              <span>{cur.name}</span>
              <span>{xp} / {next?.min ?? xp} XP</span>
              <span>{next?.name ?? "MAX"}</span>
            </div>
            <div className="h-2 bg-background border border-border overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald via-gold to-gold shadow-[0_0_20px_hsl(var(--gold)/0.6)] transition-all duration-700" style={{ width: `${progress}%` }} />
            </div>
          </div>
        </div>

        {/* Daily tasks */}
        <div className="mt-10">
          <div className="flex items-end justify-between mb-6">
            <div>
              <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Daily Wird</span>
              <h2 className="mt-1 font-display italic text-3xl">Today's Spiritual Tasks</h2>
            </div>
            <span className="text-xs text-muted-foreground">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</span>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {TASKS.map((t) => {
              const done = completed.has(t.key);
              const Icon = t.icon;
              return (
                <button
                  key={t.key}
                  disabled={done || complete.isPending}
                  onClick={() => complete.mutate(t)}
                  className={`text-left border p-5 transition-all group relative overflow-hidden ${
                    done
                      ? "border-emerald/60 bg-emerald-soft/40"
                      : "border-border bg-card/40 hover:border-gold/60 hover:bg-card hover:shadow-[0_0_30px_-10px_hsl(var(--gold)/0.5)]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className={`size-10 flex items-center justify-center border ${done ? "border-emerald bg-emerald text-primary-foreground" : "border-border text-gold group-hover:border-gold"}`}>
                      {done ? <Check className="size-5" /> : <Icon className="size-5" />}
                    </div>
                    <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 ${done ? "text-emerald" : "text-gold"}`}>+{t.xp} XP</span>
                  </div>
                  <div className="mt-4">
                    <div className="font-arabic text-2xl text-gold/70">{t.ar}</div>
                    <div className="mt-1 font-display italic text-lg">{t.label}</div>
                    <div className="mt-2 text-[11px] uppercase tracking-widest text-muted-foreground">
                      {done ? "✓ Completed" : "Tap to complete"}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Ranks table */}
        <div className="mt-14 border border-border bg-card/30 p-6">
          <h3 className="font-display italic text-2xl mb-4">The Path of Ranks</h3>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {RANKS.map((r) => {
              const unlocked = xp >= r.min;
              const isCurrent = r.name === cur.name;
              return (
                <div key={r.name} className={`p-4 border ${isCurrent ? "border-gold bg-gold-soft/30" : unlocked ? "border-emerald/40" : "border-border opacity-60"}`}>
                  <div className={`text-lg font-display italic ${r.color}`}>{r.name}</div>
                  <div className="text-[11px] uppercase tracking-widest text-muted-foreground">{r.en}</div>
                  <div className="mt-1 text-xs">{r.min}+ XP {isCurrent && <span className="text-gold ml-1">← you</span>}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-10 grid md:grid-cols-3 gap-4">
          <Link to="/quran" className="border border-border p-6 bg-card/40 hover:border-gold/60 hover:shadow-[0_0_30px_-10px_hsl(var(--gold)/0.5)] transition-all">
            <BookOpen className="size-6 text-gold" />
            <div className="mt-4 font-display italic text-xl">Continue Quran</div>
            <div className="text-xs text-muted-foreground mt-1">Read today's page</div>
          </Link>
          <Link to="/tasbih" className="border border-border p-6 bg-card/40 hover:border-gold/60 hover:shadow-[0_0_30px_-10px_hsl(var(--gold)/0.5)] transition-all">
            <Sparkles className="size-6 text-gold" />
            <div className="mt-4 font-display italic text-xl">Digital Tasbih</div>
            <div className="text-xs text-muted-foreground mt-1">Track your dhikr</div>
          </Link>
          <Link to="/ai" className="border border-border p-6 bg-card/40 hover:border-gold/60 hover:shadow-[0_0_30px_-10px_hsl(var(--gold)/0.5)] transition-all">
            <Star className="size-6 text-gold" />
            <div className="mt-4 font-display italic text-xl">Ask N-EYES</div>
            <div className="text-xs text-muted-foreground mt-1">Ja'fari AI Engine</div>
          </Link>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="border border-border bg-background/50 px-4 py-2 min-w-[90px]">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground">{icon}{label}</div>
      <div className="font-display italic text-2xl mt-0.5">{value}</div>
    </div>
  );
}
