import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { useI18n } from "@/lib/i18n";
import { FIQH_SCHOOLS, fiqhBySlug, fiqhName, fiqhTagline, useFiqh } from "@/lib/fiqh";
import { LIBRARY_BOOKS } from "@/lib/library-books";
import { buildHead, pageHead, PAGE_SEO } from "@/lib/seo";
import { SITE_NAME, SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/fiqh/$school")({
  loader: ({ params }) => {
    const school = fiqhBySlug(params.school);
    if (!school) throw notFound();
    return school;
  },
  head: ({ loaderData }) => {
    const s = loaderData;
    if (!s) return buildHead({ path: "/fiqh", title: "Fiqh", description: "Schools of Islamic jurisprudence." });
    // Every school has its own entry in the central SEO table.
    const path = `/fiqh/${s.slug}`;
    const seo = PAGE_SEO[path];
    const title = seo?.title ?? `${s.name.en} School of Jurisprudence`;
    const description =
      seo?.description ??
      `A short, factual introduction to the ${s.name.en} school of Islamic jurisprudence and the related material held in our archive.`;
    const base = pageHead(path);
    return {
      ...base,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: title,
            description,
            url: `${SITE_URL}${path}`,
            inLanguage: "en",
            isPartOf: { "@type": "WebSite", name: SITE_NAME, url: SITE_URL },
          }),
        },
      ],
    };
  },
  component: FiqhSchoolPage,
});

function FiqhSchoolPage() {
  const school = Route.useLoaderData();
  const { t, lang } = useI18n();
  const { fiqh, setFiqh } = useFiqh();

  const isCurrent = fiqh === school.id;
  const entries = LIBRARY_BOOKS.filter((b) =>
    school.id === "general" ? b.fiqh.includes("general") : b.fiqh.includes(school.id),
  );
  const others = FIQH_SCHOOLS.filter((s) => s.id !== school.id);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs
        items={[{ label: t("nav.fiqh"), to: "/fiqh" }, { label: fiqhName(school, lang) }]}
      />

      <article className="pt-4 pb-16 px-6 max-w-4xl mx-auto">
        <header>
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">
            {t("fiqh.schools")}
          </span>
          <h1 className="mt-4 font-display italic text-4xl md:text-5xl leading-tight">
            {fiqhName(school, lang)}
          </h1>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
            {fiqhTagline(school, lang)}
          </p>
        </header>

        {(school.attributedTo || school.regions.length > 0) && (
          <dl className="mt-8 grid gap-4 sm:grid-cols-3 border-y border-border py-6">
            {school.attributedTo && (
              <div>
                <dt className="text-[10px] uppercase tracking-[0.25em] text-gold">
                  {t("fiqh.attributedTo")}
                </dt>
                <dd className="mt-1.5 text-sm text-foreground/90">{school.attributedTo}</dd>
              </div>
            )}
            {school.era && (
              <div>
                <dt className="text-[10px] uppercase tracking-[0.25em] text-gold">{t("fiqh.era")}</dt>
                <dd className="mt-1.5 text-sm text-foreground/90">{school.era}</dd>
              </div>
            )}
            {school.regions.length > 0 && (
              <div>
                <dt className="text-[10px] uppercase tracking-[0.25em] text-gold">
                  {t("fiqh.regions")}
                </dt>
                <dd className="mt-1.5 text-sm text-foreground/90">{school.regions.join(", ")}</dd>
              </div>
            )}
          </dl>
        )}

        <div className="mt-8 space-y-4 text-[15px] leading-relaxed text-muted-foreground">
          {school.about.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>

        <p className="mt-8 text-sm text-muted-foreground border-s-2 border-gold/50 ps-4">
          {t("fiqh.note")}
        </p>

        <div className="mt-8 flex flex-wrap gap-2">
          {!isCurrent && (
            <button
              type="button"
              onClick={() => setFiqh(school.id)}
              className="inline-flex min-h-11 items-center px-5 bg-gold text-primary-foreground font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-foreground transition-colors"
            >
              {t("common.apply")}
            </button>
          )}
          {school.related.map((r) => (
            <Link
              key={r.to}
              to={r.to}
              className="inline-flex min-h-11 items-center px-4 border border-border text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors"
            >
              {r.label}
            </Link>
          ))}
        </div>

        {/* Catalogue entries recorded under this school */}
        <section className="mt-14" aria-labelledby="fiqh-library-heading">
          <h2 id="fiqh-library-heading" className="font-display italic text-2xl">
            {t("fiqh.inLibrary")}
          </h2>
          {entries.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">{t("fiqh.emptyLibrary")}</p>
          ) : (
            <ul className="mt-5 grid gap-px bg-border ring-1 ring-border sm:grid-cols-2">
              {entries.map((b) => (
                <li key={b.slug} className="bg-card">
                  <Link
                    to="/library/$slug"
                    params={{ slug: b.slug }}
                    className="block p-6 hover:bg-emerald-soft transition-colors h-full"
                  >
                    <span className="font-mono-display text-[10px] uppercase tracking-widest text-emerald">
                      {b.category}
                    </span>
                    <h3 className="mt-2 font-display text-lg leading-tight">{b.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground" dir="rtl" lang="ar">
                      {b.arabic}
                    </p>
                    <p className="mt-2 text-xs text-muted-foreground">{b.author}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
          <Link
            to="/library"
            className="mt-5 inline-flex min-h-11 items-center px-4 border border-border text-[11px] uppercase tracking-[0.18em] text-gold hover:border-gold/50 transition-colors"
          >
            {t("nav.library")}
          </Link>
        </section>

        {/* Sibling schools */}
        <nav className="mt-14 border-t border-border pt-8" aria-labelledby="other-schools">
          <h2 id="other-schools" className="text-[10px] uppercase tracking-[0.3em] text-gold">
            {t("fiqh.browseAll")}
          </h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {others.map((s) => (
              <li key={s.id}>
                <Link
                  to="/fiqh/$school"
                  params={{ school: s.slug }}
                  className="inline-flex min-h-10 items-center px-3 border border-border text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors"
                >
                  {fiqhName(s, lang)}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </article>

      <SiteFooter />
    </div>
  );
}
