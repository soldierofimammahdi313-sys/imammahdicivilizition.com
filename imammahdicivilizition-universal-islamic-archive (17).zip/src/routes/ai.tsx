import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { chatTransport } from "@/lib/chat-transport";
import { useEffect, useRef, useState, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { Send, Square, Copy, Share2, Plus, Trash2, MessageSquare } from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { breadcrumbLd } from "@/lib/site";
import { AiCreditsNotice } from "@/components/site/AiCreditsNotice";
import { classifyAiError } from "@/lib/ai-errors";
import {
  appendMessage,
  createConversation,
  deleteConversation,
  listConversations,
  loadConversation,
  messageText,
  toUiMessages,
} from "@/lib/ai-history";

export const Route = createFileRoute("/ai")({
  head: () => ({
    meta: [
      { title: "N-EYES — Islamic AI Knowledge Engine" },
      { name: "description", content: "Ask anything about Islam — Quran, hadith, history, spirituality. Powered by Lovable AI." },
      { property: "og:title", content: "N-EYES — Islamic AI Knowledge Engine" },
      { property: "og:description", content: "Ask anything about Islam — Quran, hadith, history, spirituality. Powered by Lovable AI." },
      { property: "og:url", content: "https://imammahdicivilizition.com/ai" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/ai" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(breadcrumbLd([{ label: "AI Assistant", to: "/ai" }])) }],
  }),
  component: AiPage,
});

const SUGGESTIONS = [
  "امام مہدی (عج) کے بارے میں احادیث کیا کہتی ہیں؟",
  "فقہ جعفریہ میں خمس کا حکم تفصیل سے بیان کریں۔",
  "نمازِ شب (تہجد) کا طریقہ اور اس کی فضیلت کیا ہے؟",
  "زیارتِ عاشورا کی اہمیت اور اس کے فوائد بتائیں۔",
  "Explain the Ja'fari ruling on wudu step by step.",
  "Give a brief biography of Imam Ja'far al-Sadiq (a.s).",
];

function AiPage() {
  const [input, setInput] = useState("");
  const [user, setUser] = useState<User | null>(null);
  const [aiError, setAiError] = useState<{ kind: "credits" | "rate-limit" | "other"; message: string } | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [seed, setSeed] = useState(0);
  const [initialMessages, setInitialMessages] = useState<ReturnType<typeof toUiMessages>>([]);
  const qc = useQueryClient();
  const { messages, sendMessage, status, stop, setMessages } = useChat({
    transport: chatTransport,
    onError: (err) => {
      const kind = classifyAiError(err);
      setAiError({ kind, message: err.message || "AI could not respond. Please try again." });
      if (kind !== "credits") toast.error(err.message || "AI could not respond. Please try again.");
    },
  });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const savedIds = useRef<Set<string>>(new Set());
  const conversationIdRef = useRef<string | null>(null);
  conversationIdRef.current = conversationId;

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const conversationsQuery = useQuery({
    queryKey: ["ai-conversations", user?.id],
    enabled: Boolean(user),
    queryFn: listConversations,
  });

  useEffect(() => {
    setMessages(initialMessages);
  }, [seed, initialMessages, setMessages]);

  /** Persist any completed messages that are not yet stored. */
  const persist = useCallback(async () => {
    if (!user || status === "streaming" || status === "submitted") return;
    const unsaved = messages.filter((m) => !savedIds.current.has(m.id) && messageText(m).trim().length > 0);
    if (unsaved.length === 0) return;
    try {
      let id = conversationIdRef.current;
      if (!id) {
        id = await createConversation(user.id, messageText(unsaved[0]));
        conversationIdRef.current = id;
        setConversationId(id);
      }
      for (const m of unsaved) {
        await appendMessage(id, m.role, messageText(m));
        savedIds.current.add(m.id);
      }
      qc.invalidateQueries({ queryKey: ["ai-conversations", user.id] });
    } catch {
      /* history is best-effort; never block the chat */
    }
  }, [messages, status, user, qc]);

  useEffect(() => {
    void persist();
  }, [persist]);

  async function openConversation(id: string) {
    const rows = await loadConversation(id);
    const ui = toUiMessages(rows);
    savedIds.current = new Set(ui.map((m) => m.id));
    setConversationId(id);
    setInitialMessages(ui);
    setSeed((s) => s + 1);
  }

  function newConversation() {
    savedIds.current = new Set();
    setConversationId(null);
    setInitialMessages([]);
    setSeed((s) => s + 1);
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  async function removeConversation(id: string) {
    await deleteConversation(id);
    if (conversationId === id) newConversation();
    qc.invalidateQueries({ queryKey: ["ai-conversations", user?.id] });
    toast.success("Conversation deleted");
  }

  async function copyText(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Could not copy");
    }
  }

  async function shareText(text: string) {
    const payload = { title: "N-EYES — Ja'fari Knowledge Engine", text };
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share(payload);
        return;
      } catch {
        /* user cancelled */
      }
    }
    await copyText(text);
  }

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const isBusy = status === "submitted" || status === "streaming";

  function submit(text?: string) {
    const value = (text ?? input).trim();
    if (!value || isBusy) return;
    setAiError(null);
    sendMessage({ text: value });
    setInput("");
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  function retryLast() {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    setAiError(null);
    if (lastUser) sendMessage({ text: messageText(lastUser) });
  }

  return (
    <div className="bg-background text-foreground min-h-screen flex flex-col">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "AI Assistant" }]} jsonLd={false} />
      <div className="flex-1 w-full max-w-7xl mx-auto pt-6 px-4 md:px-6 grid lg:grid-cols-[260px_1fr] gap-8">
        <aside className="hidden lg:flex flex-col gap-3 py-6 border-e border-border pe-4">
          <button
            onClick={newConversation}
            className="inline-flex items-center justify-center gap-2 border border-gold text-gold py-2.5 text-[10px] uppercase tracking-[0.25em] hover:bg-gold-soft/30"
          >
            <Plus className="size-3.5" /> New chat
          </button>
          <span className="mt-4 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">History</span>
          {!user && <p className="text-xs text-muted-foreground">Sign in to keep your conversation history.</p>}
          <ul className="space-y-1 overflow-y-auto max-h-[60vh]">
            {(conversationsQuery.data ?? []).map((c) => (
              <li key={c.id} className="group flex items-center gap-1">
                <button
                  onClick={() => openConversation(c.id)}
                  className={`flex-1 text-left truncate px-3 py-2 text-xs border transition-colors ${
                    conversationId === c.id ? "border-gold/60 text-gold bg-gold-soft/20" : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                  }`}
                >
                  <MessageSquare className="size-3 inline me-2 opacity-60" />
                  {c.title}
                </button>
                <button
                  onClick={() => removeConversation(c.id)}
                  aria-label="Delete conversation"
                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-opacity"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
        </aside>

        <div className="flex-1 flex flex-col min-w-0">
        <header className="text-center py-6 border-b border-border">
          <span className="font-mono-display text-[10px] text-emerald tracking-[0.4em]">N-EYES · فقہ جعفریہ AI</span>
          <h1 className="mt-2 font-display italic text-3xl md:text-4xl">Ja'fari Knowledge Engine</h1>
          <p className="mt-2 text-xs text-muted-foreground">مکتبِ اہلِ بیت ؑ · Grounded in Quran, Ahl al-Bayt & the Four Books</p>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto py-8 space-y-6">
          {messages.length === 0 && (
            <div className="space-y-6">
              <div className="text-center">
                <span className="font-arabic text-5xl text-gold/40 block">بسم الله</span>
                <p className="mt-4 text-muted-foreground">Begin a conversation. Ask in any language.</p>
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="text-left border border-border p-4 hover:border-gold/50 hover:bg-card transition-colors text-sm"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => {
            const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
            return (
              <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}>
                {m.role === "user" ? (
                  <div className="max-w-[85%] bg-emerald text-primary-foreground px-5 py-3 rounded-2xl rounded-br-sm">
                    <p className="text-sm whitespace-pre-wrap">{text}</p>
                  </div>
                ) : (
                  <div className="flex gap-3">
                    <div className="size-8 rounded-full ring-1 ring-gold/50 flex items-center justify-center text-[10px] font-bold text-gold shrink-0">IM</div>
                    <div className="flex-1 min-w-0">
                      <div className="prose prose-invert prose-sm max-w-none prose-p:my-2 prose-a:text-gold prose-strong:text-gold prose-pre:bg-background prose-pre:border prose-pre:border-border">
                        <ReactMarkdown>{text || "…"}</ReactMarkdown>
                      </div>
                      {text && (
                        <div className="mt-2 flex gap-4 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                          <button onClick={() => copyText(text)} className="inline-flex items-center gap-1.5 hover:text-gold">
                            <Copy className="size-3.5" /> Copy
                          </button>
                          <button onClick={() => shareText(text)} className="inline-flex items-center gap-1.5 hover:text-gold">
                            <Share2 className="size-3.5" /> Share
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {status === "submitted" && (
            <div className="flex gap-3">
              <div className="size-8 rounded-full ring-1 ring-gold/50 flex items-center justify-center text-[10px] font-bold text-gold shrink-0">IM</div>
              <div className="flex items-center gap-1 pt-2">
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse" />
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse [animation-delay:.2s]" />
                <span className="size-1.5 bg-gold/60 rounded-full animate-pulse [animation-delay:.4s]" />
              </div>
            </div>
          )}

          {aiError && (
            <AiCreditsNotice
              kind={aiError.kind}
              message={aiError.message}
              onRetry={retryLast}
              onDismiss={() => setAiError(null)}
            />
          )}
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); submit(); }}
          className="border-t border-border py-4 sticky bottom-0 bg-background"
        >
          <div className="flex items-end gap-2 border border-border focus-within:border-gold/60 bg-card/40 p-2">
            <textarea
              ref={inputRef}
              aria-label="Ask N-EYES a question"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
              }}
              rows={1}
              placeholder="Ask N-EYES anything…"
              className="flex-1 bg-transparent resize-none px-3 py-2 text-sm focus:outline-none max-h-40"
            />
            {isBusy ? (
              <button type="button" aria-label="Stop generating" onClick={() => stop()} className="size-10 bg-destructive text-destructive-foreground flex items-center justify-center">
                <Square className="size-4" />
              </button>
            ) : (
              <button type="submit" aria-label="Send message" disabled={!input.trim()} className="size-10 bg-gold text-primary-foreground flex items-center justify-center disabled:opacity-40">
                <Send className="size-4" />
              </button>
            )}
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground text-center">N-EYES can make mistakes. Always verify with a qualified scholar.</p>
        </form>
        </div>
      </div>
    </div>
  );
}