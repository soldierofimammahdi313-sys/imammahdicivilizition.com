import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/timeline")({
  head: () => ({
    meta: [
      { title: "Islamic History Timeline — Revelation to Occultation | Imam Mahdi Civilization" },
      { name: "description", content: "An interactive timeline of Islamic history: revelation, hijrah, the caliphate, Karbala, the Twelve Imams and the Ghaybah — with dates in Hijri and Gregorian." },
      { property: "og:title", content: "Islamic History Timeline" },
      { property: "og:description", content: "Revelation to Occultation — every turning point of Islamic history on one interactive line." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/timeline" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/timeline" }],
  }),
  component: TimelinePage,
});

type Era = "Revelation" | "Caliphate" | "Imamate" | "Ghaybah";

type Event = { ah: string; ce: string; title: string; arabic?: string; desc: string; era: Era };

const EVENTS: Event[] = [
  { ah: "−53", ce: "570 CE", title: "Birth of the Messenger ﷺ", arabic: "المولد", desc: "Muhammad ibn Abdullah is born in Makkah in the Year of the Elephant.", era: "Revelation" },
  { ah: "−13", ce: "610 CE", title: "First Revelation", arabic: "اقرأ", desc: "Iqra is revealed in the cave of Hira; the Qur'an begins its twenty-three year descent.", era: "Revelation" },
  { ah: "−10", ce: "613 CE", title: "Public Call & Dawat dhul-Ashira", desc: "The message goes public; Ali ibn Abi Talib is the first to answer.", era: "Revelation" },
  { ah: "−3", ce: "619 CE", title: "Year of Sorrow", desc: "Abu Talib and Khadijah pass away within months of one another.", era: "Revelation" },
  { ah: "1", ce: "622 CE", title: "The Hijrah", arabic: "الهجرة", desc: "Migration to Yathrib, renamed Madinat al-Nabi. The Islamic calendar begins.", era: "Revelation" },
  { ah: "2", ce: "624 CE", title: "Battle of Badr", desc: "313 believers face a thousand; the first decisive victory.", era: "Revelation" },
  { ah: "3", ce: "625 CE", title: "Battle of Uhud", desc: "Hamza is martyred; the lesson of obedience is written in blood.", era: "Revelation" },
  { ah: "5", ce: "627 CE", title: "Battle of the Trench", desc: "Ali defeats Amr ibn Abd Wudd; the confederates disperse.", era: "Revelation" },
  { ah: "6", ce: "628 CE", title: "Treaty of Hudaybiyyah", desc: "An apparent concession that opens the path to the conquest of Makkah.", era: "Revelation" },
  { ah: "8", ce: "630 CE", title: "Conquest of Makkah", desc: "The Kaaba is cleansed of idols without a battle.", era: "Revelation" },
  { ah: "10", ce: "632 CE", title: "Ghadir Khumm", arabic: "الغدیر", desc: "'Whoever's mawla I am, Ali is his mawla' — declared before the returning pilgrims.", era: "Revelation" },
  { ah: "11", ce: "632 CE", title: "Passing of the Messenger ﷺ", desc: "The Prophet returns to his Lord in Madinah, leaving the Qur'an and his Ahl al-Bayt.", era: "Caliphate" },
  { ah: "11", ce: "632 CE", title: "Fadak & the Sermon of Fatima", desc: "Sayyida Fatima al-Zahra delivers the Khutba Fadakiyya.", era: "Caliphate" },
  { ah: "35", ce: "656 CE", title: "Caliphate of Imam Ali", desc: "Ali ibn Abi Talib accepts the caliphate after the killing of Uthman.", era: "Caliphate" },
  { ah: "37", ce: "657 CE", title: "Battle of Siffin", desc: "Mu'awiya's forces raise Qur'ans on spears; arbitration fractures the army.", era: "Caliphate" },
  { ah: "40", ce: "661 CE", title: "Martyrdom of Imam Ali", desc: "Struck in the mihrab of Kufa during Ramadan.", era: "Caliphate" },
  { ah: "50", ce: "670 CE", title: "Martyrdom of Imam Hasan", desc: "Poisoned after the treaty that preserved the community.", era: "Imamate" },
  { ah: "61", ce: "680 CE", title: "Karbala", arabic: "كربلاء", desc: "Imam Husayn and 72 companions are martyred on Ashura; Zaynab carries the message.", era: "Imamate" },
  { ah: "95", ce: "713 CE", title: "Martyrdom of Imam Sajjad", desc: "Al-Sahifa al-Sajjadiyya, the Psalms of the Household, is left behind.", era: "Imamate" },
  { ah: "114", ce: "732 CE", title: "Imam al-Baqir", desc: "The Splitter of Knowledge establishes the school of the Ahl al-Bayt.", era: "Imamate" },
  { ah: "148", ce: "765 CE", title: "Imam al-Sadiq", desc: "Four thousand students; the Ja'fari school of jurisprudence takes form.", era: "Imamate" },
  { ah: "183", ce: "799 CE", title: "Imam al-Kadhim", desc: "Martyred in the prison of Harun al-Rashid.", era: "Imamate" },
  { ah: "203", ce: "818 CE", title: "Imam al-Rida in Khurasan", desc: "Forced heir apparency; martyred and buried in Mashhad.", era: "Imamate" },
  { ah: "260", ce: "874 CE", title: "Minor Occultation begins", arabic: "الغیبة الصغرى", desc: "Imam al-Mahdi assumes the imamate; contact continues through four deputies.", era: "Ghaybah" },
  { ah: "329", ce: "941 CE", title: "Major Occultation", desc: "The final letter of the fourth deputy; the age of waiting and preparation begins.", era: "Ghaybah" },
  { ah: "381", ce: "991 CE", title: "Shaykh al-Saduq", desc: "Man la yahduruhu al-Faqih is compiled — one of the Four Books.", era: "Ghaybah" },
  { ah: "460", ce: "1067 CE", title: "Shaykh al-Tusi in Najaf", desc: "The Hawza of Najaf is founded; it teaches to this day.", era: "Ghaybah" },
  { ah: "1401", ce: "1981 CE", title: "Allama Tabatabai", desc: "Tafsir al-Mizan completes twenty volumes of Qur'an-by-Qur'an exegesis.", era: "Ghaybah" },
];

const ERAS: Era[] = ["Revelation", "Caliphate", "Imamate", "Ghaybah"];
const ERA_TONE: Record<Era, string> = {
  Revelation: "text-gold border-gold/40",
  Caliphate: "text-emerald border-emerald/40",
  Imamate: "text-gold border-gold/40",
  Ghaybah: "text-muted-foreground border-border",
};

function TimelinePage() {
  const [era, setEra] = useState<Era | "all">("all");
  const events = useMemo(() => (era === "all" ? EVENTS : EVENTS.filter((e) => e.era === era)), [era]);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Timeline" }]} />
      <section className="pt-8 pb-16 px-4 md:px-6 max-w-5xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Knowledge / Timeline</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">From Revelation to Occultation</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            {EVENTS.length} turning points of Islamic history, dated in both Hijri and Gregorian reckoning.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {(["all", ...ERAS] as const).map((e) => (
            <button
              key={e}
              onClick={() => setEra(e)}
              aria-pressed={era === e}
              className={`px-4 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                era === e ? "border-gold text-gold bg-gold-soft/30" : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
              }`}
            >
              {e === "all" ? "All eras" : e}
            </button>
          ))}
        </div>

        <ol className="mt-14 relative border-s border-border ps-6 md:ps-10 space-y-8">
          {events.map((ev) => (
            <li key={ev.title + ev.ah} className="relative">
              <span className="absolute -start-[31px] md:-start-[47px] top-2 size-3 rounded-full bg-gold ring-4 ring-background" />
              <article className="bg-card border border-border p-6 hover:border-gold/50 transition-colors">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono-display text-sm text-gold">{ev.ah} AH</span>
                  <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{ev.ce}</span>
                  <span className={`ms-auto border px-2 py-1 text-[9px] uppercase tracking-[0.25em] ${ERA_TONE[ev.era]}`}>{ev.era}</span>
                </div>
                <div className="mt-3 flex items-start justify-between gap-4">
                  <h2 className="font-display italic text-2xl">{ev.title}</h2>
                  {ev.arabic && <span className="font-arabic text-xl text-gold/60 shrink-0">{ev.arabic}</span>}
                </div>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{ev.desc}</p>
              </article>
            </li>
          ))}
        </ol>
      </section>
      <SiteFooter />
    </div>
  );
}