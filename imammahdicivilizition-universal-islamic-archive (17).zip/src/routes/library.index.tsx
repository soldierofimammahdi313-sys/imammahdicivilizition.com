import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/library.jpg";
import { LIBRARY_BOOKS, ARCHIVE_TYPES, archiveTypeKey, type ArchiveType } from "@/lib/library-books";
import { libraryCover } from "@/lib/library-covers";
import { fetchPublishedLibraryItems, itemFiqh, type LibraryItem } from "@/lib/library-items";
import { FIQH_SCHOOLS, fiqhById, fiqhName, useFiqh, type FiqhId } from "@/lib/fiqh";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";
import { SITE_NAME, SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/library/")({
  head: () => {
    const base = pageHead("/library");
    return {
      ...base,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: "Universal Islamic Digital Archive",
            url: `${SITE_URL}/library`,
            isPartOf: { "@type": "WebSite", name: SITE_NAME, url: SITE_URL },
            hasPart: LIBRARY_BOOKS.map((b) => ({
              "@type": "Book",
              name: b.title,
              author: { "@type": "Person", name: b.author },
              url: `${SITE_URL}/library/${b.slug}`,
              inLanguage: "en",
            })),
          }),
        },
      ],
    };
  },
  component: LibraryPage,
});

const ALL = "all";

/** A single labelled <select>; native controls behave correctly in RTL and on mobile. */
function Filter({
  id,
  label,
  value,
  onChange,
  options,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="flex flex-col gap-1.5 min-w-0">
      <label htmlFor={id} className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full bg-card border border-border px-3 text-sm text-foreground focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold/40"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function LibraryPage() {
  const { t, lang } = useI18n();
  const { fiqh: preferred } = useFiqh();

  const [query, setQuery] = useState("");
  const [fiqhFilter, setFiqhFilter] = useState<FiqhId | typeof ALL>(ALL);
  const [typeFilter, setTypeFilter] = useState<ArchiveType | typeof ALL>(ALL);
  const [topicFilter, setTopicFilter] = useState<string>(ALL);
  const [authorFilter, setAuthorFilter] = useState<string>(ALL);
  const [langFilter, setLangFilter] = useState<string>(ALL);

  const collection = useQuery({
    queryKey: ["library-items"],
    queryFn: fetchPublishedLibraryItems,
    staleTime: 5 * 60 * 1000,
  });
  const dbItems: LibraryItem[] = collection.data ?? [];

  const needle = query.trim().toLowerCase();

  const matches = (fields: (string | null | undefined)[]) =>
    !needle || fields.some((f) => (f ?? "").toLowerCase().includes(needle));

  const books = useMemo(
    () =>
      LIBRARY_BOOKS.filter((b) => {
        if (fiqhFilter !== ALL && !b.fiqh.includes(fiqhFilter)) return false;
        if (typeFilter !== ALL && b.type !== typeFilter) return false;
        if (topicFilter !== ALL && b.category !== topicFilter) return false;
        if (authorFilter !== ALL && b.author !== authorFilter) return false;
        if (langFilter !== ALL && langFilter !== "en") return false;
        return matches([b.title, b.arabic, b.author, b.category, b.summary, b.era]);
      }),
    [fiqhFilter, typeFilter, topicFilter, authorFilter, langFilter, needle],
  );

  const items = useMemo(
    () =>
      dbItems.filter((i) => {
        const recorded = itemFiqh(i);
        if (fiqhFilter !== ALL && recorded !== fiqhFilter) return false;
        // Database entries are editorial readings and studies.
        if (typeFilter !== ALL && typeFilter !== "research") return false;
        if (topicFilter !== ALL && i.category !== topicFilter) return false;
        if (authorFilter !== ALL && i.author !== authorFilter) return false;
        if (langFilter !== ALL && i.language !== langFilter) return false;
        return matches([i.title, i.arabic_title, i.author, i.category, i.summary, i.era]);
      }),
    [dbItems, fiqhFilter, typeFilter, topicFilter, authorFilter, langFilter, needle],
  );

  const topics = useMemo(
    () =>
      Array.from(
        new Set([...LIBRARY_BOOKS.map((b) => b.category), ...dbItems.map((i) => i.category)]),
      ).sort(),
    [dbItems],
  );
  const authors = useMemo(
    () =>
      Array.from(
        new Set(
          [...LIBRARY_BOOKS.map((b) => b.author), ...dbItems.map((i) => i.author)].filter(
            (a): a is string => !!a,
          ),
        ),
      ).sort(),
    [dbItems],
  );
  const languages = useMemo(
    () => Array.from(new Set(["en", ...dbItems.map((i) => i.language)])).sort(),
    [dbItems],
  );

  const total = books.length + items.length;
  const filtered =
    !!needle ||
    fiqhFilter !== ALL ||
    typeFilter !== ALL ||
    topicFilter !== ALL ||
    authorFilter !== ALL ||
    langFilter !== ALL;

  const reset = () => {
    setQuery("");
    setFiqhFilter(ALL);
    setTypeFilter(ALL);
    setTopicFilter(ALL);
    setAuthorFilter(ALL);
    setLangFilter(ALL);
  };

  const allOption = { value: ALL, label: t("library.filter.all") };

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: t("nav.library") }]} />
      <PageBanner
        src={bannerImg}
        alt="Shelves of the Islamic digital archive"
        eyebrow={t("nav.library")}
        title={t("library.title")}
        subtitle={t("library.subtitle")}
      />

      <section className="pt-10 pb-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="font-display italic text-4xl md:text-5xl">{t("library.title")}</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">{t("library.subtitle")}</p>
        </div>

        {/* ---------------- Filters ---------------- */}
        <div role="search" aria-label={t("library.filters")} className="surface-card p-5 sm:p-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            <div className="flex flex-col gap-1.5 xl:col-span-2">
              <label
                htmlFor="library-q"
                className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground"
              >
                {t("library.search")}
              </label>
              <input
                id="library-q"
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("library.searchPlaceholder")}
                className="min-h-11 w-full bg-card border border-border px-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold/40"
              />
            </div>

            <Filter
              id="library-fiqh"
              label={t("library.filter.fiqh")}
              value={fiqhFilter}
              onChange={(v) => setFiqhFilter(v as FiqhId | typeof ALL)}
              options={[
                allOption,
                ...FIQH_SCHOOLS.map((s) => ({ value: s.id, label: fiqhName(s, lang) })),
              ]}
            />
            <Filter
              id="library-type"
              label={t("library.filter.type")}
              value={typeFilter}
              onChange={(v) => setTypeFilter(v as ArchiveType | typeof ALL)}
              options={[
                allOption,
                ...ARCHIVE_TYPES.map((a) => ({ value: a, label: t(archiveTypeKey(a)) })),
              ]}
            />
            <Filter
              id="library-topic"
              label={t("library.filter.topic")}
              value={topicFilter}
              onChange={setTopicFilter}
              options={[allOption, ...topics.map((c) => ({ value: c, label: c }))]}
            />
            <Filter
              id="library-author"
              label={t("library.filter.author")}
              value={authorFilter}
              onChange={setAuthorFilter}
              options={[allOption, ...authors.map((a) => ({ value: a, label: a }))]}
            />
            <Filter
              id="library-language"
              label={t("library.filter.language")}
              value={langFilter}
              onChange={setLangFilter}
              options={[allOption, ...languages.map((l) => ({ value: l, label: l.toUpperCase() }))]}
            />
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground" role="status" aria-live="polite">
              {total} {t("library.results")}
            </p>
            <div className="flex flex-wrap items-center gap-2">
              {fiqhFilter === ALL && preferred !== "general" && (
                <button
                  type="button"
                  onClick={() => setFiqhFilter(preferred)}
                  className="min-h-10 px-3 border border-border text-[10px] uppercase tracking-[0.2em] text-gold hover:border-gold/60 transition-colors"
                >
                  {t("fiqh.current")}
                </button>
              )}
              {filtered && (
                <button
                  type="button"
                  onClick={reset}
                  className="min-h-10 px-3 border border-border text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground hover:border-gold/40 transition-colors"
                >
                  {t("library.reset")}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* ---------------- Catalogue ---------------- */}
        {total === 0 ? (
          <div className="mt-16 text-center border border-dashed border-border py-16 px-6">
            <p className="font-display italic text-2xl">{t("library.empty")}</p>
            <p className="mt-3 text-sm text-muted-foreground">{t("library.emptyHint")}</p>
            <button
              type="button"
              onClick={reset}
              className="mt-6 inline-flex min-h-11 items-center px-5 border border-border text-[11px] uppercase tracking-[0.2em] text-gold hover:border-gold/60 transition-colors"
            >
              {t("library.reset")}
            </button>
          </div>
        ) : (
          <>
            {books.length > 0 && (
              <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
                {books.map((b, i) => (
                  <Link
                    key={b.slug}
                    to="/library/$slug"
                    params={{ slug: b.slug }}
                    className="group bg-card hover:bg-emerald-soft transition-colors flex flex-col"
                  >
                    <div className="relative aspect-[16/9] overflow-hidden bg-muted">
                      <img
                        src={libraryCover(b.slug)}
                        alt={`Cover artwork for ${b.title}`}
                        loading={i < 3 ? "eager" : "lazy"}
                        decoding="async"
                        width={640}
                        height={360}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-7 flex flex-col justify-between flex-1">
                      <span className="font-mono-display text-[10px] text-emerald tracking-widest uppercase">
                        {t(archiveTypeKey(b.type))} · {b.category}
                      </span>
                      <div className="mt-3">
                        <h2 className="font-display text-xl group-hover:text-gold transition-colors leading-tight">
                          {b.title}
                        </h2>
                        <p className="mt-1 text-sm text-muted-foreground" dir="rtl" lang="ar">
                          {b.arabic}
                        </p>
                        <p className="mt-2 text-xs text-muted-foreground">
                          {b.author} · {b.era}
                        </p>
                        <p className="mt-3 text-sm text-muted-foreground line-clamp-3">{b.summary}</p>
                        <ul className="mt-3 flex flex-wrap gap-1.5">
                          {b.fiqh.map((f) => (
                            <li
                              key={f}
                              className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground border border-border px-1.5 py-0.5"
                            >
                              {fiqhName(fiqhById(f), lang)}
                            </li>
                          ))}
                        </ul>
                        <span className="mt-4 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">
                          {t("library.readStudy")} ▸
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {items.length > 0 && (
              <div className="mt-20">
                <div className="text-center mb-10">
                  <span className="text-[10px] font-bold text-emerald uppercase tracking-[0.4em]">
                    {t("library.collections")}
                  </span>
                  <h2 className="mt-4 font-display italic text-3xl">{t("library.collections")}</h2>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
                  {items.map((item) => {
                    const recorded = itemFiqh(item);
                    const school = recorded
                      ? FIQH_SCHOOLS.find((s) => s.id === recorded)
                      : undefined;
                    return (
                      <article key={item.id} className="bg-card p-7 flex flex-col" lang={item.language}>
                        <span className="font-mono-display text-[10px] text-emerald tracking-widest uppercase">
                          {item.category}
                        </span>
                        <h3 className="mt-3 font-display text-xl leading-tight">{item.title}</h3>
                        {item.arabic_title && (
                          <p className="mt-1 text-sm text-muted-foreground" dir="rtl" lang="ar">
                            {item.arabic_title}
                          </p>
                        )}
                        <p className="mt-2 text-xs text-muted-foreground">
                          {[item.author, item.era].filter(Boolean).join(" · ") ||
                            t("library.unknownSource")}
                        </p>
                        {item.summary && (
                          <p className="mt-3 text-sm text-muted-foreground">{item.summary}</p>
                        )}
                        <span className="mt-3 inline-block w-fit text-[9px] uppercase tracking-[0.2em] text-muted-foreground border border-border px-1.5 py-0.5">
                          {school ? fiqhName(school, lang) : t("fiqh.unclassified")}
                        </span>
                        {item.body && (
                          <details className="mt-4">
                            <summary className="cursor-pointer text-[10px] uppercase tracking-[0.3em] text-gold">
                              {t("common.readMore")} ▸
                            </summary>
                            <div className="mt-3 text-sm text-muted-foreground whitespace-pre-line">
                              {item.body}
                            </div>
                          </details>
                        )}
                      </article>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}

        {/* Internal links out of the archive */}
        <nav aria-label="Related sections" className="mt-20 border-t border-border pt-8">
          <h2 className="text-[10px] uppercase tracking-[0.3em] text-gold">{t("fiqh.related")}</h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {[
              { to: "/quran", label: t("nav.quran") },
              { to: "/hadith", label: t("nav.hadith") },
              { to: "/tafsir-al-mizan", label: t("nav.tafsir") },
              { to: "/fiqh", label: t("nav.fiqh") },
              { to: "/articles", label: t("nav.research") },
              { to: "/academy", label: t("nav.academy") },
              { to: "/who-is-imam-mahdi", label: t("nav.imamMahdi") },
            ].map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to as never}
                  className="inline-flex min-h-10 items-center px-3 border border-border text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold hover:border-gold/50 transition-colors"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </section>

      <SiteFooter />
    </div>
  );
}
