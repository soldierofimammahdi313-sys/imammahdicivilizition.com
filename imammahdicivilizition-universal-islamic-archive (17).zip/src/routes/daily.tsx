import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/daily.jpg";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/daily")({
  head: () => ({
    meta: [
      { title: "Daily Devotion — Quran, Hadith, Dua, Prayer Times" },
      { name: "description", content: "A daily verse of the Quran, a hadith, a supplication, and prayer times for your location." },
      { property: "og:title", content: "Daily Devotion — Quran, Hadith, Dua, Prayer Times" },
      { property: "og:description", content: "A daily verse of the Quran, a hadith, a supplication, and prayer times for your location." },
      { property: "og:url", content: "https://imammahdicivilizition.com/daily" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/daily" }],
  }),
  component: DailyPage,
});

type Tab = "quran" | "hadith" | "dua" | "prayer";

const HADITHS = [
  { ar: "إنما الأعمال بالنيات", en: "Actions are but by intentions.", source: "Bukhari & Muslim" },
  { ar: "من حسن إسلام المرء تركه ما لا يعنيه", en: "Part of a person's good Islam is leaving what does not concern him.", source: "Tirmidhi" },
  { ar: "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه", en: "None of you truly believes until he loves for his brother what he loves for himself.", source: "Bukhari" },
  { ar: "الكلمة الطيبة صدقة", en: "A good word is charity.", source: "Bukhari" },
  { ar: "العلماء ورثة الأنبياء", en: "The scholars are the heirs of the prophets.", source: "Abu Dawud" },
];
const DUAS = [
  { ar: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", en: "Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.", source: "Quran 2:201" },
  { ar: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا", en: "O Allah, I ask You for beneficial knowledge.", source: "Ibn Majah" },
  { ar: "رَبِّ زِدْنِي عِلْمًا", en: "My Lord, increase me in knowledge.", source: "Quran 20:114" },
  { ar: "اللَّهُمَّ أَصْلِحْ لِي دِينِي الَّذِي هُوَ عِصْمَةُ أَمْرِي", en: "O Allah, set right my religion which is the safeguard of my affairs.", source: "Muslim" },
];

function dayIndex(len: number) {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const day = Math.floor((now.getTime() - start.getTime()) / 86400000);
  return day % len;
}

function DailyPage() {
  const [tab, setTab] = useState<Tab>("quran");

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Daily Devotion" }]} />
      <PageBanner src={bannerImg} alt="Daily Devotion" eyebrow="Every Day" title="Your daily spiritual trio" subtitle="Verse, narration and supplication — renewed each dawn." />
      <section className="pt-8 pb-12 px-6 max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <span className="font-mono-display text-[10px] text-emerald tracking-[0.4em]">05 / DAILY DEVOTION</span>
          <span className="font-arabic text-3xl text-gold/40 block mt-4">الورد اليومي</span>
          <h1 className="mt-2 font-display italic text-5xl">The Daily Trio</h1>
        </div>

        <div className="flex justify-center gap-1 border-b border-border mb-10">
          {(["quran", "hadith", "dua", "prayer"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-3 text-[10px] uppercase tracking-[0.3em] transition-colors ${tab === t ? "text-gold border-b-2 border-gold" : "text-muted-foreground hover:text-foreground"}`}
            >
              {t === "prayer" ? "Prayer Times" : t}
            </button>
          ))}
        </div>

        {tab === "quran" && <QuranCard />}
        {tab === "hadith" && <StaticCard label="Hadith" item={HADITHS[dayIndex(HADITHS.length)]} />}
        {tab === "dua" && <StaticCard label="Supplication" item={DUAS[dayIndex(DUAS.length)]} />}
        {tab === "prayer" && <PrayerTimes />}
      </section>
      <SiteFooter />
    </div>
  );
}

function QuranCard() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["quran-verse", new Date().toDateString()],
    queryFn: async () => {
      // Random ayah — al-quran.cloud, no key required
      const num = Math.floor(Math.random() * 6236) + 1;
      const res = await fetch(`https://api.alquran.cloud/v1/ayah/${num}/editions/quran-uthmani,en.sahih`);
      if (!res.ok) throw new Error("Failed");
      const j = await res.json();
      return {
        ar: j.data[0].text as string,
        en: j.data[1].text as string,
        surah: j.data[0].surah.englishName as string,
        number: `${j.data[0].surah.number}:${j.data[0].numberInSurah}`,
      };
    },
    staleTime: 1000 * 60 * 60,
  });

  if (isLoading) return <p className="text-center text-muted-foreground">Loading verse…</p>;
  if (error || !data) return <p className="text-center text-destructive">Failed to load verse.</p>;

  return (
    <div className="border border-border bg-card/40 p-10 md:p-14 text-center">
      <span className="text-[10px] uppercase tracking-[0.3em] text-emerald">Quran · {data.surah} · {data.number}</span>
      <p className="font-arabic text-3xl md:text-4xl mt-8 leading-loose text-foreground" dir="rtl">{data.ar}</p>
      <p className="mt-8 text-muted-foreground italic text-lg leading-relaxed max-w-2xl mx-auto">"{data.en}"</p>
    </div>
  );
}

function StaticCard({ label, item }: { label: string; item: { ar: string; en: string; source: string } }) {
  return (
    <div className="border border-border bg-card/40 p-10 md:p-14 text-center">
      <span className="text-[10px] uppercase tracking-[0.3em] text-emerald">{label} · {item.source}</span>
      <p className="font-arabic text-3xl md:text-4xl mt-8 leading-loose" dir="rtl">{item.ar}</p>
      <p className="mt-8 text-muted-foreground italic text-lg leading-relaxed max-w-2xl mx-auto">"{item.en}"</p>
    </div>
  );
}

function PrayerTimes() {
  const [city, setCity] = useState("Karachi");
  const [country, setCountry] = useState("Pakistan");
  const { data, isLoading } = useQuery({
    queryKey: ["prayer", city, country],
    queryFn: async () => {
      const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=2`);
      const j = await res.json();
      return j.data.timings as Record<string, string>;
    },
  });
  const order = useMemo(() => ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"], []);
  return (
    <div className="border border-border bg-card/40 p-10">
      <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto mb-10">
        <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" className="flex-1 bg-background border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none" />
        <input value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Country" className="flex-1 bg-background border border-border px-4 py-3 text-sm focus:border-gold focus:outline-none" />
      </div>
      {isLoading && <p className="text-center text-muted-foreground">Loading…</p>}
      {data && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
          {order.map((name) => (
            <div key={name} className="border border-border p-5 text-center">
              <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{name}</span>
              <p className="mt-2 font-display italic text-3xl">{data[name]}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}