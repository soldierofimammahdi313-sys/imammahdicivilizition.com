import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PageBanner } from "@/components/site/PageBanner";
import bannerImg from "@/assets/banners/modules.jpg";
import { SiteFooter } from "@/components/site/SiteFooter";
import { MODULE_GROUPS, MODULE_STATS, type Module } from "@/lib/modules";

export const Route = createFileRoute("/modules")({
  head: () => ({
    meta: [
      { title: "Module Grid — The Digital Civilization | Imam Mahdi Civilization" },
      {
        name: "description",
        content:
          "Every module of the Mahdi Civilization platform: AI research engines, knowledge systems, learning paths, sacred maps, research instruments and the Islamic Civilization Simulator.",
      },
      { property: "og:title", content: "Module Grid — The Digital Civilization" },
      { property: "og:description", content: "AI research engines, knowledge systems, sacred maps and scholar-grade research instruments — one grid." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/modules" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/modules" }],
  }),
  component: ModulesPage,
});

type Filter = "all" | "live" | "beta";

const STATUS_STYLE: Record<Module["status"], string> = {
  live: "text-emerald border-emerald/40 bg-emerald-soft",
  beta: "text-gold border-gold/40 bg-gold-soft/30",
  queued: "text-muted-foreground border-border bg-card",
};
const STATUS_LABEL: Record<Module["status"], string> = {
  live: "Online",
  beta: "Beta",
  queued: "In build",
};

function ModulesPage() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const groups = useMemo(() => {
    const term = q.trim().toLowerCase();
    return MODULE_GROUPS.map((g) => ({
      ...g,
      modules: g.modules.filter(
        (m) =>
          (filter === "all" || m.status === filter) &&
          (!term ||
            m.name.toLowerCase().includes(term) ||
            m.desc.toLowerCase().includes(term) ||
            g.title.toLowerCase().includes(term) ||
            (m.arabic ?? "").includes(term)),
      ),
    })).filter((g) => g.modules.length > 0);
  }, [q, filter]);

  const shown = groups.reduce((n, g) => n + g.modules.length, 0);

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Modules" }]} />
      <PageBanner src={bannerImg} alt="Platform Modules" eyebrow="Modules" title="The full constellation" subtitle="Every tool, engine and library of the civilization in one place." />

      <section className="relative pt-8 pb-14 px-4 md:px-6 max-w-7xl mx-auto">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.07] [background-image:linear-gradient(to_right,currentColor_1px,transparent_1px),linear-gradient(to_bottom,currentColor_1px,transparent_1px)] [background-size:56px_56px]"
        />
        <div className="relative text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">System / Module Grid</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">The Machinery of the Civilization</h1>
          <p className="mt-4 text-sm md:text-base text-muted-foreground max-w-2xl mx-auto">
            {MODULE_STATS.total} modules across eleven systems — intelligence, knowledge, learning, community, media,
            research and the sacred map of the earth.
          </p>

          <div className="mt-10 grid grid-cols-3 gap-px bg-border ring-1 ring-border max-w-3xl mx-auto">
            {[
              { k: "Total", v: MODULE_STATS.total, c: "text-foreground" },
              { k: "Online", v: MODULE_STATS.live, c: "text-emerald" },
              { k: "Beta", v: MODULE_STATS.beta, c: "text-gold" },
            ].map((s) => (
              <div key={s.k} className="bg-card py-6">
                <div className={`font-mono-display text-3xl ${s.c}`}>{String(s.v).padStart(2, "0")}</div>
                <div className="mt-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{s.k}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 md:px-6 max-w-7xl mx-auto">
        <div className="sticky top-[76px] z-30 bg-background/85 backdrop-blur-xl border border-border p-3 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search modules — mufti, tafsir, karbala, isnad…"
            aria-label="Search modules"
            className="flex-1 bg-transparent border border-border focus:border-gold/60 focus:outline-none px-4 py-2.5 text-sm"
          />
          <div className="flex gap-2">
            {(["all", "live", "beta"] as Filter[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                aria-pressed={filter === f}
                className={`px-3 py-2 border text-[10px] uppercase tracking-[0.22em] transition-colors ${
                  filter === f
                    ? "border-gold text-gold bg-gold-soft/30"
                    : "border-border text-muted-foreground hover:text-gold hover:border-gold/50"
                }`}
              >
                {f === "all" ? "All" : STATUS_LABEL[f]}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{shown} modules matched</p>
      </section>

      <section className="px-4 md:px-6 max-w-7xl mx-auto pb-24">
        {groups.map((g) => (
          <div key={g.code} id={`system-${g.code}`} className="mt-16 scroll-mt-28">
            <div className="flex items-end justify-between gap-4 border-b border-border pb-4">
              <div>
                <span className="font-mono-display text-[10px] text-emerald tracking-[0.3em]">{g.code}</span>
                <h2 className="mt-2 font-display italic text-3xl md:text-4xl">{g.title}</h2>
                <p className="mt-2 text-xs text-muted-foreground max-w-xl">{g.blurb}</p>
              </div>
              <span className="font-arabic text-3xl text-gold/50 shrink-0">{g.arabic}</span>
            </div>

            <div className="mt-px grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border ring-1 ring-border">
              {g.modules.map((m) => {
                const body = (
                  <>
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="font-display text-lg leading-tight group-hover:text-gold transition-colors">{m.name}</h3>
                      {m.arabic && <span className="font-arabic text-lg text-gold/50 shrink-0">{m.arabic}</span>}
                    </div>
                    <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{m.desc}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className={`border px-2 py-1 text-[9px] uppercase tracking-[0.25em] ${STATUS_STYLE[m.status]}`}>
                        {STATUS_LABEL[m.status]}
                      </span>
                      {m.to && <span className="text-[10px] uppercase tracking-[0.3em] text-gold">Enter ▸</span>}
                    </div>
                  </>
                );
                const cls =
                  "group bg-card p-6 min-h-[172px] flex flex-col justify-between transition-colors " +
                  (m.to ? "hover:bg-emerald-soft" : "opacity-80");
                return m.to ? (
                  <Link key={m.name} to={m.to as never} className={cls}>
                    {body}
                  </Link>
                ) : (
                  <div key={m.name} className={cls}>
                    {body}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {groups.length === 0 && (
          <div className="mt-16 border border-dashed border-border p-16 text-center">
            <span className="font-arabic text-3xl text-gold/40 block">لا نتائج</span>
            <p className="mt-3 text-sm text-muted-foreground">No module matches that search.</p>
          </div>
        )}

        <div className="mt-20 text-center">
          <Link
            to="/join"
            className="inline-block px-10 py-4 bg-gold text-primary-foreground font-bold uppercase text-xs tracking-[0.3em] hover:bg-foreground transition-colors"
          >
            Help build the remaining modules
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}