import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/battles")({
  head: () => ({
    meta: [
      { title: "Battle Explorer — Badr, Uhud, Karbala | Imam Mahdi Civilization" },
      { name: "description", content: "Explore the decisive battles of Islam: date, terrain, forces, commanders, outcome and the lesson each one left behind." },
      { property: "og:title", content: "Battle Explorer" },
      { property: "og:description", content: "Badr, Uhud, Khandaq, Siffin, Karbala — terrain, forces, outcome and lasting lesson." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/battles" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/battles" }],
  }),
  component: BattlesPage,
});

type Battle = {
  name: string;
  arabic: string;
  year: string;
  place: string;
  terrain: string;
  muslim: string;
  opponent: string;
  commanders: string;
  outcome: string;
  lesson: string;
  narrative: string;
};

const BATTLES: Battle[] = [
  {
    name: "Badr", arabic: "بدر", year: "2 AH / 624 CE", place: "Wells of Badr, near Madinah",
    terrain: "Sandy valley; the Muslims held the firm ground and the water.",
    muslim: "313 believers, 2 horses, 70 camels", opponent: "~1,000 Quraysh, 100 horses",
    commanders: "The Messenger ﷺ · Ali · Hamza — against Abu Jahl and Utba",
    outcome: "Decisive Muslim victory; 14 martyrs, 70 Quraysh killed, 70 captured.",
    lesson: "Numbers do not decide outcomes — sincerity and divine aid do.",
    narrative: "The first open confrontation. Ali ibn Abi Talib alone accounted for a large share of the Quraysh champions in the opening duels. The prisoners were treated with a mercy unknown in Arabian warfare: literate captives bought their freedom by teaching ten Muslims to read.",
  },
  {
    name: "Uhud", arabic: "أحد", year: "3 AH / 625 CE", place: "Mount Uhud, north of Madinah",
    terrain: "Slope of the mountain with a single archers' pass at Jabal al-Rumat.",
    muslim: "~700 after 300 withdrew", opponent: "~3,000 Quraysh, 200 cavalry",
    commanders: "The Messenger ﷺ · Hamza · Ali — against Abu Sufyan and Khalid ibn al-Walid",
    outcome: "Initial victory reversed; 70 martyrs including Hamza, the Lion of God.",
    lesson: "Victory abandoned is victory lost — discipline is obedience, not enthusiasm.",
    narrative: "The archers left the pass to gather spoils. Khalid's cavalry circled through the gap and the tide turned in minutes. Ali remained at the Prophet's side when most had scattered, and the sword Dhulfiqar was praised that day.",
  },
  {
    name: "Khandaq (the Trench)", arabic: "الخندق", year: "5 AH / 627 CE", place: "Northern approach to Madinah",
    terrain: "A trench dug across the only cavalry-passable approach — Salman al-Farsi's proposal.",
    muslim: "~3,000 defenders", opponent: "~10,000 confederates",
    commanders: "The Messenger ﷺ · Ali — against Abu Sufyan and Amr ibn Abd Wudd",
    outcome: "Siege broken by a storm and by division among the confederates.",
    lesson: "Engineering and counsel are acts of faith; Ali's single strike was 'worth more than the worship of both worlds'.",
    narrative: "For a month the confederates could not cross. When Amr ibn Abd Wudd leapt the trench and challenged the camp, only Ali answered — and returned victorious.",
  },
  {
    name: "Khaybar", arabic: "خیبر", year: "7 AH / 628 CE", place: "Oasis fortresses of Khaybar",
    terrain: "Chain of stone fortresses on volcanic rock.",
    muslim: "~1,400", opponent: "~10,000 defenders behind walls",
    commanders: "The Messenger ﷺ · Ali — against Marhab",
    outcome: "Fortresses taken; the gate of Qamus lifted by Ali.",
    lesson: "'Tomorrow I shall give the banner to one who loves God and His Messenger, and whom they love.'",
    narrative: "After two failed assaults the banner passed to Ali, who took the strongest fortress and used its torn gate as a shield.",
  },
  {
    name: "Siffin", arabic: "صفین", year: "37 AH / 657 CE", place: "Plain of Siffin on the Euphrates",
    terrain: "Open river plain; control of the water was contested first.",
    muslim: "~90,000 with Imam Ali", opponent: "~120,000 with Mu'awiya",
    commanders: "Imam Ali · Malik al-Ashtar · Ammar ibn Yasir — against Mu'awiya and Amr ibn al-As",
    outcome: "Victory within reach when Qur'ans were raised on spears; forced arbitration split the army.",
    lesson: "Religion used as a shield for politics is the oldest weapon against truth.",
    narrative: "Ammar ibn Yasir was martyred here — and the Prophet had foretold that a rebellious party would kill him, which settled the question of who stood with truth.",
  },
  {
    name: "Karbala", arabic: "كربلاء", year: "61 AH / 680 CE", place: "Plain of Karbala on the Euphrates",
    terrain: "Flat desert; the river was blockaded from the 7th of Muharram.",
    muslim: "72 companions of Imam Husayn", opponent: "~30,000 of Yazid's army",
    commanders: "Imam Husayn · Abbas · Ali al-Akbar — against Umar ibn Sa'd and Shimr",
    outcome: "All 72 martyred on Ashura; the household taken captive to Kufa and Damascus.",
    lesson: "Islam was born by the Prophet's word and survives by Husayn's blood — a victory measured in centuries, not in a day.",
    narrative: "Three days without water. Abbas fell carrying the waterskin to the children. When Husayn stood alone, the message did not end — Zaynab carried it into the courts of the tyrant and destroyed his legitimacy with speech.",
  },
];

function BattlesPage() {
  const [open, setOpen] = useState(0);
  const b = BATTLES[open]!;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Battles" }]} />
      <section className="pt-8 pb-16 px-4 md:px-6 max-w-7xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">Knowledge / Battle Explorer</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">The Decisive Fields</h1>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            Terrain, forces, commanders and consequence — the battles that shaped the Ummah.
          </p>
        </div>

        <div className="mt-12 grid lg:grid-cols-[280px_1fr] gap-px bg-border ring-1 ring-border">
          <nav aria-label="Battles" className="bg-card">
            {BATTLES.map((x, i) => (
              <button
                key={x.name}
                onClick={() => setOpen(i)}
                aria-pressed={open === i}
                className={`w-full text-start px-5 py-4 border-b border-border last:border-b-0 transition-colors ${
                  open === i ? "bg-gold-soft/30 text-gold" : "hover:bg-emerald-soft"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-lg">{x.name}</span>
                  <span className="font-arabic text-lg text-gold/60">{x.arabic}</span>
                </div>
                <span className="block mt-1 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{x.year}</span>
              </button>
            ))}
          </nav>

          <article className="bg-card p-7 md:p-10">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display italic text-4xl">{b.name}</h2>
                <p className="mt-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{b.year} · {b.place}</p>
              </div>
              <span className="font-arabic text-4xl text-gold/50">{b.arabic}</span>
            </div>

            <div className="mt-8 grid sm:grid-cols-2 gap-px bg-border ring-1 ring-border">
              {[
                { k: "Muslim force", v: b.muslim },
                { k: "Opposing force", v: b.opponent },
                { k: "Terrain", v: b.terrain },
                { k: "Commanders", v: b.commanders },
              ].map((row) => (
                <div key={row.k} className="bg-background p-5">
                  <span className="text-[9px] uppercase tracking-[0.3em] text-gold">{row.k}</span>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{row.v}</p>
                </div>
              ))}
            </div>

            <h3 className="mt-8 text-[10px] uppercase tracking-[0.3em] text-emerald">Outcome</h3>
            <p className="mt-2 text-sm">{b.outcome}</p>

            <h3 className="mt-6 text-[10px] uppercase tracking-[0.3em] text-emerald">Account</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{b.narrative}</p>

            <blockquote className="mt-8 border-s-2 border-gold ps-5 py-2">
              <span className="text-[9px] uppercase tracking-[0.3em] text-gold">Lesson</span>
              <p className="mt-2 font-display italic text-xl leading-snug">{b.lesson}</p>
            </blockquote>
          </article>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}