import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/simulator")({
  head: () => ({
    meta: [
      { title: "Islamic Civilization Simulator — Govern by the Standard of the Imams | Imam Mahdi Civilization" },
      { name: "description", content: "Set policy on justice, khums, education, defence and welfare, then watch twenty years of consequence unfold and be graded against the governance of Imam Ali." },
      { property: "og:title", content: "Islamic Civilization Simulator" },
      { property: "og:description", content: "Govern a city by the Qur'an and the Sunnah of the Ahl al-Bayt — and see what your policies build." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: "https://imammahdicivilizition.com/simulator" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/simulator" }],
  }),
  component: SimulatorPage,
});

type PolicyKey = "justice" | "khums" | "education" | "defence" | "welfare" | "trade";

const POLICIES: { k: PolicyKey; label: string; arabic: string; low: string; high: string; note: string }[] = [
  { k: "justice", label: "Justice & accountability", arabic: "العدل", low: "Lenient courts", high: "Uncompromising courts", note: "Imam Ali to Malik al-Ashtar: the strong must not hope for favour, nor the weak despair of justice." },
  { k: "khums", label: "Khums & zakat collection", arabic: "الخمس", low: "Minimal levy", high: "Full collection", note: "Wealth taken from the surplus and returned to the orphan, the traveller and the seeker of knowledge." },
  { k: "education", label: "Knowledge & hawza funding", arabic: "العلم", low: "Basic literacy", high: "Universal scholarship", note: "Seeking knowledge is an obligation upon every Muslim, man and woman." },
  { k: "defence", label: "Defence & security", arabic: "الدفاع", low: "Militia only", high: "Standing army", note: "Strength that deters aggression without becoming aggression." },
  { k: "welfare", label: "Welfare of the vulnerable", arabic: "الرعاية", low: "Family-based", high: "State-guaranteed", note: "The Imam wept when he heard of a single hungry child in the furthest town." },
  { k: "trade", label: "Markets & trade", arabic: "التجارة", low: "Tightly regulated", high: "Open markets", note: "Prohibit riba and hoarding; then let the honest merchant flourish." },
];

type Outcome = {
  justiceIdx: number;
  prosperity: number;
  knowledge: number;
  security: number;
  cohesion: number;
  faith: number;
  population: number;
  score: number;
  grade: string;
  verdict: string;
  events: string[];
};

function clamp(n: number) {
  return Math.max(0, Math.min(100, Math.round(n)));
}

function simulate(p: Record<PolicyKey, number>, years: number): Outcome {
  const { justice, khums, education, defence, welfare, trade } = p;

  // Base indices, 0-100.
  const justiceIdx = clamp(justice * 0.8 + welfare * 0.15 + (100 - Math.abs(trade - 55)) * 0.05);
  const prosperity = clamp(trade * 0.45 + khums * 0.2 + education * 0.2 + justiceIdx * 0.15 - Math.max(0, defence - 70) * 0.3);
  const knowledge = clamp(education * 0.75 + khums * 0.15 + prosperity * 0.1);
  const security = clamp(defence * 0.6 + justiceIdx * 0.25 + welfare * 0.15 - Math.max(0, 30 - justiceIdx) * 0.4);
  const cohesion = clamp(welfare * 0.35 + justiceIdx * 0.4 + knowledge * 0.15 - Math.max(0, khums - 85) * 0.5);
  const faith = clamp(knowledge * 0.35 + justiceIdx * 0.35 + cohesion * 0.3);

  const growth = (prosperity + cohesion + security) / 300;
  const population = Math.round(50_000 * (1 + growth * 0.9) ** (years / 5));

  const score = Math.round(justiceIdx * 0.25 + knowledge * 0.2 + cohesion * 0.2 + faith * 0.2 + prosperity * 0.1 + security * 0.05);

  const events: string[] = [];
  if (justice > 80 && welfare > 60) events.push(`Year ${Math.round(years * 0.2)}: A governor is dismissed for accepting a gift. Trust in the courts rises across every district.`);
  if (justice < 35) events.push(`Year ${Math.round(years * 0.3)}: The powerful settle disputes privately. The weak stop bringing cases at all.`);
  if (education > 75) events.push(`Year ${Math.round(years * 0.4)}: A hawza opens with free lodging; students arrive from three neighbouring lands.`);
  if (education < 30) events.push(`Year ${Math.round(years * 0.4)}: Manuscripts rot uncopied. A generation grows up unable to read the Book it defends.`);
  if (khums > 85) events.push(`Year ${Math.round(years * 0.5)}: Collection is thorough but heavy-handed; merchants begin moving capital abroad.`);
  if (khums < 25) events.push(`Year ${Math.round(years * 0.5)}: The treasury cannot pay the stipends of orphans and widows.`);
  if (defence > 80 && prosperity < 45) events.push(`Year ${Math.round(years * 0.6)}: The garrison consumes what the granary cannot spare.`);
  if (defence < 25) events.push(`Year ${Math.round(years * 0.6)}: Raiders test the frontier and find no answer.`);
  if (welfare > 70) events.push(`Year ${Math.round(years * 0.7)}: No child in the city sleeps hungry — the governor's report is read aloud in the mosque.`);
  if (trade > 85 && justice < 55) events.push(`Year ${Math.round(years * 0.8)}: Hoarding goes unpunished; bread doubles in price during a dry season.`);
  if (cohesion > 80 && faith > 80) events.push(`Year ${years}: Travellers describe the city as a place where the Qur'an is not recited but lived.`);
  if (events.length === 0) events.push(`Year ${years}: The city endures — unremarkable, neither corrupt nor luminous.`);

  let grade: string;
  let verdict: string;
  if (score >= 85) {
    grade = "The Standard of Ali";
    verdict = "Your governance approaches the letter to Malik al-Ashtar: justice first, the vulnerable protected, knowledge open to all, and strength held in restraint.";
  } else if (score >= 70) {
    grade = "A Just Emirate";
    verdict = "A city worth living in. Justice holds and knowledge grows, though the balance still leans on one pillar more than the rest.";
  } else if (score >= 55) {
    grade = "Stable but Uneven";
    verdict = "Order without radiance. Something essential — justice, knowledge or care for the weak — was funded last.";
  } else if (score >= 38) {
    grade = "A Fragile City";
    verdict = "The structures stand but the people do not trust them. Fragility of this kind is inherited by the next generation.";
  } else {
    grade = "The Warning of Nahj al-Balagha";
    verdict = "'Nations perish when the rights of the weak cannot be taken from the strong without trembling.' Rebuild from justice outward.";
  }

  return { justiceIdx, prosperity, knowledge, security, cohesion, faith, population, score, grade, verdict, events };
}

const DEFAULTS: Record<PolicyKey, number> = { justice: 70, khums: 55, education: 65, defence: 50, welfare: 60, trade: 60 };

function SimulatorPage() {
  const [policy, setPolicy] = useState<Record<PolicyKey, number>>(DEFAULTS);
  const [years, setYears] = useState(20);
  const [run, setRun] = useState(false);

  const outcome = useMemo(() => simulate(policy, years), [policy, years]);

  const bars: { k: string; v: number }[] = [
    { k: "Justice", v: outcome.justiceIdx },
    { k: "Knowledge", v: outcome.knowledge },
    { k: "Cohesion", v: outcome.cohesion },
    { k: "Faith", v: outcome.faith },
    { k: "Prosperity", v: outcome.prosperity },
    { k: "Security", v: outcome.security },
  ];

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <Breadcrumbs items={[{ label: "Civilization Simulator" }]} />
      <section className="pt-8 pb-20 px-4 md:px-6 max-w-6xl mx-auto">
        <div className="text-center">
          <span className="text-[10px] font-bold text-gold uppercase tracking-[0.4em]">The Singular Module</span>
          <h1 className="mt-4 font-display italic text-5xl md:text-6xl">Islamic Civilization Simulator</h1>
          <span className="mt-3 font-arabic text-2xl text-gold/60 block">محاكاة الحضارة الإسلامية</span>
          <p className="mt-4 text-sm text-muted-foreground max-w-2xl mx-auto">
            Govern a city of fifty thousand souls. Set your policy, run the years, and be measured against the letter of
            Imam Ali to Malik al-Ashtar.
          </p>
        </div>

        <div className="mt-12 grid lg:grid-cols-2 gap-px bg-border ring-1 ring-border">
          <div className="bg-card p-7">
            <h2 className="text-[10px] uppercase tracking-[0.3em] text-gold">Council of policy</h2>
            <div className="mt-6 space-y-6">
              {POLICIES.map((p) => (
                <div key={p.k}>
                  <div className="flex items-center justify-between gap-3">
                    <label htmlFor={p.k} className="text-sm font-bold">
                      {p.label} <span className="font-arabic text-base text-gold/60 ms-1">{p.arabic}</span>
                    </label>
                    <span className="font-mono-display text-sm text-gold">{policy[p.k]}</span>
                  </div>
                  <input
                    id={p.k}
                    type="range"
                    min={0}
                    max={100}
                    value={policy[p.k]}
                    onChange={(e) => { setPolicy({ ...policy, [p.k]: Number(e.target.value) }); setRun(false); }}
                    className="mt-2 w-full accent-[hsl(var(--gold))]"
                  />
                  <div className="flex justify-between text-[9px] uppercase tracking-[0.2em] text-muted-foreground">
                    <span>{p.low}</span>
                    <span>{p.high}</span>
                  </div>
                  <p className="mt-1.5 text-[11px] text-muted-foreground/80 italic leading-snug">{p.note}</p>
                </div>
              ))}

              <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="years" className="text-sm font-bold">Years to simulate</label>
                  <span className="font-mono-display text-sm text-gold">{years}</span>
                </div>
                <input
                  id="years"
                  type="range"
                  min={5}
                  max={50}
                  step={5}
                  value={years}
                  onChange={(e) => { setYears(Number(e.target.value)); setRun(false); }}
                  className="mt-2 w-full accent-[hsl(var(--emerald))]"
                />
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button
                onClick={() => setRun(true)}
                className="flex-1 py-4 bg-gold text-primary-foreground text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-foreground transition-colors"
              >
                Run the years
              </button>
              <button
                onClick={() => { setPolicy(DEFAULTS); setYears(20); setRun(false); }}
                className="px-6 py-4 border border-border text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground hover:border-gold hover:text-gold transition-colors"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="bg-card p-7">
            <h2 className="text-[10px] uppercase tracking-[0.3em] text-emerald">
              {run ? `The city after ${years} years` : "Projected outcome"}
            </h2>

            <div className={run ? "" : "opacity-60"}>
              <div className="mt-6 border border-gold/40 p-6 text-center">
                <div className="font-mono-display text-5xl text-gold">{outcome.score}</div>
                <div className="mt-1 text-[9px] uppercase tracking-[0.3em] text-muted-foreground">Civilization index</div>
                <div className="mt-4 font-display italic text-2xl">{outcome.grade}</div>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{outcome.verdict}</p>
              </div>

              <div className="mt-6 space-y-3">
                {bars.map((b) => (
                  <div key={b.k}>
                    <div className="flex justify-between text-[10px] uppercase tracking-[0.25em]">
                      <span className="text-muted-foreground">{b.k}</span>
                      <span className="text-gold font-mono-display">{b.v}</span>
                    </div>
                    <div className="mt-1 h-1.5 bg-border">
                      <div
                        className={`h-full transition-all duration-700 ${b.v >= 70 ? "bg-emerald" : b.v >= 45 ? "bg-gold" : "bg-destructive"}`}
                        style={{ width: `${b.v}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 grid grid-cols-2 gap-px bg-border ring-1 ring-border">
                <div className="bg-background py-5 text-center">
                  <div className="font-mono-display text-2xl text-gold">{outcome.population.toLocaleString()}</div>
                  <div className="mt-1 text-[9px] uppercase tracking-[0.25em] text-muted-foreground">Population</div>
                </div>
                <div className="bg-background py-5 text-center">
                  <div className="font-mono-display text-2xl text-emerald">{years}</div>
                  <div className="mt-1 text-[9px] uppercase tracking-[0.25em] text-muted-foreground">Years elapsed</div>
                </div>
              </div>

              {run && (
                <div className="mt-7">
                  <h3 className="text-[10px] uppercase tracking-[0.3em] text-gold">Chronicle of the city</h3>
                  <ol className="mt-4 space-y-3">
                    {outcome.events.map((e) => (
                      <li key={e} className="border-s-2 border-emerald/50 ps-4 text-sm text-muted-foreground leading-relaxed">
                        {e}
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>

            {!run && (
              <p className="mt-6 text-center text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                Press “Run the years” to record the chronicle
              </p>
            )}
          </div>
        </div>

        <p className="mt-10 text-center text-xs text-muted-foreground max-w-2xl mx-auto">
          The model is a teaching instrument, not a fatwa. It weights justice, knowledge and care for the vulnerable most
          heavily because the sources do.
        </p>
      </section>
      <SiteFooter />
    </div>
  );
}