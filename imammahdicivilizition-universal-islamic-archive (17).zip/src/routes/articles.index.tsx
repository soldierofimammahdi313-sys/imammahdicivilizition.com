import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CardGridSkeleton, InlineEmpty } from "@/components/site/States";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { supabase } from "@/integrations/supabase/client";
import { coverFor } from "@/lib/article-covers";

export const Route = createFileRoute("/articles/")({
  head: () => ({
    meta: [
      { title: "Articles — Imam Mahdi Civilization" },
      { name: "description", content: "Essays, research, and reflections from the global vanguard of Islamic knowledge." },
      { property: "og:title", content: "Articles — Imam Mahdi Civilization" },
      { property: "og:description", content: "Essays, research, and reflections from the vanguard." },
      { property: "og:url", content: "https://imammahdicivilizition.com/articles" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://imammahdicivilizition.com/articles" }],
  }),
  component: ArticlesPage,
});

function ArticlesPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["articles", "published"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("articles")
        .select("id, slug, title, excerpt, cover_url, published_at, reading_minutes, tags, article_categories(name, slug)")
        .eq("status", "published")
        .order("published_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="bg-background text-foreground min-h-screen">
      <SiteHeader />
      <section className="pt-36 pb-16 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="font-mono-display text-[10px] text-emerald tracking-[0.4em]">02 / REALM</span>
          <span className="font-arabic text-3xl text-gold/40 block mt-4">المقالات</span>
          <h1 className="mt-2 font-display italic text-5xl md:text-6xl">The Archive</h1>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            A living library of essays, research, and reflections — written for the soldiers of Imam Mahdi Civilization.
          </p>
        </div>

        {isLoading && <CardGridSkeleton count={6} />}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data?.map((a) => (
            <Link
              key={a.id}
              to="/articles/$slug"
              params={{ slug: a.slug }}
              className="group block border border-border bg-card/40 hover:border-gold/50 transition-colors overflow-hidden"
            >
              <div className="relative aspect-[16/9] overflow-hidden bg-muted">
                <img
                  src={coverFor({
                    cover_url: a.cover_url,
                    slug: a.slug,
                    title: a.title,
                    tags: a.tags,
                    category: (a.article_categories as { slug?: string } | null)?.slug ?? null,
                  })}
                  alt={a.title}
                  width={1280}
                  height={720}
                  loading="lazy"
                  className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/10 to-transparent" />
              </div>
              <div className="p-7">
              <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-emerald">
                <span>{(a.article_categories as { name?: string } | null)?.name ?? "Essay"}</span>
                {a.reading_minutes && <><span className="text-border">·</span><span>{a.reading_minutes} min read</span></>}
              </div>
              <h2 className="mt-4 font-display italic text-2xl text-foreground group-hover:text-gold transition-colors">
                {a.title}
              </h2>
              <p className="mt-3 text-sm text-muted-foreground line-clamp-3 leading-relaxed">{a.excerpt}</p>
              <span className="mt-6 inline-block text-[10px] uppercase tracking-[0.3em] text-gold">Read →</span>
              </div>
            </Link>
          ))}
        </div>

        {data && data.length === 0 && !isLoading && (
          <div className="mt-16">
            <InlineEmpty
              title="The archive is being prepared"
              hint="Published essays and research will appear here as soon as the first one is released."
            />
          </div>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}