export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_conversations: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "ai_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      article_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      article_revisions: {
        Row: {
          article_id: string
          change_reason: string | null
          changed_at: string
          changed_by: string | null
          id: string
          new_content: string | null
          new_title: string | null
          previous_content: string | null
          previous_title: string | null
          version: number
        }
        Insert: {
          article_id: string
          change_reason?: string | null
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_content?: string | null
          new_title?: string | null
          previous_content?: string | null
          previous_title?: string | null
          version?: number
        }
        Update: {
          article_id?: string
          change_reason?: string | null
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_content?: string | null
          new_title?: string | null
          previous_content?: string | null
          previous_title?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "article_revisions_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "articles"
            referencedColumns: ["id"]
          },
        ]
      }
      articles: {
        Row: {
          author_id: string | null
          category_id: string | null
          content: string
          cover_url: string | null
          created_at: string
          duplicate_of: string | null
          excerpt: string | null
          generation_meta: Json | null
          id: string
          image_alt_text: string | null
          image_generation_status: string
          image_prompt: string | null
          keywords: string[] | null
          language: string | null
          meta_description: string | null
          og_description: string | null
          og_title: string | null
          pipeline_status: string
          published_at: string | null
          quality_report: Json | null
          quality_score: number | null
          reading_minutes: number | null
          refs: Json
          scheduled_for: string | null
          seo_title: string | null
          similarity_score: number | null
          slug: string
          status: string
          tags: string[] | null
          title: string
          topic_id: string | null
          updated_at: string
          verification_notes: Json | null
          verification_status: string
          view_count: number
        }
        Insert: {
          author_id?: string | null
          category_id?: string | null
          content: string
          cover_url?: string | null
          created_at?: string
          duplicate_of?: string | null
          excerpt?: string | null
          generation_meta?: Json | null
          id?: string
          image_alt_text?: string | null
          image_generation_status?: string
          image_prompt?: string | null
          keywords?: string[] | null
          language?: string | null
          meta_description?: string | null
          og_description?: string | null
          og_title?: string | null
          pipeline_status?: string
          published_at?: string | null
          quality_report?: Json | null
          quality_score?: number | null
          reading_minutes?: number | null
          refs?: Json
          scheduled_for?: string | null
          seo_title?: string | null
          similarity_score?: number | null
          slug: string
          status?: string
          tags?: string[] | null
          title: string
          topic_id?: string | null
          updated_at?: string
          verification_notes?: Json | null
          verification_status?: string
          view_count?: number
        }
        Update: {
          author_id?: string | null
          category_id?: string | null
          content?: string
          cover_url?: string | null
          created_at?: string
          duplicate_of?: string | null
          excerpt?: string | null
          generation_meta?: Json | null
          id?: string
          image_alt_text?: string | null
          image_generation_status?: string
          image_prompt?: string | null
          keywords?: string[] | null
          language?: string | null
          meta_description?: string | null
          og_description?: string | null
          og_title?: string | null
          pipeline_status?: string
          published_at?: string | null
          quality_report?: Json | null
          quality_score?: number | null
          reading_minutes?: number | null
          refs?: Json
          scheduled_for?: string | null
          seo_title?: string | null
          similarity_score?: number | null
          slug?: string
          status?: string
          tags?: string[] | null
          title?: string
          topic_id?: string | null
          updated_at?: string
          verification_notes?: Json | null
          verification_status?: string
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "articles_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "article_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      autopilot_state: {
        Row: {
          id: string
          last_error: string | null
          last_run_date: string | null
          last_success_at: string | null
          lease_until: string | null
          pause_reason: string | null
          paused: boolean
          updated_at: string
        }
        Insert: {
          id: string
          last_error?: string | null
          last_run_date?: string | null
          last_success_at?: string | null
          lease_until?: string | null
          pause_reason?: string | null
          paused?: boolean
          updated_at?: string
        }
        Update: {
          id?: string
          last_error?: string | null
          last_run_date?: string | null
          last_success_at?: string | null
          lease_until?: string | null
          pause_reason?: string | null
          paused?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      community_comments: {
        Row: {
          author_avatar: string | null
          author_id: string
          author_name: string | null
          body: string
          created_at: string
          id: string
          is_hidden: boolean
          post_id: string
          updated_at: string
        }
        Insert: {
          author_avatar?: string | null
          author_id: string
          author_name?: string | null
          body: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          post_id: string
          updated_at?: string
        }
        Update: {
          author_avatar?: string | null
          author_id?: string
          author_name?: string | null
          body?: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          post_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      community_likes: {
        Row: {
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      community_post_like_counts: {
        Row: {
          like_count: number
          post_id: string
          updated_at: string
        }
        Insert: {
          like_count?: number
          post_id: string
          updated_at?: string
        }
        Update: {
          like_count?: number
          post_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_post_like_counts_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: true
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      community_posts: {
        Row: {
          author_avatar: string | null
          author_id: string
          author_name: string | null
          body: string
          category: string
          created_at: string
          id: string
          is_hidden: boolean
          is_locked: boolean
          is_pinned: boolean
          title: string
          updated_at: string
        }
        Insert: {
          author_avatar?: string | null
          author_id: string
          author_name?: string | null
          body: string
          category?: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          is_locked?: boolean
          is_pinned?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          author_avatar?: string | null
          author_id?: string
          author_name?: string | null
          body?: string
          category?: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          is_locked?: boolean
          is_pinned?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      community_reports: {
        Row: {
          created_at: string
          id: string
          reason: string
          reporter_id: string
          status: string
          target_id: string
          target_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          reason: string
          reporter_id: string
          status?: string
          target_id: string
          target_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          reason?: string
          reporter_id?: string
          status?: string
          target_id?: string
          target_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      content_api_usage: {
        Row: {
          created_at: string
          duration_ms: number | null
          error_message: string | null
          estimated_cost: number
          id: string
          kind: string
          model: string | null
          provider: string | null
          success: boolean
          usage_date: string
        }
        Insert: {
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          estimated_cost?: number
          id?: string
          kind: string
          model?: string | null
          provider?: string | null
          success?: boolean
          usage_date?: string
        }
        Update: {
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          estimated_cost?: number
          id?: string
          kind?: string
          model?: string | null
          provider?: string | null
          success?: boolean
          usage_date?: string
        }
        Relationships: []
      }
      content_engine_settings: {
        Row: {
          articles_per_day: number
          auto_image: boolean
          auto_publish: boolean
          auto_seo: boolean
          auto_translation: boolean
          auto_verification: boolean
          categories: string[]
          daily_generation_limit: number
          default_language: string
          id: string
          max_articles_per_day: number
          max_similarity: number
          min_quality_score: number
          monthly_generation_limit: number
          publish_time: string
          updated_at: string
        }
        Insert: {
          articles_per_day?: number
          auto_image?: boolean
          auto_publish?: boolean
          auto_seo?: boolean
          auto_translation?: boolean
          auto_verification?: boolean
          categories?: string[]
          daily_generation_limit?: number
          default_language?: string
          id?: string
          max_articles_per_day?: number
          max_similarity?: number
          min_quality_score?: number
          monthly_generation_limit?: number
          publish_time?: string
          updated_at?: string
        }
        Update: {
          articles_per_day?: number
          auto_image?: boolean
          auto_publish?: boolean
          auto_seo?: boolean
          auto_translation?: boolean
          auto_verification?: boolean
          categories?: string[]
          daily_generation_limit?: number
          default_language?: string
          id?: string
          max_articles_per_day?: number
          max_similarity?: number
          min_quality_score?: number
          monthly_generation_limit?: number
          publish_time?: string
          updated_at?: string
        }
        Relationships: []
      }
      content_topics: {
        Row: {
          angle: string | null
          attempts: number
          category: string
          created_at: string
          id: string
          keywords: string[]
          language: string
          last_error: string | null
          normalized_title: string | null
          priority: number
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          angle?: string | null
          attempts?: number
          category?: string
          created_at?: string
          id?: string
          keywords?: string[]
          language?: string
          last_error?: string | null
          normalized_title?: string | null
          priority?: number
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          angle?: string | null
          attempts?: number
          category?: string
          created_at?: string
          id?: string
          keywords?: string[]
          language?: string
          last_error?: string | null
          normalized_title?: string | null
          priority?: number
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      daily_task_progress: {
        Row: {
          completed_on: string
          created_at: string
          id: string
          task_key: string
          user_id: string
          xp_awarded: number
        }
        Insert: {
          completed_on?: string
          created_at?: string
          id?: string
          task_key: string
          user_id: string
          xp_awarded?: number
        }
        Update: {
          completed_on?: string
          created_at?: string
          id?: string
          task_key?: string
          user_id?: string
          xp_awarded?: number
        }
        Relationships: []
      }
      daily_ticker: {
        Row: {
          created_at: string
          hijri: string | null
          items: Json
          run_date: string
          theme: string | null
        }
        Insert: {
          created_at?: string
          hijri?: string | null
          items?: Json
          run_date: string
          theme?: string | null
        }
        Update: {
          created_at?: string
          hijri?: string | null
          items?: Json
          run_date?: string
          theme?: string | null
        }
        Relationships: []
      }
      library_items: {
        Row: {
          arabic_title: string | null
          author: string | null
          body: string | null
          category: string
          cover_url: string | null
          created_at: string
          created_by: string | null
          era: string | null
          fiqh_tradition: string | null
          id: string
          is_published: boolean
          language: string
          slug: string
          sort_order: number
          summary: string | null
          title: string
          updated_at: string
        }
        Insert: {
          arabic_title?: string | null
          author?: string | null
          body?: string | null
          category?: string
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          era?: string | null
          fiqh_tradition?: string | null
          id?: string
          is_published?: boolean
          language?: string
          slug: string
          sort_order?: number
          summary?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          arabic_title?: string | null
          author?: string | null
          body?: string | null
          category?: string
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          era?: string | null
          fiqh_tradition?: string | null
          id?: string
          is_published?: boolean
          language?: string
          slug?: string
          sort_order?: number
          summary?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          country: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      quran_surahs: {
        Row: {
          arabic_name: string
          created_at: string | null
          english_name: string | null
          id: number
          revelation_type: string | null
          surah_number: number
          total_ayahs: number | null
          urdu_name: string | null
        }
        Insert: {
          arabic_name: string
          created_at?: string | null
          english_name?: string | null
          id?: number
          revelation_type?: string | null
          surah_number: number
          total_ayahs?: number | null
          urdu_name?: string | null
        }
        Update: {
          arabic_name?: string
          created_at?: string | null
          english_name?: string | null
          id?: number
          revelation_type?: string | null
          surah_number?: number
          total_ayahs?: number | null
          urdu_name?: string | null
        }
        Relationships: []
      }
      reading_history: {
        Row: {
          created_at: string
          href: string | null
          id: string
          item_id: string
          item_type: string
          progress: number
          title: string | null
          updated_at: string
          user_id: string
          viewed_at: string
        }
        Insert: {
          created_at?: string
          href?: string | null
          id?: string
          item_id: string
          item_type: string
          progress?: number
          title?: string | null
          updated_at?: string
          user_id: string
          viewed_at?: string
        }
        Update: {
          created_at?: string
          href?: string | null
          id?: string
          item_id?: string
          item_type?: string
          progress?: number
          title?: string | null
          updated_at?: string
          user_id?: string
          viewed_at?: string
        }
        Relationships: []
      }
      saved_items: {
        Row: {
          created_at: string
          id: string
          item_id: string
          item_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_id: string
          item_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_id?: string
          item_type?: string
          user_id?: string
        }
        Relationships: []
      }
      security_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          raw_input: string
          reasons: string[]
          reviewed: boolean
          sanitized_input: string | null
          severity: string
          source: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event_type?: string
          id?: string
          raw_input: string
          reasons?: string[]
          reviewed?: boolean
          sanitized_input?: string | null
          severity?: string
          source: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          raw_input?: string
          reasons?: string[]
          reviewed?: boolean
          sanitized_input?: string | null
          severity?: string
          source?: string
          user_id?: string | null
        }
        Relationships: []
      }
      site_reviews: {
        Row: {
          approved: boolean
          created_at: string
          id: string
          message: string
          name: string
          place: string | null
          rating: number
        }
        Insert: {
          approved?: boolean
          created_at?: string
          id?: string
          message: string
          name: string
          place?: string | null
          rating: number
        }
        Update: {
          approved?: boolean
          created_at?: string
          id?: string
          message?: string
          name?: string
          place?: string | null
          rating?: number
        }
        Relationships: []
      }
      tafsir_entries: {
        Row: {
          content: string
          created_at: string
          id: string
          lang: string
          summary: string | null
          surah: number
          title: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          lang?: string
          summary?: string | null
          surah: number
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          lang?: string
          summary?: string | null
          surah?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      team_applications: {
        Row: {
          country: string
          created_at: string
          email: string
          experience: string | null
          full_name: string
          id: string
          languages: string | null
          motivation: string
          portfolio_url: string | null
          role: string
          skills: string | null
          status: string
          user_id: string | null
        }
        Insert: {
          country: string
          created_at?: string
          email: string
          experience?: string | null
          full_name: string
          id?: string
          languages?: string | null
          motivation: string
          portfolio_url?: string | null
          role: string
          skills?: string | null
          status?: string
          user_id?: string | null
        }
        Update: {
          country?: string
          created_at?: string
          email?: string
          experience?: string | null
          full_name?: string
          id?: string
          languages?: string | null
          motivation?: string
          portfolio_url?: string | null
          role?: string
          skills?: string | null
          status?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          created_at: string
          direction: string
          language: string
          notify_community: boolean
          notify_daily: boolean
          notify_email: boolean
          public_profile: boolean
          theme: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          direction?: string
          language?: string
          notify_community?: boolean
          notify_daily?: boolean
          notify_email?: boolean
          public_profile?: boolean
          theme?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          direction?: string
          language?: string
          notify_community?: boolean
          notify_daily?: boolean
          notify_email?: boolean
          public_profile?: boolean
          theme?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_xp: {
        Row: {
          created_at: string
          id: string
          last_active_date: string | null
          streak_days: number
          updated_at: string
          user_id: string
          xp: number
        }
        Insert: {
          created_at?: string
          id?: string
          last_active_date?: string | null
          streak_days?: number
          updated_at?: string
          user_id: string
          xp?: number
        }
        Update: {
          created_at?: string
          id?: string
          last_active_date?: string | null
          streak_days?: number
          updated_at?: string
          user_id?: string
          xp?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "reviewer" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "reviewer", "user"],
    },
  },
} as const
