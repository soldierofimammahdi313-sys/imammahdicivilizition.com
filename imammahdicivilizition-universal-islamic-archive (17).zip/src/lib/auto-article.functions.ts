/**
 * Manual "auto article" generator for admins.
 *
 * Keys stay server-side: generation goes through the centralized AI key
 * pool (OpenAI ⇄ Gemini fallback). Only signed-in admins may generate.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { callAi, parseJsonReply } from "./ai-providers.server";
import { NO_INVENTION_RULE } from "./content-engine.server";

const LANGS = {
  urdu: "Urdu (اردو)",
  english: "English",
  arabic: "Arabic (العربية)",
} as const;

const inputSchema = z.object({
  topic: z.string().trim().max(200).optional(),
  language: z.enum(["urdu", "english", "arabic"]).default("urdu"),
});

export type GeneratedArticle = {
  title: string;
  excerpt: string;
  content: string;
  category: string;
  language: "urdu" | "english" | "arabic";
};

export const generateAutoArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw) => inputSchema.parse(raw))
  .handler(async ({ data, context }): Promise<GeneratedArticle> => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden — admins only");

    const langName = LANGS[data.language];
    const topic =
      data.topic && data.topic.length > 0
        ? data.topic
        : "a beneficial contemporary Islamic topic (spirituality, ethics, family, knowledge, or theAwaited Savior Imam Mahdi — choose one)";

    const prompt = [
      `Write a complete, original Islamic article in ${langName} about: ${topic}.`,
      `Requirements: 700–1000 words, warm scholarly tone, authentic Shia Ja'fari perspective, respectful to all schools of thought.`,
      NO_INVENTION_RULE,
      `Reply ONLY as a JSON object with exactly these keys:`,
      `{"title": string, "excerpt": string (1–2 sentences), "content": string (full article in markdown), "category": string (one of: Aqeedah, Akhlaq, History, Fiqh, Spirituality, Family, Mahdism)}`,
      `The title and all text must be in ${langName}.`,
    ].join("\n");

    const { text } = await callAi(prompt, { json: true, maxAttempts: 5 });
    const parsed = parseJsonReply<Partial<GeneratedArticle>>(text);

    if (!parsed.title || !parsed.content) {
      throw new Error("AI returned an incomplete article — please try again");
    }

    return {
      title: String(parsed.title).trim(),
      excerpt: String(parsed.excerpt ?? "").trim(),
      content: String(parsed.content).trim(),
      category: String(parsed.category ?? "General").trim(),
      language: data.language,
    };
  });
