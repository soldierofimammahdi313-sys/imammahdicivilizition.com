/**
 * AI cover-image generation for articles.
 *
 * Generates a unique, symbolic Islamic cover for every new article through the
 * Lovable AI Gateway, stores it in the private `article-covers` bucket and
 * returns a stable public URL served by /api/public/cover/$path.
 *
 * Never depicts sacred personalities — the prompt is constrained below.
 * Best-effort: on any failure the caller falls back to the bundled cover set.
 */

const GATEWAY = "https://ai.gateway.lovable.dev/v1/images/generations";
const MODEL = "google/gemini-3-pro-image";

const STYLE_GUARD =
  "Respectful symbolic Islamic art. Absolutely no depiction of any human face or figure, " +
  "no Prophet, no Imams, no Ahl al-Bayt, no companions. Only architecture, calligraphy patterns, " +
  "manuscripts, lanterns, geometry, desert, sky and light. Cinematic, emerald and gold palette, " +
  "deep obsidian background, elegant and premium, 16:9 wide composition.";

function extractImage(payload: unknown): string | null {
  // Walk the SSE/JSON payload for the first base64 image we can find.
  const seen = new Set<unknown>();
  const walk = (node: unknown): string | null => {
    if (!node || typeof node !== "object" || seen.has(node)) return null;
    seen.add(node);
    for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
      if (typeof value === "string") {
        if (key === "b64_json" || key === "data" || key === "image" || key === "partial_image_b64") {
          if (value.length > 500) return value.replace(/^data:image\/\w+;base64,/, "");
        }
        if (key === "url" && value.startsWith("data:image")) {
          return value.replace(/^data:image\/\w+;base64,/, "");
        }
      } else if (value && typeof value === "object") {
        const found = walk(value);
        if (found) return found;
      }
    }
    return null;
  };
  return walk(payload);
}

async function generateBase64(prompt: string): Promise<string | null> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) return null;

  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      messages: [{ role: "user", content: `${prompt}\n\n${STYLE_GUARD}` }],
      modalities: ["image", "text"],
      stream: true,
    }),
  });
  if (!res.ok || !res.body) return null;

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let latest: string | null = null;

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const raw = line.slice(5).trim();
      if (!raw || raw === "[DONE]") continue;
      try {
        const found = extractImage(JSON.parse(raw));
        if (found) latest = found;
      } catch {
        /* partial frame */
      }
    }
  }
  return latest;
}

/**
 * Generates a cover and stores it. Returns the served URL, or null when
 * generation is unavailable so the caller can fall back.
 */
export async function generateArticleCover(input: {
  slug: string;
  title: string;
  prompt?: string | null;
}): Promise<string | null> {
  try {
    const prompt =
      input.prompt?.trim() ||
      `Cover artwork for an Islamic knowledge article titled "${input.title}".`;
    const b64 = await generateBase64(prompt);
    if (!b64) return null;

    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const path = `${input.slug}-${Date.now()}.png`;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.storage
      .from("article-covers")
      .upload(path, bytes, { contentType: "image/png", upsert: true });
    if (error) return null;

    return `/api/public/cover/${path}`;
  } catch {
    return null;
  }
}
