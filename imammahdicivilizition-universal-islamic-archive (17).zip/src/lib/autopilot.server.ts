/**
 * Daily Islamic content autopilot.
 *
 * One bounded run per invocation:
 *   1. single-flight DB lease (a second concurrent run exits)
 *   2. paused-state guard with a cheap probe to detect recovery
 *   3. one article per day (idempotent: last_run_date)
 *   4. verified ticker refresh for the same day
 *
 * Providers: OpenAI first for writing/SEO/social, Gemini for research and as
 * fallback. Quota/blocked failures pause the job instead of looping.
 */
import { AiUnavailableError, callAi, parseJsonReply } from "@/lib/ai-providers.server";
import type { DailyHadith } from "@/lib/daily-hadiths.types";

const JOB_ID = "daily";
const LEASE_MINUTES = 10;

const NO_INVENTION_RULE = `ABSOLUTE RULE: never invent, paraphrase-as-quotation, or guess any Quranic verse, hadith, narration, du'a text or scholarly quotation. Only use texts you are certain exist verbatim in the classical sources, and cite them exactly (surah:ayah, or book + volume/page or hadith number). If you are not certain a quotation is authentic, omit it entirely and write general explanation instead. Never attach a reference to a text you are unsure about.`;

type Json = Record<string, unknown>;

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function hijriLabel(date: Date): string {
  try {
    return new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date);
  } catch {
    return "";
  }
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 80);
}

export type AutopilotResult = {
  status: "ok" | "skipped" | "locked" | "paused" | "failed";
  detail: string;
  articleSlug?: string;
  article?: {
    title: string;
    slug: string;
    status: "published" | "draft";
  };
  tickerItems?: number;
};

export async function runDailyAutopilot(): Promise<AutopilotResult> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const dateKey = today();
  const now = new Date();

  const { data: state } = await supabaseAdmin
    .from("autopilot_state")
    .select("*")
    .eq("id", JOB_ID)
    .maybeSingle();

  if (state?.last_run_date === dateKey) {
    return { status: "skipped", detail: "Already generated today" };
  }

  // Single-flight lease.
  const leaseUntil = new Date(now.getTime() + LEASE_MINUTES * 60_000).toISOString();
  const { data: leased } = await supabaseAdmin
    .from("autopilot_state")
    .update({ lease_until: leaseUntil, updated_at: now.toISOString() })
    .eq("id", JOB_ID)
    .or(`lease_until.is.null,lease_until.lt.${now.toISOString()}`)
    .select("id");

  if (!leased?.length) {
    return { status: "locked", detail: "Another run holds the lease" };
  }

  try {
    // Paused → single cheap probe to detect out-of-band recovery.
    if (state?.paused) {
      try {
        await callAi("Reply with the single word: ok", {});
      } catch {
        return { status: "paused", detail: state.pause_reason ?? "Paused" };
      }
      await supabaseAdmin
        .from("autopilot_state")
        .update({ paused: false, pause_reason: null })
        .eq("id", JOB_ID);
    }

    // Religious content stays in Draft unless an admin turns auto-publish on.
    const { getSettings } = await import("@/lib/content-engine.server");
    const autoPublish = (await getSettings()).auto_publish;

    const hijri = hijriLabel(now);

    const { data: recent } = await supabaseAdmin
      .from("articles")
      .select("title, slug")
      .order("created_at", { ascending: false })
      .limit(60);
    const existing = (recent ?? []).map((r) => `${r.title} (${r.slug})`).join("; ");
    const existingSlugs = new Set((recent ?? []).map((r) => r.slug));

    // 1) Research brief — Gemini first (research task), OpenAI as fallback.
    const brief = await callAi(
      `Today is ${dateKey} (Hijri: ${hijri}).
Propose ONE fresh, HIGH-SEARCH-VOLUME Islamic article topic in English for a Twelver Shia (Fiqh Ja'fariya) knowledge platform that also fairly notes Sunni scholarship where relevant.

Pick a topic people actually search for on Google — history, biography, beliefs, spirituality, Quran and tafsir, Karbala and Ahl al-Bayt, Imam Mahdi, Islamic civilisation, science and ethics, daily life guidance, questions new Muslims ask.
Do NOT write another narrow "rulings / masail / fiqh procedure" article — those are already over-represented. Prefer explanatory, story-driven or evergreen questions (for example: "Who is Imam Mahdi?", "Why is Ashura commemorated?", "What does the Quran say about justice?").
Write the topic as a natural search query or clear headline.
Avoid anything close to these already-published topics: ${existing || "none"}.
Then research it and list the verified source references that genuinely support it.

${NO_INVENTION_RULE}

Return JSON only:
{"topic":"...","angle":"...","outline":["...","..."],"verified_sources":["Quran 2:255","al-Kafi 1/34 h.2"],"tags":["...","..."]}`,
      { prefer: "gemini", json: true },
    );

    const research = parseJsonReply<{
      topic?: string;
      angle?: string;
      outline?: string[];
      verified_sources?: string[];
      tags?: string[];
    }>(brief.text);

    // 2) Write the article — OpenAI first (writing + SEO + social).
    const draft = await callAi(
      `Write a complete, original Islamic article in English for the "Imam Mahdi Civilization" platform.

Topic: ${research.topic}
Angle: ${research.angle ?? ""}
Outline: ${(research.outline ?? []).join(" | ")}
Verified sources available: ${(research.verified_sources ?? []).join(" | ")}
Today: ${dateKey} (Hijri: ${hijri})

${NO_INVENTION_RULE}

Requirements:
- 900-1400 words of substantive, non-repetitive Markdown (## headings, short paragraphs, occasional lists).
- Respectful scholarly tone; Ja'fari position primary, other schools mentioned neutrally when relevant.
- Include a short "Sources" section at the end listing only references you are certain of.
- SEO title under 60 characters, meta description under 155 characters.

Return JSON only:
{"title":"...","slug":"kebab-case-slug","excerpt":"...","meta_description":"...","content":"# ...markdown...","tags":["..."],"reading_minutes":7,"social":{"x":"...","instagram":"...","facebook":"..."}}`,
      { prefer: "gemini", json: true },
    );
    const article = parseJsonReply<{
      title?: string;
      slug?: string;
      excerpt?: string;
      meta_description?: string;
      content?: string;
      tags?: string[];
      reading_minutes?: number;
      social?: Json;
    }>(draft.text);

    if (!article.title || !article.content) {
      throw new Error("Model returned an incomplete article");
    }

    // 3) Safe proofreading pass — typos, grammar, formatting only.
    let content = article.content;
    try {
      const proof = await callAi(
        `Proofread the Markdown below. Fix ONLY typos, grammar, punctuation, spacing and Markdown formatting.
Do NOT change meaning, do NOT add or remove any Quranic verse, hadith, narration or citation, do NOT reword religious quotations, do NOT add new claims.
Return JSON only: {"content":"<corrected markdown>"}

---
${content}`,
        { prefer: "gemini", json: true },
      );
      const fixed = parseJsonReply<{ content?: string }>(proof.text).content;
      // Reject a proofread that mangles or truncates the article.
      if (fixed && fixed.length > content.length * 0.85) content = fixed;
    } catch {
      /* proofreading is best-effort; keep the original draft */
    }

    let slug = slugify(article.slug || article.title);
    if (!slug) slug = `daily-${dateKey}`;
    if (existingSlugs.has(slug)) slug = `${slug}-${dateKey}`;

    const { generateArticleCover } = await import("@/lib/article-image.server");
    const coverUrl = await generateArticleCover({ slug, title: article.title });

    const { error: insertError } = await supabaseAdmin.from("articles").insert({
      slug,
      cover_url: coverUrl,
      title: article.title.slice(0, 160),
      excerpt: (article.meta_description || article.excerpt || "").slice(0, 300),
      content,
      tags: Array.isArray(article.tags) ? article.tags.slice(0, 8) : research.tags?.slice(0, 8) ?? null,
      reading_minutes:
        typeof article.reading_minutes === "number"
          ? article.reading_minutes
          : Math.max(4, Math.round(content.split(/\s+/).length / 200)),
      language: "en",
      status: autoPublish ? "published" : "draft",
      pipeline_status: autoPublish ? "published" : "draft",
      published_at: autoPublish ? new Date().toISOString() : null,
    });
    if (insertError) throw new Error(`Article insert failed: ${insertError.message}`);
    // English-only platform: no second-language article is generated.





    // 4) Daily ticker refresh — verified narrations only.
    let tickerCount = 0;
    try {
      const ticker = await callAi(
        `Today is ${dateKey} (Hijri: ${hijri}).
Give 18 authentic, well-known narrations from the Fourteen Infallibles that suit today's Islamic month and occasion, rotating across as many of the fourteen as possible.

${NO_INVENTION_RULE}

Return JSON only:
{"items":[{"text":"<complete Arabic narration> — <complete English translation>","by":"Imam Ja'far al-Sadiq (a.s)","source":"al-Kafi 2/74 h.3"}]}
Rules: complete Arabic then " — " then the complete English translation, no ellipses, no duplicates, real book + volume/hadith number for every item. If you cannot verify 18, return fewer.`,
        { prefer: "gemini", json: true },
      );
      const parsed = parseJsonReply<{ items?: DailyHadith[] }>(ticker.text);
      const items = (parsed.items ?? []).filter((i) => i?.text && i?.by && i?.source).slice(0, 24);
      if (items.length) {
        await supabaseAdmin.from("daily_ticker").upsert({
          run_date: dateKey,
          hijri,
          theme: research.topic ?? null,
          items: items as unknown as never,
        });
        tickerCount = items.length;
      }
    } catch {
      /* ticker refresh is best-effort; the article still ships */
    }

    await supabaseAdmin
      .from("autopilot_state")
      .update({
        last_run_date: dateKey,
        last_success_at: new Date().toISOString(),
        last_error: null,
        lease_until: null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", JOB_ID);

    return {
      status: "ok",
      detail: autoPublish ? `Published "${article.title}"` : `Saved as draft "${article.title}" (auto-publish is off)`,
      articleSlug: slug,
      article: { title: article.title, slug, status: autoPublish ? "published" : "draft" },
      tickerItems: tickerCount,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const quota = err instanceof AiUnavailableError && err.quota;
    await supabaseAdmin
      .from("autopilot_state")
      .update({
        lease_until: null,
        last_error: message.slice(0, 500),
        paused: quota,
        pause_reason: quota ? message.slice(0, 300) : null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", JOB_ID);
    return { status: quota ? "paused" : "failed", detail: message };
  }
}
