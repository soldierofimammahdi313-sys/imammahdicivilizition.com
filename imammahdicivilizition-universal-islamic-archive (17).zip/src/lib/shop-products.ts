// Single source of truth for Shop products (used by /shop and Related Products blocks).
export type Product = { name: string; url: string; tags?: string[] };
export type Section = { title: string; products: Product[] };

export const SECTIONS: Section[] = [
  {
    title: "Books",
    products: [
      { name: "Holy Quran", url: "https://a.co/d/02yLzrri", tags: ["quran", "surah", "tafsir"] },
      { name: "Secret of Divine Love", url: "https://a.co/d/0hqa6nKC", tags: ["spirituality", "love", "soul"] },
      { name: "The Sealed Nector", url: "https://a.co/d/0h5ybJkk", tags: ["prophet", "seerah", "history"] },
      { name: "Lost Islamic History", url: "https://a.co/d/0d8RUTTY", tags: ["history", "civilization"] },
      { name: "Nahj al-Balagha", url: "https://a.co/d/015ELKdb", tags: ["ali", "imam", "sermons"] },
      { name: "The Psalms of Islam", url: "https://a.co/d/0aMv6N78", tags: ["dua", "supplication", "sajjad"] },
      { name: "The Lantern of the Path", url: "https://a.co/d/05yWMKIr", tags: ["spirituality", "imam", "sadiq"] },
      { name: "Historic Research on the 12 Imams", url: "https://a.co/d/0bsqtMJp", tags: ["imam", "mahdi", "ahlulbayt", "history"] },
      { name: "The Tragedy of Karbala", url: "https://a.co/d/03rKu7cU", tags: ["karbala", "husayn", "ashura", "muharram"] },
      { name: "Fatima: The Flower of Life", url: "https://a.co/d/0cBmyBvz", tags: ["fatima", "ahlulbayt", "women"] },
      { name: "Sahih al-Bukhari", url: "https://a.co/d/0jemSRMm", tags: ["hadith", "sunnah"] },
      { name: "Al-Kafi", url: "https://a.co/d/01R8ZvYV", tags: ["hadith", "imam", "ahlulbayt"] },
      { name: "Muslims Who Changed the World", url: "https://a.co/d/01M6lRH8", tags: ["history", "science", "civilization"] },
      { name: "Tawakkul", url: "https://a.co/d/0dP8M3c4", tags: ["spirituality", "faith", "trust"] },
      { name: "Riad as-Salihin Book", url: "https://a.co/d/0bEt6F45", tags: ["hadith", "ethics", "sunnah"] },
      { name: "Holy Quran Arabic Only", url: "https://a.co/d/07Ym62Jw", tags: ["quran", "arabic"] },
      { name: "The Majestic Quran", url: "https://a.co/d/00z3j66i", tags: ["quran", "translation", "tafsir"] },
      { name: "Medina Calligraphy Quran Set — Gray", url: "https://a.co/d/0aiqkgtW", tags: ["quran", "calligraphy", "gift"] },
      { name: "Medina Calligraphy Quran Set — Pink", url: "https://a.co/d/00fE3vs6", tags: ["quran", "calligraphy", "gift", "women"] },
      { name: "Islamic Psychology Perspective", url: "https://a.co/d/0c5aZsqA", tags: ["psychology", "spirituality", "soul", "science"] },
      { name: "Psychology From Islamic Perspective", url: "https://a.co/d/0fYqx01b", tags: ["psychology", "spirituality", "science"] },
      { name: "Handbook of Spiritual Medicine", url: "https://a.co/d/0iUULVaR", tags: ["spirituality", "healing", "soul", "ethics"] },
      { name: "Handbook of Prophetic Characteristics", url: "https://a.co/d/07x2maue", tags: ["prophet", "ethics", "sunnah"] },
      { name: "Manuel De Médecine Spirituelle", url: "https://a.co/d/00bXur5P", tags: ["spirituality", "healing"] },
      { name: "Black Muslims in History", url: "https://a.co/d/036o3px2", tags: ["history", "civilization"] },
      { name: "Dua for the Muslimah Journal", url: "https://a.co/d/0aFaFgTf", tags: ["dua", "women", "journal", "prayer"] },
    ],
  },
  {
    title: "Kids Collection",
    products: [
      { name: "30 Stories Book for Baby", url: "https://a.co/d/038OarLC", tags: ["kids", "stories"] },
      { name: "Why We Pray", url: "https://a.co/d/09mVTbqD", tags: ["kids", "prayer", "salah"] },
      { name: "Quran for Kids", url: "https://a.co/d/088ZFroT", tags: ["kids", "quran"] },
      { name: "Prophet Stories for Kids", url: "https://a.co/d/0c1jUFpW", tags: ["kids", "prophet", "stories"] },
      { name: "Islam Kids Books", url: "https://a.co/d/00ezebM7", tags: ["kids"] },
      { name: "But Who is Allah", url: "https://a.co/d/03PyulkQ", tags: ["kids", "allah", "names"] },
      { name: "First Words of Arabic", url: "https://a.co/d/0iYpfaoo", tags: ["kids", "arabic", "learning"] },
      { name: "My Quran Pad Educational Toy", url: "https://a.co/d/0caHR7of", tags: ["kids", "quran", "learning", "toy"] },
      { name: "Islamic Dua Flashcards for Kids", url: "https://a.co/d/06TPsnoL", tags: ["kids", "dua", "flashcards", "learning"] },
      { name: "Educational Interactive Prayer Mat", url: "https://a.co/d/09Dj0OG6", tags: ["kids", "prayer", "salah", "learning"] },
      { name: "Mommy Yasmin Muslim Toy", url: "https://a.co/d/0e622sWQ", tags: ["kids", "toy"] },
    ],
  },
  {
    title: "Prayer Essentials",
    products: [
      { name: "Tasbeeh", url: "https://a.co/d/00oJHiDi", tags: ["prayer", "tasbih", "dhikr"] },
      { name: "Beautiful Hand Tasbeeh", url: "https://a.co/d/0fhERMUk", tags: ["prayer", "tasbih", "dhikr"] },
      { name: "Namaz Mat", url: "https://a.co/d/0fqNPBhb", tags: ["prayer", "salah", "rug"] },
      { name: "Smart 3D Azan Clock", url: "https://a.co/d/0d0UjUvA", tags: ["prayer", "salah", "azan", "qibla"] },
      { name: "FURKAN Prayer Rug & Beads Set", url: "https://a.co/d/0cDLJ65N", tags: ["prayer", "salah", "rug", "tasbih", "gift"] },
    ],
  },
  {
    title: "Islamic Decor & Art",
    products: [
      { name: "Islamic Art Product", url: "https://a.co/d/07Ld7Ash", tags: ["art", "decor"] },
      { name: "Ayatul Kursi Art", url: "https://a.co/d/0afgYSId", tags: ["art", "quran", "calligraphy"] },
      { name: "Islamic Wallpapers", url: "https://a.co/d/06k8oUPv", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/05KEGYPe", tags: ["art", "decor"] },
      { name: "Full Ayatul Kursi Wallpaper", url: "https://a.co/d/03tb81Tf", tags: ["art", "quran", "calligraphy"] },
      { name: "Islamic Art", url: "https://a.co/d/0cI9aX3b", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/0aE645fT", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/0iRt0Rgr", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/081DPryS", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/0eRz8Ma1", tags: ["art", "decor"] },
      { name: "Islamic Art", url: "https://a.co/d/06QkhZE8", tags: ["art", "decor"] },
      { name: "Quranic Verse on Tree", url: "https://a.co/d/067fd0yO", tags: ["art", "quran", "calligraphy"] },
      { name: "Quranic Verse Art on Square", url: "https://a.co/d/082pqMXd", tags: ["art", "quran", "calligraphy"] },
      { name: "Digital Islamic Cloth", url: "https://a.co/d/04cRJMWX", tags: ["art", "decor"] },
      { name: "Imam Ali Sword Art", url: "https://a.co/d/05ZKV5WN", tags: ["ali", "imam", "art", "karbala"] },
      { name: "Allah Bismillah Canvas Art Set", url: "https://a.co/d/058KnVkr", tags: ["art", "allah", "calligraphy", "names"] },
      { name: "Islamic Canvas Wall Art", url: "https://a.co/d/0aFQYcQm", tags: ["art", "decor"] },
      { name: "Ottoman Style Kilij Sword", url: "https://a.co/d/034diooo", tags: ["history", "art", "battle", "ottoman"] },
    ],
  },
  {
    title: "Perfumes",
    products: [
      { name: "Oud Perfume", url: "https://a.co/d/0exVnluk", tags: ["perfume", "gift"] },
      { name: "Oud Perfume", url: "https://a.co/d/0au36sQd", tags: ["perfume", "gift"] },
      { name: "Oud Perfume", url: "https://a.co/d/07l7O3WK", tags: ["perfume", "gift"] },
    ],
  },
  {
    title: "Women's Collection",
    products: [
      { name: "Hijab for Women", url: "https://a.co/d/0iz7mAk8", tags: ["women", "hijab"] },
      { name: "Hijab for Women", url: "https://a.co/d/09S1u6P2", tags: ["women", "hijab"] },
      { name: "Women Full Body Hijab Dress", url: "https://a.co/d/01GVdVHB", tags: ["women", "hijab"] },
      { name: "Women Prayer Abaya", url: "https://a.co/d/0fUYxmId", tags: ["women", "prayer", "salah"] },
    ],
  },
  {
    title: "Accessories",
    products: [
      { name: "Islamic Key Holder", url: "https://a.co/d/09UfhEgE", tags: ["gift", "decor"] },
      { name: "3D Allah Name Decor", url: "https://a.co/d/0fnkP0Hz", tags: ["allah", "names", "decor", "art"] },
      { name: "Islamic Key Chain", url: "https://a.co/d/0gbT6O1f", tags: ["gift", "decor"] },
      { name: "Luxury Metal Quran Storage Box", url: "https://a.co/d/0a758hFQ", tags: ["quran", "gift", "decor"] },
      { name: "Eid Mubarak Gift Box", url: "https://a.co/d/0bV81tjU", tags: ["eid", "ramadan", "gift"] },
    ],
  },
];

export const ALL_PRODUCTS: Product[] = SECTIONS.flatMap((s) => s.products);

/** Pick up to `limit` products relevant to a topic string (title/tags/category text). */
export function relatedProducts(topic: string, limit = 4): Product[] {
  const t = topic.toLowerCase();
  const scored = ALL_PRODUCTS.map((p) => {
    let score = 0;
    for (const tag of p.tags ?? []) if (t.includes(tag)) score += 2;
    for (const word of p.name.toLowerCase().split(/[^a-z]+/)) {
      if (word.length > 4 && t.includes(word)) score += 1;
    }
    return { p, score };
  }).filter((x) => x.score > 0);

  scored.sort((a, b) => b.score - a.score);
  const picked: Product[] = [];
  const seen = new Set<string>();
  for (const { p } of scored) {
    if (seen.has(p.url)) continue;
    seen.add(p.url);
    picked.push(p);
    if (picked.length >= limit) break;
  }
  if (picked.length < limit) {
    for (const p of ALL_PRODUCTS) {
      if (seen.has(p.url)) continue;
      seen.add(p.url);
      picked.push(p);
      if (picked.length >= limit) break;
    }
  }
  return picked;
}
