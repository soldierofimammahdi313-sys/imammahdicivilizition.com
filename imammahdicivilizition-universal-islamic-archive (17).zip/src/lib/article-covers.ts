import { generatedCover } from "@/lib/generated-cover";
import afterlife from "@/assets/covers/afterlife.jpg.asset.json";
import battle from "@/assets/covers/battle.jpg.asset.json";
import dhikr from "@/assets/covers/dhikr.jpg.asset.json";
import endtimes from "@/assets/covers/endtimes.jpg.asset.json";
import ethics from "@/assets/covers/ethics.jpg.asset.json";
import family from "@/assets/covers/family.jpg.asset.json";
import hajj from "@/assets/covers/hajj.jpg.asset.json";
import history from "@/assets/covers/history.jpg.asset.json";
import journey from "@/assets/covers/journey.jpg.asset.json";
import karbala from "@/assets/covers/karbala.jpg.asset.json";
import mahdi from "@/assets/covers/mahdi.jpg.asset.json";
import modern from "@/assets/covers/modern.jpg.asset.json";
import mosque from "@/assets/covers/mosque.jpg.asset.json";
import quran from "@/assets/covers/quran.jpg.asset.json";
import ramadan from "@/assets/covers/ramadan.jpg.asset.json";
import salah from "@/assets/covers/salah.jpg.asset.json";
import knowledge from "@/assets/covers/knowledge.jpg.asset.json";
import night from "@/assets/covers/night.jpg.asset.json";
import pattern from "@/assets/covers/pattern.jpg.asset.json";
import shrine from "@/assets/covers/shrine.jpg.asset.json";
import science from "@/assets/covers/science.jpg.asset.json";
import corridor from "@/assets/covers/corridor.jpg";
import dawn from "@/assets/covers/dawn.jpg";
import desert from "@/assets/covers/desert.jpg";
import manuscript from "@/assets/covers/manuscript.jpg";
import minbar from "@/assets/covers/minbar.jpg";
import water from "@/assets/covers/water.jpg";
import caravan from "@/assets/covers/caravan.jpg";
import scriptorium from "@/assets/covers/scriptorium.jpg";
import courtyard from "@/assets/covers/courtyard.jpg";
import observatory from "@/assets/covers/observatory.jpg";
import prayerhall from "@/assets/covers/prayerhall.jpg";
import olive from "@/assets/covers/olive.jpg";
import mosaic from "@/assets/covers/mosaic.jpg";
import lantern from "@/assets/covers/lantern.jpg";
import dome from "@/assets/covers/dome.jpg";
import tasbih from "@/assets/covers/tasbih.jpg";
import library from "@/assets/covers/library.jpg";
import horizon from "@/assets/covers/horizon.jpg";
import classroom from "@/assets/covers/classroom.jpg";
import winterShrine from "@/assets/covers/winter-shrine.jpg";

/** Themed, faceless cover art used when an article has no cover of its own. */
export const COVERS = {
  afterlife: afterlife.url,
  battle: battle.url,
  dhikr: dhikr.url,
  endtimes: endtimes.url,
  ethics: ethics.url,
  family: family.url,
  hajj: hajj.url,
  history: history.url,
  journey: journey.url,
  karbala: karbala.url,
  mahdi: mahdi.url,
  modern: modern.url,
  mosque: mosque.url,
  quran: quran.url,
  ramadan: ramadan.url,
  salah: salah.url,
  knowledge: knowledge.url,
  night: night.url,
  pattern: pattern.url,
  shrine: shrine.url,
  science: science.url,
  corridor,
  dawn,
  desert,
  manuscript,
  minbar,
  water,
  caravan,
  scriptorium,
  courtyard,
  observatory,
  prayerhall,
  olive,
  mosaic,
  lantern,
  dome,
  tasbih,
  library,
  horizon,
  classroom,
  winterShrine,
} as const;

type CoverKey = keyof typeof COVERS;

/**
 * Keyword → theme variants, checked in order against slug + title + tags.
 * Each theme lists several distinct images so two articles on the same topic
 * do not end up sharing the same picture.
 */
const RULES: Array<[RegExp, CoverKey[]]> = [
  [/scien|astronom|medicin|alchem|mathematic|algebra|jabir|khwarizmi|house-of-wisdom|invention|physician|astrolabe/, ["science", "observatory", "library"]],
  [/karbala|husayn|ashura/, ["karbala", "dome", "desert"]],
  [/shrine|najaf|ziyarat|mashhad|samarra|kadhimayn|dome/, ["shrine", "winterShrine", "dome"]],
  [/manuscript|isnad|compilation|transmission|scribe|codex/, ["manuscript", "scriptorium", "library"]],
  [/sermon|khutba|minbar|friday|jumuah|leadership|imamate|caliph/, ["minbar", "prayerhall", "courtyard"]],
  [/water|zamzam|thirst|euphrates|river|purity|wudu-/, ["water", "olive", "courtyard"]],
  [/desert|hijaz|arabia|bedouin|caravan/, ["desert", "caravan", "olive"]],
  [/dawn|fajr|hope|reappearance|revival/, ["dawn", "horizon", "olive"]],
  [/corridor|arches|column|architecture/, ["corridor", "lantern", "courtyard"]],
  [/fiqh|jurisprudence|islamic law|halal|inheritance|khums|divorce|traveler|seafood|slaughter|ahkam|masail/, ["manuscript", "minbar", "mosaic", "pattern", "corridor"]],
  [/knowledge|scholar|ilm|education|academy|library|learning|school|philosophy|logic|tadabbur|hifz/, ["knowledge", "library", "classroom", "scriptorium"]],
  [/night|laylat-al-qadr|tahajjud|moon|hilal|calendar|hijri/, ["night", "lantern", "horizon"]],
  [/art|calligraphy|geometry|pattern|civilization|culture|heritage/, ["pattern", "mosaic", "courtyard"]],
  [/mahdi|occultation|awaited|ghayba/, ["mahdi", "dawn", "horizon"]],
  [/dajjal|signs-of-the-hour|end-times|qiyamah|judgment/, ["endtimes", "horizon", "night"]],
  [/jannah|jahannam|afterlife|barzakh|paradise|death/, ["afterlife", "horizon", "olive"]],
  [/hajj|umrah|makkah|kaaba|pilgrim/, ["hajj", "caravan", "courtyard"]],
  [/badr|uhud|battle|conquest|khandaq|khaybar/, ["battle", "desert", "caravan"]],
  [/hijrah|migration|journey|travel/, ["journey", "caravan", "horizon"]],
  [/ramadan|fasting|sawm|eid|iftar/, ["ramadan", "lantern", "tasbih"]],
  [/salah|prayer|namaz|wudu|masjid|mosque/, ["salah", "prayerhall", "courtyard", "dome"]],
  [/dua|dhikr|tasbih|supplication|remembrance|zakat|khums|sadaqah|charity/, ["dhikr", "tasbih", "lantern"]],
  [/quran|revelation|tafsir|surah|ayah/, ["quran", "scriptorium", "tasbih"]],
  [/family|women|marriage|children|parents|household|fatimah|fatima/, ["family", "olive", "classroom"]],
  [/ethic|akhlaq|justice|mercy|honesty|character|patience/, ["ethics", "olive", "mosaic"]],
  [/modern|technology|environment|peace|humanity|contemporary|digital/, ["modern", "classroom", "mosaic"]],
  [/imam|ahl-al-bayt|companion|sahabah|seerah|prophet|history|hadith/, ["history", "manuscript", "scriptorium", "dome"]],
  [/islam|iman|tawhid|aqeedah|pillars|faith/, ["mosque", "prayerhall", "mosaic"]],
];

/** Every cover, used to spread articles that match no keyword. */
const ALL_KEYS = Object.keys(COVERS) as CoverKey[];

function hash(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h;
}

export function coverFor(input: {
  cover_url?: string | null;
  slug?: string | null;
  title?: string | null;
  tags?: string[] | null;
  category?: string | null;
}): string {
  if (input.cover_url) return input.cover_url;
  // No stored cover → build a unique artwork from the article identity, so two
  // articles never share the same picture.
  return generatedCover(`${input.slug ?? ""}|${input.title ?? ""}`);
}

/** Themed photographic cover, kept for editorial/hero surfaces. */
export function themedCoverFor(input: {
  slug?: string | null;
  title?: string | null;
  tags?: string[] | null;
  category?: string | null;
}): string {
  const hay = [input.slug, input.title, input.category, ...(input.tags ?? [])]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  const h = hash(hay);
  for (const [re, keys] of RULES) {
    if (re.test(hay)) return COVERS[keys[h % keys.length]];
  }
  return COVERS[ALL_KEYS[h % ALL_KEYS.length]];
}
