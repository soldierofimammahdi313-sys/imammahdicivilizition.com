import type { DailyHadithPayload } from "./daily-hadiths.types";

let cacheKey: string | null = null;
let cacheValue: DailyHadithPayload | null = null;
let pendingKey: string | null = null;
let pending: Promise<DailyHadithPayload> | null = null;

export function getCached(dateKey: string): DailyHadithPayload | null {
  return cacheKey === dateKey ? cacheValue : null;
}

export function setCached(dateKey: string, payload: DailyHadithPayload): void {
  cacheKey = dateKey;
  cacheValue = payload;
}

export function getInFlight(dateKey: string): Promise<DailyHadithPayload> | null {
  return pendingKey === dateKey ? pending : null;
}

export function trackInFlight(
  dateKey: string,
  promise: Promise<DailyHadithPayload>,
): Promise<DailyHadithPayload> {
  pendingKey = dateKey;
  pending = promise.finally(() => {
    if (pendingKey === dateKey) {
      pendingKey = null;
      pending = null;
    }
  });
  return pending;
}
