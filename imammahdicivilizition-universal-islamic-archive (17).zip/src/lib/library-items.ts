import { supabase } from "@/integrations/supabase/client";
import { isFiqhId, type FiqhId } from "@/lib/fiqh";

export type LibraryItem = {
  id: string;
  slug: string;
  title: string;
  arabic_title: string | null;
  author: string | null;
  category: string;
  era: string | null;
  language: string;
  summary: string | null;
  body: string | null;
  cover_url: string | null;
  sort_order: number;
  is_published: boolean;
  created_at: string;
  /**
   * School of jurisprudence recorded for this entry, or null when it is not
   * known. Null is shown as "General / Unclassified" — never guessed.
   */
  fiqh_tradition?: string | null;
};

/** The recorded school for an entry, or null when nothing reliable is stored. */
export function itemFiqh(item: Pick<LibraryItem, "fiqh_tradition">): FiqhId | null {
  const raw = item.fiqh_tradition;
  if (typeof raw !== "string") return null;
  const value = raw.trim().toLowerCase();
  return isFiqhId(value) ? value : null;
}

export type LibraryItemInput = {
  slug: string;
  title: string;
  arabic_title?: string | null;
  author?: string | null;
  category: string;
  era?: string | null;
  language: string;
  summary?: string | null;
  body?: string | null;
  cover_url?: string | null;
  sort_order?: number;
  is_published?: boolean;
  fiqh_tradition?: string | null;
};

export const LIBRARY_CATEGORIES = [
  "Tafsir",
  "History",
  "Philosophy",
  "Hadith",
  "Supplication",
  "Jurisprudence",
  "Biography",
  "General",
] as const;

/** Published entries, visible to everyone. */
export async function fetchPublishedLibraryItems(): Promise<LibraryItem[]> {
  const { data, error } = await supabase
    .from("library_items")
    .select("*")
    .eq("is_published", true)
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as LibraryItem[];
}

/** Every entry including drafts — the database only allows this for admins. */
export async function fetchAllLibraryItems(): Promise<LibraryItem[]> {
  const { data, error } = await supabase
    .from("library_items")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as LibraryItem[];
}

export async function createLibraryItem(input: LibraryItemInput) {
  const { error } = await supabase.from("library_items").insert(input);
  if (error) throw error;
}

export async function updateLibraryItem(id: string, input: Partial<LibraryItemInput>) {
  const { error } = await supabase.from("library_items").update(input).eq("id", id);
  if (error) throw error;
}

export async function deleteLibraryItem(id: string) {
  const { error } = await supabase.from("library_items").delete().eq("id", id);
  if (error) throw error;
}

export function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 80);
}
