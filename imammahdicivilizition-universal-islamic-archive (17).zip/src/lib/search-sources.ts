import { supabase } from "@/integrations/supabase/client";
import { BOOKS, VIDEO_CHANNELS, VIDEO_COLLECTIONS } from "@/lib/catalog";
import { NARRATIONS } from "@/components/site/LiveTicker";
import { SITE_INDEX } from "@/lib/site-index";
import type { SearchDoc } from "@/lib/search-engine";
import { guardSearchTerm, type SearchGuardSource } from "@/lib/search-guard";
import { reportSuspiciousSearch } from "@/lib/security-events.functions";

/** Instantly searchable, bundled corpus: pages, tools, books, videos, narrations. */
export const LOCAL_DOCS: SearchDoc[] = [
  ...SITE_INDEX.map((e) => ({
    id: `page:${e.to}`,
    type: "page" as const,
    title: e.label,
    arabic: e.arabic,
    subtitle: e.group,
    keywords: e.keywords,
    to: e.to,
    meta: e.to,
  })),
  ...BOOKS.map((b) => ({
    id: `book:${b.t}`,
    type: "book" as const,
    title: b.t,
    subtitle: b.a,
    keywords: `book kitab library ${b.a}`,
    href: b.u,
    meta: "Digital Library",
  })),
  ...VIDEO_COLLECTIONS.map((c) => ({
    id: `video:${c.t}`,
    type: "video" as const,
    title: c.t,
    arabic: c.a,
    subtitle: c.c,
    keywords: `video lecture playlist ${c.q}`,
    href: `https://www.youtube.com/results?search_query=${encodeURIComponent(c.q)}`,
    meta: "Video Center",
  })),
  ...VIDEO_CHANNELS.map((c) => ({
    id: `channel:${c.n}`,
    type: "video" as const,
    title: c.n,
    subtitle: "YouTube channel",
    keywords: "channel youtube scholar lecture speaker",
    href: c.u,
    meta: "Channel",
  })),
  ...NARRATIONS.map((n, i) => ({
    id: `narration:${i}`,
    type: "hadith" as const,
    title: n.by,
    body: n.text,
    subtitle: n.source,
    keywords: `hadith narration riwayah ${n.source}`,
    to: "/hadith",
    meta: n.source,
  })),
];

/**
 * PostgREST `or()` filters are comma separated — sanitize the term and report
 * anything that looks like a filter-injection probe.
 */
function safeTerm(q: string, source: SearchGuardSource): string {
  const guard = guardSearchTerm(q);
  if (guard.suspicious) {
    void reportSuspiciousSearch({ data: { source, raw: q.slice(0, 2000) } }).catch(() => {});
  }
  return guard.term;
}

export async function searchArticles(q: string): Promise<SearchDoc[]> {
  const term = safeTerm(q, "site-search");
  if (!term) return [];
  const { data, error } = await supabase
    .from("articles")
    .select("slug,title,excerpt,content,tags,published_at")
    .eq("status", "published")
    .or(`title.ilike.%${term}%,excerpt.ilike.%${term}%,content.ilike.%${term}%`)
    .limit(30);
  if (error || !data) return [];
  return data.map((a) => ({
    id: `article:${a.slug}`,
    type: "article" as const,
    title: a.title,
    subtitle: a.excerpt ?? undefined,
    body: (a.content ?? "").slice(0, 2000),
    keywords: (a.tags ?? []).join(" "),
    to: `/articles/${a.slug}`,
    date: a.published_at ?? undefined,
    meta: "Article",
  }));
}

export async function searchDiscussions(q: string): Promise<SearchDoc[]> {
  const term = safeTerm(q, "discussion-search");
  if (!term) return [];
  const { data, error } = await supabase
    .from("community_posts")
    .select("id,title,body,category,created_at,author_name")
    .eq("is_hidden", false)
    .or(`title.ilike.%${term}%,body.ilike.%${term}%`)
    .limit(30);
  if (error || !data) return [];
  return data.map((p) => ({
    id: `discussion:${p.id}`,
    type: "discussion" as const,
    title: p.title,
    body: p.body,
    subtitle: p.author_name ?? "Member",
    keywords: `discussion forum ${p.category}`,
    to: `/discussions/${p.id}`,
    date: p.created_at,
    meta: p.category,
  }));
}

interface QuranMatch {
  numberInSurah: number;
  text: string;
  surah: { number: number; englishName: string; name: string };
}

export async function searchQuran(q: string): Promise<SearchDoc[]> {
  const term = q.trim();
  if (term.length < 3) return [];
  try {
    const res = await fetch(
      `https://api.alquran.cloud/v1/search/${encodeURIComponent(term)}/all/en.asad`,
    );
    if (!res.ok) return [];
    const json = (await res.json()) as { data?: { matches?: QuranMatch[] } };
    const matches = json.data?.matches ?? [];
    return matches.slice(0, 40).map((m) => ({
      id: `quran:${m.surah.number}:${m.numberInSurah}`,
      type: "quran" as const,
      title: `Surah ${m.surah.englishName} ${m.surah.number}:${m.numberInSurah}`,
      arabic: m.surah.name,
      body: m.text,
      keywords: `quran ayah verse ${m.surah.englishName}`,
      to: `/quran/${m.surah.number}`,
      meta: `Qur'an ${m.surah.number}:${m.numberInSurah}`,
    }));
  } catch {
    return [];
  }
}