import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { guardSearchTerm, type SearchGuardSource } from "./search-guard";

const ReportInput = z.object({
  source: z.enum(["site-search", "discussion-search", "mcp-search-articles"]),
  raw: z.string().max(2000),
});

/**
 * Called from the browser when the search UI detects an input that had to be
 * sanitized. The server re-runs the guard so a spoofed client can't fabricate
 * arbitrary event content.
 */
export const reportSuspiciousSearch = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => ReportInput.parse(data))
  .handler(async ({ data }) => {
    const guard = guardSearchTerm(data.raw);
    if (!guard.suspicious) return { logged: false };
    const { recordSuspiciousSearch } = await import("./security-events.server");
    await recordSuspiciousSearch(data.source as SearchGuardSource, data.raw, guard);
    return { logged: true };
  });
