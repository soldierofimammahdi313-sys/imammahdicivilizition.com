/**
 * Server-only multi-provider text generation with smart fallback.
 *
 * Every call now goes through the centralized key pool (ai-pool.server.ts):
 * all configured OpenAI / Gemini keys are detected automatically, tried in
 * round-robin order, and any key that hits a rate limit, quota or temporary
 * error is parked on a cooldown while the next healthy key takes over.
 * Key values never appear in errors, logs or responses.
 */

import {
  keysFor,
  markFailure,
  markSuccess,
  scrub,
  isRetryableStatus,
  type AiKey,
} from "./ai-pool.server";

export type AiCallResult = {
  text: string;
  provider: "openai" | "gemini";
};

export class AiUnavailableError extends Error {
  readonly quota: boolean;
  constructor(message: string, quota: boolean) {
    super(scrub(message));
    this.name = "AiUnavailableError";
    this.quota = quota;
  }
}

type CallOptions = {
  system?: string;
  json?: boolean;
  /** Prefer gemini first (research / multimodal tasks). */
  prefer?: "openai" | "gemini";
  /** Max keys to try per vendor. */
  maxAttempts?: number;
};

class ProviderError extends Error {
  readonly status: number;
  constructor(message: string, status: number) {
    super(scrub(message));
    this.status = status;
  }
}

async function openAiRequest(key: AiKey, prompt: string, opts: CallOptions): Promise<string> {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key.value}` },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      stream: false,
      ...(opts.json ? { response_format: { type: "json_object" } } : {}),
      messages: [
        ...(opts.system ? [{ role: "system", content: opts.system }] : []),
        { role: "user", content: prompt },
      ],
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new ProviderError(`OpenAI ${res.status}: ${body.slice(0, 200)}`, res.status);
  }
  const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = json.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) throw new ProviderError("OpenAI returned empty text", 500);
  return text;
}

async function geminiRequest(key: AiKey, prompt: string, opts: CallOptions): Promise<string> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${encodeURIComponent(key.value)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...(opts.system ? { systemInstruction: { parts: [{ text: opts.system }] } } : {}),
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: opts.json ? { responseMimeType: "application/json" } : {},
      }),
    },
  );

  if (!res.ok) {
    const body = await res.text();
    throw new ProviderError(`Gemini ${res.status}: ${body.slice(0, 200)}`, res.status);
  }
  const json = (await res.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  const text = (json.candidates?.[0]?.content?.parts ?? [])
    .map((p) => p.text ?? "")
    .join("")
    .trim();
  if (!text) throw new ProviderError("Gemini returned empty text", 500);
  return text;
}

/** Tries every healthy key of one vendor, in round-robin order. */
async function callVendor(
  vendor: "openai" | "gemini",
  prompt: string,
  opts: CallOptions,
  errors: string[],
): Promise<string | null> {
  const keys = keysFor(vendor).slice(0, opts.maxAttempts ?? 4);
  if (keys.length === 0) {
    errors.push(`${vendor}: no API key configured`);
    return null;
  }
  for (const key of keys) {
    try {
      const text = vendor === "openai"
        ? await openAiRequest(key, prompt, opts)
        : await geminiRequest(key, prompt, opts);
      markSuccess(key);
      return text;
    } catch (err) {
      const status = err instanceof ProviderError ? err.status : 0;
      markFailure(key, status || undefined);
      errors.push(scrub(err instanceof Error ? err.message : String(err)));
      // Non-retryable request errors (e.g. 400 bad request) won't be fixed by
      // another key — stop trying this vendor.
      if (status && !isRetryableStatus(status) && status !== 401 && status !== 403) break;
    }
  }
  return null;
}

/** Calls the preferred provider and falls back to the other one on failure. */
export async function callAi(prompt: string, opts: CallOptions = {}): Promise<AiCallResult> {
  const order: Array<"openai" | "gemini"> =
    opts.prefer === "gemini" ? ["gemini", "openai"] : ["openai", "gemini"];

  const errors: string[] = [];
  for (const provider of order) {
    const text = await callVendor(provider, prompt, opts, errors);
    if (text) return { text, provider };
  }

  const joined = errors.join(" | ");
  const quota = /429|402|quota|rate.?limit|insufficient/i.test(joined);
  throw new AiUnavailableError(`All AI keys failed — ${joined}`, quota);
}

/** Parses a JSON object out of a model reply, tolerating code fences. */
export function parseJsonReply<T>(raw: string): T {
  const cleaned = raw.replace(/```json|```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  const slice = start >= 0 && end > start ? cleaned.slice(start, end + 1) : cleaned;
  return JSON.parse(slice) as T;
}
