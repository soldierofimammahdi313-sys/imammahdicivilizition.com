/**
 * Universal Fiqh (school of Islamic jurisprudence) preference system.
 *
 * The site serves Muslims of every school. A visitor picks one tradition once;
 * the choice is kept in localStorage under `imc_fiqh` and is used to order and
 * filter scholarly material. Nothing is ever hidden because of the choice —
 * "General / All Fiqh" material is always shown, and the visitor can switch
 * tradition at any time from the header.
 *
 * Nothing in this file states a legal ruling. The descriptions are short,
 * factual introductions to each school; rulings must be taken from qualified
 * scholars of that school.
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type FiqhId = "general" | "hanafi" | "shafii" | "maliki" | "hanbali" | "jafari";

/** localStorage key holding the visitor's chosen school. */
export const FIQH_STORAGE_KEY = "imc_fiqh";

export const FIQH_IDS: FiqhId[] = ["general", "hanafi", "shafii", "maliki", "hanbali", "jafari"];

export type FiqhSchool = {
  id: FiqhId;
  /** URL segment used by /fiqh/$school. */
  slug: string;
  /** Short display names. */
  name: { en: string; ur: string; ar: string };
  /** One-line summary shown on cards and in the preference modal. */
  tagline: { en: string; ur: string; ar: string };
  /** Named after / attributed to — left empty for the general category. */
  attributedTo: string | null;
  /** Era of the scholar the school is named after. */
  era: string | null;
  /** Regions where the school is widely followed today. */
  regions: string[];
  /** Two or three factual paragraphs. No rulings, no invented citations. */
  about: string[];
  /** Internal destinations that are genuinely relevant. */
  related: { label: string; to: string }[];
};

export const FIQH_SCHOOLS: FiqhSchool[] = [
  {
    id: "general",
    slug: "general",
    name: { en: "General / All Fiqh", ur: "عمومی / تمام فقہ", ar: "عام / كل المذاهب" },
    tagline: {
      en: "Material shared across the schools, and anything not tied to one tradition.",
      ur: "وہ مواد جو تمام مکاتبِ فکر میں مشترک ہے، اور جو کسی ایک روایت سے مخصوص نہیں۔",
      ar: "المواد المشتركة بين المذاهب، وكل ما ليس خاصًا بمذهب واحد.",
    },
    attributedTo: null,
    era: null,
    regions: [],
    about: [
      "This is the default view of the archive. It shows the Qur'an, hadith collections, history, language and reference material that Muslims study in common, together with every item whose school of jurisprudence is not recorded.",
      "Choosing a school does not remove anything: general material stays visible whichever tradition you select, and you can switch or return to this view at any time from Language & Fiqh in the header.",
      "Where the school of a text is not documented in our catalogue, it is listed here as General / Unclassified rather than being assigned to a tradition by guesswork.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Islamic Library", to: "/library" },
    ],
  },
  {
    id: "hanafi",
    slug: "hanafi",
    name: { en: "Hanafi", ur: "حنفی", ar: "الحنفي" },
    tagline: {
      en: "The school associated with Abu Hanifa al-Nu'man ibn Thabit of Kufa.",
      ur: "کوفہ کے ابو حنیفہ نعمان بن ثابت سے منسوب مکتبِ فکر۔",
      ar: "المذهب المنسوب إلى أبي حنيفة النعمان بن ثابت الكوفي.",
    },
    attributedTo: "Abu Hanifa al-Nu'man ibn Thabit",
    era: "d. 150 AH / 767 CE",
    regions: ["South Asia", "Turkey", "Central Asia", "the Balkans", "parts of the Levant and Egypt"],
    about: [
      "The Hanafi school takes its name from Abu Hanifa al-Nu'man ibn Thabit (d. 150 AH / 767 CE), who taught in Kufa. Much of what survives of his legal reasoning reaches us through his students, among them Abu Yusuf and Muhammad al-Shaybani, who wrote the early works of the school.",
      "It is, by population, the most widely followed school of Sunni jurisprudence today, long established in South Asia, Turkey, Central Asia and the Balkans.",
      "For rulings, consult a qualified scholar of the school. The material collected here is introductory and historical; it is not a fatwa.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Islamic Library", to: "/library" },
      { label: "Research & Articles", to: "/articles" },
    ],
  },
  {
    id: "shafii",
    slug: "shafii",
    name: { en: "Shafi'i", ur: "شافعی", ar: "الشافعي" },
    tagline: {
      en: "The school associated with Muhammad ibn Idris al-Shafi'i.",
      ur: "محمد بن ادریس الشافعی سے منسوب مکتبِ فکر۔",
      ar: "المذهب المنسوب إلى محمد بن إدريس الشافعي.",
    },
    attributedTo: "Muhammad ibn Idris al-Shafi'i",
    era: "d. 204 AH / 820 CE",
    regions: ["East Africa", "southern Arabia", "Southeast Asia", "parts of Egypt", "Kurdistan"],
    about: [
      "The Shafi'i school is named after Muhammad ibn Idris al-Shafi'i (d. 204 AH / 820 CE), who studied in Madina and later taught in Iraq and Egypt.",
      "He is remembered above all for al-Risala, an early systematic treatment of usul al-fiqh — the principles by which sources of law are identified, weighed and applied.",
      "For rulings, consult a qualified scholar of the school. The material collected here is introductory and historical; it is not a fatwa.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Islamic Library", to: "/library" },
      { label: "Research & Articles", to: "/articles" },
    ],
  },
  {
    id: "maliki",
    slug: "maliki",
    name: { en: "Maliki", ur: "مالکی", ar: "المالكي" },
    tagline: {
      en: "The school associated with Malik ibn Anas of Madina.",
      ur: "مدینہ کے مالک بن انس سے منسوب مکتبِ فکر۔",
      ar: "المذهب المنسوب إلى مالك بن أنس المدني.",
    },
    attributedTo: "Malik ibn Anas",
    era: "d. 179 AH / 795 CE",
    regions: ["North Africa", "West Africa", "parts of the Gulf and Upper Egypt"],
    about: [
      "The Maliki school is named after Malik ibn Anas (d. 179 AH / 795 CE), who spent his life teaching in Madina.",
      "His al-Muwatta is among the earliest surviving compilations of hadith and legal practice, and the school is known for the weight it gives to the settled practice of the people of Madina.",
      "For rulings, consult a qualified scholar of the school. The material collected here is introductory and historical; it is not a fatwa.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Islamic Library", to: "/library" },
      { label: "Research & Articles", to: "/articles" },
    ],
  },
  {
    id: "hanbali",
    slug: "hanbali",
    name: { en: "Hanbali", ur: "حنبلی", ar: "الحنبلي" },
    tagline: {
      en: "The school associated with Ahmad ibn Hanbal of Baghdad.",
      ur: "بغداد کے احمد بن حنبل سے منسوب مکتبِ فکر۔",
      ar: "المذهب المنسوب إلى أحمد بن حنبل البغدادي.",
    },
    attributedTo: "Ahmad ibn Hanbal",
    era: "d. 241 AH / 855 CE",
    regions: ["the Arabian Peninsula", "parts of the Levant and Iraq"],
    about: [
      "The Hanbali school is named after Ahmad ibn Hanbal (d. 241 AH / 855 CE), a traditionist and jurist of Baghdad.",
      "He is known first as a collector of hadith — his Musnad is one of the large early collections — and the school that carries his name is associated with close adherence to transmitted texts.",
      "For rulings, consult a qualified scholar of the school. The material collected here is introductory and historical; it is not a fatwa.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Islamic Library", to: "/library" },
      { label: "Research & Articles", to: "/articles" },
    ],
  },
  {
    id: "jafari",
    slug: "jafari",
    name: { en: "Ja'fari", ur: "جعفری", ar: "الجعفري" },
    tagline: {
      en: "The school associated with Imam Ja'far al-Sadiq (a.s.).",
      ur: "امام جعفر صادق علیہ السلام سے منسوب مکتبِ فکر۔",
      ar: "المذهب المنسوب إلى الإمام جعفر الصادق عليه السلام.",
    },
    attributedTo: "Imam Ja'far ibn Muhammad al-Sadiq (a.s.)",
    era: "d. 148 AH / 765 CE",
    regions: ["Iran", "Iraq", "parts of South Asia", "Lebanon", "the Gulf", "Azerbaijan"],
    about: [
      "The Ja'fari school takes its name from Imam Ja'far ibn Muhammad al-Sadiq (a.s.) (d. 148 AH / 765 CE), whose circle in Madina taught a generation of students in law, hadith and theology.",
      "Its hadith literature centres on the Four Books — al-Kafi, Man la Yahduruhu al-Faqih, Tahdhib al-Ahkam and al-Istibsar — and the school is distinguished by the continuing role of ijtihad in every generation.",
      "This platform's existing Ja'fari, Ahl al-Bayt, Karbala and Imam Mahdi material is preserved in full and is gathered under this heading as well as under its own sections.",
      "For rulings, consult a qualified scholar of the school. The material collected here is introductory and historical; it is not a fatwa.",
    ],
    related: [
      { label: "Qur'an", to: "/quran" },
      { label: "Hadith", to: "/hadith" },
      { label: "Tafsir al-Mizan", to: "/tafsir-al-mizan" },
      { label: "Who is Imam Mahdi", to: "/who-is-imam-mahdi" },
      { label: "Islamic Library", to: "/library" },
    ],
  },
];

export const DEFAULT_FIQH: FiqhId = "general";

export function isFiqhId(value: unknown): value is FiqhId {
  return typeof value === "string" && (FIQH_IDS as string[]).includes(value);
}

export function fiqhBySlug(slug: string): FiqhSchool | undefined {
  return FIQH_SCHOOLS.find((s) => s.slug === slug.toLowerCase());
}

export function fiqhById(id: FiqhId): FiqhSchool {
  return FIQH_SCHOOLS.find((s) => s.id === id) ?? FIQH_SCHOOLS[0];
}

/** Display name for a school in the active interface language. */
export function fiqhName(school: FiqhSchool, lang: string): string {
  if (lang === "ur") return school.name.ur;
  if (lang === "ar" || lang === "fa") return school.name.ar;
  return school.name.en;
}

export function fiqhTagline(school: FiqhSchool, lang: string): string {
  if (lang === "ur") return school.tagline.ur;
  if (lang === "ar" || lang === "fa") return school.tagline.ar;
  return school.tagline.en;
}

/** Reads the stored preference, ignoring anything corrupted or unknown. */
export function readStoredFiqh(): FiqhId | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(FIQH_STORAGE_KEY);
    if (!raw) return null;
    const value = raw.trim().toLowerCase();
    return isFiqhId(value) ? value : null;
  } catch {
    return null;
  }
}

export function writeStoredFiqh(id: FiqhId): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(FIQH_STORAGE_KEY, id);
  } catch {
    /* storage unavailable — the preference simply does not persist */
  }
}

/**
 * Does an item belong in the current view?
 * General material is always visible, and selecting "general" shows everything.
 */
export function matchesFiqh(itemTraditions: readonly FiqhId[] | null | undefined, selected: FiqhId): boolean {
  if (selected === "general") return true;
  if (!itemTraditions || itemTraditions.length === 0) return true;
  return itemTraditions.includes(selected) || itemTraditions.includes("general");
}

type FiqhCtx = {
  fiqh: FiqhId;
  setFiqh: (id: FiqhId) => void;
  /** False until the stored value has been read on the client. */
  ready: boolean;
  /** True when the visitor has never made a choice. */
  unset: boolean;
  school: FiqhSchool;
};

const FiqhContext = createContext<FiqhCtx | null>(null);

export function FiqhProvider({ children }: { children: ReactNode }) {
  const [fiqh, setFiqhState] = useState<FiqhId>(DEFAULT_FIQH);
  const [ready, setReady] = useState(false);
  const [unset, setUnset] = useState(true);

  useEffect(() => {
    const stored = readStoredFiqh();
    if (stored) {
      setFiqhState(stored);
      setUnset(false);
    }
    setReady(true);
  }, []);

  const setFiqh = useCallback((id: FiqhId) => {
    const safe = isFiqhId(id) ? id : DEFAULT_FIQH;
    setFiqhState(safe);
    setUnset(false);
    writeStoredFiqh(safe);
  }, []);

  const value = useMemo<FiqhCtx>(
    () => ({ fiqh, setFiqh, ready, unset, school: fiqhById(fiqh) }),
    [fiqh, setFiqh, ready, unset],
  );

  return <FiqhContext.Provider value={value}>{children}</FiqhContext.Provider>;
}

/** Safe outside the provider too, so no component can crash for lack of context. */
export function useFiqh(): FiqhCtx {
  const ctx = useContext(FiqhContext);
  if (!ctx) {
    return {
      fiqh: DEFAULT_FIQH,
      setFiqh: () => {},
      ready: false,
      unset: true,
      school: fiqhById(DEFAULT_FIQH),
    };
  }
  return ctx;
}
