import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  mode: z.enum(["summary", "ask", "explain", "translate"]),
  title: z.string().max(300).optional(),
  text: z.string().min(1).max(12000),
  question: z.string().max(600).optional(),
  lang: z.string().max(40).optional(),
});

const SYSTEM = `You are the study assistant of "Imam Mahdi Civilization", a Twelver Shia (Fiqh Ja'fariya) Islamic knowledge platform.
Rules:
- NEVER invent Quran verses, hadith, narrations or attributions. Only use what the provided source text contains, or clearly say "not stated in this text".
- Be respectful of all Muslims; no takfir, no sectarian insults.
- Reverence for the Ahl al-Bayt (a.s) and the Prophet (s).
- Answer in clean, short Markdown. Keep it tight and useful.`;

function buildPrompt(data: z.infer<typeof Input>): string {
  const source = `SOURCE TITLE: ${data.title ?? "(untitled)"}\n\nSOURCE TEXT:\n"""\n${data.text}\n"""`;
  switch (data.mode) {
    case "summary":
      return `${source}\n\nTask: Give a 5-point bullet summary of the source text, then one line "Key takeaway: ...". Max 160 words.`;
    case "ask":
      return `${source}\n\nReader's question: ${data.question ?? "Explain the main idea."}\n\nTask: Answer ONLY from the source text above. If the answer is not in the text, say so briefly and give general Ja'fari guidance in one sentence. Max 180 words.`;
    case "explain":
      return `${source}\n\nTask: Explain this Quranic verse / hadith simply: (1) plain meaning, (2) context if the text states it, (3) one practical lesson for daily life, following the Ja'fari (Ahl al-Bayt) understanding. Do not add any narration that is not in the source text. Max 170 words.`;
    case "translate":
      return `${source}\n\nTask: Translate the source text faithfully into ${data.lang ?? "Urdu"}. Preserve Arabic quotations as-is, translate everything else. Output only the translation.`;
  }
}

export type AiAssistResult = { text: string; provider?: string; error?: string };

export const aiAssist = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data }): Promise<AiAssistResult> => {
    const { ask } = await import("./aiService");
    try {
      const res = await ask(buildPrompt(data), { system: SYSTEM, prefer: "gemini" });
      return { text: res.text, provider: res.provider };
    } catch (err) {
      return {
        text: "",
        error:
          err instanceof Error && /quota|429|402/i.test(err.message)
            ? "AI is busy or out of quota right now. Please try again in a moment."
            : "AI could not answer this time. Please try again.",
      };
    }
  });
