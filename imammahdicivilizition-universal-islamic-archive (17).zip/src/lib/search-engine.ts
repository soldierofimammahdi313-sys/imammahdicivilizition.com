/**
 * Ranking engine for the advanced global search.
 * Pure functions — no I/O — so it can run on any corpus (local or remote).
 */

export type SearchType =
  | "page"
  | "article"
  | "book"
  | "video"
  | "quran"
  | "hadith"
  | "discussion";

export interface SearchDoc {
  id: string;
  type: SearchType;
  title: string;
  arabic?: string;
  subtitle?: string;
  body?: string;
  keywords?: string;
  /** Internal route */
  to?: string;
  /** External link */
  href?: string;
  /** ISO date, used for recency ranking */
  date?: string;
  meta?: string;
}

export interface ScoredDoc extends SearchDoc {
  score: number;
}

export const TYPE_LABELS: Record<SearchType, string> = {
  page: "Pages & Tools",
  article: "Articles",
  book: "Books",
  video: "Videos",
  quran: "Quran",
  hadith: "Hadith",
  discussion: "Discussions",
};

export const SEARCH_TYPES: SearchType[] = [
  "article",
  "quran",
  "hadith",
  "book",
  "video",
  "discussion",
  "page",
];

/** Slight preference between equally-matching sources. */
const TYPE_WEIGHT: Record<SearchType, number> = {
  quran: 1.25,
  hadith: 1.2,
  article: 1.15,
  page: 1.1,
  discussion: 1.0,
  book: 1.0,
  video: 0.95,
};

const DIACRITICS = /[\u064B-\u065F\u0670\u06D6-\u06ED\u0300-\u036f]/g;

export function normalize(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFD")
    .replace(DIACRITICS, "")
    .replace(/[إأآا]/g, "ا")
    .replace(/[ىي]/g, "ی")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenize(query: string): string[] {
  return normalize(query)
    .split(" ")
    .filter((t) => t.length > 0);
}

function fieldScore(field: string | undefined, tokens: string[], weight: number): number {
  if (!field) return 0;
  const hay = normalize(field);
  if (!hay) return 0;
  const words = hay.split(" ");
  let score = 0;
  for (const token of tokens) {
    if (words.includes(token)) score += weight;
    else if (words.some((w) => w.startsWith(token))) score += weight * 0.6;
    else if (hay.includes(token)) score += weight * 0.3;
  }
  return score;
}

function recencyBoost(date?: string): number {
  if (!date) return 0;
  const ts = Date.parse(date);
  if (Number.isNaN(ts)) return 0;
  const days = (Date.now() - ts) / 86_400_000;
  if (days < 7) return 3;
  if (days < 30) return 2;
  if (days < 120) return 1;
  return 0;
}

export function scoreDoc(doc: SearchDoc, query: string): number {
  const tokens = tokenize(query);
  if (tokens.length === 0) return 0;

  let score = 0;
  score += fieldScore(doc.title, tokens, 6);
  score += fieldScore(doc.arabic, tokens, 5);
  score += fieldScore(doc.subtitle, tokens, 3);
  score += fieldScore(doc.keywords, tokens, 2.5);
  score += fieldScore(doc.body, tokens, 1);

  if (score === 0) return 0;

  const phrase = normalize(query);
  const title = normalize(doc.title);
  if (title === phrase) score += 14;
  else if (title.startsWith(phrase)) score += 7;
  else if (title.includes(phrase)) score += 4;
  if (doc.body && normalize(doc.body).includes(phrase)) score += 2;

  /* every token matched somewhere → strong signal */
  const covered = tokens.filter((t) =>
    normalize(
      `${doc.title} ${doc.arabic ?? ""} ${doc.subtitle ?? ""} ${doc.keywords ?? ""} ${doc.body ?? ""}`,
    ).includes(t),
  ).length;
  score += (covered / tokens.length) * 4;

  score *= TYPE_WEIGHT[doc.type];
  score += recencyBoost(doc.date);
  return score;
}

export function rank(docs: SearchDoc[], query: string, limit = 200): ScoredDoc[] {
  if (!query.trim()) return [];
  return docs
    .map((d) => ({ ...d, score: scoreDoc(d, query) }))
    .filter((d) => d.score > 0)
    .sort((a, b) => b.score - a.score || a.title.localeCompare(b.title))
    .slice(0, limit);
}

/** Splits text into fragments so matched terms can be highlighted. */
export function highlight(text: string, query: string): { text: string; hit: boolean }[] {
  const tokens = Array.from(new Set(tokenize(query))).filter((t) => t.length > 1);
  if (tokens.length === 0) return [{ text, hit: false }];
  const escaped = tokens.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const re = new RegExp(`(${escaped.join("|")})`, "gi");
  return text
    .split(re)
    .filter((part) => part !== "")
    .map((part) => ({ text: part, hit: re.test(part) && tokens.includes(normalize(part)) }));
}

/** Trims a long body down to a window around the first match. */
export function snippet(body: string, query: string, size = 220): string {
  const clean = body.replace(/\s+/g, " ").trim();
  const tokens = tokenize(query);
  const hay = clean.toLowerCase();
  let idx = -1;
  for (const t of tokens) {
    const found = hay.indexOf(t);
    if (found !== -1 && (idx === -1 || found < idx)) idx = found;
  }
  if (idx === -1) return clean.slice(0, size) + (clean.length > size ? "…" : "");
  const start = Math.max(0, idx - Math.floor(size / 3));
  const end = Math.min(clean.length, start + size);
  return `${start > 0 ? "…" : ""}${clean.slice(start, end)}${end < clean.length ? "…" : ""}`;
}