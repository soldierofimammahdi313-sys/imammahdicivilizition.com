/**
 * Shared static catalogues (books, video collections, channels).
 * Consumed by the Library / Video routes AND the global search engine so both
 * always stay in sync.
 */
export type CatalogBook = { t: string; a: string; u: string };

export const BOOKS: CatalogBook[] = [
  { t: "The Holy Qur'an", a: "Tanzil — multiple translations", u: "https://tanzil.net/" },
  { t: "Nahj al-Balagha", a: "Imam Ali (a.s.)", u: "https://www.al-islam.org/nahjul-balagha-part-1-sermons" },
  { t: "Sahifa al-Sajjadiyya", a: "Imam Zayn al-ʿAbidin (a.s.)", u: "https://www.al-islam.org/al-sahifa-al-kamilah-al-sajjadiyya" },
  { t: "Sahih al-Bukhari", a: "Imam al-Bukhari", u: "https://sunnah.com/bukhari" },
  { t: "Sahih Muslim", a: "Imam Muslim", u: "https://sunnah.com/muslim" },
  { t: "Al-Kafi", a: "Shaykh al-Kulayni", u: "https://thaqalayn.net/" },
  { t: "Bihar al-Anwar", a: "Allamah al-Majlisi", u: "https://thaqalayn.net/" },
  { t: "Man La Yahduruhu al-Faqih", a: "Shaykh al-Saduq", u: "https://thaqalayn.net/" },
  { t: "Tahdhib al-Ahkam", a: "Shaykh al-Tusi", u: "https://thaqalayn.net/" },
  { t: "Tafsir al-Mizan", a: "Allamah Tabatabai", u: "https://almizan.org/" },
  { t: "Mafatih al-Jinan", a: "Shaykh Abbas al-Qummi", u: "https://www.duas.org/mafatih.htm" },
  { t: "Peak of Eloquence (English)", a: "Imam Ali (a.s.)", u: "https://www.al-islam.org/peak-eloquence-nahjul-balagha-imam-ali-ibn-abi-talib" },
  { t: "Kitab al-Irshad", a: "Shaykh al-Mufid", u: "https://www.al-islam.org/kitab-al-irshad-shaykh-al-mufid" },
  { t: "Usul al-Kafi (English)", a: "al-Kulayni", u: "https://www.al-islam.org/al-kafi" },
  { t: "Al-Islam.org Library", a: "10,000+ books online", u: "https://www.al-islam.org/library" },
  { t: "Quran.com — Modern Reader", a: "All translations & tafsirs", u: "https://quran.com/" },
];

export type CatalogCollection = { t: string; a: string; q: string; c: string };

export const VIDEO_COLLECTIONS: readonly CatalogCollection[] = [
  { t: "Tafsir & Quran", a: "تفسير", q: "tafsir quran lecture", c: "Verse-by-verse exegesis from leading scholars." },
  { t: "Nahj al-Balagha", a: "نهج البلاغة", q: "nahj al balagha lecture", c: "Wisdom & sermons of Imam Ali (a.s.)." },
  { t: "Sirah of the Prophet ﷺ", a: "سيرة", q: "seerah prophet muhammad lecture", c: "Life & mission of Rasul Allah ﷺ." },
  { t: "Lives of the Imams (a.s.)", a: "أئمة", q: "twelve imams lecture", c: "The 14 Infallibles, narrated." },
  { t: "Imam Mahdi (a.t.f.s.)", a: "المهدي", q: "imam mahdi awaited", c: "The Awaited Saviour — proofs, signs, duties." },
  { t: "Ahkam & Fiqh", a: "فقه", q: "islamic fiqh ruling lecture", c: "Practical rulings of daily life." },
  { t: "Akhlaq & Spirituality", a: "أخلاق", q: "islamic akhlaq spirituality lecture", c: "Self-purification & nearness to Allah." },
  { t: "Quran Recitation", a: "قرآن", q: "best quran recitation", c: "Masters of tilawah, beautifully recited." },
  { t: "Marsiya & Noha", a: "مرثية", q: "marsiya noha karbala", c: "Elegies of Karbala in many languages." },
  { t: "Documentaries", a: "وثائقي", q: "islamic history documentary", c: "Cinematic journeys across Islamic history." },
  { t: "English Lectures", a: "إنجليزي", q: "english islamic lecture shia", c: "Top English-language Islamic talks." },
  { t: "Urdu Lectures", a: "اردو", q: "urdu islamic lecture", c: "Majalis & dars in Urdu." },
] as const;

export const VIDEO_CHANNELS = [
  { n: "Imam Mahdi Civilization", u: "https://youtube.com/@imammahdicivilization" },
  { n: "Sayed Ammar Nakshawani", u: "https://www.youtube.com/@SayedAmmarNakshawani" },
  { n: "Sayed Mahdi al-Modarresi", u: "https://www.youtube.com/@SayedModarresi" },
  { n: "Sheikh Usama Abdulghani", u: "https://www.youtube.com/@UsamaAbdulghani" },
  { n: "Hujjat al-Islam Sayed Hashim al-Haidari", u: "https://www.youtube.com/results?search_query=sayed+hashim+al-haidari" },
  { n: "Islamic Pulse", u: "https://www.youtube.com/@IslamicPulse" },
  { n: "AhlulBayt TV", u: "https://www.youtube.com/@AhlulbaytTV" },
  { n: "Velayat TV", u: "https://www.youtube.com/results?search_query=velayat+tv" },
];