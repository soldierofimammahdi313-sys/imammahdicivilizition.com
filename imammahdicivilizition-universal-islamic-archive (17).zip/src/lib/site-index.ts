/**
 * Central, searchable index of every destination on the platform.
 * Used by the global command palette (⌘K) and future sitemap/nav surfaces.
 */
export type SiteEntry = {
  to: string;
  label: string;
  arabic?: string;
  group: string;
  keywords: string;
};

export const SITE_INDEX: SiteEntry[] = [
  // Sacred Knowledge
  { to: "/quran", label: "Quran", arabic: "القرآن", group: "Sacred Knowledge", keywords: "quran koran surah ayah recitation audio translation tilawat قرآن" },
  { to: "/tafsir-al-mizan", label: "Tafsir al-Mizan", arabic: "المیزان", group: "Sacred Knowledge", keywords: "tafsir exegesis mizan tabatabai commentary تفسیر" },
  { to: "/hadith", label: "Hadith Collections", arabic: "الحدیث", group: "Sacred Knowledge", keywords: "hadith narration bukhari muslim sunan ahlulbayt حدیث" },
  { to: "/duas", label: "Duas & Adhkar", arabic: "الادعیة", group: "Sacred Knowledge", keywords: "dua supplication adhkar ziyarat munajat دعا" },
  { to: "/names", label: "99 Names of Allah", arabic: "الأسماء", group: "Sacred Knowledge", keywords: "asma ul husna names allah 99 اسماء" },
  { to: "/articles", label: "Articles", arabic: "المقالات", group: "Sacred Knowledge", keywords: "articles essays research blog writing مقالات" },

  { to: "/library", label: "Islamic Library", arabic: "المکتبة", group: "Sacred Knowledge", keywords: "library archive books manuscripts research documents مکتبة" },

  // Fiqh — schools of Islamic jurisprudence
  { to: "/fiqh", label: "Fiqh — Schools of Jurisprudence", arabic: "الفقه", group: "Fiqh", keywords: "fiqh jurisprudence madhhab school islamic law فقہ الفقه" },
  { to: "/fiqh/general", label: "General / All Fiqh", arabic: "عام", group: "Fiqh", keywords: "general all fiqh shared unclassified عمومی" },
  { to: "/fiqh/hanafi", label: "Hanafi Fiqh", arabic: "الحنفي", group: "Fiqh", keywords: "hanafi abu hanifa fiqh school حنفی الحنفي" },
  { to: "/fiqh/shafii", label: "Shafi'i Fiqh", arabic: "الشافعي", group: "Fiqh", keywords: "shafii shafi al-shafii fiqh school شافعی الشافعي" },
  { to: "/fiqh/maliki", label: "Maliki Fiqh", arabic: "المالكي", group: "Fiqh", keywords: "maliki malik ibn anas muwatta fiqh مالکی المالكي" },
  { to: "/fiqh/hanbali", label: "Hanbali Fiqh", arabic: "الحنبلي", group: "Fiqh", keywords: "hanbali ahmad ibn hanbal musnad fiqh حنبلی الحنبلي" },
  { to: "/fiqh/jafari", label: "Ja'fari Fiqh", arabic: "الجعفري", group: "Fiqh", keywords: "jafari jaafari imam jafar sadiq fiqh جعفری الجعفري" },

  // AI & Academy
  { to: "/ai", label: "N-EYES AI Assistant", arabic: "ن-آيز", group: "AI & Academy", keywords: "ai assistant chat gpt question fiqh jafariya ask" },
  { to: "/academy-ai", label: "Mahdi AI Academy", arabic: "أستاذ مہدی", group: "AI & Academy", keywords: "academy kids tech school ustad classroom parent leaderboard" },
  { to: "/academy", label: "Courses & Academy", arabic: "الأکادیمیة", group: "AI & Academy", keywords: "courses learning certificates tracks study" },
  { to: "/videos", label: "Video Center", arabic: "الفیدیو", group: "AI & Academy", keywords: "videos media lectures streams shorts" },

  // Daily Devotion
  { to: "/daily", label: "Daily Devotion", arabic: "یومي", group: "Daily Devotion", keywords: "daily verse hadith dua prayer times routine" },
  { to: "/qibla", label: "Qibla Compass", arabic: "القبلة", group: "Daily Devotion", keywords: "qibla direction compass kaaba mecca قبلہ" },
  { to: "/tasbih", label: "Digital Tasbih", arabic: "التسبیح", group: "Daily Devotion", keywords: "tasbih dhikr counter zikr beads تسبیح" },
  { to: "/khatam", label: "Khatam Tracker", arabic: "الختم", group: "Daily Devotion", keywords: "khatam quran completion group juz" },
  { to: "/events", label: "Islamic Calendar & Events", arabic: "الفعالیات", group: "Daily Devotion", keywords: "events hijri calendar majalis muharram ramadan dates" },

  // Tools
  { to: "/zakat", label: "Zakat Calculator", arabic: "الزکاة", group: "Tools & Utilities", keywords: "zakat khums calculator wealth charity nisab زکات" },
  { to: "/inheritance", label: "Inheritance (Mirath)", arabic: "المیراث", group: "Tools & Utilities", keywords: "inheritance mirath calculator estate shares fiqh jafari" },
  { to: "/mosques", label: "Mosque Finder", arabic: "المساجد", group: "Tools & Utilities", keywords: "mosque masjid imambargah nearby map" },
  { to: "/realms", label: "The Eight Realms", arabic: "العوالم", group: "Tools & Utilities", keywords: "realms pillars overview map platform" },
  { to: "/modules", label: "Module Grid", arabic: "الوحدات", group: "Tools & Utilities", keywords: "modules grid system ai mufti research simulator maps encyclopedia timeline features roadmap" },
  { to: "/simulator", label: "Civilization Simulator", arabic: "المحاكاة", group: "Tools & Utilities", keywords: "simulator civilization governance policy justice khums nahj al-balagha malik ashtar city" },
  { to: "/media", label: "Media Center", arabic: "الإعلام", group: "Tools & Utilities", keywords: "media podcast audiobook documentary lecture noha latmiyat nasheed audio video" },
  { to: "/isnad", label: "Chain of Narrators (Isnad)", arabic: "الإسناد", group: "Tools & Utilities", keywords: "isnad chain narrators rijal thaqalayn ghadir kisa hadith grading sanad" },
  { to: "/timeline", label: "Islamic History Timeline", arabic: "التاریخ", group: "Tools & Utilities", keywords: "timeline history hijri revelation occultation events chronology" },
  { to: "/battles", label: "Battle Explorer", arabic: "الغزوات", group: "Tools & Utilities", keywords: "battles badr uhud khandaq khaybar siffin karbala war history" },
  { to: "/family-tree", label: "Family Tree of the Infallibles", arabic: "شجرة النسب", group: "Tools & Utilities", keywords: "family tree lineage prophet imams twelve ahlulbayt genealogy" },
  { to: "/flashcards", label: "Flashcards", arabic: "البطاقات", group: "Tools & Utilities", keywords: "flashcards spaced repetition arabic vocabulary hadith fiqh memorise" },
  { to: "/journal", label: "Dua & Reflection Journal", arabic: "المذكرات", group: "Tools & Utilities", keywords: "journal dua supplication reflection tadabbur notes answered private" },
  { to: "/citation", label: "Citation Generator", arabic: "المراجع", group: "Tools & Utilities", keywords: "citation reference apa mla chicago hawza bibliography quran hadith" },
  { to: "/maps", label: "Sacred Maps", arabic: "الخرائط", group: "Tools & Utilities", keywords: "maps karbala makkah madinah najaf samarra ziyarat pilgrimage shrine" },

  // Account & Community
  { to: "/discussions", label: "Discussions", arabic: "المجلس", group: "Community & Account", keywords: "discussions forum community majlis questions posts replies" },
  { to: "/bookmarks", label: "My Bookmarks", arabic: "المحفوظات", group: "Community & Account", keywords: "bookmarks saved library favourites collection" },
  { to: "/history", label: "Reading History", arabic: "السجل", group: "Community & Account", keywords: "history recent reading continue progress" },
  { to: "/settings", label: "Settings", arabic: "الإعدادات", group: "Community & Account", keywords: "settings profile preferences language notifications account" },
  { to: "/admin", label: "Admin Console", arabic: "الإدارة", group: "Community & Account", keywords: "admin moderation reports applications console" },

  // Community & Account
  { to: "/community", label: "Global Community", arabic: "المجتمع", group: "Community", keywords: "community forum study circles hubs network" },
  { to: "/about", label: "About the Civilization", arabic: "حول", group: "Community", keywords: "about mission vision founders principles" },
  { to: "/join", label: "Join Imam Mahdi Civilization", arabic: "انضم", group: "Community", keywords: "join apply team recruitment volunteer writer developer" },
  { to: "/donate", label: "Donate / Sadaqah", arabic: "تبرع", group: "Community", keywords: "donate sadaqah khums support contribute fund" },
  { to: "/dashboard", label: "My Dashboard", group: "Account", keywords: "dashboard profile xp rank saved bookmarks account" },
  { to: "/auth", label: "Sign In", arabic: "دخول", group: "Account", keywords: "sign in login register account google email" },
  { to: "/search", label: "Advanced Search", arabic: "بحث", group: "Community & Account", keywords: "search find filter ranking quran hadith articles books videos discussions" },
  { to: "/privacy", label: "Privacy Policy", group: "Legal", keywords: "privacy policy data gdpr" },
  { to: "/terms", label: "Terms of Service", group: "Legal", keywords: "terms conditions service legal" },
];

export const SITE_GROUPS = Array.from(new Set(SITE_INDEX.map((e) => e.group)));
