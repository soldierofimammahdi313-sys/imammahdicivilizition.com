/**
 * Master registry of every module of the digital civilization.
 * `to` points at a live route; modules without `to` are on the build queue.
 */
export type Module = {
  name: string;
  arabic?: string;
  desc: string;
  to?: string;
  status: "live" | "beta" | "queued";
};

export type ModuleGroup = {
  code: string;
  title: string;
  arabic: string;
  blurb: string;
  modules: Module[];
};

const ALL_MODULE_GROUPS: ModuleGroup[] = [
  {
    code: "01",
    title: "AI Intelligence",
    arabic: "الذکاء",
    blurb: "Reasoning engines trained to answer with sources, not guesses.",
    modules: [
      { name: "AI Mufti Assistant", arabic: "المفتي", desc: "Fiqh Ja'fariya answers with citation of source (حوالہ کے ساتھ).", to: "/ai", status: "beta" },
      { name: "AI Quran Research", arabic: "بحث القرآن", desc: "Thematic verse discovery across all 114 surahs.", to: "/quran", status: "beta" },
      { name: "AI Hadith Research", arabic: "بحث الحدیث", desc: "Narration lookup across the major collections.", to: "/hadith", status: "beta" },
      { name: "AI Tafsir Explorer", arabic: "التفسیر", desc: "Al-Mizan and nine tafasir, side by side.", to: "/tafsir-al-mizan", status: "beta" },
      { name: "AI Islamic Timeline", desc: "Ask any year, get the events that shaped it.", to: "/ai-tools/timeline", status: "live" },
      { name: "AI Debate Analyzer", desc: "Break an argument into claims, evidence and fallacies.", to: "/ai-tools/debate", status: "live" },
      { name: "AI Fatwa Finder", desc: "Locate rulings by marja and topic.", to: "/ai-tools/fatwa", status: "live" },
      { name: "AI Arabic Grammar Assistant", desc: "I'rab, morphology and root analysis.", to: "/ai-tools/grammar", status: "live" },
      { name: "AI Translation Engine", desc: "Seven languages, live across the whole platform.", to: "/", status: "live" },
      { name: "AI Voice Teacher", desc: "Recitation coaching with tajwid drills and audio.", to: "/ai-tools/voice", status: "live" },
    ],
  },
  {
    code: "02",
    title: "Knowledge System",
    arabic: "المعرفة",
    blurb: "The encyclopedic memory of the Ummah, made navigable.",
    modules: [
      { name: "Interactive Islamic Encyclopedia", desc: "Cross-linked entries on every concept.", to: "/articles", status: "beta" },
      { name: "Interactive Islamic World Map", desc: "The Ummah across continents and centuries.", status: "queued" },
      { name: "Islamic History Timeline", desc: "From revelation to occultation and beyond.", to: "/timeline", status: "live" },
      { name: "Prophet Family Tree", desc: "The lineage of the Messenger ﷺ.", to: "/family-tree", status: "live" },
      { name: "Imam Family Tree", desc: "The Twelve Imams and their households.", to: "/family-tree", status: "live" },
      { name: "Battle Explorer", desc: "Badr, Uhud, Karbala — terrain, forces, outcome.", to: "/battles", status: "live" },
      { name: "Mosque Explorer", desc: "Find masajid and imambargahs near you.", to: "/mosques", status: "live" },
      { name: "Historical Places Explorer", desc: "Sacred geography, documented.", status: "queued" },
    ],
  },
  {
    code: "03",
    title: "Learning",
    arabic: "التعلیم",
    blurb: "Structured mastery — from first alphabet to advanced fiqh.",
    modules: [
      { name: "AI Learning Academy", desc: "Ustad Mahdi AI teaching global Muslim youth.", to: "/academy-ai", status: "live" },
      { name: "Learning Paths", desc: "Guided tracks with prerequisites.", to: "/academy", status: "beta" },
      { name: "Daily Challenges", desc: "One task a day, streaks and XP.", to: "/daily", status: "beta" },
      { name: "Flashcards", desc: "Spaced repetition for verses and vocabulary.", to: "/flashcards", status: "live" },
      { name: "Interactive Quizzes", desc: "Timed assessments with instant feedback.", to: "/academy-ai", status: "beta" },
      { name: "Achievement System", desc: "Six ranks, XP and badges.", to: "/dashboard", status: "live" },
      { name: "Certificates", desc: "Verifiable completion credentials.", status: "queued" },
      { name: "Study Planner", desc: "Plan the week around salah and study.", status: "queued" },
    ],
  },
  {
    code: "04",
    title: "Community",
    arabic: "المجتمع",
    blurb: "One Ummah, every continent, in conversation.",
    modules: [
      { name: "Discussion Forums", desc: "Threads, replies, likes and moderation.", to: "/discussions", status: "live" },
      { name: "Ask Scholars", desc: "Route questions to verified reviewers.", status: "queued" },
      { name: "Study Groups", desc: "Halaqas with shared reading progress.", to: "/community", status: "beta" },
      { name: "Live Events", desc: "Majalis, lectures and the Hijri calendar.", to: "/events", status: "live" },
      { name: "Community Projects", desc: "Collective builds and translations.", status: "queued" },
      { name: "Volunteer Hub", desc: "Enlist in Imam Mahdi Civilization by skill.", to: "/join", status: "live" },
    ],
  },
  {
    code: "05",
    title: "Personal Dashboard",
    arabic: "لوحتي",
    blurb: "Your worship, measured — quietly, privately.",
    modules: [
      { name: "Daily Islamic Goals", desc: "Tasks that award XP on completion.", to: "/dashboard", status: "live" },
      { name: "Habit Tracker", desc: "Streaks for salah, dhikr and reading.", to: "/dashboard", status: "beta" },
      { name: "Quran Progress", desc: "Khatam tracking across all 30 juz.", to: "/khatam", status: "live" },
      { name: "Dua Journal", desc: "Record supplications and their answers.", to: "/journal", status: "live" },
      { name: "Reflection Journal", desc: "Private tadabbur notes per ayah.", to: "/journal", status: "live" },
      { name: "Reading Statistics", desc: "Everything you have read, over time.", to: "/history", status: "live" },
      { name: "Islamic Calendar Planner", desc: "Plan around the sacred months.", to: "/events", status: "beta" },
    ],
  },
  {
    code: "06",
    title: "Media Center",
    arabic: "الإعلام",
    blurb: "Sound and cinema in service of the message.",
    modules: [
      { name: "Podcast Hub", desc: "Serialized audio programmes.", to: "/media", status: "live" },
      { name: "Islamic Audiobooks", desc: "Narrated classics of the tradition.", to: "/media", status: "live" },
      { name: "Documentary Library", desc: "Long-form visual history.", to: "/media", status: "live" },
      { name: "Noha Library", desc: "Elegies of Karbala.", to: "/media", status: "live" },
      { name: "Nasheed Library", desc: "Devotional song without instruments.", to: "/media", status: "live" },
      { name: "Lecture Archive", desc: "Searchable scholarly talks.", to: "/media", status: "live" },
    ],
  },
  {
    code: "07",
    title: "Smart Tools",
    arabic: "الأدوات",
    blurb: "Utilities that remove friction from research.",
    modules: [
      { name: "Smart OCR & Scanner", desc: "Paste scanned text — AI cleans and searches it.", to: "/ai-tools/summarize", status: "live" },
      { name: "PDF Summarizer", desc: "Condense long treatises to their argument.", to: "/ai-tools/summarize", status: "live" },
      { name: "Citation Generator", desc: "Format references to Qur'an and hadith.", to: "/citation", status: "live" },
      { name: "Smart Bookmark Collections", desc: "Save and group anything on the platform.", to: "/bookmarks", status: "live" },
      { name: "Universal Search", desc: "One ranked index across every source.", to: "/search", status: "live" },
      { name: "Zakat & Khums Calculator", desc: "Fiqh Ja'fariya computation.", to: "/zakat", status: "live" },
      { name: "Inheritance (Mirath)", desc: "Share distribution per Ja'fari law.", to: "/inheritance", status: "live" },
    ],
  },
  {
    code: "08",
    title: "Sacred Maps",
    arabic: "الخرائط",
    blurb: "Walk the holy cities from anywhere on earth.",
    modules: [
      { name: "Karbala Interactive Map", desc: "The plain, the shrines, the events of 61 AH.", to: "/maps", status: "live" },
      { name: "Makkah Interactive Map", desc: "Haram, Safa, Marwa and the rites.", to: "/maps", status: "live" },
      { name: "Madinah Interactive Map", desc: "Masjid al-Nabawi and Baqi.", to: "/maps", status: "live" },
      { name: "Najaf Interactive Map", desc: "Shrine of Amir al-Mu'minin.", to: "/maps", status: "live" },
      { name: "Samarra Interactive Map", desc: "The Askari shrine and the sardab.", to: "/maps", status: "live" },
      { name: "Pilgrimage Guide", desc: "Hajj, Umrah and Ziyarat, step by step.", to: "/maps", status: "live" },
      { name: "Qibla Compass", desc: "Live direction to the Kaaba.", to: "/qibla", status: "live" },
    ],
  },
  {
    code: "09",
    title: "Platform Power",
    arabic: "المنصة",
    blurb: "The infrastructure that makes it feel native.",
    modules: [
      { name: "Offline Mode", desc: "Read and recite without connection.", status: "queued" },
      { name: "Progressive Web App", desc: "Install to home screen on any device.", status: "queued" },
      { name: "Push Notifications", desc: "Prayer, majlis and reply alerts.", to: "/settings", status: "beta" },
      { name: "Multi-language", desc: "Urdu, English, Arabic, Persian and more.", to: "/settings", status: "live" },
      { name: "Dark / Light Mode", desc: "Obsidian night and parchment day.", to: "/settings", status: "live" },
      { name: "Accessibility Mode", desc: "Landmarks, skip links and contrast.", to: "/settings", status: "beta" },
    ],
  },
  {
    code: "10",
    title: "Research",
    arabic: "البحث",
    blurb: "Scholar-grade instruments for serious study.",
    modules: [
      { name: "Compare Tafsir", desc: "Nine commentaries on one ayah.", to: "/quran", status: "beta" },
      { name: "Compare Hadith Sources", desc: "Variant chains and wordings.", to: "/hadith", status: "beta" },
      { name: "Chain of Narrators Viewer", desc: "Visualise the isnad as a graph.", to: "/isnad", status: "live" },
      { name: "Islamic Manuscript Viewer", desc: "High-resolution historic pages.", status: "queued" },
      { name: "Research Workspace", desc: "Collect sources into one project.", status: "queued" },
      { name: "Personal Notes", desc: "Annotate anything, privately.", status: "queued" },
    ],
  },
  {
    code: "11",
    title: "The Singular Idea",
    arabic: "فكرة فريدة",
    blurb: "Something no Islamic platform has ever attempted.",
    modules: [
      {
        name: "AI Islamic Civilization Simulator",
        arabic: "محاكاة الحضارة",
        desc: "Govern a city by Qur'an and the Sunnah of the Ahl al-Bayt. Set policy on justice, zakat, education and defence — the simulator plays out decades of consequence and grades your civilization against the standard of the Imams.",
        to: "/simulator",
        status: "live",
      },
    ],
  },
];

/**
 * Only modules that are actually built and reachable are published.
 * Queued / unfinished modules are kept out of navigation until they ship.
 */
export const MODULE_GROUPS: ModuleGroup[] = ALL_MODULE_GROUPS
  .map((g) => ({ ...g, modules: g.modules.filter((m) => m.status !== "queued" && !!m.to) }))
  .filter((g) => g.modules.length > 0);

export const MODULE_STATS = {
  total: MODULE_GROUPS.reduce((n, g) => n + g.modules.length, 0),
  live: MODULE_GROUPS.reduce((n, g) => n + g.modules.filter((m) => m.status === "live").length, 0),
  beta: MODULE_GROUPS.reduce((n, g) => n + g.modules.filter((m) => m.status === "beta").length, 0),
};