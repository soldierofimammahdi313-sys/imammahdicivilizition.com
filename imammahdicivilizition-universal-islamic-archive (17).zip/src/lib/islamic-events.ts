/**
 * Islamic occasions keyed by Hijri day/month ("D-M").
 * Used to (a) show today's occasion in the live ticker and
 * (b) steer the daily AI hadith set towards that occasion.
 */
export type IslamicEvent = { en: string; ur: string; theme: string };

const EVENTS: Record<string, IslamicEvent> = {
  // Muharram
  "1-1": { en: "Islamic New Year — 1 Muharram", ur: "اسلامی نیا سال — یکم محرم", theme: "the new Hijri year, the Hijrah, renewal of intention, and the opening days of Muharram" },
  "9-1": { en: "Tasu'a of Imam Husayn (a.s)", ur: "تاسوعائے امام حسینؑ", theme: "Tasu'a, the loyalty of Abbas ibn Ali (a.s), the night of Ashura" },
  "10-1": { en: "Day of Ashura — Martyrdom of Imam Husayn (a.s)", ur: "یومِ عاشورا — شہادتِ امام حسینؑ", theme: "Ashura, Karbala, the martyrdom of Imam Husayn (a.s), sacrifice, dignity, standing against injustice" },
  "25-1": { en: "Martyrdom of Imam Zayn al-Abidin (a.s)", ur: "شہادتِ امام زین العابدینؑ", theme: "Imam Zayn al-Abidin (a.s), Sahifa Sajjadiyya, supplication, patience after Karbala" },
  // Safar
  "20-2": { en: "Arba'een of Imam Husayn (a.s)", ur: "اربعینِ امام حسینؑ", theme: "Arba'een, the walk to Karbala, Ziyarat Arba'een, loyalty to Imam Husayn (a.s)" },
  "28-2": { en: "Demise of Prophet Muhammad (ﷺ) & Martyrdom of Imam Hasan (a.s)", ur: "رحلتِ رسول اللہﷺ و شہادتِ امام حسنؑ", theme: "the passing of the Prophet (ﷺ), his final counsel, and the forbearance and martyrdom of Imam Hasan al-Mujtaba (a.s)" },
  "30-2": { en: "Martyrdom of Imam Ali al-Rida (a.s)", ur: "شہادتِ امام علی رضاؑ", theme: "Imam Ali al-Rida (a.s), his knowledge, Ziyarat, and reliance on Allah" },
  // Rabi al-Awwal
  "8-3": { en: "Imamate of Imam al-Mahdi (a.j) begins", ur: "آغازِ امامتِ امام مہدی (عج)", theme: "the Imamate of Imam al-Mahdi (a.j), awaiting relief, du'a for his reappearance" },
  "17-3": { en: "Birth of Prophet Muhammad (ﷺ) & Imam Ja'far al-Sadiq (a.s)", ur: "ولادتِ رسول اللہﷺ و امام جعفر صادقؑ", theme: "the birth of the Prophet (ﷺ), his character and mercy, and the school of Imam Ja'far al-Sadiq (a.s)" },
  // Rabi al-Thani
  "8-4": { en: "Birth of Imam Hasan al-Askari (a.s)", ur: "ولادتِ امام حسن عسکریؑ", theme: "Imam Hasan al-Askari (a.s), forbearance, knowledge, and guarding the awaited Imam" },
  // Jumada al-Ula
  "5-5": { en: "Birth of Sayyida Zaynab (s.a)", ur: "ولادتِ سیدہ زینبؑ", theme: "Sayyida Zaynab (s.a), courage, eloquence, and patience" },
  "13-5": { en: "Martyrdom of Sayyida Fatima al-Zahra (s.a)", ur: "شہادتِ سیدہ فاطمہ زہراؑ", theme: "Sayyida Fatima al-Zahra (s.a), the Fadak sermon, her virtues and station" },
  // Jumada al-Thaniya
  "3-6": { en: "Martyrdom of Sayyida Fatima al-Zahra (s.a)", ur: "شہادتِ سیدہ فاطمہ زہراؑ", theme: "Sayyida Fatima al-Zahra (s.a), her sermon, worship, and the rights of the Ahl al-Bayt" },
  "20-6": { en: "Birth of Sayyida Fatima al-Zahra (s.a)", ur: "ولادتِ سیدہ فاطمہ زہراؑ", theme: "the birth of Sayyida Fatima al-Zahra (s.a), motherhood, purity, and the honour of women" },
  // Rajab
  "1-7": { en: "Birth of Imam Muhammad al-Baqir (a.s)", ur: "ولادتِ امام محمد باقرؑ", theme: "Imam al-Baqir (a.s), splitting open knowledge, and the a'mal of Rajab" },
  "3-7": { en: "Martyrdom of Imam Ali al-Hadi (a.s)", ur: "شہادتِ امام علی نقی الہادیؑ", theme: "Imam Ali al-Hadi (a.s), Ziyarat Jami'a Kabira, self-accounting" },
  "10-7": { en: "Birth of Imam Muhammad al-Jawad (a.s)", ur: "ولادتِ امام محمد تقی الجوادؑ", theme: "Imam al-Jawad (a.s), generosity, and youthful wisdom" },
  "13-7": { en: "Birth of Imam Ali (a.s) in the Ka'bah", ur: "ولادتِ امام علیؑ در کعبہ", theme: "the birth of Imam Ali (a.s) inside the Ka'bah, justice, knowledge, and Nahj al-Balagha" },
  "15-7": { en: "Death of Sayyida Zaynab (s.a)", ur: "وفاتِ سیدہ زینبؑ", theme: "Sayyida Zaynab (s.a), her sermons in Kufa and Sham, patience in trial" },
  "25-7": { en: "Martyrdom of Imam Musa al-Kadhim (a.s)", ur: "شہادتِ امام موسیٰ کاظمؑ", theme: "Imam Musa al-Kadhim (a.s), restraint of anger, prayer in prison, patience" },
  "27-7": { en: "Mab'ath — Beginning of the Prophet's Mission (ﷺ)", ur: "عیدِ مبعث", theme: "the Mab'ath, the first revelation, perfecting noble character, and the call to tawhid" },
  // Sha'ban
  "3-8": { en: "Birth of Imam Husayn (a.s)", ur: "ولادتِ امام حسینؑ", theme: "the birth of Imam Husayn (a.s), love of the Ahl al-Bayt, sacrifice" },
  "4-8": { en: "Birth of Abbas ibn Ali (a.s)", ur: "ولادتِ حضرت عباسؑ", theme: "Abu al-Fadl al-Abbas (a.s), loyalty, bravery, and service" },
  "5-8": { en: "Birth of Imam Zayn al-Abidin (a.s)", ur: "ولادتِ امام زین العابدینؑ", theme: "Imam Zayn al-Abidin (a.s), supplication, humility before Allah" },
  "15-8": { en: "Birth of Imam al-Mahdi (a.j) — Nisf Sha'ban", ur: "ولادتِ امام مہدی (عج) — نصف شعبان", theme: "the birth of Imam al-Mahdi (a.j), awaiting (intizar), justice filling the earth, du'a for his reappearance" },
  // Ramadan
  "1-9": { en: "First of Ramadan", ur: "یکم رمضان المبارک", theme: "the start of Ramadan, fasting, the Prophet's Sha'baniyya sermon, Du'a Iftitah" },
  "15-9": { en: "Birth of Imam Hasan al-Mujtaba (a.s)", ur: "ولادتِ امام حسن مجتبیٰؑ", theme: "Imam Hasan al-Mujtaba (a.s), generosity, forbearance, and peace-making" },
  "19-9": { en: "Striking of Imam Ali (a.s) — Laylat al-Qadr", ur: "ضربتِ امام علیؑ — شبِ قدر", theme: "Laylat al-Qadr, destiny, and the striking of Imam Ali (a.s) in the mihrab" },
  "21-9": { en: "Martyrdom of Imam Ali (a.s)", ur: "شہادتِ امام علیؑ", theme: "the martyrdom of Imam Ali (a.s), justice, his final testament to Hasan and Husayn (a.s)" },
  "23-9": { en: "Laylat al-Qadr", ur: "شبِ قدر", theme: "Laylat al-Qadr, the night better than a thousand months, Quran, repentance and du'a" },
  // Shawwal
  "1-10": { en: "Eid al-Fitr", ur: "عید الفطر", theme: "Eid al-Fitr, zakat al-fitrah, gratitude, and the sermon of Imam Ali (a.s) on Eid" },
  "25-10": { en: "Martyrdom of Imam Ja'far al-Sadiq (a.s)", ur: "شہادتِ امام جعفر صادقؑ", theme: "Imam Ja'far al-Sadiq (a.s), the Ja'fari school, knowledge, and honesty" },
  // Dhu al-Qa'dah
  "11-11": { en: "Birth of Imam Ali al-Rida (a.s)", ur: "ولادتِ امام علی رضاؑ", theme: "Imam al-Rida (a.s), the hadith of Silsilat al-Dhahab, tawhid, and welcoming pilgrims" },
  "29-11": { en: "Martyrdom of Imam Muhammad al-Jawad (a.s)", ur: "شہادتِ امام محمد تقی الجوادؑ", theme: "Imam al-Jawad (a.s), reliance on Allah, and worship as reflection" },
  // Dhu al-Hijjah
  "1-12": { en: "Marriage of Imam Ali (a.s) & Sayyida Fatima (s.a)", ur: "شادیٔ امام علیؑ و سیدہ فاطمہؑ", theme: "the marriage of Imam Ali (a.s) and Sayyida Fatima (s.a), family life, simplicity" },
  "7-12": { en: "Martyrdom of Imam Muhammad al-Baqir (a.s)", ur: "شہادتِ امام محمد باقرؑ", theme: "Imam al-Baqir (a.s), knowledge, and the days of Hajj" },
  "9-12": { en: "Day of Arafah", ur: "یومِ عرفہ", theme: "the Day of Arafah, Du'a Arafah of Imam Husayn (a.s), recognition of Allah, forgiveness" },
  "10-12": { en: "Eid al-Adha", ur: "عید الاضحیٰ", theme: "Eid al-Adha, the sacrifice of Ibrahim (a.s), Hajj, and closeness through sacrifice" },
  "15-12": { en: "Birth of Imam Ali al-Hadi (a.s)", ur: "ولادتِ امام علی نقی الہادیؑ", theme: "Imam Ali al-Hadi (a.s), Ziyarat Jami'a, and the station of the Imams" },
  "18-12": { en: "Eid al-Ghadir", ur: "عیدِ غدیر", theme: "Ghadir Khumm, the declaration of wilayah of Imam Ali (a.s), loyalty to the Ahl al-Bayt" },
  "24-12": { en: "Day of Mubahala", ur: "یومِ مباہلہ", theme: "the Mubahala, the Ayah of Mubahala, the People of the Cloak, and giving a ring in ruku'" },
};

export function getIslamicEvent(day: number, month: number): IslamicEvent | null {
  return EVENTS[`${day}-${month}`] ?? null;
}
