import { auth, defineMcp } from "@lovable.dev/mcp-js";
import searchArticles from "./tools/search-articles";
import getArticle from "./tools/get-article";
import listBookmarks from "./tools/list-bookmarks";
import saveItem from "./tools/save-item";
import listDiscussions from "./tools/list-discussions";
import createDiscussion from "./tools/create-discussion";
import getMyProgress from "./tools/get-my-progress";

const projectRef = import.meta.env['VITE_SUPABASE_PROJECT_ID'] ?? "project-ref-unset";

export default defineMcp({
  name: "imam-mahdi-s-digital-civilization",
  title: "Imam Mahdi's Digital Civilization",
  version: "0.1.0",
  instructions:
    "Tools for Imam Mahdi Civilization, an Islamic knowledge platform. Search and read published articles, manage the signed-in user's saved items, browse and post community discussions, and read the user's XP/streak progress. All tools act as the connected user.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [
    searchArticles,
    getArticle,
    listBookmarks,
    saveItem,
    listDiscussions,
    createDiscussion,
    getMyProgress,
  ],
});