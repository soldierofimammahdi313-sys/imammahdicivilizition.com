import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { notAuthenticated, supabaseForUser } from "../supabase";

export default defineTool({
  name: "create_discussion",
  title: "Create a discussion post",
  description: "Publish a new community discussion post as the signed-in user.",
  inputSchema: {
    title: z.string().trim().min(1).describe("Post title."),
    body: z.string().trim().min(1).describe("Post body in plain text."),
    category: z.string().trim().min(1).describe("Category, e.g. 'general', 'quran', 'fiqh'."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ title, body, category }, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("community_posts")
      .insert({ author_id: ctx.getUserId(), title, body, category })
      .select("id,title,category,created_at");
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data?.[0] ?? null) }],
      structuredContent: { post: data?.[0] ?? null },
    };
  },
});