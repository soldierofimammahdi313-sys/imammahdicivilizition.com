import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { notAuthenticated, supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_bookmarks",
  title: "List saved items",
  description: "List the signed-in user's saved/bookmarked items (articles, verses, hadith, etc.).",
  inputSchema: {
    item_type: z
      .string()
      .trim()
      .describe("Optional filter such as 'article', 'hadith' or 'ayah'. Use an empty string for all types."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ item_type }, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    let q = supabase
      .from("saved_items")
      .select("id,item_type,item_id,created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (item_type) q = q.eq("item_type", item_type);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { items: data ?? [] },
    };
  },
});