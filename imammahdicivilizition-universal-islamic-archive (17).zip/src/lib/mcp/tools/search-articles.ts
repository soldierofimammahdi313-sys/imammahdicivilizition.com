import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { notAuthenticated, supabaseForUser } from "../supabase";
import { guardSearchTerm } from "@/lib/search-guard";
import { recordSuspiciousSearch } from "@/lib/security-events.server";

export default defineTool({
  name: "search_articles",
  title: "Search articles",
  description:
    "Search published articles on Imam Mahdi Civilization by title, excerpt or tag. Returns slugs, titles and excerpts.",
  inputSchema: {
    query: z.string().trim().describe("Search text. Use an empty string to list the newest articles."),
    limit: z.number().int().describe("Maximum number of articles to return (1-25)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ query, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    const take = Math.min(Math.max(Number.isFinite(limit) ? limit : 10, 1), 25);
    let q = supabase
      .from("articles")
      .select("slug,title,excerpt,tags,published_at,reading_minutes")
      .eq("status", "published")
      .order("published_at", { ascending: false })
      .limit(take);
    const guard = guardSearchTerm(query ?? "", 100);
    if (guard.suspicious) {
      await recordSuspiciousSearch("mcp-search-articles", query ?? "", guard, ctx.getUserId() ?? null);
    }
    if (guard.term) q = q.or(`title.ilike.%${guard.term}%,excerpt.ilike.%${guard.term}%`);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { articles: data ?? [] },
    };
  },
});