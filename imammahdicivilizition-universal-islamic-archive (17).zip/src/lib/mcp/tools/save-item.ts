import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { notAuthenticated, supabaseForUser } from "../supabase";

export default defineTool({
  name: "save_item",
  title: "Save an item",
  description: "Bookmark an item (e.g. an article slug, a Quran verse key or a hadith id) for the signed-in user.",
  inputSchema: {
    item_type: z.string().trim().min(1).describe("Type of item, e.g. 'article', 'ayah', 'hadith'."),
    item_id: z.string().trim().min(1).describe("Identifier of the item, e.g. an article slug or '2:255'."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ item_type, item_id }, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("saved_items")
      .insert({ user_id: ctx.getUserId(), item_type, item_id })
      .select("id,item_type,item_id,created_at");
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data?.[0] ?? null) }],
      structuredContent: { item: data?.[0] ?? null },
    };
  },
});