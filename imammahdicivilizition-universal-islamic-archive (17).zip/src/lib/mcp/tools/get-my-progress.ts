import { defineTool } from "@lovable.dev/mcp-js";
import { notAuthenticated, supabaseForUser } from "../supabase";

export default defineTool({
  name: "get_my_progress",
  title: "Get my progress",
  description: "Get the signed-in user's XP, streak and recently completed daily spiritual tasks.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    const [xp, tasks] = await Promise.all([
      supabase.from("user_xp").select("xp,streak_days,last_active_date").maybeSingle(),
      supabase
        .from("daily_task_progress")
        .select("task_key,completed_on,xp_awarded")
        .order("completed_on", { ascending: false })
        .limit(20),
    ]);
    const error = xp.error ?? tasks.error;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    const payload = { xp: xp.data ?? { xp: 0, streak_days: 0, last_active_date: null }, recent_tasks: tasks.data ?? [] };
    return {
      content: [{ type: "text", text: JSON.stringify(payload) }],
      structuredContent: payload,
    };
  },
});