import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { notAuthenticated, supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_discussions",
  title: "List community discussions",
  description: "List recent community discussion posts, optionally filtered by category.",
  inputSchema: {
    category: z.string().trim().describe("Optional category filter. Use an empty string for all categories."),
    limit: z.number().int().describe("Maximum number of posts to return (1-25)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ category, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return notAuthenticated();
    const supabase = supabaseForUser(ctx);
    const take = Math.min(Math.max(Number.isFinite(limit) ? limit : 10, 1), 25);
    let q = supabase
      .from("community_posts")
      .select("id,title,body,category,author_name,created_at,is_pinned")
      .eq("is_hidden", false)
      .order("created_at", { ascending: false })
      .limit(take);
    if (category) q = q.eq("category", category);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { posts: data ?? [] },
    };
  },
});