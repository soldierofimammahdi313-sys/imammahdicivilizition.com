import { DefaultChatTransport } from "ai";
import { supabase } from "@/integrations/supabase/client";

const authHeaders = async (): Promise<Record<string, string>> => {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
};

/** Creates a chat transport bound to a persona handled by /api/chat. */
export function createChatTransport(persona?: string) {
  return new DefaultChatTransport({
    api: "/api/chat",
    headers: authHeaders,
    body: persona ? { persona } : undefined,
  });
}

// Attaches the signed-in user's bearer token so /api/chat can authenticate the caller.
export const chatTransport = createChatTransport();