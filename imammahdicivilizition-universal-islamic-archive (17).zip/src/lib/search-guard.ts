/**
 * Shared guard for free-text search input that ends up inside a PostgREST
 * `.or()` filter string. Sanitizes the term AND reports why it looked unsafe
 * so suspicious attempts can be logged and reviewed.
 */

export type SearchGuardSource = "site-search" | "discussion-search" | "mcp-search-articles";

export type SearchGuardResult = {
  /** Cleaned term that is safe to interpolate into a PostgREST filter. */
  term: string;
  /** True when the raw input contained filter-breaking or injection-like content. */
  suspicious: boolean;
  /** Human-readable reasons the input was flagged. */
  reasons: string[];
  /** Higher = more likely a deliberate probe. */
  severity: "info" | "warn" | "critical";
};

/** Characters that are structural in PostgREST filter syntax or SQL wildcards. */
const UNSAFE_CHARS = /[,%()*\\."']/g;

/** Patterns that look like a deliberate injection probe rather than a typo. */
const PROBE_PATTERNS: { name: string; re: RegExp }[] = [
  { name: "postgrest-operator", re: /\b(ilike|like|eq|neq|gte?|lte?|in|is|fts|cs|cd|not)\s*\./i },
  { name: "postgrest-logic", re: /\b(or|and)\s*\(/i },
  { name: "sql-keyword", re: /\b(union\s+select|select\s+.+\s+from|drop\s+table|insert\s+into|delete\s+from|update\s+\w+\s+set)\b/i },
  { name: "sql-comment", re: /(--|\/\*|\*\/|;)/ },
  // `1=1` anywhere is a probe; bare `true` only counts when quoted or paired
  // with a comment marker, since "true" is a legitimate search word.
  { name: "boolean-tautology", re: /\b1\s*=\s*1\b|['"]\s*(true|1\s*=\s*1)|\btrue\s*(--|#)/i },
  { name: "schema-probe", re: /\b(pg_catalog|information_schema|auth\.users|service_role)\b/i },
];

/** Sanitize a search term and classify how suspicious the raw input was. */
export function guardSearchTerm(raw: string, maxLength = 80): SearchGuardResult {
  const input = typeof raw === "string" ? raw : "";
  const term = input.replace(UNSAFE_CHARS, " ").replace(/\s+/g, " ").trim().slice(0, maxLength);

  const reasons: string[] = [];
  const stripped = (input.match(UNSAFE_CHARS) ?? []).length;
  if (stripped > 0) reasons.push(`stripped ${stripped} filter character(s)`);
  if (input.length > maxLength) reasons.push(`over-length input (${input.length} chars)`);
  for (const p of PROBE_PATTERNS) if (p.re.test(input)) reasons.push(p.name);

  const probeHits = reasons.filter((r) => PROBE_PATTERNS.some((p) => p.name === r)).length;
  // A stray comma or apostrophe alone is normal typing — only flag it as an
  // event when there is a real pattern hit or an unusual amount of noise.
  const suspicious = probeHits > 0 || stripped >= 3 || input.length > maxLength;

  return {
    term,
    suspicious,
    reasons,
    severity: probeHits >= 2 ? "critical" : probeHits === 1 ? "warn" : "info",
  };
}
