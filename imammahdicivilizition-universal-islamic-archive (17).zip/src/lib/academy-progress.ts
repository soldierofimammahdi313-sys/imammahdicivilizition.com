export type AcademyProgress = {
  xp: number;
  lessonsDone: string[];
  quizzesDone: string[];
  streakDays: number;
  lastActiveDay: string; // YYYY-MM-DD
  activity: Record<string, number>; // day -> xp earned
  studentName: string;
};

const KEY = "mahdi-academy-progress-v1";

export const EMPTY: AcademyProgress = {
  xp: 0,
  lessonsDone: [],
  quizzesDone: [],
  streakDays: 0,
  lastActiveDay: "",
  activity: {},
  studentName: "",
};

export function todayKey(d = new Date()): string {
  return d.toISOString().slice(0, 10);
}

export function loadProgress(): AcademyProgress {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return EMPTY;
    return { ...EMPTY, ...(JSON.parse(raw) as Partial<AcademyProgress>) };
  } catch {
    return EMPTY;
  }
}

export function saveProgress(p: AcademyProgress): AcademyProgress {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(p));
    } catch {
      /* storage unavailable — progress stays in memory */
    }
  }
  return p;
}

function bumpStreak(p: AcademyProgress): AcademyProgress {
  const today = todayKey();
  if (p.lastActiveDay === today) return p;
  const yesterday = todayKey(new Date(Date.now() - 86400000));
  return {
    ...p,
    streakDays: p.lastActiveDay === yesterday ? p.streakDays + 1 : 1,
    lastActiveDay: today,
  };
}

export function addXp(p: AcademyProgress, amount: number): AcademyProgress {
  const next = bumpStreak(p);
  const today = todayKey();
  return {
    ...next,
    xp: next.xp + amount,
    activity: { ...next.activity, [today]: (next.activity[today] ?? 0) + amount },
  };
}

export function completeLesson(p: AcademyProgress, id: string, xp = 25): AcademyProgress {
  if (p.lessonsDone.includes(id)) return p;
  return addXp({ ...p, lessonsDone: [...p.lessonsDone, id] }, xp);
}

export function completeQuiz(p: AcademyProgress, id: string, xp = 5): AcademyProgress {
  if (p.quizzesDone.includes(id)) return p;
  return addXp({ ...p, quizzesDone: [...p.quizzesDone, id] }, xp);
}

export const LEVELS = [
  { name: "Seedling", min: 0 },
  { name: "Explorer", min: 100 },
  { name: "Prompt Apprentice", min: 300 },
  { name: "Prompt Engineer", min: 700 },
  { name: "AI Scholar", min: 1200 },
  { name: "Ustad's Star", min: 2000 },
];

export function levelFor(xp: number) {
  let idx = 0;
  for (let i = 0; i < LEVELS.length; i++) if (xp >= LEVELS[i].min) idx = i;
  const current = LEVELS[idx];
  const next = LEVELS[idx + 1];
  const pct = next ? Math.round(((xp - current.min) / (next.min - current.min)) * 100) : 100;
  return { level: idx + 1, name: current.name, next, pct: Math.min(100, Math.max(0, pct)) };
}

export function last7Days(activity: Record<string, number>) {
  const out: { day: string; label: string; xp: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const key = todayKey(d);
    out.push({ day: key, label: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d.getDay()], xp: activity[key] ?? 0 });
  }
  return out;
}
