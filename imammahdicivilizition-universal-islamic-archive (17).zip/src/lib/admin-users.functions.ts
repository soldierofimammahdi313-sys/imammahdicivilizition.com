import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AdminUserRow = {
  id: string;
  full_name: string | null;
  email: string | null;
  country: string | null;
  created_at: string;
  posts: number;
  comments: number;
  saves: number;
  xp: number;
  activity: number;
};

export type AdminUsersPayload = {
  total: number;
  newLast7Days: number;
  users: AdminUserRow[];
};

/**
 * Admin-only listing of every registered member with their join date and
 * activity totals. The caller's role is verified server-side through their own
 * RLS-scoped client before any privileged read happens.
 */
export const listAllUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminUsersPayload> => {
    const { data: isAdmin, error } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (error || !isAdmin) throw new Response("Forbidden", { status: 403 });

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [profilesRes, postsRes, commentsRes, savesRes, xpRes] = await Promise.all([
      supabaseAdmin
        .from("profiles")
        .select("id, full_name, email, country, created_at")
        .order("created_at", { ascending: false })
        .limit(1000),
      supabaseAdmin.from("community_posts").select("author_id"),
      supabaseAdmin.from("community_comments").select("author_id"),
      supabaseAdmin.from("saved_items").select("user_id"),
      supabaseAdmin.from("user_xp").select("user_id, xp"),
    ]);

    const tally = (rows: { [k: string]: unknown }[] | null, key: string) => {
      const map = new Map<string, number>();
      for (const r of rows ?? []) {
        const id = r[key] as string | null;
        if (id) map.set(id, (map.get(id) ?? 0) + 1);
      }
      return map;
    };

    const posts = tally(postsRes.data, "author_id");
    const comments = tally(commentsRes.data, "author_id");
    const saves = tally(savesRes.data, "user_id");
    const xpMap = new Map<string, number>();
    for (const r of xpRes.data ?? []) xpMap.set(r.user_id, r.xp ?? 0);

    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const users: AdminUserRow[] = (profilesRes.data ?? []).map((p) => {
      const post = posts.get(p.id) ?? 0;
      const comment = comments.get(p.id) ?? 0;
      const save = saves.get(p.id) ?? 0;
      return {
        id: p.id,
        full_name: p.full_name,
        email: p.email ?? null,
        country: p.country,
        created_at: p.created_at,
        posts: post,
        comments: comment,
        saves: save,
        xp: xpMap.get(p.id) ?? 0,
        activity: post + comment + save,
      };
    });

    return {
      total: users.length,
      newLast7Days: users.filter((u) => new Date(u.created_at).getTime() > weekAgo).length,
      users,
    };
  });
