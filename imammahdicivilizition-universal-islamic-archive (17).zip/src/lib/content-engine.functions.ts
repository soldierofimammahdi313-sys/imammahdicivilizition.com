import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { EngineSettings, PipelineOutcome } from "@/lib/content-engine.server";

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (!data) throw new Error("Forbidden: admin only");
}

export type EngineOverview = {
  settings: EngineSettings;
  usage: { today: number; month: number; blocked: boolean; reason: string };
  topics: Array<{
    id: string;
    title: string;
    category: string | null;
    status: string;
    priority: number | null;
    last_error: string | null;
  }>;
  articles: Array<{
    id: string;
    slug: string;
    title: string;
    status: string;
    pipeline_status: string | null;
    quality_score: number | null;
    verification_status: string | null;
    similarity_score: number | null;
    created_at: string;
  }>;
};

export const getEngineOverview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<EngineOverview> => {
    await assertAdmin(context as never);
    const engine = await import("@/lib/content-engine.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const settings = await engine.getSettings();
    const limits = await engine.checkLimits(settings);
    const [{ data: topics }, { data: articles }] = await Promise.all([
      supabaseAdmin
        .from("content_topics")
        .select("id, title, category, status, priority, last_error")
        .order("created_at", { ascending: false })
        .limit(40),
      supabaseAdmin
        .from("articles")
        .select(
          "id, slug, title, status, pipeline_status, quality_score, verification_status, similarity_score, created_at",
        )
        .order("created_at", { ascending: false })
        .limit(40),
    ]);
    return {
      settings,
      usage: { today: limits.today, month: limits.month, blocked: limits.blocked, reason: limits.reason },
      topics: (topics ?? []) as EngineOverview["topics"],
      articles: (articles ?? []) as EngineOverview["articles"],
    };
  });

export const discoverTopicsNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ count: z.number().min(1).max(12).default(6) }).parse(input ?? {}))
  .handler(async ({ context, data }) => {
    await assertAdmin(context as never);
    const engine = await import("@/lib/content-engine.server");
    try {
      return { ok: true, ...(await engine.discoverTopics(data.count)) };
    } catch (err) {
      return { ok: false, inserted: 0, skipped: 0, error: err instanceof Error ? err.message : "Discovery failed" };
    }
  });

export const runContentPipeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ topicId: z.string().uuid().optional() }).parse(input ?? {}))
  .handler(async ({ context, data }): Promise<PipelineOutcome> => {
    await assertAdmin(context as never);
    const engine = await import("@/lib/content-engine.server");
    try {
      return data.topicId ? await engine.runPipelineForTopic(data.topicId) : await engine.runNextTopic();
    } catch (err) {
      return { ok: false, stage: "failed", message: err instanceof Error ? err.message : "Pipeline failed" };
    }
  });

export const setArticleState = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        articleId: z.string().uuid(),
        action: z.enum(["approve", "publish", "unpublish", "reject"]),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch =
      data.action === "approve"
        ? { pipeline_status: "approved" }
        : data.action === "publish"
          ? { status: "published", pipeline_status: "published", published_at: new Date().toISOString() }
          : data.action === "unpublish"
            ? { status: "draft", pipeline_status: "draft", published_at: null }
            : { status: "draft", pipeline_status: "failed" };
    const { error } = await supabaseAdmin.from("articles").update(patch as never).eq("id", data.articleId);
    if (error) return { ok: false, message: error.message };
    return { ok: true, message: `Article ${data.action}d` };
  });

export const updateEngineSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        auto_publish: z.boolean().optional(),
        auto_image: z.boolean().optional(),
        auto_seo: z.boolean().optional(),
        auto_verification: z.boolean().optional(),
        auto_translation: z.boolean().optional(),
        min_quality_score: z.number().min(0).max(100).optional(),
        daily_generation_limit: z.number().min(1).max(500).optional(),
        monthly_generation_limit: z.number().min(1).max(10000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("content_engine_settings")
      .update({ ...data, updated_at: new Date().toISOString() } as never)
      .eq("id", "default");
    if (error) return { ok: false, message: error.message };
    return { ok: true, message: "Settings saved" };
  });
