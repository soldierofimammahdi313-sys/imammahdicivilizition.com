import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ur" | "fa" | "ar" | "tr" | "fr" | "de" | "ru" | "zh" | "bn" | "hi" | "id";

export const LANGUAGES: { code: Lang; label: string; native: string; flag: string; rtl?: boolean }[] = [
  { code: "en", label: "English", native: "English", flag: "🇬🇧" },
  { code: "ur", label: "Urdu", native: "اردو", flag: "🇵🇰", rtl: true },
  { code: "fa", label: "Farsi", native: "فارسی", flag: "🇮🇷", rtl: true },
  { code: "ar", label: "Arabic", native: "العربية", flag: "🇸🇦", rtl: true },
  { code: "tr", label: "Turkish", native: "Türkçe", flag: "🇹🇷" },
  { code: "fr", label: "French", native: "Français", flag: "🇫🇷" },
  { code: "de", label: "German", native: "Deutsch", flag: "🇩🇪" },
  { code: "ru", label: "Russian", native: "Русский", flag: "🇷🇺" },
  { code: "zh", label: "Chinese", native: "中文", flag: "🇨🇳" },
  { code: "bn", label: "Bengali", native: "বাংলা", flag: "🇧🇩" },
  { code: "hi", label: "Hindi", native: "हिन्दी", flag: "🇮🇳" },
  { code: "id", label: "Indonesian", native: "Bahasa Indonesia", flag: "🇮🇩" },
];

type Dict = Record<string, string>;
const T: Partial<Record<Lang, Dict>> = {
  en: {
    "nav.realms": "Realms", "nav.quran": "Quran", "nav.hadith": "Hadith", "nav.duas": "Duas", "nav.tafsir": "Tafsir",
    "nav.ai": "N-Eyes", "nav.daily": "Daily", "nav.dashboard": "Dashboard", "nav.donate": "Donate",
    "nav.join": "Join Imam Mahdi Civilization", "nav.signin": "Sign In", "nav.signout": "Sign Out",
    "auth.welcome": "Welcome, Seeker", "auth.subtitle": "Sign in to enter the Vanguard of the Imam Mahdi Civilization.",
    "auth.email": "Email", "auth.password": "Password", "auth.signin": "Sign In",
    "auth.create": "Create Account", "auth.later": "Continue as Guest",
    "lang.choose": "Language",
    "tafsir.hero.label": "Exegesis", "tafsir.hero.title": "Tafsir al-Mizan", "tafsir.hero.desc": "The celebrated Shia exegesis of the Holy Quran by Allamah Sayyid Muhammad Husayn Tabatabai — a timeless work of reason, philosophy, and divine wisdom.",
    "tafsir.hero.author": "Allamah Tabatabai", "tafsir.hero.lang": "Arabic & Urdu", "tafsir.hero.volumes": "20 Volumes",
    "tafsir.author.name": "Allamah Sayyid Muhammad Husayn Tabatabai", "tafsir.author.bio": "One of the most prominent Shia thinkers of the 20th century, renowned for his mastery of Quranic exegesis, philosophy (Ilm al-Kalam), mysticism (Irfan), and jurisprudence (Fiqh). Tafsir al-Mizan is his magnum opus.",
    "tafsir.tag.philosophy": "Philosophy", "tafsir.tag.irfan": "Irfan", "tafsir.tag.fiqh": "Fiqh",
    "tafsir.surahs.title": "Read by Surah", "tafsir.surahs.search": "Search surahs…", "tafsir.surahs.empty": "No surahs found.",
    "tafsir.panel.title": "Tafsir", "tafsir.panel.select": "Select tafsir…", "tafsir.panel.mizan": "Tafsir al-Mizan", "tafsir.panel.mizanNote": "Read on almizan.org →",
    "hub.kicker": "Command Center", "hub.title": "Every Gate of the Imam Mahdi Civilization", "hub.subtitle": "Every realm, every tool, every gateway — one luminous control panel.",
    "hub.library": "Library", "hub.videos": "Videos", "hub.academy": "Academy", "hub.academyAi": "Mahdi AI Academy", "hub.articles": "Articles", "hub.community": "Community",
    "hub.qibla": "Qibla", "hub.tasbih": "Tasbih", "hub.names": "99 Names", "hub.khatam": "Khatam", "hub.zakat": "Zakat",
    "hub.inheritance": "Inheritance", "hub.mosques": "Mosques", "hub.events": "Events", "hub.about": "About",
    "hub.d.quran": "Read the Holy Quran with translation, audio & tafsir.",
    "hub.d.tafsir": "Tafsir al-Mizan & nine classical exegeses.",
    "hub.d.hadith": "Authentic narrations from the Prophet & Ahl al-Bayt.",
    "hub.d.duas": "Daily supplications & sacred invocations.",
    "hub.d.ai": "The N-Eyes Islamic AI assistant.",
    "hub.d.daily": "Prayer times, daily verse, hadith & dua.",
    "hub.d.realms": "The eight pillars of the civilization.",
    "hub.d.library": "Thousands of digital Islamic books.",
    "hub.d.videos": "Curated Islamic media & lecture channels.",
    "hub.d.academy": "Structured learning tracks & courses.", "hub.d.academyAi": "AI tech school for Muslim kids — Ustad Mahdi.",
    "hub.d.articles": "Research, essays & long-form writing.",
    "hub.d.community": "Forums, study circles & global hubs.",
    "hub.d.qibla": "Find the qibla from your location.",
    "hub.d.tasbih": "Digital dhikr counter with presets.",
    "hub.d.names": "The 99 Beautiful Names of Allah.",
    "hub.d.khatam": "Group Quran completion tracker.",
    "hub.d.zakat": "Calculate your zakat precisely.",
    "hub.d.inheritance": "Islamic inheritance (mirath) calculator.",
    "hub.d.mosques": "Discover nearby masajid worldwide.",
    "hub.d.events": "Majalis, conferences & global gatherings.",
    "hub.d.about": "Our mission, vision & founders.",
    "hub.d.join": "Enlist with the vanguard of the Imam Mahdi Civilization.",
    "hub.d.donate": "Support the digital civilization.",
    "hub.d.signin": "Enter your personal sanctuary.",

    // ---- Universal navigation ----
    "nav.home": "Home", "nav.library": "Islamic Library", "nav.research": "Research",
    "nav.academy": "Academy", "nav.imamMahdi": "Imam Mahdi", "nav.fiqh": "Fiqh",
    "nav.about": "About", "nav.contact": "Contact", "nav.privacy": "Privacy",
    "nav.terms": "Terms", "nav.disclaimer": "Disclaimer", "nav.knowledge": "Knowledge",
    "nav.menu": "Menu", "nav.close": "Close", "nav.search": "Search", "nav.shop": "Shop",
    "nav.preferences": "Language & Fiqh", "nav.more": "More",

    // ---- Fiqh ----
    "fiqh.title": "Schools of Islamic Jurisprudence",
    "fiqh.subtitle": "Choose the tradition you follow. Shared material stays visible whichever you pick, and you can change it at any time.",
    "fiqh.choose": "Scholarly tradition",
    "fiqh.current": "Current tradition",
    "fiqh.schools": "Fiqh schools",
    "fiqh.general": "General / All Fiqh",
    "fiqh.hanafi": "Hanafi", "fiqh.shafii": "Shafi'i", "fiqh.maliki": "Maliki",
    "fiqh.hanbali": "Hanbali", "fiqh.jafari": "Ja'fari",
    "fiqh.unclassified": "General / Unclassified",
    "fiqh.attributedTo": "Attributed to", "fiqh.era": "Era", "fiqh.regions": "Widely followed in",
    "fiqh.related": "Continue reading", "fiqh.inLibrary": "In the library",
    "fiqh.note": "These pages are short factual introductions, not legal rulings. For a ruling, ask a qualified scholar of your school.",
    "fiqh.emptyLibrary": "No catalogue entry is recorded under this school yet. Everything in the general collection is still open to you.",
    "fiqh.browseAll": "Browse all schools",

    // ---- Preferences modal ----
    "prefs.title": "Welcome to Imam Mahdi Civilization",
    "prefs.subtitle": "A universal Islamic knowledge and digital archive. Pick your language and the school you follow — both can be changed later.",
    "prefs.language": "Language",
    "prefs.fiqh": "Fiqh / Scholarly tradition",
    "prefs.continue": "Continue",
    "prefs.save": "Save preferences",
    "prefs.editTitle": "Language & Fiqh",
    "prefs.moreLanguages": "More languages",
    "prefs.fewerLanguages": "Fewer languages",
    "prefs.changeLater": "You can change this later from Language & Fiqh in the header.",

    // ---- Library / archive ----
    "library.title": "Universal Islamic Digital Archive",
    "library.subtitle": "Books, research, manuscripts, articles and documents — catalogued, filterable and hosted on this site.",
    "library.filters": "Filters",
    "library.filter.fiqh": "Fiqh tradition",
    "library.filter.type": "Content type",
    "library.filter.topic": "Topic",
    "library.filter.author": "Author",
    "library.filter.language": "Language",
    "library.filter.all": "All",
    "library.search": "Search the archive",
    "library.searchPlaceholder": "Title, author or topic…",
    "library.empty": "Nothing matches these filters",
    "library.emptyHint": "Try removing a filter or clearing the search box.",
    "library.reset": "Clear filters",
    "library.results": "entries",
    "library.type.book": "Book",
    "library.type.research": "Research paper",
    "library.type.manuscript": "Historical manuscript",
    "library.type.article": "Article",
    "library.type.document": "Document",
    "library.readStudy": "Open the study page",
    "library.collections": "Readings & studies",
    "library.unknownSource": "Source information not available",

    // ---- Common ----
    "common.home": "Home", "common.loading": "Loading…", "common.retry": "Try again",
    "common.error": "Something went wrong", "common.close": "Close", "common.back": "Back",
    "common.readMore": "Read more", "common.apply": "Apply", "common.cancel": "Cancel",

    // ---- 404 ----
    "notfound.title": "Page Not Found",
    "notfound.body": "The page you are looking for does not exist or has been moved.",
    "notfound.home": "Go to the home page",

    // ---- Footer ----
    "footer.positioning": "Universal Islamic Knowledge & Digital Archive",
    "footer.fiqh": "Fiqh Schools",
  },
  ur: {
    "nav.realms": "عوالم", "nav.quran": "قرآن", "nav.hadith": "حدیث", "nav.duas": "دعائیں", "nav.tafsir": "تفسیر",
    "nav.ai": "این-آئیز", "nav.daily": "روزانہ", "nav.dashboard": "ڈیش بورڈ", "nav.donate": "عطیہ",
    "nav.join": "Imam Mahdi Civilization میں شامل ہوں", "nav.signin": "سائن ان", "nav.signout": "سائن آؤٹ",
    "auth.welcome": "خوش آمدید، طالبِ حق", "auth.subtitle": "Imam Mahdi Civilization کے ہراول دستے میں داخل ہونے کے لیے سائن ان کریں۔",
    "auth.email": "ای میل", "auth.password": "پاس ورڈ", "auth.signin": "سائن ان",
    "auth.create": "اکاؤنٹ بنائیں", "auth.later": "بطور مہمان جاری رکھیں",
    "lang.choose": "زبان",
    "tafsir.hero.label": "تفسیر", "tafsir.hero.title": "تفسیر المیزان", "tafsir.hero.desc": "علامہ سید محمد حسین طباطبائی کی تصنیف کردہ قرآن مجید کی مشہور شیعہ تفسیر — ایک عالمی شہرت یافتہ اثر جو عقل، فلسفہ اور الہی دانش کا مجموعہ ہے۔",
    "tafsir.hero.author": "علامہ طباطبائی", "tafsir.hero.lang": "عربی و اردو", "tafsir.hero.volumes": "20 جلدیں",
    "tafsir.author.name": "علامہ سید محمد حسین طباطبائی", "tafsir.author.bio": "بیسویں صدی کے ممتاز ترین شیعہ مفکرین میں سے، جو قرآنی تفسیر، فلسفہ (علم الکلام)، عرفان اور فقہ میں مہارت رکھتے تھے۔ تفسیر المیزان ان کی شاہکار تصنیف ہے۔",
    "tafsir.tag.philosophy": "فلسفہ", "tafsir.tag.irfan": "عرفان", "tafsir.tag.fiqh": "فقہ",
    "tafsir.surahs.title": "سورہ کے لحاظ سے پڑھیں", "tafsir.surahs.search": "سورہ تلاش کریں…", "tafsir.surahs.empty": "کوئی سورہ نہیں ملی۔",
    "tafsir.panel.title": "تفسیر", "tafsir.panel.select": "تفسیر منتخب کریں…", "tafsir.panel.mizan": "تفسیر المیزان", "tafsir.panel.mizanNote": "almizan.org پر پڑھیں →",
    "hub.kicker": "کمانڈ سینٹر", "hub.title": "Imam Mahdi Civilization کے تمام دروازے", "hub.subtitle": "ہر عالم، ہر آلہ، ہر دروازہ — ایک ہی روشن کنٹرول پینل۔",
    "hub.library": "لائبریری", "hub.videos": "ویڈیوز", "hub.academy": "اکیڈمی", "hub.academyAi": "مہدی AI اکیڈمی", "hub.articles": "مضامین", "hub.community": "کمیونٹی",
    "hub.qibla": "قبلہ", "hub.tasbih": "تسبیح", "hub.names": "99 نام", "hub.khatam": "ختم", "hub.zakat": "زکوٰۃ",
    "hub.inheritance": "میراث", "hub.mosques": "مساجد", "hub.events": "تقریبات", "hub.about": "ہمارے بارے میں",
    "hub.d.quran": "قرآن مجید کو ترجمہ، آڈیو اور تفسیر کے ساتھ پڑھیں۔",
    "hub.d.tafsir": "تفسیر المیزان اور نو کلاسیکی تفاسیر۔",
    "hub.d.hadith": "رسول اللہؐ اور اہلِ بیتؑ کی مستند احادیث۔",
    "hub.d.duas": "روزانہ دعائیں اور مقدس مناجات۔",
    "hub.d.ai": "این-آئیز اسلامی اے آئی معاون۔",
    "hub.d.daily": "اوقاتِ نماز، روزانہ آیت، حدیث اور دعا۔",
    "hub.d.realms": "تہذیب کے آٹھ ستون۔",
    "hub.d.library": "ہزاروں ڈیجیٹل اسلامی کتب۔",
    "hub.d.videos": "منتخب اسلامی میڈیا اور لیکچر چینلز۔",
    "hub.d.academy": "منظم تعلیمی ٹریکس اور کورسز۔", "hub.d.academyAi": "مسلم بچوں کے لیے AI ٹیک اسکول — استاد مہدی۔",
    "hub.d.articles": "تحقیق، مضامین اور طویل تحریریں۔",
    "hub.d.community": "فورمز، مطالعہ گروپس اور عالمی مراکز۔",
    "hub.d.qibla": "اپنی جگہ سے قبلہ کا رخ معلوم کریں۔",
    "hub.d.tasbih": "ڈیجیٹل ذکر کاؤنٹر۔",
    "hub.d.names": "اللہ کے 99 خوبصورت نام۔",
    "hub.d.khatam": "گروپ ختمِ قرآن ٹریکر۔",
    "hub.d.zakat": "اپنی زکوٰۃ کا درست حساب۔",
    "hub.d.inheritance": "اسلامی میراث کیلکولیٹر۔",
    "hub.d.mosques": "دنیا بھر کی قریبی مساجد دریافت کریں۔",
    "hub.d.events": "مجالس، کانفرنسز اور عالمی اجتماعات۔",
    "hub.d.about": "ہمارا مشن، وژن اور بانیان۔",
    "hub.d.join": "Imam Mahdi Civilization کے ہراول دستے میں شامل ہوں۔",
    "hub.d.donate": "اس ڈیجیٹل تہذیب کی حمایت کریں۔",
    "hub.d.signin": "اپنے ذاتی محل میں داخل ہوں۔",

    // ---- Universal navigation ----
    "nav.home": "صفحۂ اول", "nav.library": "اسلامی لائبریری", "nav.research": "تحقیق",
    "nav.academy": "اکیڈمی", "nav.imamMahdi": "امام مہدیؑ", "nav.fiqh": "فقہ",
    "nav.about": "تعارف", "nav.contact": "رابطہ", "nav.privacy": "رازداری",
    "nav.terms": "شرائط", "nav.disclaimer": "اعلانِ لاتعلقی", "nav.knowledge": "علم",
    "nav.menu": "مینو", "nav.close": "بند کریں", "nav.search": "تلاش", "nav.shop": "دکان",
    "nav.preferences": "زبان و فقہ", "nav.more": "مزید",

    // ---- Fiqh ----
    "fiqh.title": "اسلامی مکاتبِ فقہ",
    "fiqh.subtitle": "اپنی فقہی روایت منتخب کیجیے۔ مشترکہ مواد ہر صورت میں دستیاب رہے گا، اور آپ اسے کسی بھی وقت بدل سکتے ہیں۔",
    "fiqh.choose": "علمی روایت",
    "fiqh.current": "موجودہ روایت",
    "fiqh.schools": "مکاتبِ فقہ",
    "fiqh.general": "عمومی / تمام فقہ",
    "fiqh.hanafi": "حنفی", "fiqh.shafii": "شافعی", "fiqh.maliki": "مالکی",
    "fiqh.hanbali": "حنبلی", "fiqh.jafari": "جعفری",
    "fiqh.unclassified": "عمومی / غیر متعین",
    "fiqh.attributedTo": "منسوب بہ", "fiqh.era": "دور", "fiqh.regions": "پیروی کے خطے",
    "fiqh.related": "مزید مطالعہ", "fiqh.inLibrary": "لائبریری میں",
    "fiqh.note": "یہ صفحات مختصر تعارفی معلومات ہیں، فتویٰ نہیں۔ شرعی حکم کے لیے اپنے مکتبِ فکر کے مستند عالم سے رجوع کریں۔",
    "fiqh.emptyLibrary": "اس مکتبِ فکر کے تحت ابھی کوئی اندراج درج نہیں۔ عمومی مجموعہ بدستور آپ کے لیے کھلا ہے۔",
    "fiqh.browseAll": "تمام مکاتب دیکھیں",

    // ---- Preferences modal ----
    "prefs.title": "Imam Mahdi Civilization میں خوش آمدید",
    "prefs.subtitle": "ایک عالمگیر اسلامی علمی و ڈیجیٹل آرکائیو۔ اپنی زبان اور فقہی روایت منتخب کیجیے — دونوں بعد میں بھی تبدیل ہو سکتی ہیں۔",
    "prefs.language": "زبان",
    "prefs.fiqh": "فقہ / علمی روایت",
    "prefs.continue": "داخل ہوں",
    "prefs.save": "ترجیحات محفوظ کریں",
    "prefs.editTitle": "زبان و فقہ",
    "prefs.moreLanguages": "مزید زبانیں",
    "prefs.fewerLanguages": "کم زبانیں",
    "prefs.changeLater": "آپ اسے بعد میں ہیڈر کے ”زبان و فقہ“ سے تبدیل کر سکتے ہیں۔",

    // ---- Library / archive ----
    "library.title": "عالمگیر اسلامی ڈیجیٹل آرکائیو",
    "library.subtitle": "کتب، تحقیق، تاریخی مخطوطات، مضامین اور دستاویزات — فہرست بند، قابلِ چھانٹ اور اسی سائٹ پر موجود۔",
    "library.filters": "فلٹر",
    "library.filter.fiqh": "فقہی روایت",
    "library.filter.type": "نوعیتِ مواد",
    "library.filter.topic": "موضوع",
    "library.filter.author": "مصنف",
    "library.filter.language": "زبان",
    "library.filter.all": "تمام",
    "library.search": "آرکائیو میں تلاش",
    "library.searchPlaceholder": "عنوان، مصنف یا موضوع…",
    "library.empty": "ان فلٹرز کے مطابق کچھ نہیں ملا",
    "library.emptyHint": "کوئی فلٹر ہٹائیں یا تلاش کا خانہ خالی کریں۔",
    "library.reset": "فلٹر صاف کریں",
    "library.results": "اندراجات",
    "library.type.book": "کتاب",
    "library.type.research": "تحقیقی مقالہ",
    "library.type.manuscript": "تاریخی مخطوطہ",
    "library.type.article": "مضمون",
    "library.type.document": "دستاویز",
    "library.readStudy": "مطالعہ کا صفحہ کھولیں",
    "library.collections": "مطالعات و تحقیقات",
    "library.unknownSource": "ماخذ کی معلومات دستیاب نہیں",

    // ---- Common ----
    "common.home": "صفحۂ اول", "common.loading": "لوڈ ہو رہا ہے…", "common.retry": "دوبارہ کوشش کریں",
    "common.error": "کچھ غلط ہو گیا", "common.close": "بند کریں", "common.back": "واپس",
    "common.readMore": "مزید پڑھیں", "common.apply": "لاگو کریں", "common.cancel": "منسوخ",

    // ---- 404 ----
    "notfound.title": "صفحہ نہیں ملا",
    "notfound.body": "جو صفحہ آپ تلاش کر رہے ہیں وہ موجود نہیں یا منتقل کر دیا گیا ہے۔",
    "notfound.home": "صفحۂ اول پر جائیں",

    // ---- Footer ----
    "footer.positioning": "عالمگیر اسلامی علم و ڈیجیٹل آرکائیو",
    "footer.fiqh": "مکاتبِ فقہ",
  },
  fa: {
    "nav.realms": "قلمروها", "nav.quran": "قرآن", "nav.hadith": "حدیث", "nav.duas": "ادعیه",
    "nav.ai": "ان-آیز", "nav.daily": "روزانه", "nav.dashboard": "داشبورد", "nav.donate": "صدقه",
    "nav.join": "پیوستن به Imam Mahdi Civilization", "nav.signin": "ورود", "nav.signout": "خروج",
    "auth.welcome": "خوش آمدید، جوینده", "auth.subtitle": "برای ورود به پیشتازان Imam Mahdi Civilization وارد شوید.",
    "auth.email": "ایمیل", "auth.password": "گذرواژه", "auth.signin": "ورود",
    "auth.create": "ایجاد حساب", "auth.later": "ادامه به‌عنوان مهمان",
    "lang.choose": "زبان",
    "tafsir.hero.label": "تفسیر", "tafsir.hero.title": "تفسیر المیزان", "tafsir.hero.desc": "تفسیر المیزان اثر برجسته علامه سید محمد حسین طباطبایی — تفسیری جامع و عمیق از قرآن کریم.",
    "tafsir.hero.author": "علامه طباطبایی", "tafsir.hero.lang": "عربی و فارسی", "tafsir.hero.volumes": "۲۰ جلد",
    "tafsir.author.name": "علامه سید محمد حسین طباطبایی", "tafsir.author.bio": "یکی از برجسته‌ترین متفکران شیعه در قرن بیستم، استاد تفسیر قرآن، فلسفه، عرفان و فقه. تفسیر المیزان شاهکار اوست.",
    "tafsir.tag.philosophy": "فلسفه", "tafsir.tag.irfan": "عرفان", "tafsir.tag.fiqh": "فقه",
    "tafsir.surahs.title": "خواندن بر اساس سوره", "tafsir.surahs.search": "جستجوی سوره‌ها…", "tafsir.surahs.empty": "سوره‌ای یافت نشد.",
    "tafsir.panel.title": "تفسیر", "tafsir.panel.select": "انتخاب تفسیر…", "tafsir.panel.mizan": "تفسیر المیزان", "tafsir.panel.mizanNote": "خواندن در almizan.org →",
    "nav.tafsir": "تفسیر",
    "hub.kicker": "مرکز فرماندهی", "hub.title": "همه دروازه‌های Imam Mahdi Civilization", "hub.subtitle": "هر قلمرو، هر ابزار، هر دروازه — یک پنل کنترل نورانی.",
    "hub.library": "کتابخانه", "hub.videos": "ویدیوها", "hub.academy": "آکادمی", "hub.academyAi": "آکادمی هوش مصنوعی مهدی", "hub.articles": "مقالات", "hub.community": "جامعه",
    "hub.qibla": "قبله", "hub.tasbih": "تسبیح", "hub.names": "۹۹ نام", "hub.khatam": "ختم", "hub.zakat": "زکات",
    "hub.inheritance": "ارث", "hub.mosques": "مساجد", "hub.events": "رویدادها", "hub.about": "درباره ما",
    "hub.d.quran": "خواندن قرآن کریم با ترجمه، صدا و تفسیر.",
    "hub.d.tafsir": "تفسیر المیزان و نه تفسیر کلاسیک.",
    "hub.d.hadith": "روایات معتبر از پیامبر و اهل بیت.",
    "hub.d.duas": "ادعیه روزانه و مناجات مقدس.",
    "hub.d.ai": "دستیار هوش مصنوعی اسلامی N-Eyes.",
    "hub.d.daily": "اوقات نماز، آیه، حدیث و دعای روزانه.",
    "hub.d.realms": "هشت ستون این تمدن.",
    "hub.d.library": "هزاران کتاب اسلامی دیجیتال.",
    "hub.d.videos": "رسانه‌ها و کانال‌های منتخب اسلامی.",
    "hub.d.academy": "مسیرهای آموزشی منظم.", "hub.d.academyAi": "مدرسه فناوری هوش مصنوعی برای کودکان مسلمان.",
    "hub.d.articles": "پژوهش‌ها و مقالات بلند.",
    "hub.d.community": "انجمن‌ها و حلقه‌های مطالعه.",
    "hub.d.qibla": "یافتن جهت قبله از مکان شما.",
    "hub.d.tasbih": "شمارنده دیجیتال ذکر.",
    "hub.d.names": "۹۹ نام نیکوی خداوند.",
    "hub.d.khatam": "ردیاب ختم گروهی قرآن.",
    "hub.d.zakat": "محاسبه دقیق زکات.",
    "hub.d.inheritance": "ماشین‌حساب میراث اسلامی.",
    "hub.d.mosques": "کشف مساجد نزدیک در سراسر جهان.",
    "hub.d.events": "مجالس و گردهمایی‌های جهانی.",
    "hub.d.about": "ماموریت و چشم‌انداز ما.",
    "hub.d.join": "به پیشتازان Imam Mahdi Civilization بپیوندید.",
    "hub.d.donate": "از این تمدن دیجیتال حمایت کنید.",
    "hub.d.signin": "وارد پناهگاه شخصی خود شوید.",
  },
  ar: {
    "nav.realms": "العوالم", "nav.quran": "القرآن", "nav.hadith": "الحديث", "nav.duas": "الأدعية",
    "nav.ai": "إن-آيز", "nav.daily": "اليومي", "nav.dashboard": "اللوحة", "nav.donate": "تبرع",
    "nav.join": "انضم إلى Imam Mahdi Civilization", "nav.signin": "تسجيل الدخول", "nav.signout": "تسجيل الخروج",
    "auth.welcome": "أهلاً بك أيها الطالب", "auth.subtitle": "سجّل الدخول لتنضم إلى طليعة الـImam Mahdi Civilization.",
    "auth.email": "البريد", "auth.password": "كلمة المرور", "auth.signin": "دخول",
    "auth.create": "إنشاء حساب", "auth.later": "متابعة كضيف",
    "lang.choose": "اللغة",
    "tafsir.hero.label": "تفسير", "tafsir.hero.title": "تفسير الميزان", "tafsir.hero.desc": "تفسير الميزان للعلامة السيد محمد حسين الطباطبائي — تفسير شيعي عظيم يجمع بين العقل والفلسفة والحكمة الإلهية.",
    "tafsir.hero.author": "العلامة الطباطبائي", "tafsir.hero.lang": "العربية والفارسية", "tafsir.hero.volumes": "٢٠ مجلدًا",
    "tafsir.author.name": "العلامة السيد محمد حسين الطباطبائي", "tafsir.author.bio": "أحد أبرز المفكرين الشيعة في القرن العشرين، بارع في التفسير القرآني والفلسفة والعرفان والفقه. تفسير الميزان هو عمله الخالد.",
    "tafsir.tag.philosophy": "فلسفة", "tafsir.tag.irfan": "عرفان", "tafsir.tag.fiqh": "فقه",
    "tafsir.surahs.title": "قراءة حسب السورة", "tafsir.surahs.search": "البحث في السور…", "tafsir.surahs.empty": "لم يُعثَر على سور.",
    "tafsir.panel.title": "تفسير", "tafsir.panel.select": "اختيار التفسير…", "tafsir.panel.mizan": "تفسير الميزان", "tafsir.panel.mizanNote": "اقرأ على almizan.org →",
    "nav.tafsir": "تفسير",
    "hub.kicker": "مركز القيادة", "hub.title": "كلّ أبواب الـImam Mahdi Civilization", "hub.subtitle": "كل عالَم، كل أداة، كل بوابة — لوحة تحكّم واحدة منيرة.",
    "hub.library": "المكتبة", "hub.videos": "الفيديوهات", "hub.academy": "الأكاديمية", "hub.academyAi": "أكاديمية المهدي للذكاء الاصطناعي", "hub.articles": "المقالات", "hub.community": "المجتمع",
    "hub.qibla": "القبلة", "hub.tasbih": "التسبيح", "hub.names": "٩٩ اسماً", "hub.khatam": "الختم", "hub.zakat": "الزكاة",
    "hub.inheritance": "الميراث", "hub.mosques": "المساجد", "hub.events": "الفعاليات", "hub.about": "حولنا",
    "hub.d.quran": "اقرأ القرآن الكريم مع الترجمة والصوت والتفسير.",
    "hub.d.tafsir": "تفسير الميزان وتسعة تفاسير كلاسيكية.",
    "hub.d.hadith": "روايات صحيحة عن النبيّ وأهل البيت.",
    "hub.d.duas": "أدعية يومية ومناجاة مقدسة.",
    "hub.d.ai": "مساعد إن-آيز للذكاء الإسلامي.",
    "hub.d.daily": "أوقات الصلاة والآية والحديث والدعاء اليومي.",
    "hub.d.realms": "أركان الحضارة الثمانية.",
    "hub.d.library": "آلاف الكتب الإسلامية الرقمية.",
    "hub.d.videos": "وسائط وقنوات إسلامية مختارة.",
    "hub.d.academy": "مسارات تعليمية منظمة ودورات.", "hub.d.academyAi": "مدرسة تقنية بالذكاء الاصطناعي للأطفال المسلمين.",
    "hub.d.articles": "أبحاث ومقالات مطوّلة.",
    "hub.d.community": "منتديات وحلقات دراسة عالمية.",
    "hub.d.qibla": "اعرف اتجاه القبلة من مكانك.",
    "hub.d.tasbih": "عداد ذكر رقمي.",
    "hub.d.names": "أسماء الله الحسنى التسعة والتسعون.",
    "hub.d.khatam": "متابع ختم القرآن الجماعي.",
    "hub.d.zakat": "احسب زكاتك بدقة.",
    "hub.d.inheritance": "حاسبة الميراث الإسلامية.",
    "hub.d.mosques": "اكتشف المساجد القريبة حول العالم.",
    "hub.d.events": "مجالس ومؤتمرات وتجمعات.",
    "hub.d.about": "رسالتنا ورؤيتنا ومؤسسونا.",
    "hub.d.join": "انضم إلى طليعة الـImam Mahdi Civilization.",
    "hub.d.donate": "ادعم هذه الحضارة الرقمية.",
    "hub.d.signin": "ادخل إلى ملاذك الشخصي.",

    // ---- Universal navigation ----
    "nav.home": "الرئيسية", "nav.library": "المكتبة الإسلامية", "nav.research": "الأبحاث",
    "nav.academy": "الأكاديمية", "nav.imamMahdi": "الإمام المهدي", "nav.fiqh": "الفقه",
    "nav.about": "من نحن", "nav.contact": "اتصل بنا", "nav.privacy": "الخصوصية",
    "nav.terms": "الشروط", "nav.disclaimer": "إخلاء المسؤولية", "nav.knowledge": "المعرفة",
    "nav.menu": "القائمة", "nav.close": "إغلاق", "nav.search": "بحث", "nav.shop": "المتجر",
    "nav.preferences": "اللغة والمذهب", "nav.more": "المزيد",

    // ---- Fiqh ----
    "fiqh.title": "مذاهب الفقه الإسلامي",
    "fiqh.subtitle": "اختر المذهب الذي تتبعه. تبقى المواد المشتركة ظاهرة مهما كان اختيارك، ويمكنك تغييره في أي وقت.",
    "fiqh.choose": "المذهب العلمي",
    "fiqh.current": "المذهب الحالي",
    "fiqh.schools": "المذاهب الفقهية",
    "fiqh.general": "عام / كل المذاهب",
    "fiqh.hanafi": "الحنفي", "fiqh.shafii": "الشافعي", "fiqh.maliki": "المالكي",
    "fiqh.hanbali": "الحنبلي", "fiqh.jafari": "الجعفري",
    "fiqh.unclassified": "عام / غير مصنّف",
    "fiqh.attributedTo": "منسوب إلى", "fiqh.era": "الحقبة", "fiqh.regions": "ينتشر في",
    "fiqh.related": "تابع القراءة", "fiqh.inLibrary": "في المكتبة",
    "fiqh.note": "هذه الصفحات تعريفات موجزة لا فتاوى. وللحكم الشرعي راجع عالمًا مؤهلًا من مذهبك.",
    "fiqh.emptyLibrary": "لا يوجد مدخل مسجَّل تحت هذا المذهب بعد. وتبقى المجموعة العامة متاحة لك بالكامل.",
    "fiqh.browseAll": "تصفّح كل المذاهب",

    // ---- Preferences modal ----
    "prefs.title": "أهلًا بك في Imam Mahdi Civilization",
    "prefs.subtitle": "أرشيف إسلامي رقمي ومعرفي جامع. اختر لغتك ومذهبك — ويمكن تغييرهما لاحقًا.",
    "prefs.language": "اللغة",
    "prefs.fiqh": "الفقه / المذهب العلمي",
    "prefs.continue": "دخول",
    "prefs.save": "حفظ التفضيلات",
    "prefs.editTitle": "اللغة والمذهب",
    "prefs.moreLanguages": "لغات أخرى",
    "prefs.fewerLanguages": "لغات أقل",
    "prefs.changeLater": "يمكنك تغيير ذلك لاحقًا من «اللغة والمذهب» في الأعلى.",

    // ---- Library / archive ----
    "library.title": "الأرشيف الإسلامي الرقمي الجامع",
    "library.subtitle": "كتب وأبحاث ومخطوطات تاريخية ومقالات ووثائق — مفهرسة وقابلة للتصفية ومستضافة على هذا الموقع.",
    "library.filters": "عوامل التصفية",
    "library.filter.fiqh": "المذهب الفقهي",
    "library.filter.type": "نوع المحتوى",
    "library.filter.topic": "الموضوع",
    "library.filter.author": "المؤلف",
    "library.filter.language": "اللغة",
    "library.filter.all": "الكل",
    "library.search": "ابحث في الأرشيف",
    "library.searchPlaceholder": "عنوان أو مؤلف أو موضوع…",
    "library.empty": "لا نتائج مطابقة لعوامل التصفية",
    "library.emptyHint": "جرّب إزالة أحد العوامل أو إفراغ خانة البحث.",
    "library.reset": "مسح التصفية",
    "library.results": "مدخلًا",
    "library.type.book": "كتاب",
    "library.type.research": "بحث علمي",
    "library.type.manuscript": "مخطوط تاريخي",
    "library.type.article": "مقال",
    "library.type.document": "وثيقة",
    "library.readStudy": "افتح صفحة الدراسة",
    "library.collections": "قراءات ودراسات",
    "library.unknownSource": "معلومات المصدر غير متوفرة",

    // ---- Common ----
    "common.home": "الرئيسية", "common.loading": "جارٍ التحميل…", "common.retry": "أعد المحاولة",
    "common.error": "حدث خطأ ما", "common.close": "إغلاق", "common.back": "رجوع",
    "common.readMore": "اقرأ المزيد", "common.apply": "تطبيق", "common.cancel": "إلغاء",

    // ---- 404 ----
    "notfound.title": "الصفحة غير موجودة",
    "notfound.body": "الصفحة التي تبحث عنها غير موجودة أو تم نقلها.",
    "notfound.home": "العودة إلى الصفحة الرئيسية",

    // ---- Footer ----
    "footer.positioning": "أرشيف إسلامي رقمي ومعرفي جامع",
    "footer.fiqh": "المذاهب الفقهية",
  },
  tr: {
    "nav.realms": "Alemler", "nav.quran": "Kuran", "nav.hadith": "Hadis", "nav.duas": "Dualar",
    "nav.ai": "N-Eyes", "nav.daily": "Günlük", "nav.dashboard": "Panel", "nav.donate": "Bağış",
    "nav.join": "Imam Mahdi Civilization'e Katıl", "nav.signin": "Giriş", "nav.signout": "Çıkış",
    "auth.welcome": "Hoş geldin, Arayıcı", "auth.subtitle": "Imam Mahdi Civilization'ün öncülerine katılmak için giriş yap.",
    "auth.email": "E-posta", "auth.password": "Şifre", "auth.signin": "Giriş Yap",
    "auth.create": "Hesap Oluştur", "auth.later": "Misafir Olarak Devam",
    "lang.choose": "Dil",
    "tafsir.hero.label": "Tefsir", "tafsir.hero.title": "Tefsir el-Mizan", "tafsir.hero.desc": "Allame Seyyid Muhammed Hüseyin Tabatabai'nin şanlı Şii tefsiri — akıl, felsefe ve ilahi hikmetin zamansız bir eseri.",
    "tafsir.hero.author": "Allame Tabatabai", "tafsir.hero.lang": "Arapça & Farsça", "tafsir.hero.volumes": "20 Cilt",
    "tafsir.author.name": "Allame Seyyid Muhammed Hüseyin Tabatabai", "tafsir.author.bio": "20. yüzyılın en önemli Şii düşünürlerinden biri, Kuran tefsiri, felsefe, irfan ve fıkıh alanında usta. Tefsir el-Mizan onun baş yapıtıdır.",
    "tafsir.tag.philosophy": "Felsefe", "tafsir.tag.irfan": "İrfan", "tafsir.tag.fiqh": "Fıkıh",
    "tafsir.surahs.title": "Sureye Göre Oku", "tafsir.surahs.search": "Sure ara…", "tafsir.surahs.empty": "Sure bulunamadı.",
    "tafsir.panel.title": "Tefsir", "tafsir.panel.select": "Tefsir seç…", "tafsir.panel.mizan": "Tefsir el-Mizan", "tafsir.panel.mizanNote": "almizan.org'da oku →",
    "nav.tafsir": "Tefsir",
    "hub.kicker": "Komuta Merkezi", "hub.title": "Imam Mahdi Civilization'ün Tüm Kapıları", "hub.subtitle": "Her alem, her araç, her kapı — tek bir aydınlık kontrol paneli.",
    "hub.library": "Kütüphane", "hub.videos": "Videolar", "hub.academy": "Akademi", "hub.academyAi": "Mehdi Yapay Zeka Akademisi", "hub.articles": "Makaleler", "hub.community": "Topluluk",
    "hub.qibla": "Kıble", "hub.tasbih": "Tesbih", "hub.names": "99 İsim", "hub.khatam": "Hatim", "hub.zakat": "Zekat",
    "hub.inheritance": "Miras", "hub.mosques": "Camiler", "hub.events": "Etkinlikler", "hub.about": "Hakkımızda",
    "hub.d.quran": "Kur'an-ı Kerim'i tercüme, ses ve tefsirle okuyun.",
    "hub.d.tafsir": "Tefsir el-Mizan ve dokuz klasik tefsir.",
    "hub.d.hadith": "Peygamber ve Ehl-i Beyt'ten sahih rivayetler.",
    "hub.d.duas": "Günlük dualar ve kutsal münacatlar.",
    "hub.d.ai": "N-Eyes İslami yapay zeka asistanı.",
    "hub.d.daily": "Namaz vakitleri, ayet, hadis ve dua.",
    "hub.d.realms": "Medeniyetin sekiz sütunu.",
    "hub.d.library": "Binlerce dijital İslami kitap.",
    "hub.d.videos": "Seçkin İslami medya kanalları.",
    "hub.d.academy": "Yapılandırılmış öğrenme yolları.", "hub.d.academyAi": "Müslüman çocuklar için AI teknoloji okulu.",
    "hub.d.articles": "Araştırma, deneme ve uzun yazılar.",
    "hub.d.community": "Forumlar, çalışma halkaları, küresel merkezler.",
    "hub.d.qibla": "Konumunuzdan kıble yönünü bulun.",
    "hub.d.tasbih": "Dijital zikir sayacı.",
    "hub.d.names": "Allah'ın 99 Güzel İsmi.",
    "hub.d.khatam": "Grup Kur'an hatim takipçisi.",
    "hub.d.zakat": "Zekatınızı hassas hesaplayın.",
    "hub.d.inheritance": "İslami miras hesaplayıcısı.",
    "hub.d.mosques": "Dünya çapında yakın camileri keşfedin.",
    "hub.d.events": "Meclisler, konferanslar ve toplantılar.",
    "hub.d.about": "Misyonumuz, vizyonumuz ve kurucularımız.",
    "hub.d.join": "Imam Mahdi Civilization'ün öncülerine katılın.",
    "hub.d.donate": "Bu dijital medeniyeti destekleyin.",
    "hub.d.signin": "Kişisel sığınağınıza girin.",
  },
  fr: {
    "nav.realms": "Royaumes", "nav.quran": "Coran", "nav.hadith": "Hadith", "nav.duas": "Du'as",
    "nav.ai": "N-Eyes", "nav.daily": "Quotidien", "nav.dashboard": "Tableau", "nav.donate": "Faire un don",
    "nav.join": "Rejoindre Imam Mahdi Civilization", "nav.signin": "Connexion", "nav.signout": "Déconnexion",
    "auth.welcome": "Bienvenue, Chercheur", "auth.subtitle": "Connectez-vous pour rejoindre l'avant-garde des Imam Mahdi Civilization.",
    "auth.email": "E-mail", "auth.password": "Mot de passe", "auth.signin": "Se connecter",
    "auth.create": "Créer un compte", "auth.later": "Continuer en invité",
    "lang.choose": "Langue",
    "tafsir.hero.label": "Exégèse", "tafsir.hero.title": "Tafsir al-Mizan", "tafsir.hero.desc": "Le célèbre tafsir chiite du Saint Coran par l'Allamah Sayyid Muhammad Husayn Tabatabai — une œuvre intemporelle de raison, de philosophie et de sagesse divine.",
    "tafsir.hero.author": "Allamah Tabatabai", "tafsir.hero.lang": "Arabe & Persan", "tafsir.hero.volumes": "20 Volumes",
    "tafsir.author.name": "Allamah Sayyid Muhammad Husayn Tabatabai", "tafsir.author.bio": "L'un des penseurs chiites les plus éminents du 20e siècle, réputé pour sa maîtrise de l'exégèse coranique, de la philosophie, du mysticisme et de la jurisprudence. Tafsir al-Mizan est son magnum opus.",
    "tafsir.tag.philosophy": "Philosophie", "tafsir.tag.irfan": "Irfan", "tafsir.tag.fiqh": "Fiqh",
    "tafsir.surahs.title": "Lire par Sourate", "tafsir.surahs.search": "Rechercher des sourates…", "tafsir.surahs.empty": "Aucune sourate trouvée.",
    "tafsir.panel.title": "Tafsir", "tafsir.panel.select": "Choisir un tafsir…", "tafsir.panel.mizan": "Tafsir al-Mizan", "tafsir.panel.mizanNote": "Lire sur almizan.org →",
    "nav.tafsir": "Tafsir",
    "hub.kicker": "Centre de Commande", "hub.title": "Toutes les Portes des Imam Mahdi Civilization", "hub.subtitle": "Chaque royaume, chaque outil, chaque porte — un seul panneau de contrôle lumineux.",
    "hub.library": "Bibliothèque", "hub.videos": "Vidéos", "hub.academy": "Académie", "hub.academyAi": "Académie IA Mahdi", "hub.articles": "Articles", "hub.community": "Communauté",
    "hub.qibla": "Qibla", "hub.tasbih": "Tasbih", "hub.names": "99 Noms", "hub.khatam": "Khatm", "hub.zakat": "Zakat",
    "hub.inheritance": "Héritage", "hub.mosques": "Mosquées", "hub.events": "Événements", "hub.about": "À Propos",
    "hub.d.quran": "Lire le Saint Coran avec traduction, audio et tafsir.",
    "hub.d.tafsir": "Tafsir al-Mizan et neuf exégèses classiques.",
    "hub.d.hadith": "Narrations authentiques du Prophète et des Ahl al-Bayt.",
    "hub.d.duas": "Invocations quotidiennes et oraisons sacrées.",
    "hub.d.ai": "L'assistant IA islamique N-Eyes.",
    "hub.d.daily": "Heures de prière, verset, hadith et du'a du jour.",
    "hub.d.realms": "Les huit piliers de la civilisation.",
    "hub.d.library": "Des milliers de livres islamiques numériques.",
    "hub.d.videos": "Médias et chaînes islamiques sélectionnés.",
    "hub.d.academy": "Parcours d'apprentissage structurés.", "hub.d.academyAi": "École tech IA pour enfants musulmans.",
    "hub.d.articles": "Recherches, essais et textes longs.",
    "hub.d.community": "Forums, cercles d'étude, pôles mondiaux.",
    "hub.d.qibla": "Trouvez la qibla depuis votre emplacement.",
    "hub.d.tasbih": "Compteur de dhikr numérique.",
    "hub.d.names": "Les 99 Beaux Noms d'Allah.",
    "hub.d.khatam": "Suivi de khatm collectif du Coran.",
    "hub.d.zakat": "Calculez votre zakat avec précision.",
    "hub.d.inheritance": "Calculateur d'héritage islamique.",
    "hub.d.mosques": "Découvrez les mosquées proches dans le monde.",
    "hub.d.events": "Majalis, conférences et rassemblements.",
    "hub.d.about": "Notre mission, vision et fondateurs.",
    "hub.d.join": "Rejoignez l'avant-garde des Imam Mahdi Civilization.",
    "hub.d.donate": "Soutenez cette civilisation numérique.",
    "hub.d.signin": "Entrez dans votre sanctuaire personnel.",
  },
  de: {
    "nav.realms": "Reiche", "nav.quran": "Koran", "nav.hadith": "Hadith", "nav.duas": "Bittgebete",
    "nav.ai": "N-Eyes", "nav.daily": "Täglich", "nav.dashboard": "Dashboard", "nav.donate": "Spenden",
    "nav.join": "Imam Mahdi Civilization beitreten", "nav.signin": "Anmelden", "nav.signout": "Abmelden",
    "auth.welcome": "Willkommen, Suchender", "auth.subtitle": "Melde dich an, um der Vorhut der Imam Mahdi Civilization beizutreten.",
    "auth.email": "E-Mail", "auth.password": "Passwort", "auth.signin": "Anmelden",
    "auth.create": "Konto erstellen", "auth.later": "Als Gast fortfahren",
    "lang.choose": "Sprache",
    "tafsir.hero.label": "Exegese", "tafsir.hero.title": "Tafsir al-Mizan", "tafsir.hero.desc": "Die berühmte schiitische Koranexegese von Allamah Sayyid Muhammad Husayn Tabatabai — ein zeitloses Werk der Vernunft, Philosophie und göttlichen Weisheit.",
    "tafsir.hero.author": "Allamah Tabatabai", "tafsir.hero.lang": "Arabisch & Persisch", "tafsir.hero.volumes": "20 Bände",
    "tafsir.author.name": "Allamah Sayyid Muhammad Husayn Tabatabai", "tafsir.author.bio": "Einer der bedeutendsten schiitischen Denker des 20. Jahrhunderts, bekannt für seine Meisterschaft in Koranexegese, Philosophie, Mystik und Rechtswissenschaft. Tafsir al-Mizan ist sein Hauptwerk.",
    "tafsir.tag.philosophy": "Philosophie", "tafsir.tag.irfan": "Irfan", "tafsir.tag.fiqh": "Fiqh",
    "tafsir.surahs.title": "Nach Sure lesen", "tafsir.surahs.search": "Suren suchen…", "tafsir.surahs.empty": "Keine Suren gefunden.",
    "tafsir.panel.title": "Tafsir", "tafsir.panel.select": "Tafsir wählen…", "tafsir.panel.mizan": "Tafsir al-Mizan", "tafsir.panel.mizanNote": "Auf almizan.org lesen →",
    "nav.tafsir": "Tafsir",
    "hub.kicker": "Kommandozentrale", "hub.title": "Alle Tore der Imam Mahdi Civilization", "hub.subtitle": "Jedes Reich, jedes Werkzeug, jedes Tor — eine leuchtende Steuertafel.",
    "hub.library": "Bibliothek", "hub.videos": "Videos", "hub.academy": "Akademie", "hub.academyAi": "Mahdi KI-Akademie", "hub.articles": "Artikel", "hub.community": "Gemeinschaft",
    "hub.qibla": "Qibla", "hub.tasbih": "Tasbih", "hub.names": "99 Namen", "hub.khatam": "Khatm", "hub.zakat": "Zakat",
    "hub.inheritance": "Erbe", "hub.mosques": "Moscheen", "hub.events": "Veranstaltungen", "hub.about": "Über uns",
    "hub.d.quran": "Lies den Heiligen Koran mit Übersetzung, Audio und Tafsir.",
    "hub.d.tafsir": "Tafsir al-Mizan und neun klassische Exegesen.",
    "hub.d.hadith": "Authentische Überlieferungen des Propheten und der Ahl al-Bayt.",
    "hub.d.duas": "Tägliche Bittgebete und heilige Anrufungen.",
    "hub.d.ai": "Der N-Eyes islamische KI-Assistent.",
    "hub.d.daily": "Gebetszeiten, Vers, Hadith und Du'a des Tages.",
    "hub.d.realms": "Die acht Säulen der Zivilisation.",
    "hub.d.library": "Tausende digitale islamische Bücher.",
    "hub.d.videos": "Kuratierte islamische Medien und Kanäle.",
    "hub.d.academy": "Strukturierte Lernpfade und Kurse.", "hub.d.academyAi": "KI-Techschule für muslimische Kinder.",
    "hub.d.articles": "Forschung, Essays und Langtexte.",
    "hub.d.community": "Foren, Lernkreise und globale Zentren.",
    "hub.d.qibla": "Finde die Qibla von deinem Standort.",
    "hub.d.tasbih": "Digitaler Dhikr-Zähler.",
    "hub.d.names": "Die 99 schönen Namen Allahs.",
    "hub.d.khatam": "Gruppen-Khatm-Tracker für den Koran.",
    "hub.d.zakat": "Berechne deine Zakat präzise.",
    "hub.d.inheritance": "Islamischer Erbschaftsrechner.",
    "hub.d.mosques": "Entdecke nahegelegene Moscheen weltweit.",
    "hub.d.events": "Majalis, Konferenzen und Versammlungen.",
    "hub.d.about": "Unsere Mission, Vision und Gründer.",
    "hub.d.join": "Schließe dich der Vorhut der Imam Mahdi Civilization an.",
    "hub.d.donate": "Unterstütze diese digitale Zivilisation.",
    "hub.d.signin": "Betritt dein persönliches Heiligtum.",
  },
  ru: { "lang.choose": "Язык" },
  zh: { "lang.choose": "语言" },
  bn: { "lang.choose": "ভাষা" },
  hi: { "lang.choose": "भाषा" },
  id: { "lang.choose": "Bahasa" },
};

/** localStorage key for the chosen interface language. */
export const LANG_STORAGE_KEY = "imc_language";
/** Key used before the universal preference system; still honoured. */
const LEGACY_LANG_KEY = "lang";

export function isLang(value: unknown): value is Lang {
  return typeof value === "string" && LANGUAGES.some((l) => l.code === value);
}

/** Reads the saved language, ignoring corrupted or unknown values. */
export function readStoredLang(): Lang | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(LANG_STORAGE_KEY) ?? localStorage.getItem(LEGACY_LANG_KEY);
    if (!raw) return null;
    const value = raw.trim().toLowerCase();
    return isLang(value) ? value : null;
  } catch {
    return null;
  }
}

export function writeStoredLang(l: Lang): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(LANG_STORAGE_KEY, l);
    // Keep the legacy key in step so an older tab does not fight the new one.
    localStorage.setItem(LEGACY_LANG_KEY, l);
  } catch {
    /* storage unavailable — the preference simply does not persist */
  }
}

/**
 * Maps a BCP-47 tag to a supported language.
 * Every Arabic regional tag (ar, ar-SA, ar-AE, ar-IQ, ar-KW, ar-QA, ar-BH,
 * ar-OM, ar-JO …) resolves to Arabic; Urdu tags resolve to Urdu, and so on.
 */
export function langFromTag(tag: string | undefined | null): Lang | null {
  if (!tag) return null;
  const base = tag.trim().toLowerCase().split(/[-_]/)[0];
  if (!base) return null;
  const direct: Record<string, Lang> = {
    ar: "ar", ur: "ur", fa: "fa", en: "en", tr: "tr", fr: "fr", de: "de",
    ru: "ru", zh: "zh", bn: "bn", hi: "hi", id: "id",
    // Close relatives that read Urdu/Persian/Indonesian comfortably.
    ps: "ur", pa: "ur", sd: "ur", ms: "id", prs: "fa", tg: "fa",
  };
  return direct[base] ?? null;
}

/** First supported language among the browser's preferences. */
export function detectBrowserLang(): Lang | null {
  if (typeof navigator === "undefined") return null;
  const tags = [
    ...(Array.isArray(navigator.languages) ? navigator.languages : []),
    navigator.language,
  ].filter(Boolean) as string[];
  for (const tag of tags) {
    const match = langFromTag(tag);
    if (match) return match;
  }
  return null;
}

/** Country code → language, used only as a last resort before English. */
const COUNTRY_LANG: Record<string, Lang> = {
  SA: "ar", AE: "ar", IQ: "ar", KW: "ar", QA: "ar", BH: "ar", OM: "ar", JO: "ar",
  EG: "ar", SY: "ar", LB: "ar", YE: "ar", LY: "ar", SD: "ar", TN: "ar", DZ: "ar",
  MA: "ar", MR: "ar", PS: "ar", SO: "ar", DJ: "ar", KM: "ar",
  PK: "ur", IR: "fa", AF: "fa", TJ: "fa", TR: "tr", BD: "bn", IN: "hi",
  ID: "id", MY: "id", CN: "zh", RU: "ru", FR: "fr", DE: "de", AT: "de", CH: "de",
};

/**
 * Country lookup over IP. Deliberately fire-and-forget:
 * it is started after the page has rendered, it aborts after two seconds, and
 * any failure is swallowed so nothing about the page depends on the service.
 * No API key is involved, so there is no secret to expose.
 */
async function detectCountryLang(signal: AbortSignal): Promise<Lang | null> {
  try {
    const res = await fetch("https://ipapi.co/country/", { signal, cache: "no-store" });
    if (!res.ok) return null;
    const code = (await res.text()).trim().toUpperCase().slice(0, 2);
    return COUNTRY_LANG[code] ?? null;
  } catch {
    return null;
  }
}

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (k: string) => string;
  dir: "ltr" | "rtl";
  /** True once the client has resolved the visitor's language. */
  ready: boolean;
  /** True when the visitor has never chosen a language explicitly. */
  unset: boolean;
};
const I18nContext = createContext<Ctx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  const [ready, setReady] = useState(false);
  const [unset, setUnset] = useState(true);

  // Resolution order: saved choice → browser language → IP country → English.
  useEffect(() => {
    const saved = readStoredLang();
    if (saved) {
      setLangState(saved);
      setUnset(false);
      setReady(true);
      return;
    }
    const browser = detectBrowserLang();
    if (browser) {
      setLangState(browser);
      setReady(true);
      return;
    }
    // Nothing usable locally: try the network, but never wait on it.
    setReady(true);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    let cancelled = false;
    detectCountryLang(controller.signal)
      .then((byCountry) => {
        // A choice made while the lookup was in flight always wins.
        if (cancelled || !byCountry || readStoredLang()) return;
        setLangState(byCountry);
      })
      .catch(() => {})
      .finally(() => clearTimeout(timer));
    return () => {
      cancelled = true;
      clearTimeout(timer);
      controller.abort();
    };
  }, []);

  const setLang = (l: Lang) => {
    const safe = isLang(l) ? l : "en";
    setLangState(safe);
    setUnset(false);
    writeStoredLang(safe);
    applyGoogleTranslate(safe);
  };

  const rtl = !!LANGUAGES.find((l) => l.code === lang)?.rtl;
  const dir = rtl ? "rtl" : "ltr";

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = dir;
      // Only pull in the (heavy) Google Translate widget when a non-English
      // language is actually in use — English visitors pay nothing for it.
      if (lang !== "en" || gtLoaded) {
        loadGoogleTranslate();
        applyGoogleTranslate(lang);
      }
    }
  }, [lang, dir]);

  const t = (k: string) => T[lang]?.[k] ?? T.en?.[k] ?? k;
  return (
    <I18nContext.Provider value={{ lang, setLang, t, dir, ready, unset }}>{children}</I18nContext.Provider>
  );
}

// ---- Google Translate integration (translates entire DOM live) ----
let gtLoaded = false;
function loadGoogleTranslate() {
  if (gtLoaded || typeof document === "undefined") return;
  gtLoaded = true;
  if (!document.getElementById("google_translate_element")) {
    const host = document.createElement("div");
    host.id = "google_translate_element";
    host.style.cssText = "position:fixed;left:-9999px;top:-9999px;visibility:hidden;";
    document.body.appendChild(host);
  }
  (window as any).googleTranslateElementInit = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const g = (window as any).google;
    if (g?.translate?.TranslateElement) {
      new g.translate.TranslateElement(
        { pageLanguage: "en", includedLanguages: "en,ur,fa,ar,tr,fr,de,ru,zh-CN,bn,hi,id", autoDisplay: false },
        "google_translate_element",
      );
    }
  };
  const s = document.createElement("script");
  s.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
  s.async = true;
  document.body.appendChild(s);
  // Hide the Google top banner & restore body position
  const style = document.createElement("style");
  style.textContent = `
    .goog-te-banner-frame, .skiptranslate { display: none !important; }
    body { top: 0 !important; }
    .goog-tooltip, .goog-tooltip:hover { display: none !important; }
    .goog-text-highlight { background: none !important; box-shadow: none !important; }
  `;
  document.head.appendChild(style);
}

function applyGoogleTranslate(lang: Lang) {
  if (typeof document === "undefined") return;
  const setCookie = (v: string) => {
    document.cookie = `googtrans=${v};path=/`;
    const host = location.hostname;
    document.cookie = `googtrans=${v};path=/;domain=${host}`;
    const parts = host.split(".");
    if (parts.length > 1) document.cookie = `googtrans=${v};path=/;domain=.${parts.slice(-2).join(".")}`;
  };
  const gcode = lang === "zh" ? "zh-CN" : lang;
  const val = lang === "en" ? "/en/en" : `/en/${gcode}`;
  setCookie(val);

  const trigger = () => {
    const sel = document.querySelector<HTMLSelectElement>("select.goog-te-combo");
    if (!sel) return false;
    sel.value = gcode;
    sel.dispatchEvent(new Event("change"));
    return true;
  };
  if (!trigger()) {
    let tries = 0;
    const iv = setInterval(() => {
      tries++;
      if (trigger() || tries > 40) clearInterval(iv);
    }, 80);
  }
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    return {
      lang: "en" as Lang,
      setLang: () => {},
      t: (k: string) => T.en?.[k] ?? k,
      dir: "ltr" as const,
      ready: false,
      unset: true,
    };
  }
  return ctx;
}