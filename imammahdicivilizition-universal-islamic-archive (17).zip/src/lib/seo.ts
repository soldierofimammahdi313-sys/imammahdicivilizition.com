import { SITE_URL, SITE_NAME } from "./site";

/**
 * Central SEO source of truth.
 *
 * Every indexable route pulls its <title>, <meta name="description">,
 * <meta name="keywords"> and canonical URL from here so no two pages
 * ever share the same description and every title stays inside the
 * 50–60 character window search engines render in full.
 */

export type PageSeo = {
  /** Page-specific part of the title; the site name suffix is appended. */
  title: string;
  /** 150–160 character unique summary. */
  description: string;
  /** Short 2–3 word search terms only. */
  keywords: string[];
  type?: "website" | "article";
};

const TITLE_SUFFIX = ` | ${SITE_NAME}`;

/** Clean, lowercase, hyphenated permalink segment. */
export function slugifyPath(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9\s/-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/\/{2,}/g, "/")
    .replace(/^-|-$/g, "");
}

/** Normalises any internal path to a clean lowercase hyphenated URL. */
export function cleanPath(path: string): string {
  if (!path || path === "/") return "/";
  const cleaned = slugifyPath(path.startsWith("/") ? path : `/${path}`);
  const withSlash = cleaned.startsWith("/") ? cleaned : `/${cleaned}`;
  return withSlash.length > 1 ? withSlash.replace(/\/$/, "") : "/";
}

/** Keeps only short, relevant 2–3 word search terms. */
export function normalizeKeywords(keywords: string[]): string {
  const seen = new Set<string>();
  const terms: string[] = [];
  for (const raw of keywords) {
    const term = raw.toLowerCase().replace(/[.,;:!?]/g, "").replace(/\s+/g, " ").trim();
    const words = term.split(" ").filter(Boolean);
    if (words.length < 1 || words.length > 3) continue;
    if (term.length > 30) continue;
    if (seen.has(term)) continue;
    seen.add(term);
    terms.push(term);
    if (terms.length === 10) break;
  }
  return terms.join(", ");
}

/** Trims a description into the 150–160 character sweet spot. */
export function clampDescription(text: string, max = 160): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${cut.slice(0, lastSpace > 120 ? lastSpace : max).replace(/[,;:\-–—]$/, "")}…`;
}

export function fullTitle(title: string): string {
  return title.endsWith(SITE_NAME) ? title : `${title}${TITLE_SUFFIX}`;
}

export type HeadInput = {
  path: string;
  title: string;
  description: string;
  keywords?: string[];
  type?: "website" | "article";
  /** Absolute or site-relative hero image for social previews. */
  image?: string | null;
  noindex?: boolean;
};

export function buildHead({
  path,
  title,
  description,
  keywords = [],
  type = "website",
  image,
  noindex,
}: HeadInput) {
  const url = `${SITE_URL}${cleanPath(path) === "/" ? "" : cleanPath(path)}`;
  const t = fullTitle(title);
  const d = clampDescription(description);
  const kw = normalizeKeywords(keywords);
  const img = image ? (image.startsWith("http") ? image : `${SITE_URL}${image}`) : null;

  return {
    meta: [
      { title: t },
      { name: "description", content: d },
      ...(kw ? [{ name: "keywords", content: kw }] : []),
      ...(noindex ? [{ name: "robots", content: "noindex, nofollow" }] : []),
      { property: "og:title", content: t },
      { property: "og:description", content: d },
      { property: "og:type", content: type },
      { property: "og:url", content: url },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: t },
      { name: "twitter:description", content: d },
      ...(img
        ? [
            { property: "og:image", content: img },
            { name: "twitter:image", content: img },
          ]
        : []),
    ],
    links: [{ rel: "canonical", href: url }],
  };
}

/** Per-route metadata. Descriptions are unique, 150–160 characters. */
export const PAGE_SEO: Record<string, PageSeo> = {
  "/": {
    title: "Universal Islamic Knowledge Archive",
    description:
      "Read the complete Quran, study authentic hadith and tafsir, browse a filterable Islamic library and explore the Hanafi, Shafi'i, Maliki, Hanbali and Ja'fari schools.",
    keywords: ["islamic archive", "quran online", "hadith study", "islamic library", "fiqh schools"],
  },
  "/about": {
    title: "About Our Mission & Vision",
    description:
      "Learn why Imam Mahdi Civilization exists: our mission, founding vision, the scholarly standards behind every module and the people building this digital ummah.",
    keywords: ["about us", "islamic mission", "digital ummah", "our vision"],
  },
  "/academy": {
    title: "Islamic Academy Learning Tracks",
    description:
      "Structured Islamic learning tracks covering aqidah, fiqh, seerah, Quranic Arabic and history, with progress tracking, lessons and quizzes for every level.",
    keywords: ["islamic academy", "online learning", "fiqh course", "quran study", "islamic lessons"],
  },
  "/academy-ai": {
    title: "Mahdi AI Academy for Kids",
    description:
      "An AI-powered tech school for Muslim children: guided coding and prompt lessons, an AI tutor, XP badges, parent reporting and a global student leaderboard.",
    keywords: ["ai academy", "muslim kids", "coding for kids", "ai tutor", "islamic education"],
  },
  "/ai": {
    title: "N-EYES Islamic AI Assistant",
    description:
      "Ask N-EYES about Quran, hadith, fiqh and Islamic history. Answers are grounded in cited classical sources so you can verify every ruling and narration yourself.",
    keywords: ["islamic ai", "fiqh questions", "quran answers", "ai assistant", "hadith search"],
  },
  "/articles": {
    title: "Islamic Articles & Research",
    description:
      "Browse essays and researched articles on Quranic reflection, hadith science, Islamic history, ethics and modern questions, each written with cited references.",
    keywords: ["islamic articles", "quran research", "hadith study", "islamic history", "muslim essays"],
  },
  "/auth": {
    title: "Sign In or Create Account",
    description:
      "Sign in with email or Google to save articles, sync your Quran progress, keep private journals and unlock the full Imam Mahdi Civilization member experience.",
    keywords: ["sign in", "create account", "member login"],
    type: "website",
  },
  "/battles": {
    title: "Battles of Islamic History",
    description:
      "Explore Badr, Uhud, Khandaq, Karbala and other decisive events with maps, timelines, participant details and sourced narrations explaining what happened.",
    keywords: ["islamic battles", "battle of badr", "karbala history", "seerah events"],
  },
  "/citation": {
    title: "Quran & Hadith Citation Tool",
    description:
      "Generate clean, accurate citations for Quranic verses and hadith narrations in academic formats, ready to paste into essays, research papers and lecture notes.",
    keywords: ["citation generator", "quran citation", "hadith reference", "research tool"],
  },
  "/community": {
    title: "Global Muslim Community Hub",
    description:
      "Meet believers worldwide: share reflections, ask questions, join study circles and take part in a respectful, moderated community built on knowledge and adab.",
    keywords: ["muslim community", "study circles", "islamic forum", "global ummah"],
  },
  "/contact": {
    title: "Contact the Imam Mahdi Team",
    description:
      "Reach the Imam Mahdi Civilization team with questions, corrections, partnership proposals, content reports or technical issues. We answer every message.",
    keywords: ["contact us", "support email", "report issue", "get in touch"],
  },
  "/cookies": {
    title: "Cookie Policy & Preferences",
    description:
      "Understand which cookies this site uses for sign-in, preferences, analytics and advertising, how long each lasts and how you can control or remove them anytime.",
    keywords: ["cookie policy", "site cookies", "privacy settings"],
  },
  "/daily": {
    title: "Daily Quran, Dua & Prayer",
    description:
      "Start each day with a Quranic verse, an authentic hadith, a recommended dua and accurate local prayer times, refreshed automatically every twenty-four hours.",
    keywords: ["daily quran", "daily hadith", "daily dua", "prayer times", "islamic routine"],
  },
  "/disclaimer": {
    title: "Content & Religious Disclaimer",
    description:
      "Read how content is sourced, why AI answers must be verified with qualified scholars and the limits of legal, medical and financial information published here.",
    keywords: ["site disclaimer", "content notice", "ai limitations"],
  },
  "/discussions": {
    title: "Community Discussion Board",
    description:
      "Open threads on aqidah, fiqh, history and daily practice. Ask a question, follow ongoing conversations and learn from answers backed by traceable references.",
    keywords: ["islamic discussions", "muslim forum", "ask question", "community threads"],
  },
  "/donate": {
    title: "Sadaqah Jariyah — Support Us",
    description:
      "Support ongoing charity: your contribution keeps the Quran reader, AI teaching tools, article archive and academy free for students in every country, forever.",
    keywords: ["sadaqah jariyah", "islamic charity", "support project", "donate online"],
  },
  "/duas": {
    title: "Daily Duas and Islamic Adhkar",
    description:
      "A curated collection of authentic duas and adhkar for morning, evening, travel, distress and gratitude, with Arabic text, transliteration and clear translation.",
    keywords: ["islamic duas", "daily adhkar", "morning dua", "evening dhikr"],
  },
  "/events": {
    title: "Islamic Calendar & Events",
    description:
      "Follow the Hijri calendar with Ramadan, Eid, Muharram, Ashura and other significant dates, plus concise background on the events each commemoration remembers.",
    keywords: ["islamic calendar", "hijri dates", "ramadan dates", "muharram events"],
  },
  "/family-tree": {
    title: "Prophet & Imams Family Tree",
    description:
      "An interactive lineage of the Prophet Muhammad and the Twelve Imams, mapping births, relationships and successions so the blessed chain is easy to follow.",
    keywords: ["family tree", "twelve imams", "prophet lineage", "ahlul bayt"],
  },
  "/fiqh": {
    title: "Schools of Islamic Jurisprudence",
    description:
      "An introduction to the Hanafi, Shafi'i, Maliki, Hanbali and Ja'fari schools of Islamic jurisprudence, with the archive material recorded under each tradition.",
    keywords: ["islamic jurisprudence", "fiqh schools", "hanafi fiqh", "jafari fiqh", "islamic law"],
  },
  "/fiqh/general": {
    title: "General and Shared Fiqh Material",
    description:
      "Material studied in common across the schools of Islamic jurisprudence, together with every archive entry whose school of law is not recorded in our catalogue.",
    keywords: ["general fiqh", "islamic law", "shared scholarship"],
    type: "article",
  },
  "/fiqh/hanafi": {
    title: "Hanafi School of Jurisprudence",
    description:
      "A short factual introduction to the Hanafi school, associated with Abu Hanifa al-Nu'man ibn Thabit of Kufa, and the related material held in our Islamic archive.",
    keywords: ["hanafi fiqh", "abu hanifa", "islamic jurisprudence", "hanafi school"],
    type: "article",
  },
  "/fiqh/shafii": {
    title: "Shafi'i School of Jurisprudence",
    description:
      "A short factual introduction to the Shafi'i school, associated with Muhammad ibn Idris al-Shafi'i and his work on legal principles, plus related archive material.",
    keywords: ["shafii fiqh", "al-shafii", "islamic jurisprudence", "usul al-fiqh"],
    type: "article",
  },
  "/fiqh/maliki": {
    title: "Maliki School of Jurisprudence",
    description:
      "A short factual introduction to the Maliki school, associated with Malik ibn Anas of Madina and his Muwatta, together with related material from our archive.",
    keywords: ["maliki fiqh", "malik ibn anas", "islamic jurisprudence", "al-muwatta"],
    type: "article",
  },
  "/fiqh/hanbali": {
    title: "Hanbali School of Jurisprudence",
    description:
      "A short factual introduction to the Hanbali school, associated with Ahmad ibn Hanbal of Baghdad and his Musnad, together with related material from our archive.",
    keywords: ["hanbali fiqh", "ahmad ibn hanbal", "islamic jurisprudence", "hanbali school"],
    type: "article",
  },
  "/fiqh/jafari": {
    title: "Ja'fari School of Jurisprudence",
    description:
      "A short factual introduction to the Ja'fari school, associated with Imam Ja'far al-Sadiq, its Four Books of hadith, and the Ja'fari material held in our archive.",
    keywords: ["jafari fiqh", "imam jafar al-sadiq", "islamic jurisprudence", "four books"],
    type: "article",
  },
  "/founder": {
    title: "The Founder of the Archive",
    description:
      "Who founded Imam Mahdi Civilization, the intention behind a free universal Islamic archive, and the editorial standards every page on this site is held to.",
    keywords: ["founder", "about founder", "project origin"],
  },
  "/shop": {
    title: "Islamic Books and Resources Shop",
    description:
      "Physical and digital resources offered alongside the free archive, with clear pricing and no advertising anywhere on the platform.",
    keywords: ["islamic shop", "islamic books", "muslim resources"],
  },
  "/who-is-imam-mahdi": {
    title: "Who Is Imam Mahdi? Sourced Answer",
    description:
      "What the Qur'an and the major hadith collections of both traditions record about the awaited Imam, with every reference named so that it can be checked.",
    keywords: ["imam mahdi", "awaited imam", "mahdi hadith", "islamic belief"],
    type: "article",
  },
  "/flashcards": {
    title: "Islamic Flashcards & Review",
    description:
      "Memorise Quranic vocabulary, hadith terms and fiqh rulings using spaced repetition flashcards that resurface each card exactly when you are about to forget it.",
    keywords: ["islamic flashcards", "spaced repetition", "quran vocabulary", "memorise hadith"],
  },
  "/hadith": {
    title: "Authentic Hadith Library",
    description:
      "Search thousands of narrations by theme, narrator and collection, each shown with its chain, grading and full text so you can study hadith with real confidence.",
    keywords: ["hadith library", "hadith search", "authentic narrations", "sunnah collection"],
  },
  "/inheritance": {
    title: "Islamic Inheritance Calculator",
    description:
      "Work out mirath shares for heirs according to Ja'fari jurisprudence with a guided calculator that explains each portion and the reasoning behind the division.",
    keywords: ["inheritance calculator", "islamic mirath", "estate shares", "jafari fiqh"],
  },
  "/isnad": {
    title: "Isnad Chain of Narrators",
    description:
      "Visualise the chain of transmission behind a narration, inspect each narrator in the isnad and see how scholars evaluated their reliability across generations.",
    keywords: ["isnad viewer", "hadith chain", "narrator study", "hadith science"],
  },
  "/join": {
    title: "Join and Build With Our Team",
    description:
      "Apply to contribute as a writer, translator, developer, designer or teacher and help build the world's most complete free Islamic knowledge platform with us.",
    keywords: ["join team", "volunteer islamic", "contribute project", "apply now"],
  },
  "/journal": {
    title: "Private Reflection Journal",
    description:
      "Keep a private tadabbur journal: record duas, verse reflections and spiritual goals, review past entries and watch your relationship with the Quran deepen.",
    keywords: ["islamic journal", "tadabbur notes", "dua diary", "spiritual growth"],
  },
  "/khatam": {
    title: "Quran Khatam Progress Tracker",
    description:
      "Plan and track a full Quran completion: set a target date, log daily pages or juz, monitor your streak and finish your khatam without losing momentum.",
    keywords: ["khatam tracker", "quran progress", "reading plan", "juz tracker"],
  },
  "/library": {
    title: "Universal Islamic Digital Archive",
    description:
      "Browse books, research, manuscripts and documents across tafsir, hadith, history and jurisprudence, filtered by school of fiqh, topic, author, language and type.",
    keywords: ["islamic library", "islamic archive", "online books", "tafsir books", "islamic research"],
  },
  "/maps": {
    title: "Sacred Sites & Islamic Maps",
    description:
      "Explore Makkah, Madinah, Karbala, Najaf and Samarra through interactive maps that place each sacred site in its geography, history and pilgrimage context.",
    keywords: ["sacred maps", "karbala map", "makkah madinah", "islamic geography"],
  },
  "/media": {
    title: "Islamic Media & Audio Center",
    description:
      "Listen to lectures, podcasts, audiobooks, nasheed and noha in one place, with curated playlists that make Islamic learning easy during commutes and chores.",
    keywords: ["islamic media", "islamic podcast", "nasheed audio", "lecture library"],
  },
  "/modules": {
    title: "All Platform Modules & Tools",
    description:
      "See every tool the platform offers: Quran reader, hadith library, calculators, academy, AI assistants, community spaces and trackers, in one clear grid.",
    keywords: ["platform modules", "islamic tools", "feature grid", "site directory"],
  },
  "/mosques": {
    title: "Mosque Finder Near Your Area",
    description:
      "Find mosques and prayer spaces near your location with directions, and check congregation timings before you travel so you never miss a jamaat prayer again.",
    keywords: ["mosque finder", "masjid near", "prayer space", "jamaat timings"],
  },
  "/names": {
    title: "The 99 Names of Allah Explained",
    description:
      "Study Asma-ul-Husna one name at a time with Arabic script, transliteration, meaning and reflection notes to help you memorise and internalise each attribute.",
    keywords: ["99 names", "asma ul husna", "names of allah", "islamic dhikr"],
  },
  "/privacy": {
    title: "Privacy Policy and Your Data",
    description:
      "Learn exactly what data we collect, why we collect it, how long we keep it, who can access it and the simple steps you can take to export or delete it.",
    keywords: ["privacy policy", "data protection", "user data"],
  },
  "/qibla": {
    title: "Qibla Compass Direction Finder",
    description:
      "Point your device towards the Kaaba with a live qibla compass that uses your location and device sensors to show the exact prayer direction wherever you are.",
    keywords: ["qibla compass", "prayer direction", "kaaba direction", "find qibla"],
  },
  "/quran": {
    title: "Read the Complete Noble Quran",
    description:
      "Read all 114 surahs with Arabic script, English and Urdu translation, verse-by-verse audio recitation and tafsir, hosted entirely on this site for fast access.",
    keywords: ["read quran", "quran online", "quran translation", "quran audio", "surah list"],
  },
  "/realms": {
    title: "The Eight Realms Overview",
    description:
      "Tour the eight realms of the platform — knowledge, worship, community, media, academy, tools, archive and intelligence — and see what each realm contains.",
    keywords: ["eight realms", "site overview", "platform guide"],
  },
  "/search": {
    title: "Search Quran, Hadith & Articles",
    description:
      "Search across the Quran, hadith collections, articles, tools and discussions from one box, with ranked results that point you straight to the passage you need.",
    keywords: ["islamic search", "quran search", "hadith search", "site search"],
  },
  "/simulator": {
    title: "Islamic Civilization Simulator",
    description:
      "Govern a simulated society by the standards of justice taught by the Imams: balance economy, education, welfare and ethics, then see the consequences unfold.",
    keywords: ["islamic simulator", "civilization game", "justice simulation", "learning game"],
  },
  "/tafsir-al-mizan": {
    title: "Tafsir al-Mizan by Tabatabai",
    description:
      "Study Allamah Tabatabai's al-Mizan verse by verse, with the Quran-by-Quran method that made this tafsir one of the most influential commentaries of our era.",
    keywords: ["tafsir al-mizan", "tabatabai tafsir", "quran commentary", "quran exegesis"],
  },
  "/tasbih": {
    title: "Digital Tasbih Dhikr Counter",
    description:
      "Count your dhikr with a digital tasbih that saves totals between sessions, supports custom targets and keeps Tasbih of Fatima Zahra always one tap away.",
    keywords: ["digital tasbih", "dhikr counter", "tasbih fatima", "count dhikr"],
  },
  "/terms": {
    title: "Terms of Service and Site Use",
    description:
      "The rules for using this platform: acceptable use, account responsibilities, content ownership, moderation, liability limits and how these terms may change.",
    keywords: ["terms of service", "usage rules", "user agreement"],
  },
  "/timeline": {
    title: "Islamic History Timeline",
    description:
      "Follow Islamic history from the first revelation to the Major Occultation, with dated milestones, key figures and context that ties every era to the next.",
    keywords: ["islamic timeline", "muslim history", "revelation history", "occultation era"],
  },
  "/videos": {
    title: "Islamic Video Lecture Center",
    description:
      "Watch curated lectures, documentaries, short reminders and explainer videos on Quran, hadith, history and practice, organised into easy-to-follow playlists.",
    keywords: ["islamic videos", "muslim lectures", "video library", "islamic documentary"],
  },
  "/zakat": {
    title: "Zakat Calculator for Muslims",
    description:
      "Calculate zakat on cash, gold, silver, business assets and investments against the current silver nisab, and see precisely how much is due before you give.",
    keywords: ["zakat calculator", "calculate zakat", "nisab value", "islamic charity"],
  },
};

/** Head for a static page defined in PAGE_SEO. */
export function pageHead(path: string, extra?: Partial<HeadInput>) {
  const seo = PAGE_SEO[path];
  if (!seo) {
    return buildHead({
      path,
      title: SITE_NAME,
      description:
        "A global Islamic digital platform uniting the Quran, hadith, education, AI tools and community in one free, carefully sourced knowledge experience.",
      keywords: ["islamic platform", "quran online", "hadith study"],
      ...extra,
    });
  }
  return buildHead({
    path,
    title: seo.title,
    description: seo.description,
    keywords: seo.keywords,
    type: seo.type ?? "website",
    ...extra,
  });
}
