import { createServerFn } from "@tanstack/react-start";

/**
 * Light "first visitor of the day" trigger for the daily autopilot.
 * Cheap DB read first: only runs the (expensive) autopilot when the last run
 * is older than 24h, the job isn't paused, and no lease is held.
 * The run itself stays bounded/single-flight/idempotent inside runDailyAutopilot.
 */
export const maybeRunDailyAutopilot = createServerFn({ method: "POST" }).handler(
  async (): Promise<{ triggered: boolean; reason: string }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: state } = await supabaseAdmin
      .from("autopilot_state")
      .select("paused, lease_until, last_run_date, last_success_at")
      .eq("id", "daily")
      .maybeSingle();

    if (!state) return { triggered: false, reason: "no-state" };
    if (state.paused) return { triggered: false, reason: "paused" };

    const today = new Date().toISOString().slice(0, 10);
    if (state.last_run_date === today) return { triggered: false, reason: "already-ran-today" };

    const now = Date.now();
    if (state.lease_until && new Date(state.lease_until).getTime() > now) {
      return { triggered: false, reason: "locked" };
    }
    if (state.last_success_at && now - new Date(state.last_success_at).getTime() < 24 * 60 * 60 * 1000) {
      return { triggered: false, reason: "within-24h" };
    }

    const { runDailyAutopilot } = await import("@/lib/autopilot.server");
    const result = await runDailyAutopilot();
    return { triggered: true, reason: `${result.status}: ${result.detail}` };
  },
);
