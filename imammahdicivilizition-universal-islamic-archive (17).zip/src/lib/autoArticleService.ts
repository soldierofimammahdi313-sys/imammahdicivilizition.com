/**
 * Client-side service for the Auto Article Generator.
 *
 * Generation happens on the server (admin-only, keys never leave the
 * backend); this module only calls the server function and keeps a local
 * history of generated articles in localStorage.
 */

import { generateAutoArticle, type GeneratedArticle } from "./auto-article.functions";

export type Article = GeneratedArticle & {
  id: string;
  createdAt: string;
};

const STORAGE_KEY = "imc_auto_articles";

export function getSavedArticles(): Article[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Article[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function save(articles: Article[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(articles.slice(0, 100)));
  } catch {
    // storage full / unavailable — history is best-effort only
  }
}

export async function generateNewArticle(
  topic: string | undefined,
  language: "urdu" | "english" | "arabic",
): Promise<Article> {
  const generated = await generateAutoArticle({
    data: { topic: topic?.trim() || undefined, language },
  });

  const article: Article = {
    ...generated,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  };

  save([article, ...getSavedArticles()]);
  return article;
}

export function clearSavedArticles() {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
