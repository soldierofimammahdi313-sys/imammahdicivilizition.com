import { createServerFn } from "@tanstack/react-start";
import { useSession } from "@tanstack/react-start/server";
import { createHash, timingSafeEqual } from "node:crypto";

type GateSession = { unlocked?: boolean };

function sessionConfig() {
  return {
    password: process.env["ADMIN_SESSION_SECRET"]!,
    name: "secret-admin",
    maxAge: 60 * 60 * 24 * 7,
    cookie: { httpOnly: true, secure: true, sameSite: "lax" as const, path: "/" },
  };
}

function matches(input: string, expected: string) {
  const a = createHash("sha256").update(input, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}

async function requireUnlocked() {
  const session = await useSession<GateSession>(sessionConfig());
  if (!session.data.unlocked) throw new Response("Locked", { status: 401 });
}

export const unlockAdmin = createServerFn({ method: "POST" })
  .inputValidator((d: { password: string }) => d)
  .handler(async ({ data }) => {
    const expected = process.env["ADMIN_PORTAL_PASSWORD"];
    if (!expected) throw new Error("ADMIN_PORTAL_PASSWORD is not set");
    if (!matches(data.password, expected)) return { ok: false as const };
    const session = await useSession<GateSession>(sessionConfig());
    await session.update({ unlocked: true });
    return { ok: true as const };
  });

export const adminStatus = createServerFn({ method: "GET" }).handler(async () => {
  const session = await useSession<GateSession>(sessionConfig());
  return { unlocked: Boolean(session.data.unlocked) };
});

export const lockAdmin = createServerFn({ method: "POST" }).handler(async () => {
  const session = await useSession<GateSession>(sessionConfig());
  await session.clear();
  return { ok: true as const };
});

export const adminListArticles = createServerFn({ method: "GET" }).handler(async () => {
  await requireUnlocked();
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("articles")
    .select("id,slug,title,excerpt,content,status")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const adminSaveArticle = createServerFn({ method: "POST" })
  .inputValidator(
    (d: { id?: string; slug: string; title: string; excerpt: string; content: string }) => d,
  )
  .handler(async ({ data }) => {
    await requireUnlocked();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const slug = (data.slug || data.title)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    const payload = {
      slug,
      title: data.title,
      excerpt: data.excerpt || null,
      content: data.content,
      status: "published",
      published_at: new Date().toISOString(),
    };
    const { error } = data.id
      ? await supabaseAdmin.from("articles").update(payload).eq("id", data.id)
      : await supabaseAdmin.from("articles").insert(payload);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

/** Generates AI cover images for articles that still have none (small batch per call). */
export const adminBackfillCovers = createServerFn({ method: "POST" })
  .inputValidator((d: { limit?: number } | undefined) => d ?? {})
  .handler(async ({ data }) => {
    await requireUnlocked();
    const limit = Math.min(Math.max(data.limit ?? 3, 1), 5);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { generateArticleCover } = await import("@/lib/article-image.server");

    const { data: rows, error } = await supabaseAdmin
      .from("articles")
      .select("id,slug,title")
      .is("cover_url", null)
      .limit(limit);
    if (error) throw new Error(error.message);

    let done = 0;
    let failed = 0;
    for (const row of rows ?? []) {
      const url = await generateArticleCover({ slug: row.slug, title: row.title });
      if (!url) {
        failed += 1;
        continue;
      }
      await supabaseAdmin.from("articles").update({ cover_url: url }).eq("id", row.id);
      done += 1;
    }

    const { count } = await supabaseAdmin
      .from("articles")
      .select("id", { count: "exact", head: true })
      .is("cover_url", null);

    return { done, failed, remaining: count ?? 0 };
  });

export const adminDeleteArticle = createServerFn({ method: "POST" })
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    await requireUnlocked();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("articles").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
