/**
 * Digital Library — our own written catalogue.
 * Every entry is described in our own words and links only to pages we host.
 * No external website links are used anywhere in the library.
 */
import type { FiqhId } from "./fiqh";

/** Kinds of material the archive holds. */
export const ARCHIVE_TYPES = ["book", "research", "manuscript", "article", "document"] as const;
export type ArchiveType = (typeof ARCHIVE_TYPES)[number];

/** Translation key for a content type label. */
export const archiveTypeKey = (t: ArchiveType) => `library.type.${t}`;
export type LibraryBook = {
  slug: string;
  title: string;
  arabic: string;
  author: string;
  era: string;
  category: string;
  /**
   * Schools of jurisprudence the work is associated with, taken only from what
   * the entry itself records. "general" means it is not tied to one school —
   * it is never a guess.
   */
  fiqh: FiqhId[];
  /** What kind of item this is in the archive. */
  type: ArchiveType;
  summary: string;
  about: string[];
  structure: string[];
  /** Internal routes where related material is hosted on this site. */
  readOn: { label: string; to: string }[];
};

export const LIBRARY_BOOKS: LibraryBook[] = [
  {
    slug: "the-holy-quran",
    title: "The Holy Qur'an",
    arabic: "القرآن الكريم",
    author: "Revelation to the Prophet Muhammad ﷺ",
    era: "610–632 CE",
    category: "Qur'an",
    fiqh: ["general"],
    type: "book",
    summary:
      "The complete Qur'an — 114 surahs and 6,236 verses — hosted on this site in Arabic with English and Urdu translation and recitation.",
    about: [
      "The Qur'an was revealed over roughly twenty-three years, first in Makkah and then in Madinah, and was preserved both in memory and in writing from the lifetime of the Prophet ﷺ onward.",
      "Makkan surahs generally address belief, accountability and the moral reform of the individual; Madinan surahs deal more with law, community life, treaties and social justice.",
      "On this site the entire text is stored locally, so the reader works offline-friendly and without depending on any outside service.",
    ],
    structure: [
      "114 surahs, ordered as in the standard mushaf",
      "6,236 verses, divided into 30 ajza' for recitation",
      "Arabic text with English and Urdu translation side by side",
      "Verse-by-verse audio recitation",
    ],
    readOn: [
      { label: "Open the Qur'an reader", to: "/quran" },
      { label: "Tafsir al-Mizan", to: "/tafsir-al-mizan" },
    ],
  },
  {
    slug: "nahj-al-balagha",
    title: "Nahj al-Balagha",
    arabic: "نهج البلاغة",
    author: "Sayings of Imam Ali (a.s.), compiled by al-Sharif al-Radi",
    era: "compiled c. 400 AH",
    category: "Sermons & Letters",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "A compilation of sermons, letters and short sayings attributed to Imam Ali ibn Abi Talib (a.s.), assembled for their eloquence and moral depth.",
    about: [
      "Al-Sharif al-Radi (d. 406 AH) gathered the material in the late fourth century AH, choosing passages he considered the height of Arabic eloquence.",
      "The sermons deal with the unity of God, creation, death, leadership and the duties of a just ruler; the letters include the well-known instruction to Malik al-Ashtar on governance.",
      "It has remained a core text of ethics and political guidance in Muslim scholarship for a thousand years.",
    ],
    structure: [
      "Part one — sermons (khutab)",
      "Part two — letters and instructions (rasa'il)",
      "Part three — short sayings and aphorisms (hikam)",
    ],
    readOn: [
      { label: "Sayings in the live narration ticker", to: "/" },
      { label: "Articles on Imam Ali (a.s.)", to: "/articles" },
    ],
  },
  {
    slug: "sahifa-al-sajjadiyya",
    title: "Al-Sahifa al-Sajjadiyya",
    arabic: "الصحيفة السجادية",
    author: "Imam Zayn al-'Abidin (a.s.)",
    era: "1st century AH",
    category: "Supplication",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "A collection of supplications transmitted from the fourth Imam, often called the Psalms of the Household of the Prophet.",
    about: [
      "The supplications were taught after the events of Karbala, in a period when direct public teaching was dangerous, and prayer became the medium of instruction.",
      "The themes move from praise of God and gratitude, through repentance and hardship, to prayers for parents, neighbours, borders and the wider community.",
      "It is valued as much for its theology as for its devotion: much of what it teaches about divine mercy and human need is expressed only in the form of prayer.",
    ],
    structure: [
      "Fifty-four principal supplications",
      "Prayers for daily and weekly occasions",
      "Prayers for Ramadan, Eid and the changing of the year",
      "Whispered prayers (munajat) on repentance and hope",
    ],
    readOn: [
      { label: "Duʿāʾ collection", to: "/duas" },
      { label: "Daily devotion", to: "/daily" },
    ],
  },
  {
    slug: "al-kafi",
    title: "Al-Kafi",
    arabic: "الكافي",
    author: "Shaykh Muhammad ibn Ya'qub al-Kulayni",
    era: "d. 329 AH",
    category: "Hadith",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "The earliest and most cited of the four major Shi'i hadith collections, arranged by subject across belief, law and manners.",
    about: [
      "Al-Kulayni compiled the work over about twenty years, drawing on the written notebooks (usul) of earlier narrators.",
      "It is organised in three broad divisions: al-Usul on doctrine, al-Furu' on jurisprudence, and al-Rawda, a miscellany of longer reports and letters.",
      "Later scholars examined its chains of transmission in detail; inclusion in al-Kafi is treated as significant but not as automatic authentication.",
    ],
    structure: [
      "Usul al-Kafi — reason, knowledge, divine unity, proof and leadership",
      "Furu' al-Kafi — purity, prayer, fasting, hajj, trade, marriage, inheritance",
      "Al-Rawda — assorted narrations, sermons and letters",
    ],
    readOn: [
      { label: "Hadith library", to: "/hadith" },
      { label: "Chains of transmission (isnad)", to: "/isnad" },
    ],
  },
  {
    slug: "man-la-yahduruhu-al-faqih",
    title: "Man La Yahduruhu al-Faqih",
    arabic: "من لا يحضره الفقيه",
    author: "Shaykh al-Saduq",
    era: "d. 381 AH",
    category: "Hadith",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "A practical legal hadith collection written so that a believer without access to a jurist could still find guidance.",
    about: [
      "The title means roughly 'for one who has no jurist at hand', and the arrangement follows the practical order of worship and daily transactions.",
      "Al-Saduq shortened chains of transmission and listed his sources in an appendix, an approach that later scholars studied closely.",
      "It remains one of the four books relied upon in Ja'fari jurisprudence.",
    ],
    structure: [
      "Purity and prayer",
      "Fasting, zakat and hajj",
      "Trade, marriage, divorce and inheritance",
      "Appendix of transmission routes",
    ],
    readOn: [
      { label: "Hadith library", to: "/hadith" },
      { label: "Inheritance calculator (Fiqh Ja'fari)", to: "/inheritance" },
    ],
  },
  {
    slug: "tahdhib-al-ahkam",
    title: "Tahdhib al-Ahkam",
    arabic: "تهذيب الأحكام",
    author: "Shaykh al-Tusi",
    era: "d. 460 AH",
    category: "Hadith",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "A large legal hadith collection written to reconcile apparent contradictions between reports on points of law.",
    about: [
      "Al-Tusi began the work as a commentary on a legal treatise of Shaykh al-Mufid and expanded it into a full collection.",
      "Its distinctive contribution is method: where two reports conflict, he sets out how they may be harmonised or which is preferred.",
      "Together with his companion volume al-Istibsar it completes the four books of Shi'i hadith.",
    ],
    structure: [
      "Chapters following the standard order of jurisprudence",
      "Conflicting reports presented side by side",
      "Reconciliation and preference discussed by the author",
    ],
    readOn: [
      { label: "Hadith library", to: "/hadith" },
      { label: "Citation tools", to: "/citation" },
    ],
  },
  {
    slug: "bihar-al-anwar",
    title: "Bihar al-Anwar",
    arabic: "بحار الأنوار",
    author: "Allamah Muhammad Baqir al-Majlisi",
    era: "d. 1110 AH",
    category: "Encyclopaedia",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "An encyclopaedic gathering of narrations across every subject, assembled to preserve material scattered in rare manuscripts.",
    about: [
      "Al-Majlisi's aim was preservation rather than selection, so the work records reports of very different levels of reliability.",
      "Because of this, scholars treat it as an archive to be examined, not as a book where every report carries equal weight.",
      "Its breadth covers creation, prophets, history, ethics, cosmology, medicine and the lives of the Imams.",
    ],
    structure: [
      "Volumes on divine unity and justice",
      "Volumes on the prophets and the life of the Prophet ﷺ",
      "Volumes on each of the twelve Imams",
      "Volumes on ethics, supplication and the hereafter",
    ],
    readOn: [
      { label: "Hadith library", to: "/hadith" },
      { label: "Historical timeline", to: "/timeline" },
    ],
  },
  {
    slug: "sahih-al-bukhari",
    title: "Sahih al-Bukhari",
    arabic: "صحيح البخاري",
    author: "Imam Muhammad ibn Isma'il al-Bukhari",
    era: "d. 256 AH",
    category: "Hadith",
    fiqh: ["hanafi", "shafii", "maliki", "hanbali"],
    type: "book",
    summary:
      "The best known Sunni hadith collection, compiled according to strict conditions of continuous and reliable transmission.",
    about: [
      "Al-Bukhari travelled widely to hear narrations directly and selected a small fraction of the material he collected.",
      "The chapter headings themselves carry legal reasoning, so the arrangement is part of the scholarship.",
      "We include it because serious study compares what both major traditions transmit.",
    ],
    structure: [
      "Books arranged by subject, beginning with revelation and faith",
      "Worship, transactions, campaigns and manners",
      "Chapter titles that indicate the compiler's legal view",
    ],
    readOn: [{ label: "Hadith library", to: "/hadith" }],
  },
  {
    slug: "sahih-muslim",
    title: "Sahih Muslim",
    arabic: "صحيح مسلم",
    author: "Imam Muslim ibn al-Hajjaj",
    era: "d. 261 AH",
    category: "Hadith",
    fiqh: ["hanafi", "shafii", "maliki", "hanbali"],
    type: "book",
    summary:
      "A companion collection to al-Bukhari, noted for gathering all versions of a report together in one place.",
    about: [
      "Muslim grouped the variant wordings and chains of a single narration together, which makes comparison easier than in most collections.",
      "The introduction is itself an early treatise on the science of hadith criticism.",
      "It is widely used alongside al-Bukhari in comparative study.",
    ],
    structure: [
      "An introduction on the method of authentication",
      "Books on faith, purity, prayer, zakat, fasting and hajj",
      "Books on transactions, governance, virtues and manners",
    ],
    readOn: [{ label: "Hadith library", to: "/hadith" }],
  },
  {
    slug: "tafsir-al-mizan",
    title: "Tafsir al-Mizan",
    arabic: "الميزان في تفسير القرآن",
    author: "Allamah Sayyid Muhammad Husayn Tabatabai",
    era: "20th century",
    category: "Tafsir",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "A twenty-volume commentary built on the principle of explaining the Qur'an by the Qur'an itself.",
    about: [
      "Tabatabai first reads a passage in the light of related verses, then brings narrations, and then discusses philosophical, historical and social questions in separate sections.",
      "This separation of method makes the reasoning transparent: the reader can see which conclusion rests on which kind of evidence.",
      "It is among the most influential Qur'anic commentaries written in the modern period.",
    ],
    structure: [
      "Verse groups presented together rather than one at a time",
      "Qur'anic discussion first, then narrations",
      "Separate philosophical, historical and social sections",
    ],
    readOn: [
      { label: "Tafsir al-Mizan section", to: "/tafsir-al-mizan" },
      { label: "Qur'an reader with tafsir panel", to: "/quran" },
    ],
  },
  {
    slug: "kitab-al-irshad",
    title: "Kitab al-Irshad",
    arabic: "كتاب الإرشاد",
    author: "Shaykh al-Mufid",
    era: "d. 413 AH",
    category: "History",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "An early biographical account of the twelve Imams, one of the primary sources for their lives and circumstances.",
    about: [
      "Al-Mufid writes as a theologian and historian together, giving events alongside the arguments made about succession.",
      "The section on Imam Husayn (a.s.) and Karbala is among the earliest surviving connected narratives of those events.",
      "Later historical writing in the tradition draws heavily on it.",
    ],
    structure: [
      "Life of Imam Ali (a.s.) in detail",
      "Successive chapters on each Imam",
      "Reports of designation, virtues and historical setting",
    ],
    readOn: [
      { label: "Historical timeline", to: "/timeline" },
      { label: "Family tree of the Ahl al-Bayt", to: "/family-tree" },
    ],
  },
  {
    slug: "mafatih-al-jinan",
    title: "Mafatih al-Jinan",
    arabic: "مفاتيح الجنان",
    author: "Shaykh Abbas al-Qummi",
    era: "d. 1359 AH",
    category: "Supplication",
    fiqh: ["jafari"],
    type: "book",
    summary:
      "The most widely used handbook of supplications, ziyarat and devotional practices through the Islamic year.",
    about: [
      "Al-Qummi drew the contents from earlier collections and noted his sources, which is why the book is trusted in ordinary practice.",
      "It is arranged by occasion — daily, weekly, monthly and by month of the Hijri calendar — so it functions as a devotional companion.",
      "Its final section gathers the well-known ziyarat texts.",
    ],
    structure: [
      "Daily and weekly supplications",
      "Prayers by Hijri month, especially Rajab, Sha'ban and Ramadan",
      "Recommended prayers (a'mal) for specific nights",
      "Ziyarat texts",
    ],
    readOn: [
      { label: "Duʿāʾ collection", to: "/duas" },
      { label: "Hijri calendar & occasions", to: "/events" },
    ],
  },
  {
    slug: "usul-al-fiqh-foundations",
    title: "Foundations of Ja'fari Jurisprudence",
    arabic: "أصول الفقه",
    author: "Our own study guide",
    era: "written for this site",
    category: "Fiqh",
    fiqh: ["jafari"],
    type: "research",
    summary:
      "An introductory guide, written for this site, to how rulings are derived in Ja'fari jurisprudence and how our calculators apply them.",
    about: [
      "Rulings rest on the Qur'an, the sunnah of the Prophet ﷺ and the Imams (a.s.), reason and consensus, weighed by an established method.",
      "The guide explains the vocabulary a reader meets constantly — obligatory, recommended, permissible, disliked, forbidden — and what taqlid means in practice.",
      "It also documents exactly which rules our zakat, khums and inheritance calculators implement, so results can be checked rather than trusted blindly.",
    ],
    structure: [
      "Sources of ruling and how they are weighed",
      "The five categories of legal value",
      "Following a qualified jurist (taqlid)",
      "How our calculators apply these rules",
    ],
    readOn: [
      { label: "Zakat & khums calculator", to: "/zakat" },
      { label: "Inheritance calculator", to: "/inheritance" },
    ],
  },
  {
    slug: "ninety-nine-names",
    title: "The Ninety-Nine Names of Allah",
    arabic: "أسماء الله الحسنى",
    author: "Our own reference edition",
    era: "written for this site",
    category: "Reference",
    fiqh: ["general"],
    type: "document",
    summary:
      "Our own reference edition of the divine names, with Arabic, transliteration and a careful English meaning for each.",
    about: [
      "The names are gathered from the Qur'an and the well-known narrated list, and are presented without added commentary beyond the meaning.",
      "Each entry gives the Arabic, a transliteration for readers who do not read Arabic script, and a concise translation.",
      "The list is used across the site by the dhikr counter and the daily devotion page.",
    ],
    structure: [
      "Ninety-nine entries in the traditional order",
      "Arabic, transliteration and English meaning",
      "Cross-linked to the dhikr counter",
    ],
    readOn: [
      { label: "The 99 Names", to: "/names" },
      { label: "Tasbih counter", to: "/tasbih" },
    ],
  },
  {
    slug: "karbala-narrative",
    title: "Karbala — A Documented Narrative",
    arabic: "واقعة كربلاء",
    author: "Our own compiled account",
    era: "written for this site",
    category: "History",
    fiqh: ["general", "jafari"],
    type: "research",
    summary:
      "A connected account of the events of 61 AH written for this site, following the sequence recorded in the early historical sources.",
    about: [
      "The account runs from the refusal of allegiance in Madinah, through the journey to Kufa and the encampment at Karbala, to the aftermath in Damascus.",
      "Where the early sources differ, the difference is stated rather than smoothed over.",
      "Nothing is added to the reports: no speech or detail appears here that is not found in the recorded histories.",
    ],
    structure: [
      "Madinah and Makkah — the refusal of allegiance",
      "The journey and the letters of Kufa",
      "The days at Karbala",
      "Aftermath: the captives, Kufa and Damascus",
    ],
    readOn: [
      { label: "Historical timeline", to: "/timeline" },
      { label: "Articles archive", to: "/articles" },
    ],
  },
  {
    slug: "imam-mahdi-sources",
    title: "The Awaited Imam — Source Readings",
    arabic: "الإمام المهدي (عج)",
    author: "Our own compiled reader",
    era: "written for this site",
    category: "Doctrine",
    fiqh: ["general", "jafari"],
    type: "research",
    summary:
      "A source-based reader on the belief in the awaited Imam, gathering what the Qur'an and the major hadith collections record.",
    about: [
      "The reader sets out the narrations found in both Shi'i and Sunni collections, with each reference named so it can be checked.",
      "It distinguishes clearly between what is transmitted, what is inferred, and what is popular assumption.",
      "Speculation about timing is not included; the sources themselves discourage it.",
    ],
    structure: [
      "What the Qur'an indicates about divine promise and justice",
      "Narrations recorded in Shi'i collections",
      "Narrations recorded in Sunni collections",
      "Responsibilities of those who await",
    ],
    readOn: [
      { label: "Who is Imam Mahdi?", to: "/who-is-imam-mahdi" },
      { label: "Articles archive", to: "/articles" },
    ],
  },
];

export function bookBySlug(slug: string): LibraryBook | undefined {
  return LIBRARY_BOOKS.find((b) => b.slug === slug);
}
