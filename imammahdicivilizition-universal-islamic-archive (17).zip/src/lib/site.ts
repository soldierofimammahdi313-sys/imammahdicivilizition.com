/** Single source of truth for the public site origin. */
export const SITE_URL = "https://imammahdicivilizition.com";

/** Absolute URL for a path such as "/about". */
export const abs = (path: string) => `${SITE_URL}${path === "/" ? "" : path}`;

export const SITE_NAME = "Imam Mahdi Civilization";
export const SITE_EMAIL = "imammahdicivilization@gmail.com";

export type BreadcrumbCrumb = { label: string; to?: string };

/** BreadcrumbList JSON-LD object for a trail (Home is prepended automatically). */
export const breadcrumbLd = (items: BreadcrumbCrumb[]) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [{ label: "Home", to: "/" }, ...items].map((c, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: c.label,
    ...(c.to ? { item: abs(c.to) } : {}),
  })),
});
