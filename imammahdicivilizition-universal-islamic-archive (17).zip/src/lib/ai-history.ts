import { supabase } from "@/integrations/supabase/client";
import type { UIMessage } from "ai";

export type StoredMessage = { id: string; role: string; content: string; created_at: string };

export function messageText(m: UIMessage) {
  return m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
}

export async function listConversations() {
  const { data } = await supabase
    .from("ai_conversations")
    .select("id,title,updated_at")
    .order("updated_at", { ascending: false })
    .limit(40);
  return data ?? [];
}

export async function loadConversation(conversationId: string) {
  const { data } = await supabase
    .from("ai_messages")
    .select("id,role,content,created_at")
    .eq("conversation_id", conversationId)
    .order("created_at");
  return (data ?? []) as StoredMessage[];
}

export async function createConversation(userId: string, title: string) {
  const { data, error } = await supabase
    .from("ai_conversations")
    .insert({ user_id: userId, title: title.slice(0, 80) || "New conversation" })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}

export async function appendMessage(conversationId: string, role: string, content: string) {
  const { error } = await supabase.from("ai_messages").insert({ conversation_id: conversationId, role, content });
  if (error) throw error;
  await supabase.from("ai_conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversationId);
}

export async function deleteConversation(conversationId: string) {
  await supabase.from("ai_messages").delete().eq("conversation_id", conversationId);
  await supabase.from("ai_conversations").delete().eq("id", conversationId);
}

export function toUiMessages(rows: StoredMessage[]): UIMessage[] {
  return rows.map((r) => ({
    id: r.id,
    role: r.role === "user" ? "user" : "assistant",
    parts: [{ type: "text", text: r.content }],
  })) as UIMessage[];
}