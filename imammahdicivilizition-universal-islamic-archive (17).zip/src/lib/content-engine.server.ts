/**
 * AI Islamic Content Engine — server-only pipeline.
 *
 * TOPIC → RESEARCH → WRITE → VERIFY → SEO → IMAGE → QUALITY → DUPLICATE → DRAFT
 *
 * Nothing here is ever imported by client code. Every AI call is metered into
 * content_api_usage so the admin cost monitor and the daily/monthly caps work.
 */
import { AiUnavailableError, callAi, parseJsonReply } from "@/lib/ai-providers.server";
import { coverFor } from "@/lib/article-covers";

export const NO_INVENTION_RULE = `ABSOLUTE RULE: never invent, paraphrase-as-quotation, or guess any Quranic verse, hadith, narration, du'a text, historical date or scholarly quotation. Only use texts you are certain exist verbatim in the classical sources, and cite them exactly (surah number:ayah number, or collection + volume/page or hadith number). If you are not certain a quotation is authentic, omit it entirely and write general explanation instead. Never attach a reference to a text you are unsure about. It is always better to write less than to fabricate.`;

export const PIPELINE_STAGES = [
  "idea",
  "researching",
  "generating",
  "verification",
  "draft",
  "approved",
  "scheduled",
  "published",
  "duplicate_review",
  "failed",
] as const;
export type PipelineStage = (typeof PIPELINE_STAGES)[number];

export type EngineSettings = {
  auto_publish: boolean;
  auto_image: boolean;
  auto_translation: boolean;
  auto_seo: boolean;
  auto_verification: boolean;
  articles_per_day: number;
  max_articles_per_day: number;
  publish_time: string;
  default_language: string;
  daily_generation_limit: number;
  monthly_generation_limit: number;
  min_quality_score: number;
  max_similarity: number;
};

type Admin = Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"];

async function admin(): Promise<Admin> {
  const mod = await import("@/integrations/supabase/client.server");
  return mod.supabaseAdmin;
}

export async function getSettings(): Promise<EngineSettings> {
  const db = await admin();
  const { data } = await db.from("content_engine_settings").select("*").eq("id", "default").maybeSingle();
  return {
    auto_publish: data?.auto_publish ?? false,
    auto_image: data?.auto_image ?? true,
    auto_translation: data?.auto_translation ?? false,
    auto_seo: data?.auto_seo ?? true,
    auto_verification: data?.auto_verification ?? true,
    articles_per_day: data?.articles_per_day ?? 1,
    max_articles_per_day: data?.max_articles_per_day ?? 3,
    publish_time: data?.publish_time ?? "06:00",
    default_language: data?.default_language ?? "en",
    daily_generation_limit: data?.daily_generation_limit ?? 40,
    monthly_generation_limit: data?.monthly_generation_limit ?? 600,
    min_quality_score: data?.min_quality_score ?? 75,
    max_similarity: Number(data?.max_similarity ?? 0.72),
  };
}

/* ------------------------------------------------------------------ */
/* Metered AI call                                                     */
/* ------------------------------------------------------------------ */

/** Rough per-call cost estimate (USD) purely for the admin usage monitor. */
const COST_PER_CALL = 0.004;

export async function meteredAi(
  kind: string,
  prompt: string,
  opts: { prefer?: "openai" | "gemini"; json?: boolean; system?: string } = {},
) {
  const db = await admin();
  const started = Date.now();
  try {
    const res = await callAi(prompt, opts);
    await db.from("content_api_usage").insert({
      kind,
      provider: res.provider,
      success: true,
      duration_ms: Date.now() - started,
      estimated_cost: COST_PER_CALL,
    });
    return res;
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await db.from("content_api_usage").insert({
      kind,
      provider: null,
      success: false,
      error_message: message.slice(0, 400),
      duration_ms: Date.now() - started,
      estimated_cost: 0,
    });
    throw err;
  }
}

export type LimitState = { blocked: boolean; reason: string; today: number; month: number };

export async function checkLimits(settings: EngineSettings): Promise<LimitState> {
  const db = await admin();
  const now = new Date();
  const dayKey = now.toISOString().slice(0, 10);
  const monthStart = `${now.toISOString().slice(0, 7)}-01`;

  const [{ count: today }, { count: month }] = await Promise.all([
    db.from("content_api_usage").select("id", { count: "exact", head: true }).eq("usage_date", dayKey),
    db.from("content_api_usage").select("id", { count: "exact", head: true }).gte("usage_date", monthStart),
  ]);

  const t = today ?? 0;
  const m = month ?? 0;
  if (t >= settings.daily_generation_limit)
    return { blocked: true, reason: "Daily AI generation limit reached.", today: t, month: m };
  if (m >= settings.monthly_generation_limit)
    return { blocked: true, reason: "Monthly AI generation limit reached.", today: t, month: m };
  return { blocked: false, reason: "", today: t, month: m };
}

/* ------------------------------------------------------------------ */
/* 1. Topic discovery                                                  */
/* ------------------------------------------------------------------ */

export const TOPIC_CATEGORIES = [
  "Quran",
  "Hadith",
  "Islamic history",
  "Ahl al-Bayt",
  "Imam Mahdi",
  "Karbala",
  "Imam Hussain",
  "Imam Ali",
  "Lady Fatima",
  "Imam Hasan",
  "Duas",
  "Ziyarat",
  "Islamic ethics",
  "Islamic civilization",
  "Islamic philosophy",
  "Islamic education",
  "Muslim history",
  "Islamic dates",
  "Islamic events",
  "Common questions",
];

export function normalize(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

export async function discoverTopics(count = 8): Promise<{ inserted: number; skipped: number }> {
  const db = await admin();
  const settings = await getSettings();
  const limit = await checkLimits(settings);
  if (limit.blocked) throw new Error(limit.reason);

  const [{ data: topics }, { data: articles }] = await Promise.all([
    db.from("content_topics").select("title").limit(300),
    db.from("articles").select("title").order("created_at", { ascending: false }).limit(200),
  ]);
  const known = new Set([...(topics ?? []), ...(articles ?? [])].map((r) => normalize(r.title)));
  const knownList = [...(topics ?? []), ...(articles ?? [])].map((r) => r.title).slice(0, 120).join("; ");

  const res = await meteredAi(
    "topic_discovery",
    `You are the editorial planner for "Imam Mahdi Civilization", a Twelver Shia (Fiqh Ja'fariya) Islamic knowledge platform that also fairly notes Sunni scholarship.

Propose ${count} genuinely useful, specific, non-overlapping article ideas.
Draw from these areas: ${TOPIC_CATEGORIES.join(", ")}.
Avoid vague, clickbait or repetitive ideas. Each must be researchable from classical sources.
Do NOT repeat or closely resemble anything here: ${knownList || "none"}.

${NO_INVENTION_RULE}

Return JSON only:
{"topics":[{"title":"...","category":"one of the areas above","language":"en","priority":1-100,"keywords":["two word term","another term"],"angle":"one sentence on what makes it useful"}]}`,
    { prefer: "gemini", json: true },
  );

  const parsed = parseJsonReply<{
    topics?: Array<{
      title?: string;
      category?: string;
      language?: string;
      priority?: number;
      keywords?: string[];
      angle?: string;
    }>;
  }>(res.text);

  let inserted = 0;
  let skipped = 0;
  for (const t of parsed.topics ?? []) {
    if (!t.title) continue;
    if (known.has(normalize(t.title))) {
      skipped++;
      continue;
    }
    const { error } = await db.from("content_topics").insert({
      title: t.title.slice(0, 200),
      category: t.category?.slice(0, 60) ?? "general",
      language: t.language ?? settings.default_language,
      priority: Math.min(100, Math.max(1, Math.round(t.priority ?? 50))),
      keywords: (t.keywords ?? []).filter((k) => k.split(/\s+/).length <= 3).slice(0, 8),
      angle: t.angle ?? null,
      status: "idea",
    });
    if (error) skipped++;
    else {
      inserted++;
      known.add(normalize(t.title));
    }
  }
  return { inserted, skipped };
}

/* ------------------------------------------------------------------ */
/* 2. Duplicate detection                                              */
/* ------------------------------------------------------------------ */

function tokens(text: string): Set<string> {
  return new Set(
    normalize(text)
      .split(" ")
      .filter((w) => w.length > 3),
  );
}

export function similarity(a: string, b: string): number {
  const A = tokens(a);
  const B = tokens(b);
  if (!A.size || !B.size) return 0;
  let shared = 0;
  for (const w of A) if (B.has(w)) shared++;
  return shared / Math.min(A.size, B.size);
}

export async function findDuplicate(title: string, body: string) {
  const db = await admin();
  const { data } = await db
    .from("articles")
    .select("id, title, slug, excerpt")
    .order("created_at", { ascending: false })
    .limit(300);
  let best: { id: string; title: string; slug: string; score: number } | null = null;
  for (const row of data ?? []) {
    const score = Math.max(
      similarity(title, row.title),
      similarity(`${title} ${body.slice(0, 1500)}`, `${row.title} ${row.excerpt ?? ""}`) * 0.9,
    );
    if (!best || score > best.score) best = { id: row.id, title: row.title, slug: row.slug, score };
  }
  return best;
}

/* ------------------------------------------------------------------ */
/* 3. Quality control                                                  */
/* ------------------------------------------------------------------ */

export type QualityIssue = { code: string; label: string; weight: number };

export function scoreQuality(input: {
  title: string;
  slug: string;
  content: string;
  metaDescription?: string | null;
  seoTitle?: string | null;
  keywords?: string[] | null;
  imageUrl?: string | null;
  refCount: number;
  unverifiedCount: number;
}): { score: number; issues: QualityIssue[] } {
  const issues: QualityIssue[] = [];
  const words = input.content.trim().split(/\s+/).filter(Boolean).length;

  const add = (code: string, label: string, weight: number) => issues.push({ code, label, weight });

  if (words < 350) add("too_short", `Very short content (${words} words)`, 30);
  else if (words < 700) add("short", `Below target length (${words} words)`, 10);

  if (!/^#|\n##\s/.test(input.content)) add("no_headings", "No subheadings found", 8);
  if (/\n\s*##\s*\S+\s*\n\s*(\n|##|$)/.test(input.content)) add("empty_section", "Empty section detected", 8);

  const paras = input.content
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter((p) => p.length > 80);
  const seen = new Set<string>();
  for (const p of paras) {
    const key = normalize(p).slice(0, 120);
    if (seen.has(key)) {
      add("duplicate_paragraph", "Repeated paragraph", 12);
      break;
    }
    seen.add(key);
  }

  const wordCounts = new Map<string, number>();
  for (const w of normalize(input.content).split(" ")) {
    if (w.length > 6) wordCounts.set(w, (wordCounts.get(w) ?? 0) + 1);
  }
  const worst = [...wordCounts.values()].sort((a, b) => b - a)[0] ?? 0;
  if (words > 0 && worst / words > 0.03) add("repetition", "Excessive repetition of a term", 8);

  if (!input.metaDescription) add("no_meta", "Missing meta description", 10);
  else if (input.metaDescription.length < 80 || input.metaDescription.length > 165)
    add("meta_length", "Meta description outside 80–165 characters", 5);

  if (!input.seoTitle) add("no_seo_title", "Missing SEO title", 6);
  else if (input.seoTitle.length > 62) add("seo_title_length", "SEO title longer than 62 characters", 4);

  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(input.slug)) add("bad_slug", "Slug is not clean kebab-case", 8);
  if (!input.keywords?.length) add("no_keywords", "No keywords", 4);
  if (!input.imageUrl) add("no_image", "No featured image", 6);
  if (input.refCount === 0) add("no_refs", "No sources or references", 15);
  if (input.unverifiedCount > 0)
    add("unverified_refs", `${input.unverifiedCount} reference(s) require verification`, 12);

  if (/\b(lorem ipsum|TODO|TBD|\[insert)\b/i.test(input.content)) add("placeholder", "Placeholder text found", 25);

  const score = Math.max(0, Math.min(100, 100 - issues.reduce((n, i) => n + i.weight, 0)));
  return { score, issues };
}

export function qualityBand(score: number) {
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 60) return "Needs Review";
  return "Do Not Publish";
}

/* ------------------------------------------------------------------ */
/* 4. Reference verification                                           */
/* ------------------------------------------------------------------ */

export type QuranRef = {
  surah_name?: string;
  surah_number?: number;
  ayah_number?: number;
  arabic?: string;
  translation?: string;
  reference?: string;
  verified?: boolean;
};
export type HadithRef = {
  collection?: string;
  book?: string;
  chapter?: string;
  hadith_number?: string;
  text?: string;
  reference?: string;
  verified?: boolean;
};
export type ArticleRefs = {
  quran: QuranRef[];
  hadith: HadithRef[];
  historical: Array<{ title?: string; author?: string; detail?: string; url?: string; verified?: boolean }>;
  additional: Array<{ title?: string; url?: string }>;
};

export const EMPTY_REFS: ArticleRefs = { quran: [], hadith: [], historical: [], additional: [] };

/**
 * Structural verification of Quran citations against the local surah dataset,
 * plus a conservative model self-check for hadith. Anything we cannot confirm
 * is flagged, never silently accepted.
 */
export async function verifyReferences(refs: ArticleRefs): Promise<{
  refs: ArticleRefs;
  unverified: number;
  notes: string[];
}> {
  const notes: string[] = [];
  const db = await admin();

  const { data: surahs } = await db.from("quran_surahs").select("surah_number, total_ayahs, english_name, arabic_name");
  const byNumber = new Map((surahs ?? []).map((s) => [s.surah_number, s]));

  const quran = refs.quran.map((r) => {
    const s = r.surah_number ? byNumber.get(r.surah_number) : undefined;
    const ok =
      !!s &&
      typeof r.ayah_number === "number" &&
      r.ayah_number >= 1 &&
      (!s.total_ayahs || r.ayah_number <= s.total_ayahs);
    if (!ok) notes.push(`Quran reference requires verification: ${r.reference ?? `${r.surah_number}:${r.ayah_number}`}`);
    return {
      ...r,
      surah_name: r.surah_name ?? s?.english_name ?? undefined,
      reference: r.reference ?? (s ? `Quran ${r.surah_number}:${r.ayah_number}` : undefined),
      verified: ok,
    };
  });

  // Hadith cannot be structurally validated here: accept only citations that
  // carry a named collection AND a locating number/volume, flag the rest.
  const hadith = refs.hadith.map((r) => {
    const ok = Boolean(r.collection && (r.hadith_number || r.book));
    if (!ok) notes.push(`Hadith reference requires verification: ${r.reference ?? r.collection ?? "unnamed"}`);
    return { ...r, verified: ok };
  });

  const historical = refs.historical.map((r) => ({ ...r, verified: Boolean(r.title && (r.author || r.url)) }));
  for (const r of historical) if (!r.verified) notes.push(`Historical source requires verification: ${r.title ?? "untitled"}`);

  const unverified =
    quran.filter((r) => !r.verified).length +
    hadith.filter((r) => !r.verified).length +
    historical.filter((r) => !r.verified).length;

  return { refs: { quran, hadith, historical, additional: refs.additional ?? [] }, unverified, notes };
}

/* ------------------------------------------------------------------ */
/* 5. Full pipeline for one topic                                      */
/* ------------------------------------------------------------------ */

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

export type PipelineOutcome = {
  ok: boolean;
  stage: PipelineStage;
  message: string;
  articleId?: string;
  slug?: string;
  qualityScore?: number;
};

export async function runPipelineForTopic(topicId: string): Promise<PipelineOutcome> {
  const db = await admin();
  const settings = await getSettings();
  const limit = await checkLimits(settings);
  if (limit.blocked) return { ok: false, stage: "failed", message: limit.reason };

  const { data: topic } = await db.from("content_topics").select("*").eq("id", topicId).maybeSingle();
  if (!topic) return { ok: false, stage: "failed", message: "Topic not found" };
  if (topic.attempts >= 3)
    return { ok: false, stage: "failed", message: "Topic exceeded the retry limit (3). Reset it to retry." };

  const fail = async (message: string) => {
    await db
      .from("content_topics")
      .update({ status: "failed", last_error: message.slice(0, 400), attempts: topic.attempts + 1 })
      .eq("id", topicId);
    return { ok: false, stage: "failed" as const, message };
  };

  try {
    // --- RESEARCH ---
    await db.from("content_topics").update({ status: "researching", attempts: topic.attempts + 1 }).eq("id", topicId);
    const research = parseJsonReply<{
      outline?: string[];
      quran?: QuranRef[];
      hadith?: HadithRef[];
      historical?: ArticleRefs["historical"];
      additional?: ArticleRefs["additional"];
    }>(
      (
        await meteredAi(
          "research",
          `Research this Islamic article topic for a Twelver Shia knowledge platform.

Topic: ${topic.title}
Angle: ${topic.angle ?? ""}
Category: ${topic.category}

${NO_INVENTION_RULE}

Collect ONLY references you are certain of. For each Quran verse give surah name, surah number, ayah number and a reliable English translation. For each hadith give the collection, book/volume and hadith number where you are certain of them; omit any hadith whose locator you are not sure about.

Return JSON only:
{"outline":["...","..."],
 "quran":[{"surah_name":"Al-Baqarah","surah_number":2,"ayah_number":255,"arabic":"","translation":"...","reference":"Quran 2:255"}],
 "hadith":[{"collection":"al-Kafi","book":"1","chapter":"","hadith_number":"2","text":"...","reference":"al-Kafi 1/34 h.2"}],
 "historical":[{"title":"Tarikh al-Tabari","author":"al-Tabari","detail":"vol. 5"}],
 "additional":[{"title":"...","url":"https://..."}]}`,
          { prefer: "gemini", json: true },
        )
      ).text,
    );

    // --- WRITE ---
    await db.from("content_topics").update({ status: "generating" }).eq("id", topicId);
    const draft = parseJsonReply<{
      title?: string;
      seo_title?: string;
      slug?: string;
      intro?: string;
      content?: string;
      summary?: string;
      faq?: Array<{ q?: string; a?: string }>;
      meta_description?: string;
      og_title?: string;
      og_description?: string;
      keywords?: string[];
      tags?: string[];
      reading_minutes?: number;
      image_prompt?: string;
      image_alt_text?: string;
    }>(
      (
        await meteredAi(
          "article_writing",
          `Write a complete, original, human-readable Islamic article in ${topic.language === "en" ? "English" : topic.language} for "Imam Mahdi Civilization".

Topic: ${topic.title}
Angle: ${topic.angle ?? ""}
Outline: ${(research.outline ?? []).join(" | ")}
Verified references available (use ONLY these, and only where they genuinely fit):
Quran: ${(research.quran ?? []).map((q) => q.reference).join("; ") || "none"}
Hadith: ${(research.hadith ?? []).map((h) => h.reference).join("; ") || "none"}

${NO_INVENTION_RULE}

Requirements:
- 900–1400 words of substantive Markdown: ## subheadings, short paragraphs, occasional lists. No filler, no repetition.
- Respectful scholarly tone. Ja'fari position primary; other schools noted neutrally where relevant.
- Clearly separate scripture/narration from your own explanation.
- End with a "## Frequently Asked Questions" section (3–5 Q&A) when it genuinely helps the reader.
- SEO title max 60 characters. Meta description 120–155 characters. Slug lowercase kebab-case.
- Keywords: 5–8 short search terms of 1–3 words each. No sentences.
- image_prompt must describe a respectful symbolic Islamic scene (mosque, calligraphy, manuscript, desert, light, geometry). NEVER depict the Prophet, the Imams, Ahl al-Bayt, companions or any sacred personality.

Return JSON only:
{"title":"...","seo_title":"...","slug":"...","intro":"...","content":"## ...markdown...","summary":"...","faq":[{"q":"...","a":"..."}],"meta_description":"...","og_title":"...","og_description":"...","keywords":["..."],"tags":["..."],"reading_minutes":7,"image_prompt":"...","image_alt_text":"..."}`,
          { prefer: "gemini", json: true },
        )
      ).text,
    );

    if (!draft.title || !draft.content || draft.content.length < 400) return fail("Model returned an incomplete article");

    // --- VERIFY ---
    await db.from("content_topics").update({ status: "verification" }).eq("id", topicId);
    const rawRefs: ArticleRefs = {
      quran: research.quran ?? [],
      hadith: research.hadith ?? [],
      historical: research.historical ?? [],
      additional: research.additional ?? [],
    };
    const verified = settings.auto_verification
      ? await verifyReferences(rawRefs)
      : { refs: rawRefs, unverified: 0, notes: [] as string[] };

    // --- DUPLICATE ---
    const dup = await findDuplicate(draft.title, draft.content);
    const isDuplicate = !!dup && dup.score >= settings.max_similarity;

    // --- SEO + IMAGE ---
    let slug = slugify(draft.slug || draft.title);
    if (!slug) slug = `article-${Date.now()}`;
    const { data: clash } = await db.from("articles").select("id").eq("slug", slug).maybeSingle();
    if (clash) slug = `${slug}-${new Date().toISOString().slice(0, 10)}`;

    let imageUrl: string | null = null;
    if (settings.auto_image) {
      const { generateArticleCover } = await import("@/lib/article-image.server");
      imageUrl =
        (await generateArticleCover({ slug, title: draft.title, prompt: draft.image_prompt })) ??
        coverFor({ slug, title: draft.title, category: topic.category, tags: draft.tags ?? [] });
    }

    const content = draft.content;
    const quality = scoreQuality({
      title: draft.title,
      slug,
      content,
      metaDescription: draft.meta_description,
      seoTitle: draft.seo_title,
      keywords: draft.keywords,
      imageUrl,
      refCount: verified.refs.quran.length + verified.refs.hadith.length + verified.refs.historical.length,
      unverifiedCount: verified.unverified,
    });

    // --- STAGE DECISION (auto publish is OFF by default) ---
    let stage: PipelineStage = "draft";
    if (isDuplicate) stage = "duplicate_review";
    else if (verified.unverified > 0) stage = "verification";
    else if (settings.auto_publish && quality.score >= settings.min_quality_score) stage = "published";

    const publish = stage === "published";

    const { data: inserted, error } = await db
      .from("articles")
      .insert({
        slug,
        title: draft.title.slice(0, 160),
        excerpt: (draft.meta_description || draft.summary || draft.intro || "").slice(0, 300),
        content,
        cover_url: imageUrl,
        language: topic.language,
        tags: (draft.tags ?? topic.keywords ?? []).slice(0, 8),
        reading_minutes:
          typeof draft.reading_minutes === "number"
            ? draft.reading_minutes
            : Math.max(4, Math.round(content.split(/\s+/).length / 200)),
        status: publish ? "published" : "draft",
        published_at: publish ? new Date().toISOString() : null,
        pipeline_status: stage,
        quality_score: quality.score,
        quality_report: { band: qualityBand(quality.score), issues: quality.issues } as never,
        seo_title: (draft.seo_title || draft.title).slice(0, 70),
        meta_description: (draft.meta_description || "").slice(0, 200),
        og_title: (draft.og_title || draft.seo_title || draft.title).slice(0, 90),
        og_description: (draft.og_description || draft.meta_description || "").slice(0, 200),
        keywords: (draft.keywords ?? [])
          .filter((k) => k.split(/\s+/).length <= 3 && k.length <= 30)
          .slice(0, 10),
        image_prompt: draft.image_prompt ?? null,
        image_alt_text: draft.image_alt_text ?? `Symbolic Islamic illustration for ${draft.title}`,
        image_generation_status: imageUrl ? "matched" : "none",
        refs: verified.refs as never,
        verification_status: verified.unverified > 0 ? "needs_verification" : "verified",
        verification_notes: verified.notes as never,
        similarity_score: dup?.score ?? 0,
        duplicate_of: isDuplicate ? dup!.id : null,
        topic_id: topicId,
        generation_meta: { engine: "content-engine-v1", generated_at: new Date().toISOString() } as never,
      })
      .select("id, slug")
      .maybeSingle();

    if (error) return fail(`Article insert failed: ${error.message}`);

    await db
      .from("content_topics")
      .update({ status: publish ? "published" : "drafted", last_error: null })
      .eq("id", topicId);

    return {
      ok: true,
      stage,
      message: isDuplicate
        ? `Sent to duplicate review (${Math.round((dup?.score ?? 0) * 100)}% similar to "${dup?.title}")`
        : verified.unverified > 0
          ? `Saved as draft — ${verified.unverified} reference(s) require verification`
          : publish
            ? `Published "${draft.title}"`
            : `Saved as draft "${draft.title}"`,
      articleId: inserted?.id,
      slug: inserted?.slug,
      qualityScore: quality.score,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (err instanceof AiUnavailableError && err.quota) {
      await db
        .from("autopilot_state")
        .update({ paused: true, pause_reason: message.slice(0, 300) })
        .eq("id", "daily");
    }
    return fail(message);
  }
}

/** Picks the highest-priority idea and runs it end-to-end. */
export async function runNextTopic(): Promise<PipelineOutcome> {
  const db = await admin();
  const { data } = await db
    .from("content_topics")
    .select("id")
    .in("status", ["idea"])
    .order("priority", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!data) {
    const discovered = await discoverTopics(6);
    if (!discovered.inserted) return { ok: false, stage: "failed", message: "No topics available" };
    const { data: fresh } = await db
      .from("content_topics")
      .select("id")
      .eq("status", "idea")
      .order("priority", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!fresh) return { ok: false, stage: "failed", message: "No topics available" };
    return runPipelineForTopic(fresh.id);
  }
  return runPipelineForTopic(data.id);
}
