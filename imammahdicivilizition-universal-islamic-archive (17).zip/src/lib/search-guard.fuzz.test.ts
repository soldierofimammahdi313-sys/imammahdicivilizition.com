import { describe, expect, it } from "vitest";
import fc from "fast-check";
import { guardSearchTerm } from "./search-guard";

/** Characters the guard must never leave in the sanitized term. */
const UNSAFE = /[,%()*\\."']/;

/** Payload fragments, each tagged with the reason the guard MUST report. */
const PROBES: { reason: string; arb: fc.Arbitrary<string> }[] = [
  {
    reason: "postgrest-operator",
    arb: fc
      .tuple(
        fc.constantFrom("ilike", "like", "eq", "neq", "gt", "gte", "lt", "lte", "in", "is", "fts", "cs", "cd", "not"),
        fc.constantFrom("", " "),
      )
      .map(([op, sp]) => `${op}${sp}.value`),
  },
  {
    reason: "postgrest-logic",
    arb: fc.tuple(fc.constantFrom("or", "and", "OR", "And"), fc.constantFrom("", " ")).map(([k, sp]) => `${k}${sp}(title.ilike.x)`),
  },
  {
    reason: "sql-keyword",
    arb: fc.constantFrom(
      "union select password",
      "UNION   SELECT 1",
      "select id from profiles",
      "drop table articles",
      "insert into user_roles",
      "delete from profiles",
      "update profiles set role",
    ),
  },
  { reason: "sql-comment", arb: fc.constantFrom("--", "/*", "*/", ";") },
  {
    reason: "boolean-tautology",
    arb: fc
      .tuple(fc.constantFrom("'", '"', ""), fc.constantFrom("1=1", "1 = 1", "true", "TRUE"), fc.constantFrom("--", "#", ""))
      // A bare, unquoted `true` with no comment marker is an ordinary word, not a probe.
      .map(([q, t, tail]) => `${q}${t}${q === "" && tail === "" && !t.includes("=") ? "--" : tail}`),
  },
  {
    reason: "schema-probe",
    arb: fc.constantFrom("pg_catalog", "information_schema", "auth.users", "service_role"),
  },
];

/** Harmless words that must never trip a probe pattern. */
const SAFE_WORDS = fc.constantFrom(
  "imam",
  "mahdi",
  "quran",
  "hadith",
  "tafsir",
  "zakat",
  "namaz",
  "civilization",
  "313",
  "knowledge",
  "kitab",
  "dua",
);

describe("guardSearchTerm property-based fuzzing", () => {
  it("always flags generated injection payloads with at least one correct reason", () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: PROBES.length - 1 }).chain((i) =>
          PROBES[i]!.arb.map((payload) => ({ reason: PROBES[i]!.reason, payload })),
        ),
        fc.array(SAFE_WORDS, { maxLength: 3 }),
        fc.array(SAFE_WORDS, { maxLength: 3 }),
        ({ reason, payload }, before, after) => {
          const raw = [...before, payload, ...after].join(" ");
          const result = guardSearchTerm(raw);

          expect(result.suspicious).toBe(true);
          expect(result.reasons).toContain(reason);
          expect(result.severity === "warn" || result.severity === "critical").toBe(true);
          expect(UNSAFE.test(result.term)).toBe(false);
          expect(result.term.length).toBeLessThanOrEqual(80);
        },
      ),
      { numRuns: 500 },
    );
  });

  it("escalates to critical when two independent probe families are combined", () => {
    fc.assert(
      fc.property(
        fc.constantFrom("union select password", "drop table articles"),
        fc.constantFrom("pg_catalog", "information_schema", "auth.users"),
        (sql, schema) => {
          const result = guardSearchTerm(`${sql} ${schema}`);
          expect(result.severity).toBe("critical");
          expect(result.reasons).toEqual(expect.arrayContaining(["sql-keyword", "schema-probe"]));
        },
      ),
      { numRuns: 100 },
    );
  });

  it("never emits unsafe characters or over-length terms for arbitrary unicode input", () => {
    fc.assert(
      fc.property(fc.string({ maxLength: 400, unit: "binary" }), (raw) => {
        const result = guardSearchTerm(raw);
        expect(UNSAFE.test(result.term)).toBe(false);
        expect(result.term.length).toBeLessThanOrEqual(80);
        expect(result.term).toBe(result.term.trim());
        if (raw.length > 80) expect(result.suspicious).toBe(true);
      }),
      { numRuns: 1000 },
    );
  });

  it("leaves ordinary multi-word searches unflagged", () => {
    fc.assert(
      fc.property(fc.array(SAFE_WORDS, { minLength: 1, maxLength: 6 }), (words) => {
        const result = guardSearchTerm(words.join(" "));
        expect(result.suspicious).toBe(false);
        expect(result.reasons).toEqual([]);
        expect(result.severity).toBe("info");
      }),
      { numRuns: 300 },
    );
  });
});
