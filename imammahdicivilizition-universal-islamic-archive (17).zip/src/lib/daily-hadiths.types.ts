export type DailyHadith = { text: string; by: string; source: string };
export type DailyHadithPayload = {
  date: string; // YYYY-MM-DD (gregorian, used as cache key)
  hijri: string;
  theme: string;
  event?: string | null; // today's Islamic occasion, if any
  items: DailyHadith[];
};
