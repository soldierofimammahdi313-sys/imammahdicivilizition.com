import DOMPurify from "dompurify";

const ALLOWED_TAGS = ["p", "br", "b", "strong", "i", "em", "u", "sup", "sub", "span", "div", "ul", "ol", "li", "blockquote", "h3", "h4", "h5", "h6"];

/**
 * Sanitize untrusted third-party HTML (e.g. tafsir text from external APIs)
 * before it is injected via dangerouslySetInnerHTML.
 * On the server (no DOM), all tags are stripped as a safe fallback.
 */
export function sanitizeHtml(dirty: string): string {
  if (!dirty) return "";
  if (typeof window === "undefined" || !DOMPurify.isSupported) {
    return dirty.replace(/<[^>]*>/g, "");
  }
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS,
    ALLOWED_ATTR: ["class", "dir", "lang"],
    FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form"],
    FORBID_ATTR: ["style", "onerror", "onload", "onclick"],
  });
}
