import { beforeEach, describe, expect, it, vi } from "vitest";
import { guardSearchTerm } from "./search-guard";

type InsertResult = { error: { message: string } | null };
const insert = vi.fn(
  async (_payload: Record<string, unknown>): Promise<InsertResult> => ({ error: null }),
);
vi.mock("@/integrations/supabase/client.server", () => ({
  supabaseAdmin: { from: () => ({ insert }) },
}));

import { recordSuspiciousSearch } from "./security-events.server";

describe("recordSuspiciousSearch", () => {
  beforeEach(() => {
    insert.mockClear();
    vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  it("logs the exact reasons and severity for an injection payload", async () => {
    const raw = "' union select password from auth.users --";
    const guard = guardSearchTerm(raw);
    await recordSuspiciousSearch("site-search", raw, guard, "user-1");

    expect(insert).toHaveBeenCalledTimes(1);
    const payload = insert.mock.calls[0]![0];
    expect(payload).toMatchObject({
      event_type: "suspicious_search_input",
      severity: "critical",
      source: "site-search",
      raw_input: raw,
      sanitized_input: guard.term,
      user_id: "user-1",
    });
    expect(payload["reasons"]).toEqual(guard.reasons);
    expect(console.warn).toHaveBeenCalledWith(
      expect.stringContaining("suspicious_search_input"),
    );
  });

  it("truncates stored raw input to 500 characters", async () => {
    const raw = `${"z".repeat(600)};`;
    await recordSuspiciousSearch("discussion-search", raw, guardSearchTerm(raw));
    const payload = insert.mock.calls[0]![0];
    expect(payload["raw_input"]).toHaveLength(500);
    expect(payload["user_id"]).toBeNull();
  });

  it("never throws when the database write fails", async () => {
    insert.mockResolvedValueOnce({ error: { message: "boom" } });
    vi.spyOn(console, "error").mockImplementation(() => {});
    const raw = "x,or(a.eq.b)";
    await expect(
      recordSuspiciousSearch("mcp-search-articles", raw, guardSearchTerm(raw)),
    ).resolves.toBeUndefined();
    expect(console.error).toHaveBeenCalled();
  });
});