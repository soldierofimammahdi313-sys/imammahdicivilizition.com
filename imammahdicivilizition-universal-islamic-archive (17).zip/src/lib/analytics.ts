/**
 * Google Analytics 4 initialization and helpers.
 * The measurement ID is injected by the Google Analytics connector as
 * VITE_LOVABLE_CONNECTOR_GOOGLE_ANALYTICS_API_KEY.
 */

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}


const MEASUREMENT_ID = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_ANALYTICS_API_KEY;

let initialized = false;

export function initGoogleAnalytics(): boolean {
  if (typeof window === "undefined") return false;
  if (initialized) return true;
  if (!MEASUREMENT_ID) {
    console.warn("VITE_LOVABLE_CONNECTOR_GOOGLE_ANALYTICS_API_KEY is not configured");
    return false;
  }


  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${MEASUREMENT_ID}`;
  document.head.appendChild(script);

  window.dataLayer = window.dataLayer || [];
  function gtag(...args: unknown[]) {
    window.dataLayer!.push(args);
  }
  window.gtag = gtag;

  gtag("js", new Date());
  gtag("config", MEASUREMENT_ID, {
    send_page_view: false,
    cookie_flags: "SameSite=None;Secure",
  });

  initialized = true;
  return true;
}

export function trackPageView(path: string, title?: string): void {
  if (typeof window === "undefined" || !window.gtag || !MEASUREMENT_ID) return;
  window.gtag("event", "page_view", {
    page_path: path,
    page_title: title ?? document.title,
    page_location: window.location.href,
  });
}

export function trackEvent(
  name: string,
  params?: Record<string, string | number | boolean | null>,
): void {
  if (typeof window === "undefined" || !window.gtag || !MEASUREMENT_ID) return;
  window.gtag("event", name, params ?? {});
}
