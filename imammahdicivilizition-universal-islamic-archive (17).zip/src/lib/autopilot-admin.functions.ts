import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AutopilotRunResult = {
  success: boolean;
  status: string;
  message: string;
  article: { title: string; slug: string; status: string } | null;
  tickerItems: number;
};


/**
 * Admin-only manual trigger for the daily autopilot.
 * Role is verified server-side through the caller's own (RLS-scoped) client,
 * never from client-supplied data.
 */
export const runAutopilotNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AutopilotRunResult> => {
    const { data: isAdmin, error } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });

    if (error || !isAdmin) {
      throw new Response("Forbidden", { status: 403 });
    }

    const { runDailyAutopilot } = await import("@/lib/autopilot.server");
    const result = await runDailyAutopilot();

    return {
      success: result.status === "ok" || result.status === "skipped",
      status: result.status,
      message: result.detail,
      article: result.article ?? null,
      tickerItems: result.tickerItems ?? 0,
    };
  });
