import { supabase } from "@/integrations/supabase/client";

export type ReadableType = "quran" | "hadith" | "article" | "dua" | "book" | "video" | "page";

/** Record (or refresh) an item in the member's reading history. Silently no-ops when signed out. */
export async function recordReading(entry: {
  itemType: ReadableType;
  itemId: string;
  title?: string;
  href?: string;
  progress?: number;
}) {
  const { data } = await supabase.auth.getUser();
  const user = data.user;
  if (!user) return;
  await supabase.from("reading_history").upsert(
    {
      user_id: user.id,
      item_type: entry.itemType,
      item_id: entry.itemId,
      title: entry.title ?? null,
      href: entry.href ?? null,
      progress: entry.progress ?? 0,
      viewed_at: new Date().toISOString(),
    },
    { onConflict: "user_id,item_type,item_id" },
  );
}

export async function isSaved(itemType: string, itemId: string) {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return false;
  const { data: row } = await supabase
    .from("saved_items")
    .select("id")
    .eq("user_id", data.user.id)
    .eq("item_type", itemType)
    .eq("item_id", itemId)
    .maybeSingle();
  return Boolean(row);
}

/** Toggle a bookmark. Returns the new saved state, or null when signed out. */
export async function toggleSaved(itemType: string, itemId: string) {
  const { data } = await supabase.auth.getUser();
  const user = data.user;
  if (!user) return null;
  const saved = await isSaved(itemType, itemId);
  if (saved) {
    await supabase
      .from("saved_items")
      .delete()
      .eq("user_id", user.id)
      .eq("item_type", itemType)
      .eq("item_id", itemId);
    return false;
  }
  await supabase.from("saved_items").insert({ user_id: user.id, item_type: itemType, item_id: itemId });
  return true;
}

export async function fetchRoles(userId: string) {
  const [{ data: admin }, { data: reviewer }] = await Promise.all([
    supabase.rpc("has_role", { _user_id: userId, _role: "admin" }),
    supabase.rpc("has_role", { _user_id: userId, _role: "reviewer" }),
  ]);
  return { isAdmin: Boolean(admin), isModerator: Boolean(admin) || Boolean(reviewer) };
}