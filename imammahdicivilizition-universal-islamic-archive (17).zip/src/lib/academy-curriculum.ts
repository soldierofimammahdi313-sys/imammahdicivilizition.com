export type Lesson = {
  id: string;
  title: string;
  emoji: string;
  summary: string;
  /** First message sent to Ustad Mahdi AI when the child starts this lesson. */
  opener: string;
};

export const LESSONS: Lesson[] = [
  {
    id: "intro-ai",
    title: "Intro to AI",
    emoji: "🤖",
    summary: "What is Artificial Intelligence and how does it think?",
    opener: "Ustad, please start Lesson 1: Intro to AI. Teach me step by step what AI is, in simple words, then give me a small task.",
  },
  {
    id: "prompt-basics",
    title: "Prompt Basics",
    emoji: "✍️",
    summary: "Roles, context and clear instructions.",
    opener: "Ustad, please start Lesson 2: Prompt Basics. Teach me Rule #1 about giving the AI a role, then give me a task to try.",
  },
  {
    id: "image-prompts",
    title: "Image Prompts",
    emoji: "🎨",
    summary: "Describe scenes, style and mood for image AI.",
    opener: "Ustad, please start Lesson 3: Image Prompts. Teach me how to describe a beautiful halal scene for an image AI, then give me a task.",
  },
  {
    id: "ai-ethics",
    title: "AI Ethics in Islam",
    emoji: "🤍",
    summary: "Honesty, respect and halal use of technology.",
    opener: "Ustad, please start Lesson 4: AI Ethics in Islam. Teach me how a Muslim child should use AI honestly, then ask me a question.",
  },
  {
    id: "build-bot",
    title: "Build Your First Bot",
    emoji: "🛠️",
    summary: "Design a helpful assistant with a system prompt.",
    opener: "Ustad, please start Lesson 5: Build Your First Bot. Help me design my own helpful Islamic study bot step by step.",
  },
];

export type QuizItem = {
  id: string;
  q: string;
  a: { t: string; correct?: boolean }[];
  explain: string;
};

export const QUIZ_BANK: QuizItem[] = [
  {
    id: "q-system-prompt",
    q: "What is a system prompt?",
    a: [
      { t: "A message the user types to ask the AI a question." },
      { t: "The hidden instruction that gives the AI its role, tone and rules before the chat starts.", correct: true },
      { t: "An error shown when the AI is offline." },
    ],
    explain: "A system prompt sets the AI's role and rules before you even say salam.",
  },
  {
    id: "q-specific",
    q: "Which prompt will give the best image?",
    a: [
      { t: "a mosque" },
      { t: "nice picture please" },
      { t: "A golden-domed mosque at sunset, calligraphy on the walls, warm cinematic light.", correct: true },
    ],
    explain: "Detail wins: subject + setting + light + style.",
  },
  {
    id: "q-ethics",
    q: "Your homework is due. What is the honest way to use AI?",
    a: [
      { t: "Ask AI to explain the topic, then write the answer yourself.", correct: true },
      { t: "Copy the AI answer and say you wrote it." },
      { t: "Ask AI to write it and change two words." },
    ],
    explain: "AI is a teacher, not a substitute for your own effort. Honesty is amanah.",
  },
  {
    id: "q-hallucination",
    q: "The AI gives you a hadith reference you cannot find. What should you do?",
    a: [
      { t: "Share it quickly with friends." },
      { t: "Verify it in a real book or with a scholar before trusting it.", correct: true },
      { t: "Assume the AI is always right." },
    ],
    explain: "AI can make mistakes. Narrations must always be verified from real sources.",
  },
  {
    id: "q-context",
    q: "What makes a prompt clearer?",
    a: [
      { t: "Writing it in ALL CAPS." },
      { t: "Adding context: who it is for, how long, and in what style.", correct: true },
      { t: "Making it as short as possible." },
    ],
    explain: "Context — audience, length, style — is Rule #2 of prompt engineering.",
  },
  {
    id: "q-safety",
    q: "An app asks a child for their home address. What is safest?",
    a: [
      { t: "Type it in quickly." },
      { t: "Never share it and tell your parents.", correct: true },
      { t: "Share it only if the app looks nice." },
    ],
    explain: "Digital safety: personal details stay private, always tell a trusted adult.",
  },
];
