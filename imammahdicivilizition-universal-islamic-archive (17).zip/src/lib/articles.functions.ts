import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type PublicArticle = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  content: string;
  cover_url: string | null;
  reading_minutes: number | null;
  published_at: string | null;
  tags: string[] | null;
  category: string | null;
};

/** Server-rendered fetch of a single published article (public, read-only). */
export const getPublicArticle = createServerFn({ method: "GET" })
  .inputValidator((data: { slug: string }) => data)
  .handler(async ({ data }): Promise<PublicArticle | null> => {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) return null;

    const client = createClient<Database>(url, key, {
      auth: { persistSession: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });

    const { data: row } = await client
      .from("articles")
      .select("id, slug, title, excerpt, content, cover_url, reading_minutes, published_at, tags, article_categories(name)")
      .eq("slug", data.slug)
      .eq("status", "published")
      .maybeSingle();

    if (!row) return null;
    const cat = row.article_categories as { name?: string } | null;
    return {
      id: row.id,
      slug: row.slug,
      title: row.title,
      excerpt: row.excerpt,
      content: row.content,
      cover_url: row.cover_url,
      reading_minutes: row.reading_minutes,
      published_at: row.published_at,
      tags: row.tags,
      category: cat?.name ?? null,
    };
  });