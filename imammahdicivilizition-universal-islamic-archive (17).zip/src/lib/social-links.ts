export const SOCIAL_LINKS = [
  { name: "YouTube", href: "https://youtube.com/@imammahdicivilization", icon: "youtube" },
  { name: "Facebook", href: "https://www.facebook.com/share/1PWhUxSdSm/", icon: "facebook" },
] as const;

export const CONTACT = {
  admin: "Syed Ahmad Raza Shamsi",
};
