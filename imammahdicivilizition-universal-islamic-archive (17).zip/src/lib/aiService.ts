/**
 * Unified AI helper service (server-side use only).
 *
 * - Auto-detects every OpenAI / Gemini key present in Secrets / environment
 *   (OPENAI_API_KEY, OPENAI_API_KEY_2..N, GEMINI_API_KEY,
 *   GOOGLE_GENERATIVE_AI_API_KEY, GOOGLE_AI_API_KEY, ...).
 * - Round-robin across healthy keys with automatic fallback: a key hit by a
 *   rate limit / quota / temporary error is parked on a cooldown and the next
 *   healthy key takes over — across vendors too.
 * - Key values never reach the client, logs or error messages.
 *
 * Every AI feature of the site (article generator, content engine, autopilot,
 * ticker enrichment, article AI assist, chat) goes through this service.
 */

export type AiVendorName = "openai" | "gemini";

export type AiAskOptions = {
  /** System / role instruction. */
  system?: string;
  /** Ask the model for strict JSON output. */
  json?: boolean;
  /** Which vendor to try first. */
  prefer?: AiVendorName;
  /** Max keys to try per vendor before moving on. */
  maxAttempts?: number;
};

export type AiAskResult = { text: string; provider: AiVendorName };

/** Sends a prompt through the key pool with automatic key/vendor fallback. */
export async function ask(prompt: string, options: AiAskOptions = {}): Promise<AiAskResult> {
  const { callAi } = await import("./ai-providers.server");
  return callAi(prompt, options);
}

/** Same as `ask`, but parses the reply as JSON (tolerates code fences). */
export async function askJson<T>(prompt: string, options: AiAskOptions = {}): Promise<T> {
  const { callAi, parseJsonReply } = await import("./ai-providers.server");
  const res = await callAi(prompt, { ...options, json: true });
  return parseJsonReply<T>(res.text);
}

/** True when at least one usable key is configured for that vendor. */
export async function hasKeys(vendor: AiVendorName): Promise<boolean> {
  const { hasVendor } = await import("./ai-pool.server");
  return hasVendor(vendor);
}

/** True when any AI key at all is configured. */
export async function isConfigured(): Promise<boolean> {
  const { hasVendor } = await import("./ai-pool.server");
  return hasVendor("gemini") || hasVendor("openai");
}

/** Admin diagnostics: key names + health only, never key values. */
export async function status() {
  const { poolStatus } = await import("./ai-pool.server");
  return poolStatus();
}

/** Removes any key material from a string before logging or displaying it. */
export async function safeMessage(message: string): Promise<string> {
  const { scrub } = await import("./ai-pool.server");
  return scrub(message);
}
