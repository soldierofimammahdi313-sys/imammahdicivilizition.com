/** Marker the /api/chat stream emits when the Lovable AI gateway is out of credits. */
export const AI_CREDITS_CODE = "AI_CREDITS_EXHAUSTED";
/** Marker for gateway rate limiting. */
export const AI_RATE_LIMIT_CODE = "AI_RATE_LIMITED";

export function classifyAiError(raw: unknown): "credits" | "rate-limit" | "other" {
  const msg = (raw instanceof Error ? raw.message : String(raw ?? "")).toLowerCase();
  if (!msg) return "other";
  if (msg.includes(AI_CREDITS_CODE.toLowerCase()) || msg.includes("402") || msg.includes("payment required") || msg.includes("insufficient credit")) {
    return "credits";
  }
  if (msg.includes(AI_RATE_LIMIT_CODE.toLowerCase()) || msg.includes("429") || msg.includes("rate limit")) {
    return "rate-limit";
  }
  return "other";
}

/** Where the user tops up AI credits (Lovable workspace settings → Plans & credits). */
export const CREDITS_SETTINGS_URL = "https://lovable.dev/settings/plans";
export const CREDITS_DOCS_URL = "https://docs.lovable.dev/introduction/plans-and-credits";