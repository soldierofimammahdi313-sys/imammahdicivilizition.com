/**
 * Location helpers that never trigger a browser permission popup on page load.
 *
 * Widgets that merely *decorate* the page (prayer tickers, prayer table) call
 * `getCoordsSilently`: it only reads the device position when the visitor has
 * ALREADY granted permission in a previous session. Otherwise it resolves with
 * a sensible fallback city, so the first visit stays popup-free.
 *
 * Pages where location is the whole point (Qibla, nearby mosques) call
 * `requestCoords` from an explicit user click.
 */

export type Coords = { lat: number; lng: number };

/** Default centre used when we may not ask for the device position. */
export const DEFAULT_COORDS: Coords = { lat: 24.8607, lng: 67.0011 }; // Karachi

async function permissionGranted(): Promise<boolean> {
  if (typeof navigator === "undefined" || !navigator.geolocation) return false;
  const perms = (navigator as Navigator & { permissions?: Permissions }).permissions;
  if (!perms?.query) return false;
  try {
    const status = await perms.query({ name: "geolocation" as PermissionName });
    return status.state === "granted";
  } catch {
    return false;
  }
}

/** Position without ever showing a permission prompt. */
export async function getCoordsSilently(fallback: Coords = DEFAULT_COORDS): Promise<Coords> {
  if (!(await permissionGranted())) return fallback;
  return new Promise<Coords>((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => resolve(fallback),
      { timeout: 4000, maximumAge: 10 * 60 * 1000 },
    );
  });
}

/** Explicit request — only call this from a user gesture (button click). */
export function requestCoords(): Promise<Coords> {
  return new Promise<Coords>((resolve, reject) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      reject(new Error("Location is not supported on this device."));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      (e) => reject(new Error(e.message || "Location permission was declined.")),
      { timeout: 10000 },
    );
  });
}
