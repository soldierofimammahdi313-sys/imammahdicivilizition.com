import type { SearchGuardResult, SearchGuardSource } from "./search-guard";

const MAX_STORED_INPUT = 500;

/**
 * Records a suspicious search input as a reviewable security event and writes a
 * structured server log line so it also shows up in runtime logs / alerting.
 */
export async function recordSuspiciousSearch(
  source: SearchGuardSource,
  raw: string,
  guard: SearchGuardResult,
  userId?: string | null,
): Promise<void> {
  const payload = {
    event_type: "suspicious_search_input",
    severity: guard.severity,
    source,
    raw_input: raw.slice(0, MAX_STORED_INPUT),
    sanitized_input: guard.term,
    reasons: guard.reasons,
    user_id: userId ?? null,
  };

  // Structured log first: this survives even if the database write fails.
  console.warn(
    `[security] suspicious_search_input ${JSON.stringify({
      source,
      severity: guard.severity,
      reasons: guard.reasons,
      length: raw.length,
    })}`,
  );

  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("security_events").insert(payload);
    if (error) console.error("[security] failed to store security event:", error.message);
  } catch (err) {
    console.error("[security] security event logging unavailable:", err);
  }
}
