/**
 * Centralized AI key pool — server only.
 *
 * - Auto-detects every OpenAI / Gemini key present in the environment
 *   (OPENAI_API_KEY, OPENAI_API_KEY_2..N, GEMINI_API_KEY, GOOGLE_GENERATIVE_AI_API_KEY, ...).
 * - Round-robin selection across healthy keys.
 * - Cooldown + failure tracking: a key hit by 429/402/403/5xx is parked
 *   for a while and the next healthy key is used automatically.
 * - Keys are NEVER returned to the client, logged, or embedded in error text.
 */

export type AiVendor = "openai" | "gemini";

export type AiKey = {
  vendor: AiVendor;
  /** Environment variable name — safe to log, unlike the value. */
  name: string;
  value: string;
};

const RATE_COOLDOWN_MS = 5 * 60 * 1000; // 429 / quota
const ERROR_COOLDOWN_MS = 60 * 1000; // transient 5xx
const HARD_COOLDOWN_MS = 30 * 60 * 1000; // 401 / invalid key

type KeyState = { cooldownUntil: number; failures: number };

const state = new Map<string, KeyState>();
const cursor = new Map<AiVendor, number>();

const OPENAI_PATTERNS = [/^OPENAI_API_KEY(_\d+)?$/, /^OPENAI_KEY(_\d+)?$/];
const GEMINI_PATTERNS = [
  /^GEMINI_API_KEY(_\d+)?$/,
  /^GOOGLE_GENERATIVE_AI_API_KEY(_\d+)?$/,
  /^GOOGLE_AI_API_KEY(_\d+)?$/,
];

/**
 * Value-shape detection: any secret holding a real OpenAI / Google AI key is
 * used, whatever the env var is called (users often save extra keys under
 * custom names). Names that clearly belong to other systems are excluded.
 */
const OPENAI_VALUE = /^sk-[A-Za-z0-9_\-]{20,}$/;
const GEMINI_VALUE = /^(AIza|AQ\.)[A-Za-z0-9_.\-]{20,}$/;
const NAME_DENYLIST =
  /(SUPABASE|LOVABLE|CRON|WEBHOOK|SESSION|JWT|DATABASE|POSTGRES|STRIPE|PADDLE|RESEND|SEARCH_CONSOLE|NPM|TRIGGER)/i;

function matchesVendor(vendor: AiVendor, name: string, value: string): boolean {
  const patterns = vendor === "openai" ? OPENAI_PATTERNS : GEMINI_PATTERNS;
  if (patterns.some((p) => p.test(name))) return true;
  if (NAME_DENYLIST.test(name)) return false;
  return (vendor === "openai" ? OPENAI_VALUE : GEMINI_VALUE).test(value);
}

function detect(vendor: AiVendor): AiKey[] {
  const found: AiKey[] = [];
  const seen = new Set<string>();
  for (const [name, raw] of Object.entries(process.env)) {
    const value = (raw ?? "").trim();
    if (!value) continue;
    if (!matchesVendor(vendor, name, value)) continue;
    if (seen.has(value)) continue; // same key exposed under two names
    seen.add(value);
    found.push({ vendor, name, value });
  }
  return found.sort((a, b) => a.name.localeCompare(b.name));
}


/** All configured keys for a vendor (healthy or not). */
export function allKeys(vendor: AiVendor): AiKey[] {
  return detect(vendor);
}

export function hasVendor(vendor: AiVendor): boolean {
  return detect(vendor).length > 0;
}

function healthy(keys: AiKey[]): AiKey[] {
  const now = Date.now();
  return keys.filter((k) => (state.get(k.name)?.cooldownUntil ?? 0) <= now);
}

/**
 * Healthy keys for a vendor, ordered round-robin so load spreads across keys.
 * Falls back to all keys when every key is cooling down (last-resort attempt).
 */
export function keysFor(vendor: AiVendor): AiKey[] {
  const all = detect(vendor);
  if (all.length === 0) return [];
  const pool = healthy(all).length > 0 ? healthy(all) : all;
  const start = (cursor.get(vendor) ?? 0) % pool.length;
  cursor.set(vendor, start + 1);
  return [...pool.slice(start), ...pool.slice(0, start)];
}

/**
 * Only keys that are NOT cooling down, round-robin ordered.
 * Latency-sensitive paths (live chat) use this so a known-dead key is never
 * re-tried in front of the user.
 */
export function healthyKeysFor(vendor: AiVendor): AiKey[] {
  const all = detect(vendor);
  const pool = healthy(all);
  if (pool.length === 0) return [];
  const start = (cursor.get(vendor) ?? 0) % pool.length;
  cursor.set(vendor, start + 1);
  return [...pool.slice(start), ...pool.slice(0, start)];
}

/** Best single key for a vendor, or null when none is configured. */
export function pickKey(vendor: AiVendor): AiKey | null {
  return keysFor(vendor)[0] ?? null;
}

export function markSuccess(key: AiKey) {
  state.set(key.name, { cooldownUntil: 0, failures: 0 });
}

/** Parks a key after a failure. `status` is the upstream HTTP status if known. */
export function markFailure(key: AiKey, status?: number) {
  const prev = state.get(key.name) ?? { cooldownUntil: 0, failures: 0 };
  const failures = prev.failures + 1;
  let cooldown = ERROR_COOLDOWN_MS;
  if (status === 429 || status === 402) cooldown = RATE_COOLDOWN_MS;
  else if (status === 401 || status === 403) cooldown = HARD_COOLDOWN_MS;
  // Repeated failures back off further, capped.
  cooldown = Math.min(cooldown * Math.min(failures, 4), HARD_COOLDOWN_MS);
  state.set(key.name, { cooldownUntil: Date.now() + cooldown, failures });
}

/** Removes any key material from a message before it can reach a log or the UI. */
export function scrub(message: string): string {
  let out = message;
  for (const vendor of ["openai", "gemini"] as AiVendor[]) {
    for (const k of detect(vendor)) {
      if (k.value.length >= 8) out = out.split(k.value).join("***");
    }
  }
  return out
    .replace(/sk-[A-Za-z0-9_-]{8,}/g, "***")
    .replace(/AIza[A-Za-z0-9_-]{8,}/g, "***")
    .replace(/key=[^&\s"']+/g, "key=***");
}

export function isRetryableStatus(status: number): boolean {
  return status === 429 || status === 402 || status === 408 || status >= 500;
}

/** Diagnostics for admins — counts only, never key values. */
export function poolStatus() {
  const now = Date.now();
  const describe = (vendor: AiVendor) =>
    detect(vendor).map((k) => ({
      name: k.name,
      healthy: (state.get(k.name)?.cooldownUntil ?? 0) <= now,
      failures: state.get(k.name)?.failures ?? 0,
    }));
  return { openai: describe("openai"), gemini: describe("gemini") };
}
