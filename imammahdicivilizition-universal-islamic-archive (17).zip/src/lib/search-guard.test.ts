import { describe, expect, it } from "vitest";
import { guardSearchTerm } from "./search-guard";

/**
 * Integration-style payload matrix: each known injection probe must be
 * neutralised in `term`, flagged as suspicious, and tagged with EXACTLY the
 * reasons we expect (pattern names only — character-stripping counts vary).
 */
const patternReasons = (r: string[]) =>
  r.filter((x) => !x.startsWith("stripped ") && !x.startsWith("over-length"));

const PAYLOADS: {
  name: string;
  input: string;
  reasons: string[];
  severity: "warn" | "critical";
}[] = [
  {
    name: "PostgREST operator injection",
    input: "karbala,title.ilike.%25admin%25",
    reasons: ["postgrest-operator"],
    severity: "warn",
  },
  {
    name: "PostgREST logic injection",
    input: "x,or(status.eq.draft)",
    reasons: ["postgrest-operator", "postgrest-logic"],
    severity: "critical",
  },
  {
    name: "classic UNION SELECT",
    input: "' union select password from auth.users --",
    reasons: ["sql-keyword", "sql-comment", "schema-probe"],
    severity: "critical",
  },
  {
    name: "statement terminator + DROP",
    input: "hadith'; drop table articles;",
    reasons: ["sql-keyword", "sql-comment"],
    severity: "critical",
  },
  {
    name: "boolean tautology",
    input: "quran' or 1=1 --",
    reasons: ["sql-comment", "boolean-tautology"],
    severity: "critical",
  },
  {
    name: "schema probe",
    input: "information_schema tables",
    reasons: ["schema-probe"],
    severity: "warn",
  },
  {
    name: "block comment probe",
    input: "imam /* comment */ mahdi",
    reasons: ["sql-comment"],
    severity: "warn",
  },
];

describe("guardSearchTerm — injection payloads", () => {
  for (const p of PAYLOADS) {
    it(`flags ${p.name} with the expected reasons`, () => {
      const g = guardSearchTerm(p.input);
      expect(g.suspicious).toBe(true);
      expect(patternReasons(g.reasons).sort()).toEqual([...p.reasons].sort());
      expect(g.severity).toBe(p.severity);
      // Sanitized term can never carry PostgREST/SQL structural characters.
      expect(g.term).not.toMatch(/[,%()*\\."']/);
    });
  }

  it("strips filter characters while keeping readable words", () => {
    expect(guardSearchTerm("karbala,%(imam)").term).toBe("karbala imam");
  });

  it("truncates and flags over-length input", () => {
    const g = guardSearchTerm("a".repeat(200));
    expect(g.term).toHaveLength(80);
    expect(g.suspicious).toBe(true);
    expect(g.reasons.some((r) => r.startsWith("over-length"))).toBe(true);
  });

  it("honours a custom max length (MCP tool uses 100)", () => {
    expect(guardSearchTerm("b".repeat(150), 100).term).toHaveLength(100);
  });
});

describe("guardSearchTerm — legitimate queries stay quiet", () => {
  const CLEAN = [
    "karbala",
    "imam mahdi",
    "zakat calculation",
    "sahifa sajjadiyya",
    "what is patience",
    "Ali ibn Abi Talib",
    "prayer times",
    "",
  ];
  for (const q of CLEAN) {
    it(`does not flag "${q}"`, () => {
      const g = guardSearchTerm(q);
      expect(g.suspicious).toBe(false);
      expect(g.severity).toBe("info");
    });
  }

  it("tolerates a single apostrophe typo without alerting", () => {
    const g = guardSearchTerm("qur'an");
    expect(g.suspicious).toBe(false);
    expect(g.term).toBe("qur an");
  });

  it("handles non-string input defensively", () => {
    const g = guardSearchTerm(undefined as unknown as string);
    expect(g.term).toBe("");
    expect(g.suspicious).toBe(false);
  });
});