import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import {
  getCached,
  getInFlight,
  setCached,
  trackInFlight,
} from "@/lib/daily-hadiths-cache.server";
import type { DailyHadith, DailyHadithPayload } from "@/lib/daily-hadiths.types";
import { getIslamicEvent } from "@/lib/islamic-events";

export type { DailyHadith, DailyHadithPayload };

function getHijri(date: Date) {
  try {
    const fmt = new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", {
      day: "numeric", month: "long", year: "numeric",
    });
    return fmt.format(date);
  } catch {
    return "";
  }
}

function hijriMonthNumber(date: Date): number {
  try {
    const fmt = new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", { month: "numeric" });
    return Number(fmt.formatToParts(date).find(p => p.type === "month")?.value || 0);
  } catch { return 0; }
}

function hijriDayNumber(date: Date): number {
  try {
    const fmt = new Intl.DateTimeFormat("en-TN-u-ca-islamic-umalqura", { day: "numeric" });
    return Number(fmt.formatToParts(date).find(p => p.type === "day")?.value || 0);
  } catch { return 0; }
}

function themeFor(date: Date): string {
  const m = hijriMonthNumber(date);
  const map: Record<number, string> = {
    1: "Muharram — martyrdom of Imam Husayn (a.s), Karbala, sacrifice, patience, standing against injustice, ashura, ziyarat 'Ashura",
    2: "Safar — Arba'een of Imam Husayn (a.s), the return of the caravan of Karbala, martyrdom of Prophet Muhammad (s) and Imam Hasan (a.s) (28 Safar)",
    3: "Rabi al-Awwal — birth of Prophet Muhammad (s) (17 Rabi al-Awwal per Shia narrations), Hijrah, Eid al-Zahra",
    4: "Rabi al-Thani — birth of Imam Hasan al-Askari (a.s), knowledge and forbearance",
    5: "Jumada al-Ula — martyrdom of Sayyida Fatima al-Zahra (s.a) (per one narration), her sermon and virtues",
    6: "Jumada al-Thaniya — birth of Sayyida Fatima al-Zahra (s.a) (20 Jumada al-Thaniya)",
    7: "Rajab — birth of Imam Ali (a.s) (13 Rajab), Mab'ath of the Prophet (s) (27 Rajab), a'mal of Rajab, du'a, fasting",
    8: "Sha'ban — birth of Imam Mahdi (a.j) (15 Sha'ban / Nisf Sha'ban), Munajat Sha'baniya, preparation for Ramadan",
    9: "Ramadan — Quran, laylat al-qadr, martyrdom of Imam Ali (a.s) (21 Ramadan), fasting, du'a Iftitah, du'a Abu Hamza",
    10: "Shawwal — Eid al-Fitr, zakat al-fitrah, gratitude, du'a after Ramadan",
    11: "Dhu al-Qa'dah — the sacred month, birth of Imam Rida (a.s) (11 Dhu al-Qa'dah), pilgrimage preparations",
    12: "Dhu al-Hijjah — Hajj, Arafah, Eid al-Adha, Eid al-Ghadir (18 Dhu al-Hijjah), Mubahala (24 Dhu al-Hijjah)",
  };
  return map[m] || "general Ahl al-Bayt teachings, taqwa, patience, and awaiting Imam al-Mahdi (a.j)";
}

/** Reads today's ticker items produced by the daily autopilot (public, read-only). */
async function readStoredTicker(dateKey: string): Promise<{ items: DailyHadith[] } | null> {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return null;
  try {
    const client = createClient<Database>(url, key, {
      auth: { persistSession: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data } = await client
      .from("daily_ticker")
      .select("items")
      .lte("run_date", dateKey)
      .order("run_date", { ascending: false })
      .limit(1)
      .maybeSingle();
    const items = (data?.items as unknown as DailyHadith[] | null) ?? [];
    return { items: items.filter((i) => i?.text && i?.by && i?.source) };
  } catch {
    return null;
  }
}

export const getDailyHadiths = createServerFn({ method: "GET" }).handler(
  async (): Promise<DailyHadithPayload> => {
    const now = new Date();
    const dateKey = now.toISOString().slice(0, 10);
    const hijri = getHijri(now);
    const occasion = getIslamicEvent(hijriDayNumber(now), hijriMonthNumber(now));
    const theme = occasion
      ? `${occasion.en} — ${occasion.theme}. (Month context: ${themeFor(now)})`
      : themeFor(now);
    const event = occasion?.en ?? null;

    // Serve the cached payload for the current day so the paid AI gateway is
    // called at most once per day, no matter how often this endpoint is hit.
    const cached = getCached(dateKey);
    if (cached) return cached;
    const inFlight = getInFlight(dateKey);
    if (inFlight) return inFlight;

    // Prefer the verified set published by the daily autopilot.
    const stored = await readStoredTicker(dateKey);
    if (stored?.items.length) {
      const payload = { date: dateKey, hijri, theme, event, items: stored.items };
      setCached(dateKey, payload);
      return payload;
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return { date: dateKey, hijri, theme, event, items: [] };
    }

    const gateway = createLovableAiGatewayProvider(key);
    const prompt = `Today is ${dateKey} (Hijri: ${hijri}). Islamic occasion / theme for today: ${theme}.${occasion ? `

TODAY IS A SPECIAL ISLAMIC OCCASION: ${occasion.en}. At least 12 of the 18 items MUST relate directly to this occasion (its personality, its lesson, its du'a, or its historical event).` : ""}

Give me EXACTLY 18 authentic hadiths / sayings from the Fourteen Infallibles (Ma'sumin) that fit today's Islamic occasion and month theme above. Rotate the coverage across all fourteen — Rasul Allah Muhammad (ﷺ), Sayyida Fatima al-Zahra (s.a), Imam Ali (a.s), Imam Hasan al-Mujtaba (a.s), Imam Husayn (a.s), Imam Zayn al-Abidin (a.s), Imam Muhammad al-Baqir (a.s), Imam Ja'far al-Sadiq (a.s), Imam Musa al-Kadhim (a.s), Imam Ali al-Rida (a.s), Imam Muhammad al-Jawad (a.s), Imam Ali al-Hadi (a.s), Imam Hasan al-Askari (a.s), Imam al-Mahdi (a.j) — so that as many of the fourteen as possible appear. If the month is Muharram, weight it towards Imam Husayn (a.s), Karbala, sacrifice and Ashura, while still including other Infallibles.

Return ONLY valid JSON — no prose, no markdown fences — matching this exact shape:
{"items":[{"text":"<Arabic text> — <English translation>","by":"<narrator, e.g. Imam Husayn (a.s)>","source":"<book + reference, e.g. Bihar al-Anwar 44/192>"}]}

Rules:
- text MUST contain the COMPLETE Arabic narration (never a fragment, never truncated, no ellipses) followed by " — " and the COMPLETE English translation of that same full narration.
- by MUST be the Infallible's full recognised name with the honorific, e.g. "Imam Ja'far al-Sadiq (a.s)", "Sayyida Fatima al-Zahra (s.a)", "Imam al-Mahdi (a.j)", "Rasul Allah Muhammad (ﷺ)".
- source MUST be a real Shia or Sunni hadith reference with volume/hadith number.
- Exactly 18 items. No duplicates. No commentary outside JSON.`;

    const run = async (): Promise<DailyHadithPayload> => {
     try {
      const { text } = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        prompt,
      });
      const cleaned = text.replace(/```json|```/g, "").trim();
      const start = cleaned.indexOf("{");
      const end = cleaned.lastIndexOf("}");
      const json = start >= 0 && end > start ? cleaned.slice(start, end + 1) : cleaned;
      const parsed = JSON.parse(json) as { items?: DailyHadith[] };
      const items = Array.isArray(parsed.items)
        ? parsed.items.filter(i => i?.text && i?.by && i?.source).slice(0, 24)
        : [];
      const payload = { date: dateKey, hijri, theme, event, items };
      if (items.length) setCached(dateKey, payload);
      return payload;
     } catch {
      return { date: dateKey, hijri, theme, event, items: [] };
     }
    };

    return trackInFlight(dateKey, run());
  },
);