/**
 * Google AdSense configuration — the ONLY place AdSense values live.
 *
 * HOW TO FINISH SETUP (after Google approves the site):
 *
 * 1. PUBLISHER ID
 *    Replace ADSENSE_PUBLISHER_ID below with the exact "ca-pub-XXXXXXXXXXXXXXXX"
 *    value shown in your AdSense account (Account -> Settings -> Account information).
 *    Leave it as an empty string if you do not have one yet — nothing is loaded then.
 *
 * 2. SITE VERIFICATION
 *    If AdSense asks for a meta tag, paste ONLY the content value into
 *    ADSENSE_VERIFICATION below. It is rendered in <head> automatically
 *    from src/routes/__root.tsx. If AdSense asks for the "AdSense code snippet"
 *    instead, setting ADSENSE_PUBLISHER_ID is already enough.
 *
 * 3. ads.txt
 *    public/ads.txt must contain the exact line AdSense shows you under
 *    Sites -> ads.txt. Do not hand-edit the values.
 *
 * 4. SHOWING ADS
 *    Set ADS_ENABLED to true only when you actually want ad units to render.
 *    No ad units exist in the codebase yet — this flag simply gates the loader.
 *
 * Never put private API keys or secrets in this file: it ships to the browser.
 * The publisher ID and verification token are public values by design.
 */

export const ADSENSE_PUBLISHER_ID = "ca-pub-9467507763265762";

/** Content value of the google-adsense-account / site verification meta tag. */
export const ADSENSE_VERIFICATION = "";

/** Master switch for loading the AdSense script. */
export const ADS_ENABLED = false;

export const adsenseScriptSrc = () =>
  `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_PUBLISHER_ID}`;

export const adsenseReady = () => ADS_ENABLED && ADSENSE_PUBLISHER_ID.startsWith("ca-pub-");