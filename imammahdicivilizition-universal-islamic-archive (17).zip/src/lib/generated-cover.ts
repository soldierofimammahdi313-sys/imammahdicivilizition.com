/**
 * Deterministic, unique cover artwork for every article.
 *
 * Builds an inline SVG (no network, no AI credits) from a hash of the article
 * slug/title, so no two articles ever share the same picture. Emerald + gold
 * Islamic geometry on obsidian, matching the platform identity.
 */

function hash(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

/** Small deterministic PRNG so one seed drives every visual choice. */
function rng(seed: number) {
  let s = seed || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

const PALETTES: Array<[string, string, string]> = [
  ["#04110d", "#0c3b2e", "#d8b46a"],
  ["#050a14", "#123a5c", "#e0c07a"],
  ["#100a04", "#3d2a12", "#f0cf8a"],
  ["#0a0410", "#2e1a45", "#cbb07e"],
  ["#04100f", "#0f4a45", "#e6cf9a"],
  ["#0e0406", "#4a1520", "#dcb36c"],
  ["#060d04", "#25401a", "#d9c784"],
  ["#040d12", "#0b3244", "#cdb583"],
];

function star(cx: number, cy: number, r: number, points: number, rot: number) {
  const pts: string[] = [];
  const inner = r * 0.46;
  for (let i = 0; i < points * 2; i++) {
    const rad = (Math.PI * i) / points + rot;
    const rr = i % 2 === 0 ? r : inner;
    pts.push(`${(cx + Math.cos(rad) * rr).toFixed(1)},${(cy + Math.sin(rad) * rr).toFixed(1)}`);
  }
  return pts.join(" ");
}

/** Returns a data-URI SVG cover that is unique to `key`. */
export function generatedCover(key: string): string {
  const seed = hash(key);
  const rand = rng(seed);
  const [bg, mid, gold] = PALETTES[seed % PALETTES.length];
  const angle = Math.floor(rand() * 360);
  const W = 1200;
  const H = 675;

  let shapes = "";

  // Orbiting rings
  const rings = 2 + Math.floor(rand() * 3);
  for (let i = 0; i < rings; i++) {
    const cx = 200 + rand() * 800;
    const cy = 120 + rand() * 440;
    const r = 90 + rand() * 230;
    shapes += `<circle cx="${cx.toFixed(0)}" cy="${cy.toFixed(0)}" r="${r.toFixed(0)}" fill="none" stroke="${gold}" stroke-opacity="${(0.08 + rand() * 0.16).toFixed(2)}" stroke-width="${(1 + rand() * 2).toFixed(1)}"/>`;
  }

  // Eight/twelve-pointed stars
  const stars = 3 + Math.floor(rand() * 4);
  for (let i = 0; i < stars; i++) {
    const cx = 80 + rand() * 1040;
    const cy = 80 + rand() * 520;
    const r = 40 + rand() * 150;
    const pts = [6, 8, 12][Math.floor(rand() * 3)];
    shapes += `<polygon points="${star(cx, cy, r, pts, rand() * Math.PI)}" fill="none" stroke="${gold}" stroke-opacity="${(0.14 + rand() * 0.3).toFixed(2)}" stroke-width="${(1 + rand() * 1.6).toFixed(1)}"/>`;
  }

  // Arch silhouettes
  const arches = 2 + Math.floor(rand() * 4);
  for (let i = 0; i < arches; i++) {
    const w = 70 + rand() * 120;
    const x = rand() * (W - w);
    const h = 150 + rand() * 260;
    const y = H - h;
    shapes += `<path d="M${x.toFixed(0)} ${H} L${x.toFixed(0)} ${(y + w / 2).toFixed(0)} A${(w / 2).toFixed(0)} ${(w / 2).toFixed(0)} 0 0 1 ${(x + w).toFixed(0)} ${(y + w / 2).toFixed(0)} L${(x + w).toFixed(0)} ${H} Z" fill="${gold}" fill-opacity="${(0.05 + rand() * 0.09).toFixed(2)}"/>`;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
<defs>
<linearGradient id="g" gradientTransform="rotate(${angle})"><stop offset="0" stop-color="${bg}"/><stop offset="1" stop-color="${mid}"/></linearGradient>
<radialGradient id="h" cx="${(0.2 + rand() * 0.6).toFixed(2)}" cy="${(0.2 + rand() * 0.5).toFixed(2)}" r="0.8"><stop offset="0" stop-color="${gold}" stop-opacity="0.22"/><stop offset="1" stop-color="${gold}" stop-opacity="0"/></radialGradient>
</defs>
<rect width="${W}" height="${H}" fill="url(#g)"/>
${shapes}
<rect width="${W}" height="${H}" fill="url(#h)"/>
<rect x="14" y="14" width="${W - 28}" height="${H - 28}" fill="none" stroke="${gold}" stroke-opacity="0.28" stroke-width="2"/>
</svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
