import { COVERS } from "@/lib/article-covers";

/** One distinct cover image per library book (no duplicates). */
export const LIBRARY_COVERS: Record<string, string> = {
  "the-holy-quran": COVERS.quran,
  "nahj-al-balagha": COVERS.minbar,
  "sahifa-al-sajjadiyya": COVERS.night,
  "al-kafi": COVERS.manuscript,
  "man-la-yahduruhu-al-faqih": COVERS.knowledge,
  "tahdhib-al-ahkam": COVERS.corridor,
  "bihar-al-anwar": COVERS.science,
  "sahih-al-bukhari": COVERS.desert,
  "sahih-muslim": COVERS.pattern,
  "tafsir-al-mizan": COVERS.dawn,
  "kitab-al-irshad": COVERS.history,
  "mafatih-al-jinan": COVERS.dhikr,
  "usul-al-fiqh-foundations": COVERS.ethics,
  "ninety-nine-names": COVERS.mosque,
  "karbala-narrative": COVERS.karbala,
  "imam-mahdi-sources": COVERS.mahdi,
};

export function libraryCover(slug: string): string {
  return LIBRARY_COVERS[slug] ?? COVERS.manuscript;
}
