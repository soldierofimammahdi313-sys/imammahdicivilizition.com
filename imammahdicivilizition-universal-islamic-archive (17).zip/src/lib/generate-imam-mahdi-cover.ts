/**
 * Generate AI cover image for the Imam Mahdi article
 * Run this function on your server with LOVABLE_API_KEY set
 */

import type { Database } from "@/integrations/supabase/types";

export interface GeneratedCoverResult {
  success: boolean;
  imageUrl?: string;
  base64?: string;
  error?: string;
  timestamp: string;
}

/**
 * Generate and save cover image for Imam Mahdi article
 * This function uses Gemini AI to create Islamic symbolic art
 */
export async function generateImamMahdiCover(): Promise<GeneratedCoverResult> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) {
    return {
      success: false,
      error: "LOVABLE_API_KEY not found in environment",
      timestamp: new Date().toISOString(),
    };
  }

  const prompt = `Create a stunning Islamic cover artwork for an article titled "امام مہدی ؑ - منتظر نجات دہندہ" (Imam Mahdi - The Awaited Savior).

Style Requirements:
- Respectful symbolic Islamic art
- Absolutely NO human faces or figures
- Features: Islamic calligraphy patterns, geometric tessellations, ancient Quranic manuscript pages
- Architectural elements: mosque dome silhouette, Islamic arches, minarets in soft focus
- Spiritual elements: ethereal light rays, divine glow, celestial atmosphere
- Symbolic items: lanterns glowing with inner light, prayer beads (tasbih), Quranic verses in flowing script
- Color palette: Deep emerald green (#1a4d3e), rich gold (#d4af37), obsidian black background, cream accents
- Composition: 16:9 widescreen, cinematic, premium quality, elegant and sophisticated
- Mood: Hopeful, reverent, mystical, representing awaited salvation and divine justice
- No text overlay, suitable for article header image
- High resolution, professional quality`;

  try {
    const response = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-pro-image",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        modalities: ["image", "text"],
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      return {
        success: false,
        error: `API Error: ${response.status} - ${errorText}`,
        timestamp: new Date().toISOString(),
      };
    }

    const data = await response.json();

    // Extract base64 image from response
    let base64Image: string | null = null;
    if (data.data && Array.isArray(data.data) && data.data[0]) {
      if (data.data[0].b64_json) {
        base64Image = data.data[0].b64_json;
      } else if (data.data[0].url && data.data[0].url.startsWith("data:")) {
        base64Image = data.data[0].url.split(",")[1];
      }
    }

    if (!base64Image) {
      return {
        success: false,
        error: "No image data in API response",
        timestamp: new Date().toISOString(),
      };
    }

    return {
      success: true,
      base64: base64Image,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      error: `Generation failed: ${error instanceof Error ? error.message : String(error)}`,
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Generate and upload cover image to Supabase storage
 */
export async function generateAndUploadImamMahdiCover(supabaseAdmin: any): Promise<GeneratedCoverResult> {
  try {
    const result = await generateImamMahdiCover();

    if (!result.success || !result.base64) {
      return result;
    }

    // Convert base64 to bytes
    const bytes = Uint8Array.from(atob(result.base64), (c) => c.charCodeAt(0));
    const fileName = `imam-mahdi-awaited-savior-${Date.now()}.png`;

    // Upload to Supabase storage
    const { error: uploadError } = await supabaseAdmin.storage
      .from("article-covers")
      .upload(fileName, bytes, {
        contentType: "image/png",
        upsert: true,
      });

    if (uploadError) {
      return {
        success: false,
        error: `Upload failed: ${uploadError.message}`,
        timestamp: new Date().toISOString(),
      };
    }

    // Return public URL
    const imageUrl = `/api/public/cover/${fileName}`;

    return {
      success: true,
      imageUrl,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      error: `Process failed: ${error instanceof Error ? error.message : String(error)}`,
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Usage example:
 * 
 * import { generateAndUploadImamMahdiCover } from "@/lib/generate-imam-mahdi-cover";
 * import { supabaseAdmin } from "@/integrations/supabase/client.server";
 * 
 * const result = await generateAndUploadImamMahdiCover(supabaseAdmin);
 * if (result.success) {
 *   console.log("Cover image URL:", result.imageUrl);
 *   // Update article in database with: cover_url = result.imageUrl
 * } else {
 *   console.error("Generation failed:", result.error);
 * }
 */
