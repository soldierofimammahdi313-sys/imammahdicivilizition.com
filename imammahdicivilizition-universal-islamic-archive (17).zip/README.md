# Imam Mahdi's Digital Civilization

⚔️ SOLDIERS OF IMAM MAHDI 313

THE WORLD'S FIRST ISLAMIC DIGITAL CIVILIZATION

SUPREME DEVELOPMENT DIRECTIVE

Create a platform so advanced, immersive, intelligent, and inspiring that visitors immediately realize they have entered something extraordinary.

This is not a website.

This is not a blog.

This is not a library.

This is not a social network.

This is a living Islamic digital civilization.

The platform must unite knowledge, education, media, research, technology, spirituality, community, and global participation into a single ecosystem.

Every interaction should feel premium, meaningful, and world-class.

━━━━━━━━━━━━━━━━━━━━━━

COMPLETE SITE MAP

Home

About

Knowledge Center

Articles

Research Papers

Video Center

Podcasts

Digital Library

AI Assistant

Ask A Question

Courses & Academy

Scholar Directory

Islamic Encyclopedia

Events Center

Daily Quran

Daily Hadith

Daily Dua

Prayer Times

Qibla Finder

Islamic Calendar

Community

Forum

Join Our Team

Volunteer Program

Careers

Donations

Contact

User Dashboard

Admin Dashboard

━━━━━━━━━━━━━━━━━━━━━━

USER ACCOUNT SYSTEM

Users can:

✓ Sign Up

✓ Sign In

✓ Google Login

✓ Save Articles

✓ Save Videos

✓ Save Books

✓ Follow Topics

✓ Follow Scholars

✓ Create Reading Lists

✓ Track Learning Progress

✓ Receive Certificates

✓ Join Community Groups

✓ Participate In Events

━━━━━━━━━━━━━━━━━━━━━━

GLOBAL ARTICLE PLATFORM

Professional publishing system.

Features:

✓ Unlimited Articles

✓ Categories

✓ Tags

✓ Featured Images

✓ Author Profiles

✓ References

✓ Related Articles

✓ Reading Time

✓ Audio Version

✓ Comments

✓ Social Sharing

✓ Bookmarks

✓ Multi-Language Support

✓ SEO Optimization

━━━━━━━━━━━━━━━━━━━━━━

PREMIUM VIDEO PLATFORM

Netflix-style Islamic media center.

Features:

✓ Featured Videos

✓ Trending Videos

✓ Categories

✓ Playlists

✓ Shorts

✓ Live Streams

✓ Watch Later

✓ Favorites

✓ Comments

✓ Subtitles

✓ Multi-language Captions

✓ AI Summaries

✓ AI Translation

━━━━━━━━━━━━━━━━━━━━━━

JOIN OUR TEAM

Dedicated recruitment portal.

Roles:

• Writer

• Researcher

• Video Editor

• Graphic Designer

• Translator

• Developer

• Moderator

• Social Media Manager

• Volunteer

Application Form:

Name

Country

Languages

Skills

Experience

Portfolio

Resume Upload

Motivation Letter

━━━━━━━━━━━━━━━━━━━━━━

DIGITAL LIBRARY

Thousands of books.

PDF Reader.

Audio Books.

Smart Search.

Bookmarks.

Highlights.

Collections.

Scholar Recommendations.

━━━━━━━━━━━━━━━━━━━━━━

AI KNOWLEDGE ENGINE

Powered by:

OpenAI

Google Gemini

Features:

Voice Chat

Voice Search

Research Mode

Article Generation

Content Summaries

Translation

Recommendations

Learning Assistance

━━━━━━━━━━━━━━━━━━━━━━

GLOBAL COMMUNITY

User Profiles

Discussion Boards

Study Groups

Event Participation

Community Challenges

Knowledge Sharing

━━━━━━━━━━━━━━━━━━━━━━

OFFICIAL SOCIAL MEDIA

YouTube: https://youtube.com/@soldierofimammahdi313⁠�

TikTok: https://www.tiktok.com/@soldierofimammahdi313⁠�

X: https://x.com/ImamofImamMahdi⁠�

Instagram: https://www.instagram.com/soldierofimammahdi313⁠�

Facebook: https://www.facebook.com/share/1PWhUxSdSm/⁠�

Display social icons in:

Header

Footer

Sidebar

Profile Pages

Article Pages

Video Pages

━━━━━━━━━━━━━━━━━━━━━━

CONTACT

Phone: 0326-4861847

WhatsApp: 0326-4861847

SEO / Admin: Syed Ahmad Raza Shamsi

━━━━━━━━━━━━━━━━━━━━━━

FINAL GOAL

Build a world-class Islamic digital platform that combines knowledge, media, education, technology, and community into one unified experience that can grow and serve people globally for years to come. :::

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://mahdi-civilization.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/060bee1d-b88b-4791-8b0c-2e71ff0b5e89).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

---

## Universal Islamic Knowledge & Digital Archive — 2026 update

This build extends the platform to serve Muslims across every school of Islamic
jurisprudence, while preserving all existing content, including the site's
Ja'fari/Shia material, in full.

### What was added

- **Fiqh system** (`src/lib/fiqh.tsx`) — six traditions (General, Hanafi,
  Shafi'i, Maliki, Hanbali, Ja'fari), stored in `localStorage` under
  `imc_fiqh`. Selecting a tradition never hides anything: general material
  stays visible under every selection.
- **First-visit preferences modal** (`src/components/site/PreferencesModal.tsx`)
  — asks for language and fiqh tradition once, reopenable at any time from
  "Language & Fiqh" in the header or footer. Stored under `imc_language` and
  `imc_fiqh`; corrupted values are ignored rather than crashing the page.
- **Language detection** — saved choice → browser language → IP-based country
  (via a public, keyless lookup, 2-second timeout, never blocks first paint)
  → English. Extended in `src/lib/i18n.tsx`; the existing 12-language
  dictionary and Google Translate fallback are unchanged.
- **Fiqh pages** — `/fiqh` (hub) and `/fiqh/$school` (one page per tradition),
  each a short factual introduction plus the related archive entries.
- **Universal Islamic Library** — `/library` is now filterable by fiqh
  tradition, content type, topic, author and language, with a search box and
  an honest "General / Unclassified" label for anything whose school is not
  recorded. No books, authors or citations were invented; classification was
  only added where the existing catalogue text already stated it.
- **Navigation** — the header gained a Knowledge menu and a Fiqh menu; the
  footer gained a Fiqh column. All existing links were kept.
- **SEO** — new entries in `src/lib/seo.ts` for the fiqh pages, `/founder`,
  `/shop` and `/who-is-imam-mahdi`; `sitemap.xml` and `robots.txt` updated to
  match (verified against each other — no sitemap URL is blocked by robots).
- **Ad network removed** — the Ezoic scripts and ad slots that were wired
  into `src/routes/__root.tsx` have been removed to keep the site ad-free, as
  directed. Google AdSense was already disabled (`ADS_ENABLED = false` in
  `src/lib/adsense.ts`) and is untouched.
- **Database** — one additive migration
  (`supabase/migrations/20260921120000_add_fiqh_tradition_to_library_items.sql`)
  adds a nullable `fiqh_tradition` column with a check constraint to
  `library_items`. No existing rows were rewritten except the single entry
  that already names its own school in its title.
- **RTL & accessibility** — logical CSS properties, horizontal-overflow
  containment, LTR isolation for numerals/code inside RTL text, visible
  focus rings, and a translated, direction-aware 404 page.

### What was deliberately left untouched

Routing, authentication, Supabase integration, OneSignal, the AI assistant,
existing Ja'fari/Shia content and pages, and the visual design system.

### Before you deploy

This container has no network access, so `npm install`, `tsc`, `eslint` and
`vite build` were never run here. Everything above was verified statically
(import resolution, route-tree consistency, JSX tag balance, sitemap/robots
cross-check). Run the following before deploying:

```bash
npm install
npm run lint
npm run build
```

`.env` is **not** included in this archive (it now also has a
`.gitignore` entry). Copy your existing environment values into a new
`.env` from `.env.example` before running the project locally.
